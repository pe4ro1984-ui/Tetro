package ru.metalpipe.dbdamp.survivor;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import ru.metalpipe.dbdamp.gameplay.model.Match;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * System for presenting timing-based skill check mini-games.
 * Used for generator repairs, healing, sabotage, and other actions.
 */
public class SkillCheckSystem {
    
    private final Logger logger;
    private final Random random;
    
    // Active skill checks by player UUID
    private final Map<UUID, ActiveSkillCheck> activeChecks;
    
    // Skill check configuration
    private static final double BASE_SUCCESS_ZONE = 0.15; // 15% of the bar
    private static final double GREAT_SKILL_ZONE = 0.03;  // 3% for great skill check
    private static final double FAILURE_PENALTY = 0.10;   // 10% progress loss on failure
    
    // Skill check types
    public enum SkillCheckType {
        GENERATOR_REPAIR(1.0, 0.05, "Generator Repair"),
        HEALING(0.8, 0.03, "Healing"),
        SABOTAGE(1.2, 0.08, "Sabotage"),
        SELF_CARE(0.6, 0.02, "Self-Care"),
        DECISIVE_STRIKE(2.0, 0.10, "Decisive Strike");
        
        private final double difficultyMultiplier;
        private final double bonusProgress;
        private final String displayName;
        
        SkillCheckType(double difficultyMultiplier, double bonusProgress, String displayName) {
            this.difficultyMultiplier = difficultyMultiplier;
            this.bonusProgress = bonusProgress;
            this.displayName = displayName;
        }
        
        public double getDifficultyMultiplier() { return difficultyMultiplier; }
        public double getBonusProgress() { return bonusProgress; }
        public String getDisplayName() { return displayName; }
    }
    
    // Skill check result
    public enum SkillCheckResult {
        GREAT_SUCCESS("Great!", 0.05, true),
        GOOD_SUCCESS("Good!", 0.02, true),
        SUCCESS("Success", 0.0, true),
        FAILURE("Failed!", -FAILURE_PENALTY, false);
        
        private final String message;
        private final double progressModifier;
        private final boolean success;
        
        SkillCheckResult(String message, double progressModifier, boolean success) {
            this.message = message;
            this.progressModifier = progressModifier;
            this.success = success;
        }
        
        public String getMessage() { return message; }
        public double getProgressModifier() { return progressModifier; }
        public boolean isSuccess() { return success; }
    }
    
    public SkillCheckSystem() {
        this.logger = Logger.getLogger(getClass().getName());
        this.random = new Random();
        this.activeChecks = new ConcurrentHashMap<>();
    }
    
    /**
     * Start a new skill check for a player.
     * 
     * @param playerId The player's UUID
     * @param type The type of skill check
     * @param actionId The ID of the associated action (generator, healing target, etc.)
     * @return The created skill check, or null if player already has an active check
     */
    public ActiveSkillCheck startSkillCheck(UUID playerId, SkillCheckType type, UUID actionId) {
        if (activeChecks.containsKey(playerId)) {
            return null; // Player already has an active skill check
        }
        
        ActiveSkillCheck check = new ActiveSkillCheck(
            playerId,
            type,
            actionId,
            calculateSuccessZone(type),
            calculateGreatZone(type),
            calculateDuration(type),
            generateTargetPosition()
        );
        
        activeChecks.put(playerId, check);
        
        // Notify player
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.0f);
            player.sendTitle("§eSkill Check!", "§7Press SPACE at the right moment", 5, 40, 10);
        }
        
        logger.fine("Started " + type.getDisplayName() + " skill check for player " + playerId);
        return check;
    }
    
    /**
     * Process a skill check response from a player.
     * 
     * @param playerId The player's UUID
     * @param currentPosition The current position of the skill check indicator
     * @return The result of the skill check
     */
    public SkillCheckResult processSkillCheck(UUID playerId, double currentPosition) {
        ActiveSkillCheck check = activeChecks.remove(playerId);
        if (check == null) {
            return SkillCheckResult.FAILURE;
        }
        
        // Calculate distance from target
        double distance = Math.abs(currentPosition - check.targetPosition);
        
        // Determine result based on accuracy
        SkillCheckResult result;
        if (distance <= check.greatZone) {
            result = SkillCheckResult.GREAT_SUCCESS;
        } else if (distance <= check.successZone) {
            result = SkillCheckResult.GOOD_SUCCESS;
        } else if (distance <= check.successZone * 1.5) {
            result = SkillCheckResult.SUCCESS;
        } else {
            result = SkillCheckResult.FAILURE;
        }
        
        // Apply progress modifier
        check.progressGain = result.getProgressModifier() + check.type.getBonusProgress();
        
        // Notify player
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            String color = result.isSuccess() ? 
                (result == SkillCheckResult.GREAT_SUCCESS ? "§a" : "§e") : "§c";
            player.sendTitle(color + result.getMessage(), "", 5, 20, 5);
            
            if (result.isSuccess()) {
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 
                    result == SkillCheckResult.GREAT_SUCCESS ? 2.0f : 1.5f);
            } else {
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.5f);
            }
        }
        
        logger.fine("Skill check result for " + playerId + ": " + result.getMessage());
        return result;
    }
    
    /**
     * Cancel an active skill check.
     * 
     * @param playerId The player's UUID
     */
    public void cancelSkillCheck(UUID playerId) {
        ActiveSkillCheck check = activeChecks.remove(playerId);
        if (check != null) {
            logger.fine("Cancelled skill check for player " + playerId);
        }
    }
    
    /**
     * Check if a player has an active skill check.
     * 
     * @param playerId The player's UUID
     * @return true if player has an active skill check
     */
    public boolean hasActiveSkillCheck(UUID playerId) {
        return activeChecks.containsKey(playerId);
    }
    
    /**
     * Get the active skill check for a player.
     * 
     * @param playerId The player's UUID
     * @return The active skill check, or null if none
     */
    public ActiveSkillCheck getActiveSkillCheck(UUID playerId) {
        return activeChecks.get(playerId);
    }
    
    /**
     * Update all active skill checks.
     * Called every tick to advance the indicator position.
     * 
     * @param match The current match
     */
    public void update(Match match) {
        Iterator<Map.Entry<UUID, ActiveSkillCheck>> iter = activeChecks.entrySet().iterator();
        
        while (iter.hasNext()) {
            Map.Entry<UUID, ActiveSkillCheck> entry = iter.next();
            ActiveSkillCheck check = entry.getValue();
            
            // Advance indicator position
            check.currentPosition += check.speed;
            
            // Check if skill check expired (indicator moved past bar)
            if (check.currentPosition > 1.0) {
                // Auto-fail if expired
                Player player = Bukkit.getPlayer(entry.getKey());
                if (player != null) {
                    player.sendTitle("§cSkill Check Failed!", "§7Too slow!", 5, 20, 5);
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.5f);
                }
                iter.remove();
            }
        }
    }
    
    /**
     * Clear all active skill checks.
     */
    public void clearAll() {
        activeChecks.clear();
    }
    
    // Helper methods
    private double calculateSuccessZone(SkillCheckType type) {
        // Harder skill checks have smaller success zones
        return BASE_SUCCESS_ZONE / type.getDifficultyMultiplier();
    }
    
    private double calculateGreatZone(SkillCheckType type) {
        return GREAT_SKILL_ZONE / type.getDifficultyMultiplier();
    }
    
    private int calculateDuration(SkillCheckType type) {
        // Duration in ticks (1 second = 20 ticks)
        // Harder skill checks are faster
        return (int) (40 / type.getDifficultyMultiplier());
    }
    
    private double generateTargetPosition() {
        // Target position is between 0.2 and 0.8 (avoiding edges)
        return 0.2 + (random.nextDouble() * 0.6);
    }
    
    /**
     * Represents an active skill check in progress.
     */
    public static class ActiveSkillCheck {
        public final UUID playerId;
        public final SkillCheckType type;
        public final UUID actionId;
        public final double successZone;
        public final double greatZone;
        public final int duration;
        public final double targetPosition;
        
        public double currentPosition;
        public double speed;
        public double progressGain;
        public long startTime;
        
        public ActiveSkillCheck(UUID playerId, SkillCheckType type, UUID actionId,
                               double successZone, double greatZone, int duration,
                               double targetPosition) {
            this.playerId = playerId;
            this.type = type;
            this.actionId = actionId;
            this.successZone = successZone;
            this.greatZone = greatZone;
            this.duration = duration;
            this.targetPosition = targetPosition;
            
            this.currentPosition = 0.0;
            this.speed = 1.0 / duration; // Move across bar in 'duration' ticks
            this.progressGain = 0.0;
            this.startTime = System.currentTimeMillis();
        }
        
        /**
         * Get remaining time in ticks.
         */
        public int getRemainingTicks() {
            return (int) ((1.0 - currentPosition) / speed);
        }
        
        /**
         * Check if the skill check has expired.
         */
        public boolean isExpired() {
            return currentPosition >= 1.0;
        }
        
        /**
         * Get progress gain from this skill check.
         */
        public double getProgressGain() {
            return progressGain;
        }
    }
}
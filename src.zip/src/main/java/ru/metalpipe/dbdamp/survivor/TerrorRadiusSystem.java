package ru.metalpipe.dbdamp.survivor;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import ru.metalpipe.dbdamp.gameplay.model.Match;
import ru.metalpipe.dbdamp.gameplay.model.PlayerRole;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * System for managing killer proximity detection and heartbeat sounds.
 * Creates tension through audio cues based on distance from the killer.
 */
public class TerrorRadiusSystem {
    
    private final Logger logger;
    
    // Track survivor terror radius state
    private final Map<UUID, TerrorRadiusState> survivorStates;
    
    // Configuration
    private static final double MAX_TERROR_RADIUS = 32.0;
    private static final double DETECTION_INTERVAL = 20; // Check every second (20 ticks)
    private static final int HEARTBEAT_BASE_INTERVAL = 60; // Base heartbeat interval in ticks
    
    public TerrorRadiusSystem() {
        this.logger = Logger.getLogger(getClass().getName());
        this.survivorStates = new ConcurrentHashMap<>();
    }
    
    /**
     * Update terror radius for all survivors based on killer position.
     * 
     * @param match The current match
     * @param killerId The killer's UUID
     * @param killerLocation The killer's current location
     */
    public void update(Match match, UUID killerId, Location killerLocation) {
        if (killerLocation == null || killerLocation.getWorld() == null) {
            return;
        }
        
        Map<UUID, PlayerRole> players = match.getPlayerRoles();
        if (players == null) return;
        
        for (Map.Entry<UUID, PlayerRole> entry : players.entrySet()) {
            UUID playerId = entry.getKey();
            PlayerRole role = entry.getValue();
            
            if (role != PlayerRole.SURVIVOR) continue;
            
            Player player = Bukkit.getPlayer(playerId);
            if (player == null || !player.isOnline()) continue;
            
            TerrorRadiusState state = getOrCreateState(playerId);
            
            // Check if survivor is in a locker (immune to terror radius detection)
            if (state.isInLocker) {
                continue;
            }
            
            // Calculate distance to killer
            Location playerLocation = player.getLocation();
            if (!playerLocation.getWorld().equals(killerLocation.getWorld())) {
                continue;
            }
            
            double distance = playerLocation.distance(killerLocation);
            
            // Update terror radius intensity
            updateTerrorRadius(state, distance);
            
            // Play heartbeat sounds based on intensity
            playHeartbeatSound(player, state);
            
            // Add visual indicators
            applyVisualIndicators(player, state);
        }
    }
    
    /**
     * Mark a survivor as being in a locker (immune to terror radius).
     * 
     * @param survivorId The survivor's UUID
     * @param inLocker Whether the survivor is in a locker
     */
    public void setInLocker(UUID survivorId, boolean inLocker) {
        TerrorRadiusState state = getOrCreateState(survivorId);
        state.isInLocker = inLocker;
    }
    
    /**
     * Get the current terror radius intensity for a survivor.
     * 
     * @param survivorId The survivor's UUID
     * @return Intensity from 0.0 to 1.0
     */
    public double getIntensity(UUID survivorId) {
        TerrorRadiusState state = survivorStates.get(survivorId);
        return state != null ? state.intensity : 0.0;
    }
    
    /**
     * Check if a survivor is in the terror radius.
     * 
     * @param survivorId The survivor's UUID
     * @return true if survivor is within terror radius
     */
    public boolean isInTerrorRadius(UUID survivorId) {
        TerrorRadiusState state = survivorStates.get(survivorId);
        return state != null && state.intensity > 0;
    }
    
    /**
     * Reset terror radius state for a survivor.
     * 
     * @param survivorId The survivor's UUID
     */
    public void resetSurvivor(UUID survivorId) {
        survivorStates.remove(survivorId);
    }
    
    /**
     * Clear all states.
     */
    public void clearAll() {
        survivorStates.clear();
    }
    
    // Helper methods
    private TerrorRadiusState getOrCreateState(UUID survivorId) {
        return survivorStates.computeIfAbsent(survivorId, id -> new TerrorRadiusState());
    }
    
    private void updateTerrorRadius(TerrorRadiusState state, double distance) {
        if (distance > MAX_TERROR_RADIUS) {
            state.intensity = 0.0;
            state.distanceToKiller = Double.MAX_VALUE;
        } else {
            state.distanceToKiller = distance;
            state.intensity = 1.0 - (distance / MAX_TERROR_RADIUS);
        }
    }
    
    private void playHeartbeatSound(Player player, TerrorRadiusState state) {
        if (state.intensity <= 0) {
            state.heartbeatCooldown = 0;
            return;
        }
        
        // Calculate heartbeat interval based on intensity
        // Higher intensity = faster heartbeat
        int interval = (int) (HEARTBEAT_BASE_INTERVAL * (1.0 - state.intensity * 0.7));
        interval = Math.max(10, interval); // Minimum 10 ticks between beats
        
        state.heartbeatCooldown--;
        
        if (state.heartbeatCooldown <= 0) {
            // Play heartbeat sound
            float volume = (float) (0.5 + state.intensity * 0.5);
            float pitch = (float) (0.8 + state.intensity * 0.4);
            
            player.playSound(player.getLocation(), Sound.ENTITY_WARDEN_HEARTBEAT, volume, pitch);
            
            // Reset cooldown
            state.heartbeatCooldown = interval;
        }
    }
    
    private void applyVisualIndicators(Player player, TerrorRadiusState state) {
        if (state.intensity <= 0) {
            return;
        }
        
        // Could apply screen effects, particles, etc.
        // For now, we'll use action bar message
        if (state.intensity > 0.7) {
            player.sendActionBar("§c§l⚠ DANGER! Killer is very close!");
        } else if (state.intensity > 0.4) {
            player.sendActionBar("§e⚠ Killer is nearby");
        } else if (state.intensity > 0.1) {
            player.sendActionBar("§7You sense the killer's presence");
        }
    }
    
    /**
     * Internal state for terror radius tracking.
     */
    private static class TerrorRadiusState {
        double intensity = 0.0;
        double distanceToKiller = Double.MAX_VALUE;
        int heartbeatCooldown = 0;
        boolean isInLocker = false;
    }
}
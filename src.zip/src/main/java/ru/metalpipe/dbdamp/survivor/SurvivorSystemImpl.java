package ru.metalpipe.dbdamp.survivor;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ru.metalpipe.dbdamp.gameplay.model.Match;
import ru.metalpipe.dbdamp.gameplay.model.PlayerRole;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Implementation of survivor-specific mechanics and abilities.
 * Manages sprinting, crouching, vaulting, hiding, health, and healing.
 */
public class SurvivorSystemImpl implements SurvivorSystem {
    
    private final Logger logger;
    
    // Player state tracking
    private final Map<UUID, SurvivorState> survivorStates;
    
    // Configuration values
    private static final int MAX_STAMINA = 100;
    private static final int STAMINA_REGEN_RATE = 2; // per tick
    private static final int SPRINT_STAMINA_COST = 3; // per tick
    private static final int HEALING_TIME_TICKS = 480; // 24 seconds at 20 ticks/sec
    private static final int SELF_HEALING_PENALTY = 160; // +8 seconds for self-heal
    
    // Speed effects
    private static final int SPRINT_SPEED_AMPLIFIER = 1;
    private static final int CROUCH_SPEED_AMPLIFIER = -2;
    private static final int INJURED_SPEED_AMPLIFIER = -1;
    
    public SurvivorSystemImpl() {
        this.logger = Logger.getLogger(getClass().getName());
        this.survivorStates = new ConcurrentHashMap<>();
    }
    
    // Sprint mechanics
    @Override
    public void enableSprint(UUID playerId) {
        SurvivorState state = getOrCreateState(playerId);
        if (state.stamina <= 0) {
            return;
        }
        state.isSprinting = true;
        applySpeedEffects(playerId);
    }
    
    @Override
    public void disableSprint(UUID playerId) {
        SurvivorState state = getState(playerId);
        if (state == null) return;
        
        state.isSprinting = false;
        applySpeedEffects(playerId);
    }
    
    // Crouch mechanics
    @Override
    public void enableCrouch(UUID playerId) {
        SurvivorState state = getOrCreateState(playerId);
        state.isCrouching = true;
        state.isSprinting = false;
        applySpeedEffects(playerId);
    }
    
    @Override
    public void disableCrouch(UUID playerId) {
        SurvivorState state = getState(playerId);
        if (state == null) return;
        
        state.isCrouching = false;
        applySpeedEffects(playerId);
    }
    
    // Vault mechanics
    @Override
    public boolean vault(UUID playerId, Location location) {
        SurvivorState state = getOrCreateState(playerId);
        
        if (state.vaultCooldown > 0) {
            return false;
        }
        
        Player player = Bukkit.getPlayer(playerId);
        if (player == null) return false;
        
        // Check if location is vaultable (window, pallet, etc.)
        if (!isVaultable(location)) {
            return false;
        }
        
        // Apply vault animation and movement
        Location vaultTarget = calculateVaultTarget(location, player.getLocation());
        player.teleport(vaultTarget);
        
        // Set cooldown
        state.vaultCooldown = 60; // 3 seconds
        
        // Use stamina
        state.stamina = Math.max(0, state.stamina - 10);
        
        logger.fine("Player " + player.getName() + " vaulted at " + location);
        return true;
    }
    
    // Locker mechanics
    @Override
    public boolean enterLocker(UUID playerId, Location lockerLocation) {
        SurvivorState state = getOrCreateState(playerId);
        
        if (state.isInLocker) {
            return false;
        }
        
        // Check if there's a locker at the location
        if (!isLockerAt(lockerLocation)) {
            return false;
        }
        
        state.isInLocker = true;
        state.lockerLocation = lockerLocation.clone();
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            // Hide the player from others using invisibility
            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
            player.teleport(lockerLocation);
        }
        
        return true;
    }
    
    @Override
    public boolean exitLocker(UUID playerId) {
        SurvivorState state = getState(playerId);
        if (state == null || !state.isInLocker) {
            return false;
        }
        
        state.isInLocker = false;
        state.lockerLocation = null;
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            // Show the player again by removing invisibility
            player.removePotionEffect(PotionEffectType.INVISIBILITY);
        }
        
        return true;
    }
    
    @Override
    public boolean isInLocker(UUID playerId) {
        SurvivorState state = getState(playerId);
        return state != null && state.isInLocker;
    }
    
    // Pallet mechanics
    @Override
    public boolean dropPallet(UUID playerId, Location palletLocation) {
        SurvivorState state = getOrCreateState(playerId);
        
        if (state.palletDropCooldown > 0) {
            return false;
        }
        
        // Check if pallet can be dropped at location
        if (!canDropPalletAt(palletLocation)) {
            return false;
        }
        
        // Drop the pallet (create visual and collision)
        // This would integrate with the map system
        
        state.palletDropCooldown = 40; // 2 seconds
        
        logger.fine("Player " + playerId + " dropped pallet at " + palletLocation);
        return true;
    }
    
    // Health mechanics
    @Override
    public boolean isInjured(UUID playerId) {
        SurvivorState state = getState(playerId);
        return state != null && state.healthState == HealthState.INJURED;
    }
    
    @Override
    public boolean isDying(UUID playerId) {
        SurvivorState state = getState(playerId);
        return state != null && state.healthState == HealthState.DYING;
    }
    
    @Override
    public HealthState applyInjury(UUID playerId, String damageSource) {
        SurvivorState state = getOrCreateState(playerId);
        HealthState previousState = state.healthState;
        
        state.healthState = state.healthState.getNextState();
        
        if (state.healthState != previousState) {
            applySpeedEffects(playerId);
            logger.info("Player " + playerId + " now in state " + state.healthState + 
                       " (damage source: " + damageSource + ")");
        }
        
        return state.healthState;
    }
    
    @Override
    public HealthState getHealthState(UUID playerId) {
        SurvivorState state = getState(playerId);
        return state != null ? state.healthState : HealthState.HEALTHY;
    }
    
    // Healing mechanics
    @Override
    public boolean startSelfHealing(UUID playerId) {
        SurvivorState state = getOrCreateState(playerId);
        
        if (state.healthState != HealthState.INJURED) {
            return false;
        }
        
        if (state.isHealing) {
            return false;
        }
        
        state.isHealing = true;
        state.healingTarget = playerId;
        state.healingProgress = 0;
        state.healingTimeRequired = HEALING_TIME_TICKS + SELF_HEALING_PENALTY;
        
        return true;
    }
    
    @Override
    public boolean startHealingOther(UUID healerId, UUID targetId) {
        SurvivorState healerState = getOrCreateState(healerId);
        SurvivorState targetState = getOrCreateState(targetId);
        
        if (targetState.healthState != HealthState.INJURED) {
            return false;
        }
        
        if (healerState.isHealing || healerState.healthState != HealthState.HEALTHY) {
            return false;
        }
        
        // Check distance
        Player healer = Bukkit.getPlayer(healerId);
        Player target = Bukkit.getPlayer(targetId);
        if (healer == null || target == null) return false;
        
        if (healer.getLocation().distance(target.getLocation()) > 3.0) {
            return false;
        }
        
        healerState.isHealing = true;
        healerState.healingTarget = targetId;
        healerState.healingProgress = 0;
        healerState.healingTimeRequired = HEALING_TIME_TICKS;
        
        return true;
    }
    
    @Override
    public void cancelHealing(UUID playerId) {
        SurvivorState state = getState(playerId);
        if (state != null) {
            state.isHealing = false;
            state.healingTarget = null;
            state.healingProgress = 0;
        }
    }
    
    // Stamina
    @Override
    public int getStamina(UUID playerId) {
        SurvivorState state = getState(playerId);
        return state != null ? state.stamina : MAX_STAMINA;
    }
    
    // Update loop
    @Override
    public void update(Match match) {
        for (UUID playerId : survivorStates.keySet()) {
            SurvivorState state = survivorStates.get(playerId);
            
            // Regenerate stamina when not sprinting
            if (!state.isSprinting && state.stamina < MAX_STAMINA) {
                state.stamina = Math.min(MAX_STAMINA, state.stamina + STAMINA_REGEN_RATE);
            }
            
            // Consume stamina while sprinting
            if (state.isSprinting && state.stamina > 0) {
                state.stamina = Math.max(0, state.stamina - SPRINT_STAMINA_COST);
                if (state.stamina <= 0) {
                    disableSprint(playerId);
                }
            }
            
            // Update cooldowns
            if (state.vaultCooldown > 0) state.vaultCooldown--;
            if (state.palletDropCooldown > 0) state.palletDropCooldown--;
            
            // Update healing progress
            if (state.isHealing) {
                state.healingProgress++;
                
                if (state.healingProgress >= state.healingTimeRequired) {
                    // Complete healing
                    if (state.healingTarget != null) {
                        SurvivorState targetState = getOrCreateState(state.healingTarget);
                        targetState.healthState = targetState.healthState.getPreviousState();
                        applySpeedEffects(state.healingTarget);
                    }
                    cancelHealing(playerId);
                }
            }
        }
    }
    
    @Override
    public void resetSurvivor(UUID playerId) {
        survivorStates.remove(playerId);
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.removePotionEffect(PotionEffectType.SPEED);
            player.removePotionEffect(PotionEffectType.INVISIBILITY);
        }
    }
    
    // Helper methods
    private SurvivorState getOrCreateState(UUID playerId) {
        return survivorStates.computeIfAbsent(playerId, id -> new SurvivorState());
    }
    
    private SurvivorState getState(UUID playerId) {
        return survivorStates.get(playerId);
    }
    
    private void applySpeedEffects(UUID playerId) {
        Player player = Bukkit.getPlayer(playerId);
        if (player == null) return;
        
        SurvivorState state = getState(playerId);
        if (state == null) return;
        
        // Remove existing speed effects
        player.removePotionEffect(PotionEffectType.SPEED);
        
        // Calculate total speed modifier
        int amplifier = 0;
        
        if (state.isSprinting) amplifier += SPRINT_SPEED_AMPLIFIER;
        if (state.isCrouching) amplifier += CROUCH_SPEED_AMPLIFIER;
        if (state.healthState == HealthState.INJURED) amplifier += INJURED_SPEED_AMPLIFIER;
        if (state.healthState == HealthState.DYING) amplifier += INJURED_SPEED_AMPLIFIER * 2;
        
        if (amplifier != 0) {
            player.addPotionEffect(new PotionEffect(
                PotionEffectType.SPEED,
                Integer.MAX_VALUE, // Permanent until removed
                amplifier,
                false,
                false
            ));
        }
    }
    
    private boolean isVaultable(Location location) {
        // Check if block at location is vaultable
        // This would integrate with the map system
        return true; // Placeholder
    }
    
    private Location calculateVaultTarget(Location vaultLocation, Location playerLocation) {
        // Calculate the position after vaulting
        double dx = vaultLocation.getX() - playerLocation.getX();
        double dz = vaultLocation.getZ() - playerLocation.getZ();
        
        // Move to the opposite side
        return vaultLocation.clone().add(dx * 1.5, 0, dz * 1.5);
    }
    
    private boolean isLockerAt(Location location) {
        // Check if there's a locker at location
        // This would integrate with the map system
        return true; // Placeholder
    }
    
    private boolean canDropPalletAt(Location location) {
        // Check if pallet can be dropped
        // This would integrate with the map system
        return true; // Placeholder
    }
    
    /**
     * Internal state for each survivor.
     */
    private static class SurvivorState {
        HealthState healthState = HealthState.HEALTHY;
        int stamina = MAX_STAMINA;
        boolean isSprinting = false;
        boolean isCrouching = false;
        boolean isInLocker = false;
        Location lockerLocation = null;
        int vaultCooldown = 0;
        int palletDropCooldown = 0;
        
        boolean isHealing = false;
        UUID healingTarget = null;
        int healingProgress = 0;
        int healingTimeRequired = HEALING_TIME_TICKS;
    }
}
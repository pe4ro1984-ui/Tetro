package ru.metalpipe.dbdamp.survivor;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ru.metalpipe.dbdamp.gameplay.model.Match;

import java.util.UUID;

/**
 * Interface for survivor-specific mechanics and abilities.
 * Implements sprinting, crouching, vaulting, hiding, and healing mechanics.
 */
public interface SurvivorSystem {
    
    /**
     * Enable sprint mode for a survivor.
     * Applies speed boost and消耗 stamina.
     * 
     * @param playerId The survivor's UUID
     */
    void enableSprint(UUID playerId);
    
    /**
     * Disable sprint mode for a survivor.
     * 
     * @param playerId The survivor's UUID
     */
    void disableSprint(UUID playerId);
    
    /**
     * Enable crouch mode for a survivor.
     * Reduces visibility and noise but slows movement.
     * 
     * @param playerId The survivor's UUID
     */
    void enableCrouch(UUID playerId);
    
    /**
     * Disable crouch mode for a survivor.
     * 
     * @param playerId The survivor's UUID
     */
    void disableCrouch(UUID playerId);
    
    /**
     * Perform a vault action over an obstacle.
     * 
     * @param playerId The survivor's UUID
     * @param location The vault location
     * @return true if vault was successful
     */
    boolean vault(UUID playerId, Location location);
    
    /**
     * Enter a locker to hide from the killer.
     * 
     * @param playerId The survivor's UUID
     * @param lockerLocation The locker location
     * @return true if successfully entered locker
     */
    boolean enterLocker(UUID playerId, Location lockerLocation);
    
    /**
     * Exit a locker.
     * 
     * @param playerId The survivor's UUID
     * @return true if successfully exited locker
     */
    boolean exitLocker(UUID playerId);
    
    /**
     * Drop a pallet at the specified location.
     * 
     * @param playerId The survivor's UUID
     * @param palletLocation The pallet location
     * @return true if pallet was dropped successfully
     */
    boolean dropPallet(UUID playerId, Location palletLocation);
    
    /**
     * Check if a survivor is injured.
     * 
     * @param playerId The survivor's UUID
     * @return true if survivor is injured
     */
    boolean isInjured(UUID playerId);
    
    /**
     * Check if a survivor is in dying state.
     * 
     * @param playerId The survivor's UUID
     * @return true if survivor is dying
     */
    boolean isDying(UUID playerId);
    
    /**
     * Apply injury to a survivor.
     * Transitions from healthy to injured, or injured to dying.
     * 
     * @param playerId The survivor's UUID
     * @param damageSource The source of damage
     * @return The new health state
     */
    HealthState applyInjury(UUID playerId, String damageSource);
    
    /**
     * Start self-healing with a med-kit.
     * 
     * @param playerId The survivor's UUID
     * @return true if healing started successfully
     */
    boolean startSelfHealing(UUID playerId);
    
    /**
     * Start healing another survivor.
     * 
     * @param healerId The healer's UUID
     * @param targetId The target survivor's UUID
     * @return true if healing started successfully
     */
    boolean startHealingOther(UUID healerId, UUID targetId);
    
    /**
     * Cancel healing action.
     * 
     * @param playerId The survivor's UUID
     */
    void cancelHealing(UUID playerId);
    
    /**
     * Get survivor's current health state.
     * 
     * @param playerId The survivor's UUID
     * @return The current health state
     */
    HealthState getHealthState(UUID playerId);
    
    /**
     * Get survivor's current stamina.
     * 
     * @param playerId The survivor's UUID
     * @return Stamina value (0-100)
     */
    int getStamina(UUID playerId);
    
    /**
     * Check if survivor is currently hiding in a locker.
     * 
     * @param playerId The survivor's UUID
     * @return true if hiding in locker
     */
    boolean isInLocker(UUID playerId);
    
    /**
     * Update survivor state (called every tick).
     * 
     * @param match The current match
     */
    void update(Match match);
    
    /**
     * Reset survivor state for a new match.
     * 
     * @param playerId The survivor's UUID
     */
    void resetSurvivor(UUID playerId);
    
    /**
     * Health state enum for survivors.
     */
    enum HealthState {
        HEALTHY(100, 1.0, "Healthy"),
        INJURED(75, 0.9, "Injured"),
        DYING(50, 0.7, "Dying"),
        DEAD(0, 0.0, "Dead");
        
        private final int health;
        private final double speedModifier;
        private final String displayName;
        
        HealthState(int health, double speedModifier, String displayName) {
            this.health = health;
            this.speedModifier = speedModifier;
            this.displayName = displayName;
        }
        
        public int getHealth() { return health; }
        public double getSpeedModifier() { return speedModifier; }
        public String getDisplayName() { return displayName; }
        
        public HealthState getNextState() {
            switch (this) {
                case HEALTHY: return INJURED;
                case INJURED: return DYING;
                default: return DEAD;
            }
        }
        
        public HealthState getPreviousState() {
            switch (this) {
                case INJURED: return HEALTHY;
                case DYING: return INJURED;
                default: return this;
            }
        }
        
        public boolean isAlive() {
            return this != DEAD;
        }
    }
}
package ru.metalpipe.dbdamp.survivor;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ru.metalpipe.dbdamp.gameplay.model.Match;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * System for managing player health states, injuries, and healing mechanics.
 * Implements healthy, injured, and dying states with visual and audio effects.
 */
public class HealthSystem {
    
    private final Logger logger;
    
    // Player health states
    private final Map<UUID, HealthState> healthStates;
    
    // Healing tracking
    private final Map<UUID, HealingSession> healingSessions;
    
    // Configuration
    private static final int BASE_HEALING_TIME = 480; // 24 seconds (in ticks)
    private static final int SELF_HEAL_PENALTY = 160; // +8 seconds for self-heal
    private static final double MAX_HEAL_DISTANCE = 3.0;
    private static final int BLEED_OUT_TIME = 1200; // 60 seconds before dying
    
    /**
     * Health state enum representing a player's current health.
     */
    public enum HealthState {
        HEALTHY(100, 1.0, "Healthy", "§a"),
        INJURED(75, 0.9, "Injured", "§e"),
        DYING(50, 0.7, "Dying", "§c"),
        DEAD(0, 0.0, "Dead", "§4");
        
        private final int health;
        private final double speedModifier;
        private final String displayName;
        private final String colorCode;
        
        HealthState(int health, double speedModifier, String displayName, String colorCode) {
            this.health = health;
            this.speedModifier = speedModifier;
            this.displayName = displayName;
            this.colorCode = colorCode;
        }
        
        public int getHealth() { return health; }
        public double getSpeedModifier() { return speedModifier; }
        public String getDisplayName() { return displayName; }
        public String getColorCode() { return colorCode; }
        
        public boolean isAlive() {
            return this != DEAD;
        }
        
        public boolean canAct() {
            return this == HEALTHY || this == INJURED;
        }
        
        public HealthState getNextState() {
            switch (this) {
                case HEALTHY: return INJURED;
                case INJURED: return DYING;
                default: return DEAD;
            }
        }
        
        public HealthState getPreviousState() {
            switch (this) {
                case INJURED: return HEALTHY;
                case DYING: return INJURED;
                default: return this;
            }
        }
    }
    
    public HealthSystem() {
        this.logger = Logger.getLogger(getClass().getName());
        this.healthStates = new ConcurrentHashMap<>();
        this.healingSessions = new ConcurrentHashMap<>();
    }
    
    /**
     * Get a player's current health state.
     * 
     * @param playerId The player's UUID
     * @return The player's health state
     */
    public HealthState getHealthState(UUID playerId) {
        return healthStates.getOrDefault(playerId, HealthState.HEALTHY);
    }
    
    /**
     * Check if a player is healthy.
     */
    public boolean isHealthy(UUID playerId) {
        return getHealthState(playerId) == HealthState.HEALTHY;
    }
    
    /**
     * Check if a player is injured.
     */
    public boolean isInjured(UUID playerId) {
        return getHealthState(playerId) == HealthState.INJURED;
    }
    
    /**
     * Check if a player is dying.
     */
    public boolean isDying(UUID playerId) {
        return getHealthState(playerId) == HealthState.DYING;
    }
    
    /**
     * Check if a player is dead.
     */
    public boolean isDead(UUID playerId) {
        return getHealthState(playerId) == HealthState.DEAD;
    }
    
    /**
     * Apply damage to a player, transitioning them to the next health state.
     * 
     * @param playerId The player's UUID
     * @param damageSource The source of the damage
     * @return The new health state
     */
    public HealthState applyDamage(UUID playerId, String damageSource) {
        HealthState current = getHealthState(playerId);
        
        if (current == HealthState.DEAD) {
            return HealthState.DEAD;
        }
        
        HealthState newState = current.getNextState();
        healthStates.put(playerId, newState);
        
        // Apply effects
        applyHealthEffects(playerId, newState);
        
        // Cancel any active healing
        cancelHealing(playerId);
        
        // Play effects
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_HURT, 1.0f, 1.0f);
            
            String message = newState.getColorCode() + "You are now " + newState.getDisplayName();
            player.sendTitle(newState.getColorCode() + newState.getDisplayName(), "", 10, 40, 10);
        }
        
        logger.info("Player " + playerId + " damaged by " + damageSource + ", now " + newState.getDisplayName());
        
        return newState;
    }
    
    /**
     * Heal a player, transitioning them to the previous health state.
     * 
     * @param playerId The player's UUID
     * @return The new health state
     */
    public HealthState heal(UUID playerId) {
        HealthState current = getHealthState(playerId);
        
        if (current == HealthState.HEALTHY || current == HealthState.DEAD) {
            return current;
        }
        
        HealthState newState = current.getPreviousState();
        healthStates.put(playerId, newState);
        
        // Apply effects
        applyHealthEffects(playerId, newState);
        
        // Play effects
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 2.0f);
            player.sendTitle("§aHealed!", "You are now " + newState.getDisplayName(), 10, 30, 10);
        }
        
        logger.info("Player " + playerId + " healed, now " + newState.getDisplayName());
        
        return newState;
    }
    
    /**
     * Start healing a player (by another player).
     * 
     * @param healerId The healer's UUID
     * @param targetId The target's UUID
     * @return true if healing started successfully
     */
    public boolean startHealing(UUID healerId, UUID targetId) {
        // Check if target needs healing
        HealthState targetState = getHealthState(targetId);
        if (targetState == HealthState.HEALTHY || targetState == HealthState.DEAD) {
            return false;
        }
        
        // Check if healer can heal
        HealthState healerState = getHealthState(healerId);
        if (!healerState.canAct()) {
            return false;
        }
        
        // Check distance
        Player healer = Bukkit.getPlayer(healerId);
        Player target = Bukkit.getPlayer(targetId);
        if (healer == null || target == null) return false;
        
        if (healer.getLocation().distance(target.getLocation()) > MAX_HEAL_DISTANCE) {
            return false;
        }
        
        // Cancel existing healing session
        cancelHealing(targetId);
        
        // Create new healing session
        HealingSession session = new HealingSession(healerId, targetId, BASE_HEALING_TIME);
        healingSessions.put(targetId, session);
        
        healer.sendActionBar("§aHealing " + target.getName() + "...");
        target.sendActionBar("§aBeing healed by " + healer.getName() + "...");
        
        return true;
    }
    
    /**
     * Start self-healing.
     * 
     * @param playerId The player's UUID
     * @return true if self-healing started successfully
     */
    public boolean startSelfHealing(UUID playerId) {
        HealthState state = getHealthState(playerId);
        if (state != HealthState.INJURED) {
            return false;
        }
        
        // Cancel existing healing
        cancelHealing(playerId);
        
        // Create self-healing session (longer time)
        HealingSession session = new HealingSession(playerId, playerId, BASE_HEALING_TIME + SELF_HEAL_PENALTY);
        healingSessions.put(playerId, session);
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.sendActionBar("§eSelf-healing...");
        }
        
        return true;
    }
    
    /**
     * Cancel healing for a player.
     * 
     * @param playerId The player's UUID
     */
    public void cancelHealing(UUID playerId) {
        HealingSession session = healingSessions.remove(playerId);
        if (session != null && !session.healerId.equals(playerId)) {
            // Notify healer if it wasn't self-healing
            Player healer = Bukkit.getPlayer(session.healerId);
            if (healer != null) {
                healer.sendActionBar("§cHealing cancelled");
            }
        }
    }
    
    /**
     * Get healing progress for a player.
     * 
     * @param playerId The player's UUID
     * @return Progress from 0.0 to 1.0, or -1 if not healing
     */
    public double getHealingProgress(UUID playerId) {
        HealingSession session = healingSessions.get(playerId);
        if (session == null) return -1;
        
        return (double) session.progress / session.totalTime;
    }
    
    /**
     * Update health system (called every tick).
     * 
     * @param match The current match
     */
    public void update(Match match) {
        // Update healing sessions
        Iterator<Map.Entry<UUID, HealingSession>> iter = healingSessions.entrySet().iterator();
        
        while (iter.hasNext()) {
            Map.Entry<UUID, HealingSession> entry = iter.next();
            HealingSession session = entry.getValue();
            
            // Check if healer and target are still close enough
            Player healer = Bukkit.getPlayer(session.healerId);
            Player target = Bukkit.getPlayer(session.targetId);
            
            if (healer == null || target == null) {
                iter.remove();
                continue;
            }
            
            // Skip distance check for self-healing
            if (!session.healerId.equals(session.targetId)) {
                if (healer.getLocation().distance(target.getLocation()) > MAX_HEAL_DISTANCE) {
                    iter.remove();
                    healer.sendActionBar("§cHealing cancelled - too far from target");
                    continue;
                }
            }
            
            // Progress healing
            session.progress++;
            
            // Update progress display
            double progress = (double) session.progress / session.totalTime;
            healer.sendActionBar(String.format("§aHealing... %.0f%%", progress * 100));
            
            // Check if complete
            if (session.progress >= session.totalTime) {
                heal(session.targetId);
                iter.remove();
            }
        }
        
        // Update dying player bleed out timer
        for (Map.Entry<UUID, HealthState> entry : healthStates.entrySet()) {
            if (entry.getValue() == HealthState.DYING) {
                DyingState dying = getOrCreateDyingState(entry.getKey());
                dying.bleedOutTimer--;
                
                // Visual/audio indicators
                Player player = Bukkit.getPlayer(entry.getKey());
                if (player != null && dying.bleedOutTimer % 20 == 0) {
                    int seconds = dying.bleedOutTimer / 20;
                    player.sendActionBar("§cBleeding out! " + seconds + "s remaining");
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_HURT, 0.5f, 0.8f);
                }
                
                // Check if bled out
                if (dying.bleedOutTimer <= 0) {
                    healthStates.put(entry.getKey(), HealthState.DEAD);
                    if (player != null) {
                        player.sendTitle("§4You died", "", 10, 40, 10);
                    }
                }
            }
        }
    }
    
    /**
     * Reset health state for a player.
     * 
     * @param playerId The player's UUID
     */
    public void resetPlayer(UUID playerId) {
        healthStates.remove(playerId, HealthState.HEALTHY);
        healingSessions.remove(playerId);
        dyingStates.remove(playerId);
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.removePotionEffect(PotionEffectType.SPEED);
            player.removePotionEffect(PotionEffectType.SLOW);
        }
    }
    
    /**
     * Reset all players.
     */
    public void resetAll() {
        healthStates.clear();
        healingSessions.clear();
        dyingStates.clear();
    }
    
    // Helper methods
    private void applyHealthEffects(UUID playerId, HealthState state) {
        Player player = Bukkit.getPlayer(playerId);
        if (player == null) return;
        
        // Remove existing speed effects
        player.removePotionEffect(PotionEffectType.SPEED);
        player.removePotionEffect(PotionEffectType.SLOW);
        
        switch (state) {
            case INJURED:
                // Apply slight speed penalty and blood particles
                player.addPotionEffect(new PotionEffect(
                    PotionEffectType.SPEED,
                    Integer.MAX_VALUE,
                    -1, // Speed I reduction
                    false,
                    false
                ));
                // Could add blood particle effect on a timer
                break;
                
            case DYING:
                // Apply significant speed penalty
                player.addPotionEffect(new PotionEffect(
                    PotionEffectType.SLOW,
                    Integer.MAX_VALUE,
                    1,
                    false,
                    false
                ));
                break;
                
            case DEAD:
                // Clear all effects
                break;
        }
    }
    
    // Dying state tracking
    private final Map<UUID, DyingState> dyingStates = new ConcurrentHashMap<>();
    
    private DyingState getOrCreateDyingState(UUID playerId) {
        return dyingStates.computeIfAbsent(playerId, id -> new DyingState());
    }
    
    /**
     * Internal class for dying state tracking.
     */
    private static class DyingState {
        int bleedOutTimer = BLEED_OUT_TIME;
        int recoveryProgress = 0; // For recovery from dying state
    }
    
    /**
     * Internal class for healing session tracking.
     */
    private static class HealingSession {
        final UUID healerId;
        final UUID targetId;
        final int totalTime;
        int progress = 0;
        
        HealingSession(UUID healerId, UUID targetId, int totalTime) {
            this.healerId = healerId;
            this.targetId = targetId;
            this.totalTime = totalTime;
        }
    }
}
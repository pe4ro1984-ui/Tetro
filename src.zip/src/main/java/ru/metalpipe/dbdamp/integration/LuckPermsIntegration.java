package ru.metalpipe.dbdamp.integration;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.UUID;
import java.util.logging.Logger;

/**
 * Integration with LuckPerms for permission management.
 * Uses reflection to avoid hard dependency.
 */
public class LuckPermsIntegration implements PluginIntegration {
    
    private final Logger logger;
    private Object luckPermsApi;
    private boolean enabled;
    
    public LuckPermsIntegration() {
        this.logger = Logger.getLogger(getClass().getName());
        this.enabled = false;
    }
    
    @Override
    public String getPluginName() {
        return "LuckPerms";
    }
    
    @Override
    public boolean enable() {
        if (!PluginIntegrationManager.isPluginInstalled("LuckPerms")) {
            return false;
        }
        
        try {
            Class<?> luckPermsProviderClass = Class.forName("net.luckperms.api.LuckPermsProvider");
            java.lang.reflect.Method getMethod = luckPermsProviderClass.getMethod("get");
            luckPermsApi = getMethod.invoke(null);
            enabled = true;
            logger.info("LuckPerms integration enabled");
            return true;
        } catch (ClassNotFoundException e) {
            logger.warning("LuckPerms API not found in classpath");
            return false;
        } catch (Exception e) {
            logger.warning("Failed to enable LuckPerms integration: " + e.getMessage());
            return false;
        }
    }
    
    @Override
    public void disable() {
        luckPermsApi = null;
        enabled = false;
    }
    
    /**
     * Check if a player has a permission.
     */
    public boolean hasPermission(UUID playerId, String permission) {
        if (!enabled || luckPermsApi == null) {
            Player player = Bukkit.getPlayer(playerId);
            return player != null && player.hasPermission(permission);
        }
        
        try {
            Object userManager = luckPermsApi.getClass().getMethod("getUserManager").invoke(luckPermsApi);
            Object user = userManager.getClass().getMethod("getUser", UUID.class).invoke(userManager, playerId);
            
            if (user != null) {
                Object cachedData = user.getClass().getMethod("getCachedData").invoke(user);
                Object permissionData = cachedData.getClass().getMethod("getPermissionData").invoke(cachedData);
                
                // Simple check using the PermissionCheckResult
                Object result = permissionData.getClass().getMethod("checkPermission", String.class)
                    .invoke(permissionData, permission);
                
                Class<?> tristateClass = Class.forName("net.luckperms.api.util.Tristate");
                Object asBooleanResult = result.getClass().getMethod("result").invoke(result);
                return tristateClass.getMethod("asBoolean").invoke(asBooleanResult) instanceof Boolean 
                    && (Boolean) tristateClass.getMethod("asBoolean").invoke(asBooleanResult);
            }
        } catch (Exception e) {
            logger.fine("Failed to check permission via LuckPerms: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Get a player's primary group.
     */
    public String getPrimaryGroup(UUID playerId) {
        if (!enabled || luckPermsApi == null) return "default";
        
        try {
            Object userManager = luckPermsApi.getClass().getMethod("getUserManager").invoke(luckPermsApi);
            Object user = userManager.getClass().getMethod("getUser", UUID.class).invoke(userManager, playerId);
            
            if (user != null) {
                return (String) user.getClass().getMethod("getPrimaryGroup").invoke(user);
            }
        } catch (Exception e) {
            logger.fine("Failed to get primary group: " + e.getMessage());
        }
        
        return "default";
    }
    
    public boolean isEnabled() {
        return enabled;
    }
}

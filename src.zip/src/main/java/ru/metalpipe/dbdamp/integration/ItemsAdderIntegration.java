package ru.metalpipe.dbdamp.integration;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;
import java.util.logging.Logger;

/**
 * Integration with ItemsAdder for custom items.
 * Uses reflection to avoid hard dependency.
 */
public class ItemsAdderIntegration implements PluginIntegration {
    
    private final Logger logger;
    private boolean enabled;
    private Class<?> customStackClass;
    
    public ItemsAdderIntegration() {
        this.logger = Logger.getLogger(getClass().getName());
        this.enabled = false;
    }
    
    @Override
    public String getPluginName() {
        return "ItemsAdder";
    }
    
    @Override
    public boolean enable() {
        if (!PluginIntegrationManager.isPluginInstalled("ItemsAdder")) {
            return false;
        }
        
        try {
            customStackClass = Class.forName("dev.lone.itemsadder.api.CustomStack");
            enabled = true;
            logger.info("ItemsAdder integration enabled");
            return true;
        } catch (ClassNotFoundException e) {
            logger.warning("ItemsAdder API not found in classpath");
            return false;
        }
    }
    
    @Override
    public void disable() {
        enabled = false;
        customStackClass = null;
    }
    
    /**
     * Get a custom item from ItemsAdder.
     */
    public Optional<ItemStack> getCustomItem(String namespacedId) {
        if (!enabled) return Optional.empty();
        
        try {
            java.lang.reflect.Method getInstance = customStackClass.getMethod("getInstance", String.class);
            Object stack = getInstance.invoke(null, namespacedId);
            if (stack != null) {
                java.lang.reflect.Method getItemStack = customStackClass.getMethod("getItemStack");
                ItemStack item = (ItemStack) getItemStack.invoke(stack);
                return Optional.ofNullable(item);
            }
        } catch (Exception e) {
            logger.fine("ItemsAdder item not found: " + namespacedId);
        }
        
        return Optional.empty();
    }
    
    /**
     * Check if an ItemStack is a custom ItemsAdder item.
     */
    public boolean isCustomItem(ItemStack item) {
        if (!enabled || item == null) return false;
        
        try {
            java.lang.reflect.Method byItemStack = customStackClass.getMethod("byItemStack", ItemStack.class);
            Object stack = byItemStack.invoke(null, item);
            return stack != null;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Get the namespaced ID of a custom item.
     */
    public String getCustomItemId(ItemStack item) {
        if (!enabled || item == null) return null;
        
        try {
            java.lang.reflect.Method byItemStack = customStackClass.getMethod("byItemStack", ItemStack.class);
            Object stack = byItemStack.invoke(null, item);
            if (stack != null) {
                java.lang.reflect.Method getNamespacedID = customStackClass.getMethod("getNamespacedID");
                return (String) getNamespacedID.invoke(stack);
            }
        } catch (Exception e) {
            // Not a custom item
        }
        
        return null;
    }
    
    /**
     * Give a custom item to a player.
     */
    public boolean giveCustomItem(Player player, String namespacedId, int amount) {
        if (!enabled || player == null) return false;
        
        try {
            Optional<ItemStack> itemOpt = getCustomItem(namespacedId);
            if (itemOpt.isPresent()) {
                ItemStack item = itemOpt.get().clone();
                item.setAmount(amount);
                player.getInventory().addItem(item);
                return true;
            }
        } catch (Exception e) {
            logger.warning("Failed to give ItemsAdder item: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Drop a custom item at a location.
     */
    public boolean dropCustomItem(Location location, String namespacedId, int amount) {
        if (!enabled || location == null || location.getWorld() == null) return false;
        
        try {
            Optional<ItemStack> itemOpt = getCustomItem(namespacedId);
            if (itemOpt.isPresent()) {
                ItemStack item = itemOpt.get().clone();
                item.setAmount(amount);
                location.getWorld().dropItemNaturally(location, item);
                return true;
            }
        } catch (Exception e) {
            logger.warning("Failed to drop ItemsAdder item: " + e.getMessage());
        }
        
        return false;
    }
    
    public boolean isEnabled() {
        return enabled;
    }
}

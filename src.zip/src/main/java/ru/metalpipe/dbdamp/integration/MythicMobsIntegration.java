package ru.metalpipe.dbdamp.integration;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;

import java.util.Optional;
import java.util.logging.Logger;

/**
 * Integration with MythicMobs for custom mob support.
 * Uses reflection to avoid hard dependency.
 */
public class MythicMobsIntegration implements PluginIntegration {
    
    private final Logger logger;
    private boolean enabled;
    private Object mobManager;
    private Class<?> mythicBukkitClass;
    private Class<?> mythicMobClass;
    
    public MythicMobsIntegration() {
        this.logger = Logger.getLogger(getClass().getName());
        this.enabled = false;
    }
    
    @Override
    public String getPluginName() {
        return "MythicMobs";
    }
    
    @Override
    public boolean enable() {
        if (!PluginIntegrationManager.isPluginInstalled("MythicMobs")) {
            return false;
        }
        
        try {
            mythicBukkitClass = Class.forName("io.lumine.mythic.bukkit.MythicBukkit");
            mythicMobClass = Class.forName("io.lumine.mythic.core.mobs.MythicMob");
            
            java.lang.reflect.Method instMethod = mythicBukkitClass.getMethod("inst");
            Object mythicBukkit = instMethod.invoke(null);
            
            java.lang.reflect.Method getMobManagerMethod = mythicBukkitClass.getMethod("getMobManager");
            mobManager = getMobManagerMethod.invoke(mythicBukkit);
            
            enabled = true;
            logger.info("MythicMobs integration enabled");
            return true;
        } catch (ClassNotFoundException e) {
            logger.warning("MythicMobs API not found in classpath");
            return false;
        } catch (Exception e) {
            logger.warning("Failed to enable MythicMobs integration: " + e.getMessage());
            return false;
        }
    }
    
    @Override
    public void disable() {
        mobManager = null;
        enabled = false;
    }
    
    /**
     * Spawn a MythicMob at a location.
     */
    public Optional<LivingEntity> spawnMythicMob(String mobType, Location location, int level) {
        if (!enabled || location == null || location.getWorld() == null || mobManager == null) {
            return Optional.empty();
        }
        
        try {
            java.lang.reflect.Method getMythicMobMethod = mobManager.getClass().getMethod("getMythicMob", String.class);
            Object mythicMob = getMythicMobMethod.invoke(mobManager, mobType);
            
            if (mythicMob == null) {
                logger.fine("MythicMob not found: " + mobType);
                return Optional.empty();
            }
            
            java.lang.reflect.Method spawnMethod = mythicMob.getClass().getMethod("spawn", Location.class, int.class);
            Object entity = spawnMethod.invoke(mythicMob, location, level);
            
            if (entity instanceof LivingEntity) {
                return Optional.of((LivingEntity) entity);
            }
        } catch (Exception e) {
            logger.warning("Failed to spawn MythicMob: " + e.getMessage());
        }
        
        return Optional.empty();
    }
    
    /**
     * Spawn a MythicMob with default level.
     */
    public Optional<LivingEntity> spawnMythicMob(String mobType, Location location) {
        return spawnMythicMob(mobType, location, 1);
    }
    
    /**
     * Check if an entity is a MythicMob.
     */
    public boolean isMythicMob(Entity entity) {
        if (!enabled || entity == null || mobManager == null) return false;
        
        try {
            java.lang.reflect.Method isMythicMobMethod = mobManager.getClass().getMethod("isMythicMob", Entity.class);
            Object result = isMythicMobMethod.invoke(mobManager, entity);
            return result instanceof Boolean && (Boolean) result;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Get the MythicMob type from an entity.
     */
    public String getMythicMobType(Entity entity) {
        if (!enabled || entity == null || mobManager == null) return null;
        
        try {
            java.lang.reflect.Method getActiveMobMethod = mobManager.getClass().getMethod("getActiveMob", java.util.UUID.class);
            Object activeMob = getActiveMobMethod.invoke(mobManager, entity.getUniqueId());
            
            if (activeMob != null) {
                java.lang.reflect.Method getMobTypeMethod = activeMob.getClass().getMethod("getMobType");
                return (String) getMobTypeMethod.invoke(activeMob);
            }
        } catch (Exception e) {
            // Not a MythicMob
        }
        
        return null;
    }
    
    public boolean isEnabled() {
        return enabled;
    }
}

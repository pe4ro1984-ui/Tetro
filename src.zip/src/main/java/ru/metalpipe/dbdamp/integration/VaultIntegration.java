package ru.metalpipe.dbdamp.integration;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.UUID;
import java.util.logging.Logger;

/**
 * Integration with Vault for economy support.
 * Uses reflection to avoid hard dependency.
 */
public class VaultIntegration implements PluginIntegration {
    
    private final Logger logger;
    private Object economy;
    private boolean enabled;
    private Class<?> economyClass;
    
    public VaultIntegration() {
        this.logger = Logger.getLogger(getClass().getName());
        this.enabled = false;
    }
    
    @Override
    public String getPluginName() {
        return "Vault";
    }
    
    @Override
    public boolean enable() {
        if (!PluginIntegrationManager.isPluginInstalled("Vault")) {
            return false;
        }
        
        try {
            Class<?> vaultEconomyClass = Class.forName("net.milkbowl.vault.economy.Economy");
            RegisteredServiceProvider<?> rsp = Bukkit.getServicesManager().getRegistration(vaultEconomyClass);
            
            if (rsp == null) {
                logger.warning("Vault economy provider not found");
                return false;
            }
            
            economy = rsp.getProvider();
            economyClass = vaultEconomyClass;
            enabled = true;
            logger.info("Vault economy integration enabled");
            return true;
        } catch (ClassNotFoundException e) {
            logger.warning("Vault API not found in classpath");
            return false;
        } catch (Exception e) {
            logger.severe("Failed to enable Vault integration: " + e.getMessage());
            return false;
        }
    }
    
    @Override
    public void disable() {
        economy = null;
        economyClass = null;
        enabled = false;
    }
    
    /**
     * Get the player's balance.
     */
    public double getBalance(UUID playerId) {
        if (!enabled || economy == null) return 0;
        try {
            OfflinePlayer player = Bukkit.getOfflinePlayer(playerId);
            java.lang.reflect.Method method = economyClass.getMethod("getBalance", OfflinePlayer.class);
            Object result = method.invoke(economy, player);
            return result instanceof Number ? ((Number) result).doubleValue() : 0;
        } catch (Exception e) {
            return 0;
        }
    }
    
    /**
     * Deposit money to a player.
     */
    public boolean deposit(UUID playerId, double amount) {
        if (!enabled || economy == null) return false;
        try {
            OfflinePlayer player = Bukkit.getOfflinePlayer(playerId);
            java.lang.reflect.Method method = economyClass.getMethod("depositPlayer", OfflinePlayer.class, double.class);
            Object response = method.invoke(economy, player, amount);
            Class<?> responseClass = Class.forName("net.milkbowl.vault.economy.EconomyResponse");
            java.lang.reflect.Method successMethod = responseClass.getMethod("transactionSuccess");
            return (Boolean) successMethod.invoke(response);
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Withdraw money from a player.
     */
    public boolean withdraw(UUID playerId, double amount) {
        if (!enabled || economy == null) return false;
        try {
            OfflinePlayer player = Bukkit.getOfflinePlayer(playerId);
            java.lang.reflect.Method method = economyClass.getMethod("withdrawPlayer", OfflinePlayer.class, double.class);
            Object response = method.invoke(economy, player, amount);
            Class<?> responseClass = Class.forName("net.milkbowl.vault.economy.EconomyResponse");
            java.lang.reflect.Method successMethod = responseClass.getMethod("transactionSuccess");
            return (Boolean) successMethod.invoke(response);
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Check if a player has enough money.
     */
    public boolean has(UUID playerId, double amount) {
        if (!enabled || economy == null) return false;
        try {
            OfflinePlayer player = Bukkit.getOfflinePlayer(playerId);
            java.lang.reflect.Method method = economyClass.getMethod("has", OfflinePlayer.class, double.class);
            Object result = method.invoke(economy, player, amount);
            return result instanceof Boolean && (Boolean) result;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Format money amount.
     */
    public String format(double amount) {
        if (!enabled || economy == null) return String.format("%.2f", amount);
        try {
            java.lang.reflect.Method method = economyClass.getMethod("format", double.class);
            Object result = method.invoke(economy, amount);
            return result != null ? result.toString() : String.format("%.2f", amount);
        } catch (Exception e) {
            return String.format("%.2f", amount);
        }
    }
    
    public boolean isEnabled() {
        return enabled;
    }
}

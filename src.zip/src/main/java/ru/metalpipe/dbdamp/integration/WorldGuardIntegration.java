package ru.metalpipe.dbdamp.integration;

import org.bukkit.Bukkit;
import org.bukkit.Location;

import java.util.Collections;
import java.util.Set;
import java.util.logging.Logger;

/**
 * Integration with WorldGuard for region-based features.
 * Uses reflection to avoid hard dependency.
 */
public class WorldGuardIntegration implements PluginIntegration {
    
    private final Logger logger;
    private boolean enabled;
    private Object worldGuardInstance;
    
    public WorldGuardIntegration() {
        this.logger = Logger.getLogger(getClass().getName());
        this.enabled = false;
    }
    
    @Override
    public String getPluginName() {
        return "WorldGuard";
    }
    
    @Override
    public boolean enable() {
        if (!PluginIntegrationManager.isPluginInstalled("WorldGuard")) {
            return false;
        }
        
        try {
            Class<?> worldGuardClass = Class.forName("com.sk89q.worldguard.WorldGuard");
            java.lang.reflect.Method getInstanceMethod = worldGuardClass.getMethod("getInstance");
            worldGuardInstance = getInstanceMethod.invoke(null);
            enabled = true;
            logger.info("WorldGuard integration enabled");
            return true;
        } catch (ClassNotFoundException e) {
            logger.warning("WorldGuard API not found in classpath");
            return false;
        } catch (Exception e) {
            logger.warning("Failed to enable WorldGuard integration: " + e.getMessage());
            return false;
        }
    }
    
    @Override
    public void disable() {
        worldGuardInstance = null;
        enabled = false;
    }
    
    /**
     * Check if a location is in a region with a specific flag.
     */
    public boolean hasFlag(Location location, String flagName) {
        if (!enabled || worldGuardInstance == null || location == null || location.getWorld() == null) {
            return false;
        }
        
        try {
            // Get platform
            java.lang.reflect.Method getPlatformMethod = worldGuardInstance.getClass().getMethod("getPlatform");
            Object platform = getPlatformMethod.invoke(worldGuardInstance);
            
            // Get region container
            java.lang.reflect.Method getRegionContainerMethod = platform.getClass().getMethod("getRegionContainer");
            Object regionContainer = getRegionContainerMethod.invoke(platform);
            
            // Create query
            java.lang.reflect.Method createQueryMethod = regionContainer.getClass().getMethod("createQuery");
            Object query = createQueryMethod.invoke(regionContainer);
            
            // Get the flag
            Class<?> flagRegistryClass = Class.forName("com.sk89q.worldguard.protection.flags.registry.FlagRegistry");
            java.lang.reflect.Method getFlagRegistryMethod = worldGuardInstance.getClass().getMethod("getFlagRegistry");
            Object flagRegistry = getFlagRegistryMethod.invoke(worldGuardInstance);
            
            java.lang.reflect.Method getMethod = flagRegistryClass.getMethod("get", String.class);
            Object flag = getMethod.invoke(flagRegistry, flagName);
            
            if (flag == null) return false;
            
            // Test state
            Class<?> stateFlagClass = Class.forName("com.sk89q.worldguard.protection.flags.StateFlag");
            java.lang.reflect.Method testStateMethod = query.getClass().getMethod("testState", 
                Class.forName("com.sk89q.worldedit.util.Location"), 
                stateFlagClass.arrayType());
            
            // Convert Bukkit location to WorldEdit location
            Object worldEditLocation = convertLocation(location);
            if (worldEditLocation == null) return false;
            
            Object result = testStateMethod.invoke(query, worldEditLocation, new Object[] { flag });
            return result instanceof Boolean && (Boolean) result;
        } catch (Exception e) {
            logger.fine("Failed to check WorldGuard flag: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Check if a location is in a DBD match region.
     */
    public boolean isInMatchRegion(Location location) {
        return hasFlag(location, "dbd-match-region");
    }
    
    /**
     * Check if a location is a safe zone.
     */
    public boolean isSafeZone(Location location) {
        return hasFlag(location, "dbd-safe-zone");
    }
    
    /**
     * Convert Bukkit location to WorldEdit location.
     */
    private Object convertLocation(Location location) {
        try {
            Class<?> worldEditClass = Class.forName("com.sk89q.worldedit.WorldEdit");
            java.lang.reflect.Method getInstanceMethod = worldEditClass.getMethod("getInstance");
            Object worldEdit = getInstanceMethod.invoke(null);
            
            java.lang.reflect.Method getPlatformManagerMethod = worldEdit.getClass().getMethod("getPlatformManager");
            Object platformManager = getPlatformManagerMethod.invoke(worldEdit);
            
            java.lang.reflect.Method queryCapabilityMethod = platformManager.getClass().getMethod("queryCapability", 
                Class.forName("com.sk89q.worldedit.extension.platform.Capability"));
            
            Class<?> capabilityClass = Class.forName("com.sk89q.worldedit.extension.platform.Capability");
            Object worldEditing = java.lang.reflect.Array.get(capabilityClass.getMethod("values").invoke(null), 0);
            Object platform = queryCapabilityMethod.invoke(platformManager, worldEditing);
            
            java.lang.reflect.Method adaptMethod = platform.getClass().getMethod("adapt", org.bukkit.World.class);
            Object adaptedWorld = adaptMethod.invoke(platform, location.getWorld());
            
            Class<?> locationClass = Class.forName("com.sk89q.worldedit.util.Location");
            java.lang.reflect.Method atMethod = locationClass.getMethod("at", 
                Class.forName("com.sk89q.worldedit.world.World"), 
                double.class, double.class, double.class);
            
            return atMethod.invoke(null, adaptedWorld, location.getX(), location.getY(), location.getZ());
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Get all regions at a location.
     */
    public Set<?> getRegionsAt(Location location) {
        if (!enabled || location == null) return Collections.emptySet();
        // Simplified implementation
        return Collections.emptySet();
    }
    
    public boolean isEnabled() {
        return enabled;
    }
}

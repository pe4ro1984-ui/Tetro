package ru.metalpipe.dbdamp.integration;

/**
 * Base interface for plugin integrations.
 */
public interface PluginIntegration {
    
    /**
     * Get the name of the plugin this integrates with.
     * 
     * @return The plugin name
     */
    String getPluginName();
    
    /**
     * Enable the integration.
     * 
     * @return true if the integration was enabled successfully
     */
    boolean enable();
    
    /**
     * Disable the integration.
     */
    void disable();
    
    /**
     * Check if this integration is optional.
     * Optional integrations don't prevent the plugin from working if missing.
     * 
     * @return true if this integration is optional
     */
    default boolean isOptional() {
        return true;
    }
}

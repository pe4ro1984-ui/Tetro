package ru.metalpipe.dbdamp.integration;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Manages integration with external plugins.
 * Supports optional integrations that enhance the DBD-AMP experience.
 */
public class PluginIntegrationManager {
    
    private final Logger logger;
    private final Map<String, PluginIntegration> integrations;
    private final Map<String, Boolean> integrationStatus;
    
    public PluginIntegrationManager() {
        this.logger = Logger.getLogger(getClass().getName());
        this.integrations = new HashMap<>();
        this.integrationStatus = new HashMap<>();
    }
    
    /**
     * Initialize all plugin integrations.
     */
    public void initializeIntegrations() {
        logger.info("Initializing plugin integrations...");
        
        // Register integrations
        registerIntegration("Vault", new VaultIntegration());
        registerIntegration("PlaceholderAPI", new PlaceholderAPIIntegration());
        registerIntegration("ItemsAdder", new ItemsAdderIntegration());
        registerIntegration("MythicMobs", new MythicMobsIntegration());
        registerIntegration("KillEffect", new KillEffectIntegration());
        registerIntegration("LuckPerms", new LuckPermsIntegration());
        registerIntegration("WorldGuard", new WorldGuardIntegration());
        registerIntegration("DeluxeMenus", new DeluxeMenusIntegration());
        
        // Enable all integrations
        for (Map.Entry<String, PluginIntegration> entry : integrations.entrySet()) {
            String pluginName = entry.getKey();
            PluginIntegration integration = entry.getValue();
            
            try {
                boolean enabled = integration.enable();
                integrationStatus.put(pluginName, enabled);
                
                if (enabled) {
                    logger.info("§a[✓] " + pluginName + " integration enabled");
                } else {
                    logger.info("§7[ ] " + pluginName + " not found (optional)");
                }
            } catch (Exception e) {
                integrationStatus.put(pluginName, false);
                logger.warning("§c[!] " + pluginName + " integration failed: " + e.getMessage());
            }
        }
        
        logger.info("Plugin integrations initialized");
    }
    
    /**
     * Register a plugin integration.
     * 
     * @param pluginName The name of the plugin
     * @param integration The integration instance
     */
    public void registerIntegration(String pluginName, PluginIntegration integration) {
        integrations.put(pluginName, integration);
    }
    
    /**
     * Check if a plugin integration is enabled.
     * 
     * @param pluginName The plugin name
     * @return true if the integration is active
     */
    public boolean isIntegrationEnabled(String pluginName) {
        return integrationStatus.getOrDefault(pluginName, false);
    }
    
    /**
     * Get an integration instance.
     * 
     * @param pluginName The plugin name
     * @param <T> The integration type
     * @return The integration, or null if not enabled
     */
    @SuppressWarnings("unchecked")
    public <T extends PluginIntegration> T getIntegration(String pluginName) {
        if (!isIntegrationEnabled(pluginName)) {
            return null;
        }
        return (T) integrations.get(pluginName);
    }
    
    /**
     * Disable all integrations.
     */
    public void disableIntegrations() {
        for (Map.Entry<String, PluginIntegration> entry : integrations.entrySet()) {
            if (integrationStatus.getOrDefault(entry.getKey(), false)) {
                try {
                    entry.getValue().disable();
                } catch (Exception e) {
                    logger.warning("Failed to disable " + entry.getKey() + ": " + e.getMessage());
                }
            }
        }
        integrations.clear();
        integrationStatus.clear();
    }
    
    /**
     * Check if a plugin is installed.
     * 
     * @param pluginName The plugin name
     * @return true if the plugin is installed
     */
    public static boolean isPluginInstalled(String pluginName) {
        Plugin plugin = Bukkit.getPluginManager().getPlugin(pluginName);
        return plugin != null && plugin.isEnabled();
    }
    
    /**
     * Get the version of an installed plugin.
     * 
     * @param pluginName The plugin name
     * @return The version, or null if not installed
     */
    public static String getPluginVersion(String pluginName) {
        Plugin plugin = Bukkit.getPluginManager().getPlugin(pluginName);
        return plugin != null ? plugin.getDescription().getVersion() : null;
    }
    
    /**
     * Get integration status summary.
     * 
     * @return A map of plugin names to their status
     */
    public Map<String, Boolean> getIntegrationStatus() {
        return new HashMap<>(integrationStatus);
    }
}

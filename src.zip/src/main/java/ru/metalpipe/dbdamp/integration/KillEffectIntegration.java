package ru.metalpipe.dbdamp.integration;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.UUID;
import java.util.logging.Logger;

/**
 * Integration with KillEffect plugins.
 * Provides custom death effects for DBD-AMP matches.
 */
public class KillEffectIntegration implements PluginIntegration {
    
    private final Logger logger;
    private boolean enabled;
    private Plugin killEffectPlugin;
    
    // Available kill effect types
    public enum KillEffectType {
        BLOOD_EXPLOSION,
        LIGHTNING_STRIKE,
        SOUL_RIP,
        FIREWORK,
        PARTICLE_BURST,
        CUSTOM_MODEL
    }
    
    public KillEffectIntegration() {
        this.logger = Logger.getLogger(getClass().getName());
        this.enabled = false;
    }
    
    @Override
    public String getPluginName() {
        return "KillEffect";
    }
    
    @Override
    public boolean enable() {
        // Check for various KillEffect plugins
        String[] possiblePlugins = {"KillEffect", "KillEffects", "KillEffectZ", "UltimateKillEffect"};
        
        for (String pluginName : possiblePlugins) {
            if (PluginIntegrationManager.isPluginInstalled(pluginName)) {
                killEffectPlugin = Bukkit.getPluginManager().getPlugin(pluginName);
                enabled = true;
                logger.info("KillEffect integration enabled: " + pluginName);
                return true;
            }
        }
        
        return false;
    }
    
    @Override
    public void disable() {
        killEffectPlugin = null;
        enabled = false;
    }
    
    /**
     * Play a kill effect at a location.
     * 
     * @param location The location
     * @param effectType The effect type
     */
    public void playKillEffect(Location location, KillEffectType effectType) {
        if (!enabled || location == null || location.getWorld() == null) {
            // Fallback to vanilla effects
            playVanillaEffect(location, effectType);
            return;
        }
        
        // Try to use the installed KillEffect plugin
        try {
            playVanillaEffect(location, effectType);
        } catch (Exception e) {
            logger.warning("Failed to play kill effect: " + e.getMessage());
        }
    }
    
    /**
     * Play a kill effect for a victim.
     * 
     * @param victim The victim player
     * @param killer The killer player (can be null)
     * @param effectType The effect type
     */
    public void playKillEffect(Player victim, Player killer, KillEffectType effectType) {
        if (victim == null) return;
        
        Location location = victim.getLocation();
        playKillEffect(location, effectType);
        
        // Additional effects based on killer
        if (killer != null) {
            killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.2f);
        }
    }
    
    /**
     * Play a vanilla Minecraft effect as fallback.
     */
    private void playVanillaEffect(Location location, KillEffectType effectType) {
        if (location == null || location.getWorld() == null) return;
        
        switch (effectType) {
            case BLOOD_EXPLOSION:
                location.getWorld().spawnParticle(Particle.REDSTONE, location, 50, 1, 1, 1, 0.1,
                    new Particle.DustOptions(org.bukkit.Color.RED, 2));
                location.getWorld().playSound(location, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.5f);
                break;
                
            case LIGHTNING_STRIKE:
                location.getWorld().strikeLightningEffect(location);
                location.getWorld().playSound(location, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 1.0f);
                break;
                
            case SOUL_RIP:
                location.getWorld().spawnParticle(Particle.SOUL, location, 30, 0.5, 1, 0.5, 0.2);
                location.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, location, 20, 0.5, 1, 0.5, 0.1);
                location.getWorld().playSound(location, Sound.ENTITY_WITHER_SHOOT, 0.5f, 1.5f);
                break;
                
            case FIREWORK:
                org.bukkit.entity.Firework firework = location.getWorld().spawn(location, org.bukkit.entity.Firework.class);
                org.bukkit.inventory.meta.FireworkMeta meta = firework.getFireworkMeta();
                meta.addEffect(org.bukkit.FireworkEffect.builder()
                    .withColor(org.bukkit.Color.RED)
                    .withFade(org.bukkit.Color.BLACK)
                    .with(org.bukkit.FireworkEffect.Type.BURST)
                    .build());
                meta.setPower(0);
                firework.setFireworkMeta(meta);
                // Detonate immediately
                Bukkit.getScheduler().runTaskLater(killEffectPlugin != null ? killEffectPlugin : 
                    Bukkit.getPluginManager().getPlugin("DBD-AMP"), firework::detonate, 1);
                break;
                
            case PARTICLE_BURST:
                location.getWorld().spawnParticle(Particle.EXPLOSION_LARGE, location, 5, 0.5, 0.5, 0.5, 0.1);
                location.getWorld().spawnParticle(Particle.FLAME, location, 40, 1, 1, 1, 0.2);
                location.getWorld().playSound(location, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1.0f, 0.8f);
                break;
                
            case CUSTOM_MODEL:
                // For custom models, spawn particles in a specific pattern
                for (int i = 0; i < 360; i += 30) {
                    double x = Math.cos(Math.toRadians(i)) * 2;
                    double z = Math.sin(Math.toRadians(i)) * 2;
                    Location particleLoc = location.clone().add(x, 1, z);
                    location.getWorld().spawnParticle(Particle.HEART, particleLoc, 3, 0, 0, 0, 0);
                }
                break;
        }
    }
    
    /**
     * Play a sacrifice effect (for hook sacrifice in DBD).
     * 
     * @param location The sacrifice location
     */
    public void playSacrificeEffect(Location location) {
        if (location == null || location.getWorld() == null) return;
        
        // Soul particles rising
        for (int i = 0; i < 3; i++) {
            final double yOffset = i * 2;
            Bukkit.getScheduler().runTaskLater(killEffectPlugin != null ? killEffectPlugin :
                Bukkit.getPluginManager().getPlugin("DBD-AMP"), () -> {
                    location.getWorld().spawnParticle(Particle.SOUL, location.clone().add(0, yOffset, 0), 20, 0.3, 0.5, 0.3, 0.1);
                }, i * 10L);
        }
        
        location.getWorld().playSound(location, Sound.ENTITY_WITHER_AMBIENT, 1.0f, 0.8f);
        location.getWorld().playSound(location, Sound.BLOCK_BELL_USE, 1.0f, 0.5f);
    }
    
    /**
     * Play an escape effect (for survivor escape).
     * 
     * @param location The escape location
     */
    public void playEscapeEffect(Location location) {
        if (location == null || location.getWorld() == null) return;
        
        location.getWorld().spawnParticle(Particle.TOTEM, location, 50, 1, 2, 1, 0.5);
        location.getWorld().spawnParticle(Particle.END_ROD, location, 30, 1, 2, 1, 0.2);
        location.getWorld().playSound(location, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
    }
    
    public boolean isEnabled() {
        return enabled;
    }
}

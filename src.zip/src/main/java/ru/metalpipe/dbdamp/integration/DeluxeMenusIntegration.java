package ru.metalpipe.dbdamp.integration;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Integration with DeluxeMenus for GUI menu support.
 * Provides easy-to-use GUI menus for DBD-AMP features.
 */
public class DeluxeMenusIntegration implements PluginIntegration {
    
    private final Logger logger;
    private boolean enabled;
    private Plugin deluxeMenusPlugin;
    
    public DeluxeMenusIntegration() {
        this.logger = Logger.getLogger(getClass().getName());
        this.enabled = false;
    }
    
    @Override
    public String getPluginName() {
        return "DeluxeMenus";
    }
    
    @Override
    public boolean enable() {
        if (!PluginIntegrationManager.isPluginInstalled("DeluxeMenus")) {
            return false;
        }
        
        try {
            deluxeMenusPlugin = Bukkit.getPluginManager().getPlugin("DeluxeMenus");
            enabled = true;
            logger.info("DeluxeMenus integration enabled");
            return true;
        } catch (Exception e) {
            logger.warning("Failed to enable DeluxeMenus integration: " + e.getMessage());
            return false;
        }
    }
    
    @Override
    public void disable() {
        deluxeMenusPlugin = null;
        enabled = false;
    }
    
    /**
     * Open a menu for a player.
     * 
     * @param player The player
     * @param menuName The menu identifier
     * @return true if the menu was opened
     */
    public boolean openMenu(Player player, String menuName) {
        if (!enabled || player == null || menuName == null) {
            return false;
        }
        
        try {
            // Use DeluxeMenus API via reflection
            Class<?> deluxeMenusClass = Class.forName("com.extendedclip.deluxemenus.DeluxeMenus");
            java.lang.reflect.Method getMenuMethod = deluxeMenusClass.getMethod("getMenu", String.class);
            Object menu = getMenuMethod.invoke(null, menuName);
            
            if (menu != null) {
                java.lang.reflect.Method openMethod = menu.getClass().getMethod("openMenu", Player.class);
                openMethod.invoke(menu, player);
                return true;
            }
        } catch (ClassNotFoundException e) {
            // Try alternative method - execute command
            return openMenuByCommand(player, menuName);
        } catch (Exception e) {
            logger.fine("Failed to open menu " + menuName + ": " + e.getMessage());
            return openMenuByCommand(player, menuName);
        }
        
        return false;
    }
    
    /**
     * Open menu using command (fallback method).
     */
    private boolean openMenuByCommand(Player player, String menuName) {
        try {
            Bukkit.dispatchCommand(player, "dm open " + menuName);
            return true;
        } catch (Exception e) {
            logger.warning("Failed to open menu via command: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Check if a menu exists.
     * 
     * @param menuName The menu name
     * @return true if the menu exists
     */
    public boolean menuExists(String menuName) {
        if (!enabled || menuName == null) {
            return false;
        }
        
        try {
            Class<?> deluxeMenusClass = Class.forName("com.extendedclip.deluxemenus.DeluxeMenus");
            java.lang.reflect.Method getMenuMethod = deluxeMenusClass.getMethod("getMenu", String.class);
            Object menu = getMenuMethod.invoke(null, menuName);
            return menu != null;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Open the main DBD menu for a player.
     * 
     * @param player The player
     * @return true if successful
     */
    public boolean openMainMenu(Player player) {
        return openMenu(player, "dbd_main");
    }
    
    /**
     * Open the perk selection menu.
     * 
     * @param player The player
     * @return true if successful
     */
    public boolean openPerkMenu(Player player) {
        return openMenu(player, "dbd_perks");
    }
    
    /**
     * Open the shop menu.
     * 
     * @param player The player
     * @return true if successful
     */
    public boolean openShopMenu(Player player) {
        return openMenu(player, "dbd_shop");
    }
    
    /**
     * Open the lobby menu.
     * 
     * @param player The player
     * @return true if successful
     */
    public boolean openLobbyMenu(Player player) {
        return openMenu(player, "dbd_lobby");
    }
    
    /**
     * Open the statistics menu.
     * 
     * @param player The player
     * @return true if successful
     */
    public boolean openStatsMenu(Player player) {
        return openMenu(player, "dbd_stats");
    }
    
    /**
     * Open the killer select menu.
     * 
     * @param player The player
     * @return true if successful
     */
    public boolean openKillerSelectMenu(Player player) {
        return openMenu(player, "dbd_killer_select");
    }
    
    /**
     * Open the survivor select menu.
     * 
     * @param player The player
     * @return true if successful
     */
    public boolean openSurvivorSelectMenu(Player player) {
        return openMenu(player, "dbd_survivor_select");
    }
    
    /**
     * Open the event shop menu (Stalcraft X).
     * 
     * @param player The player
     * @return true if successful
     */
    public boolean openEventShopMenu(Player player) {
        return openMenu(player, "dbd_event_shop");
    }
    
    /**
     * Open the settings menu.
     * 
     * @param player The player
     * @return true if successful
     */
    public boolean openSettingsMenu(Player player) {
        return openMenu(player, "dbd_settings");
    }
    
    /**
     * Get placeholders for a player to use in menus.
     * 
     * @param player The player
     * @return Map of placeholders
     */
    public Map<String, String> getPlayerPlaceholders(Player player) {
        Map<String, String> placeholders = new HashMap<>();
        
        if (player == null) {
            return placeholders;
        }
        
        // Basic placeholders
        placeholders.put("player_name", player.getName());
        placeholders.put("player_uuid", player.getUniqueId().toString());
        
        // DBD-AMP specific placeholders (would be populated from actual data)
        placeholders.put("dbd_level", "1");
        placeholders.put("dbd_bloodpoints", "0");
        placeholders.put("dbd_escapes", "0");
        placeholders.put("dbd_kills", "0");
        placeholders.put("dbd_generators", "0");
        
        return placeholders;
    }
    
    public boolean isEnabled() {
        return enabled;
    }
}

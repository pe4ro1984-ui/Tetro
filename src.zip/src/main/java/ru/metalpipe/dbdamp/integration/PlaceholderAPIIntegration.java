package ru.metalpipe.dbdamp.integration;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.logging.Logger;

/**
 * Integration with PlaceholderAPI for placeholder support.
 * Uses reflection to avoid hard dependency.
 */
public class PlaceholderAPIIntegration implements PluginIntegration {
    
    private final Logger logger;
    private boolean enabled;
    private Class<?> placeholderAPIClass;
    
    public PlaceholderAPIIntegration() {
        this.logger = Logger.getLogger(getClass().getName());
        this.enabled = false;
    }
    
    @Override
    public String getPluginName() {
        return "PlaceholderAPI";
    }
    
    @Override
    public boolean enable() {
        if (!PluginIntegrationManager.isPluginInstalled("PlaceholderAPI")) {
            return false;
        }
        
        try {
            placeholderAPIClass = Class.forName("me.clip.placeholderapi.PlaceholderAPI");
            enabled = true;
            logger.info("PlaceholderAPI integration enabled");
            return true;
        } catch (ClassNotFoundException e) {
            logger.warning("PlaceholderAPI not found in classpath");
            return false;
        }
    }
    
    @Override
    public void disable() {
        enabled = false;
        placeholderAPIClass = null;
    }
    
    /**
     * Set placeholders in a string for a player.
     */
    public String setPlaceholders(Player player, String text) {
        if (!enabled || player == null || text == null) {
            return text;
        }
        
        try {
            java.lang.reflect.Method method = placeholderAPIClass.getMethod("setPlaceholders", Player.class, String.class);
            Object result = method.invoke(null, player, text);
            return result != null ? result.toString() : text;
        } catch (Exception e) {
            logger.fine("Failed to set placeholders: " + e.getMessage());
            return text;
        }
    }
    
    /**
     * Set placeholders in a string for an offline player.
     */
    public String setPlaceholders(OfflinePlayer player, String text) {
        if (!enabled || player == null || text == null) {
            return text;
        }
        
        try {
            java.lang.reflect.Method method = placeholderAPIClass.getMethod("setPlaceholders", OfflinePlayer.class, String.class);
            Object result = method.invoke(null, player, text);
            return result != null ? result.toString() : text;
        } catch (Exception e) {
            logger.fine("Failed to set placeholders: " + e.getMessage());
            return text;
        }
    }
    
    /**
     * Check if a string contains placeholders.
     */
    public boolean containsPlaceholders(String text) {
        if (!enabled || text == null) {
            return false;
        }
        
        try {
            java.lang.reflect.Method method = placeholderAPIClass.getMethod("containsPlaceholder", String.class);
            Object result = method.invoke(null, text);
            return result instanceof Boolean && (Boolean) result;
        } catch (Exception e) {
            return false;
        }
    }
    
    public boolean isEnabled() {
        return enabled;
    }
}

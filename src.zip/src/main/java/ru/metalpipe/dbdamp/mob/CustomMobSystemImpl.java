package ru.metalpipe.dbdamp.mob;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Implementation of the custom mob system.
 * Manages custom mobs with special behaviors and abilities.
 */
public class CustomMobSystemImpl implements CustomMobSystem {
    
    private final Logger logger;
    private final Map<String, CustomMob> registeredMobs;
    private final Map<UUID, SpawnedMob> spawnedMobs;
    private final Map<String, MobSkill> registeredSkills;
    private final NamespacedKey mobIdKey;
    
    public CustomMobSystemImpl() {
        this.logger = Logger.getLogger(getClass().getName());
        this.registeredMobs = new ConcurrentHashMap<>();
        this.spawnedMobs = new ConcurrentHashMap<>();
        this.registeredSkills = new ConcurrentHashMap<>();
        this.mobIdKey = new NamespacedKey("dbdamp", "custom_mob_id");
    }
    
    @Override
    public boolean registerMob(String mobId, Map<String, Object> config) {
        if (registeredMobs.containsKey(mobId)) {
            logger.warning("Mob " + mobId + " is already registered");
            return false;
        }
        
        try {
            CustomMob mob = parseMobConfig(mobId, config);
            registeredMobs.put(mobId, mob);
            logger.info("Registered custom mob: " + mobId);
            return true;
        } catch (Exception e) {
            logger.severe("Failed to register mob " + mobId + ": " + e.getMessage());
            return false;
        }
    }
    
    private CustomMob parseMobConfig(String mobId, Map<String, Object> config) {
        String displayName = (String) config.getOrDefault("display_name", mobId);
        String displayType = (String) config.getOrDefault("display_type", "minion");
        
        String entityTypeName = (String) config.getOrDefault("entity_type", "ZOMBIE");
        EntityType entityType;
        try {
            entityType = EntityType.valueOf(entityTypeName.toUpperCase());
        } catch (IllegalArgumentException e) {
            entityType = EntityType.ZOMBIE;
        }
        
        int baseHealth = ((Number) config.getOrDefault("base_health", 20)).intValue();
        int baseDamage = ((Number) config.getOrDefault("base_damage", 5)).intValue();
        int baseArmor = ((Number) config.getOrDefault("base_armor", 0)).intValue();
        double baseSpeed = ((Number) config.getOrDefault("base_speed", 0.25)).doubleValue();
        
        @SuppressWarnings("unchecked")
        List<String> skills = (List<String>) config.getOrDefault("skills", new ArrayList<>());
        
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> lootConfig = (List<Map<String, Object>>) config.getOrDefault("loot_table", new ArrayList<>());
        List<LootEntry> lootTable = new ArrayList<>();
        for (Map<String, Object> entry : lootConfig) {
            String itemId = (String) entry.getOrDefault("item_id", "");
            double chance = ((Number) entry.getOrDefault("chance", 0.0)).doubleValue();
            int minAmount = ((Number) entry.getOrDefault("min_amount", 1)).intValue();
            int maxAmount = ((Number) entry.getOrDefault("max_amount", 1)).intValue();
            lootTable.add(new LootEntry(itemId, chance, minAmount, maxAmount));
        }
        
        @SuppressWarnings("unchecked")
        Map<String, Object> options = (Map<String, Object>) config.getOrDefault("options", new HashMap<>());
        
        return new CustomMob(mobId, displayName, displayType, entityType, baseHealth, 
                           baseDamage, baseArmor, baseSpeed, skills, lootTable, options);
    }
    
    @Override
    public void unregisterMob(String mobId) {
        registeredMobs.remove(mobId);
        logger.info("Unregistered custom mob: " + mobId);
    }
    
    @Override
    public Optional<CustomMob> getMob(String mobId) {
        return Optional.ofNullable(registeredMobs.get(mobId));
    }
    
    @Override
    public Optional<LivingEntity> spawnMob(String mobId, Location location) {
        return spawnMob(mobId, location, 1);
    }
    
    @Override
    public Optional<LivingEntity> spawnMob(String mobId, Location location, int level) {
        CustomMob customMob = registeredMobs.get(mobId);
        if (customMob == null || location == null || location.getWorld() == null) {
            return Optional.empty();
        }
        
        try {
            Entity entity = location.getWorld().spawnEntity(location, customMob.getEntityType());
            if (!(entity instanceof LivingEntity)) {
                entity.remove();
                return Optional.empty();
            }
            
            LivingEntity livingEntity = (LivingEntity) entity;
            
            // Apply stats
            int health = customMob.getBaseHealth() * level;
            int damage = customMob.getBaseDamage() * level;
            int armor = customMob.getBaseArmor() * level;
            double speed = customMob.getBaseSpeed();
            
            // Set attributes
            AttributeInstance healthAttr = livingEntity.getAttribute(Attribute.GENERIC_MAX_HEALTH);
            if (healthAttr != null) {
                healthAttr.setBaseValue(health);
                livingEntity.setHealth(health);
            }
            
            AttributeInstance damageAttr = livingEntity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE);
            if (damageAttr != null) {
                damageAttr.setBaseValue(damage);
            }
            
            AttributeInstance armorAttr = livingEntity.getAttribute(Attribute.GENERIC_ARMOR);
            if (armorAttr != null) {
                armorAttr.setBaseValue(armor);
            }
            
            AttributeInstance speedAttr = livingEntity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
            if (speedAttr != null) {
                speedAttr.setBaseValue(speed);
            }
            
            // Set custom name
            livingEntity.setCustomName(customMob.getDisplayName() + (level > 1 ? " §7Lv." + level : ""));
            livingEntity.setCustomNameVisible(true);
            
            // Store mob ID
            PersistentDataContainer container = livingEntity.getPersistentDataContainer();
            container.set(mobIdKey, PersistentDataType.STRING, mobId);
            
            // Create spawned mob instance
            MobStats stats = new MobStats(health, damage, armor, speed);
            SpawnedMob spawnedMob = new SpawnedMob(entity.getUniqueId(), mobId, livingEntity, level, stats);
            spawnedMobs.put(entity.getUniqueId(), spawnedMob);
            
            logger.fine("Spawned " + mobId + " at " + location);
            return Optional.of(livingEntity);
        } catch (Exception e) {
            logger.warning("Failed to spawn mob " + mobId + ": " + e.getMessage());
            return Optional.empty();
        }
    }
    
    @Override
    public boolean isCustomMob(Entity entity) {
        if (entity == null) return false;
        PersistentDataContainer container = entity.getPersistentDataContainer();
        return container.has(mobIdKey, PersistentDataType.STRING);
    }
    
    @Override
    public Optional<String> getMobId(Entity entity) {
        if (!isCustomMob(entity)) return Optional.empty();
        PersistentDataContainer container = entity.getPersistentDataContainer();
        return Optional.ofNullable(container.get(mobIdKey, PersistentDataType.STRING));
    }
    
    @Override
    public Map<UUID, SpawnedMob> getSpawnedMobs() {
        return new HashMap<>(spawnedMobs);
    }
    
    @Override
    public List<SpawnedMob> getSpawnedMobsByType(String mobId) {
        return spawnedMobs.values().stream()
            .filter(mob -> mob.getMobId().equals(mobId))
            .toList();
    }
    
    @Override
    public boolean killMob(UUID entityId) {
        SpawnedMob mob = spawnedMobs.get(entityId);
        if (mob == null) return false;
        
        LivingEntity entity = mob.getEntity();
        if (entity != null && !entity.isDead()) {
            entity.setHealth(0);
        }
        spawnedMobs.remove(entityId);
        return true;
    }
    
    @Override
    public Optional<MobStats> getMobStats(Entity entity) {
        if (!isCustomMob(entity)) return Optional.empty();
        SpawnedMob mob = spawnedMobs.get(entity.getUniqueId());
        return mob != null ? Optional.of(mob.getStats()) : Optional.empty();
    }
    
    @Override
    public void registerSkill(String skillId, MobSkill skill) {
        registeredSkills.put(skillId, skill);
        logger.fine("Registered mob skill: " + skillId);
    }
    
    @Override
    public boolean triggerSkill(SpawnedMob mob, String skillId) {
        MobSkill skill = registeredSkills.get(skillId);
        if (skill == null || mob == null) return false;
        
        if (!skill.canUse(mob)) return false;
        
        boolean executed = skill.execute(mob, null);
        if (executed) {
            mob.updateLastSkillUse();
        }
        return executed;
    }
    
    @Override
    public void updateMobs() {
        // Update all spawned mobs - called every tick
        Iterator<Map.Entry<UUID, SpawnedMob>> iter = spawnedMobs.entrySet().iterator();
        
        while (iter.hasNext()) {
            Map.Entry<UUID, SpawnedMob> entry = iter.next();
            SpawnedMob mob = entry.getValue();
            
            // Remove dead mobs
            if (mob.getEntity() == null || mob.getEntity().isDead()) {
                iter.remove();
                continue;
            }
            
            // Update alive time
            mob.getStats().addAliveTime(1);
        }
    }
    
    @Override
    public Map<String, CustomMob> getAllMobs() {
        return new HashMap<>(registeredMobs);
    }
}

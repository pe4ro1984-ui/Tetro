package ru.metalpipe.dbdamp.mob;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * System for creating and managing custom mobs with special abilities.
 * Provides MythicMobs-like functionality for custom mob behaviors.
 */
public interface CustomMobSystem {
    
    /**
     * Register a custom mob type from configuration.
     * 
     * @param mobId The unique ID for this mob type
     * @param config The configuration map for the mob
     * @return true if the mob was registered successfully
     */
    boolean registerMob(String mobId, Map<String, Object> config);
    
    /**
     * Unregister a custom mob type.
     * 
     * @param mobId The mob ID to unregister
     */
    void unregisterMob(String mobId);
    
    /**
     * Get a custom mob type by ID.
     * 
     * @param mobId The mob ID
     * @return The custom mob definition, or empty if not found
     */
    Optional<CustomMob> getMob(String mobId);
    
    /**
     * Spawn a custom mob at a location.
     * 
     * @param mobId The mob ID to spawn
     * @param location The location to spawn at
     * @return The spawned entity, or empty if failed
     */
    Optional<LivingEntity> spawnMob(String mobId, Location location);
    
    /**
     * Spawn a custom mob with a level modifier.
     * 
     * @param mobId The mob ID to spawn
     * @param location The location to spawn at
     * @param level The level modifier
     * @return The spawned entity, or empty if failed
     */
    Optional<LivingEntity> spawnMob(String mobId, Location location, int level);
    
    /**
     * Check if an entity is a custom mob.
     * 
     * @param entity The entity to check
     * @return true if it's a custom mob
     */
    boolean isCustomMob(Entity entity);
    
    /**
     * Get the custom mob ID from an entity.
     * 
     * @param entity The entity to check
     * @return The mob ID, or empty if not a custom mob
     */
    Optional<String> getMobId(Entity entity);
    
    /**
     * Get all spawned custom mobs.
     * 
     * @return Map of entity UUIDs to mob instances
     */
    Map<UUID, SpawnedMob> getSpawnedMobs();
    
    /**
     * Get all spawned mobs of a specific type.
     * 
     * @param mobId The mob type ID
     * @return List of spawned mobs
     */
    List<SpawnedMob> getSpawnedMobsByType(String mobId);
    
    /**
     * Kill a custom mob.
     * 
     * @param entityId The entity UUID
     * @return true if the mob was killed
     */
    boolean killMob(UUID entityId);
    
    /**
     * Get mob stats for an entity.
     * 
     * @param entity The entity
     * @return The mob stats, or empty if not a custom mob
     */
    Optional<MobStats> getMobStats(Entity entity);
    
    /**
     * Register a custom skill for mobs.
     * 
     * @param skillId The skill ID
     * @param skill The skill
     */
    void registerSkill(String skillId, MobSkill skill);
    
    /**
     * Trigger a skill on a mob.
     * 
     * @param mob The spawned mob
     * @param skillId The skill ID to trigger
     * @return true if the skill was triggered
     */
    boolean triggerSkill(SpawnedMob mob, String skillId);
    
    /**
     * Update all spawned mobs.
     * Called every tick to process AI and behaviors.
     */
    void updateMobs();
    
    /**
     * Get all registered mob types.
     * 
     * @return Map of mob IDs to mob definitions
     */
    Map<String, CustomMob> getAllMobs();
    
    /**
     * Represents a custom mob definition.
     */
    class CustomMob {
        private final String mobId;
        private final String displayName;
        private final String displayType; // boss, elite, minion
        private final EntityType entityType;
        private final int baseHealth;
        private final int baseDamage;
        private final int baseArmor;
        private final double baseSpeed;
        private final List<String> skills;
        private final List<LootEntry> lootTable;
        private final Map<String, Object> options;
        
        public CustomMob(String mobId, String displayName, String displayType, EntityType entityType,
                        int baseHealth, int baseDamage, int baseArmor, double baseSpeed,
                        List<String> skills, List<LootEntry> lootTable, Map<String, Object> options) {
            this.mobId = mobId;
            this.displayName = displayName;
            this.displayType = displayType;
            this.entityType = entityType;
            this.baseHealth = baseHealth;
            this.baseDamage = baseDamage;
            this.baseArmor = baseArmor;
            this.baseSpeed = baseSpeed;
            this.skills = skills;
            this.lootTable = lootTable;
            this.options = options;
        }
        
        public String getMobId() { return mobId; }
        public String getDisplayName() { return displayName; }
        public String getDisplayType() { return displayType; }
        public EntityType getEntityType() { return entityType; }
        public int getBaseHealth() { return baseHealth; }
        public int getBaseDamage() { return baseDamage; }
        public int getBaseArmor() { return baseArmor; }
        public double getBaseSpeed() { return baseSpeed; }
        public List<String> getSkills() { return new ArrayList<>(skills); }
        public List<LootEntry> getLootTable() { return new ArrayList<>(lootTable); }
        public Map<String, Object> getOptions() { return new HashMap<>(options); }
        
        public Object getOption(String key) {
            return options.get(key);
        }
        
        @SuppressWarnings("unchecked")
        public <T> T getOption(String key, T defaultValue) {
            Object value = options.get(key);
            if (value == null) return defaultValue;
            try {
                return (T) value;
            } catch (ClassCastException e) {
                return defaultValue;
            }
        }
    }
    
    /**
     * Represents a spawned instance of a custom mob.
     */
    class SpawnedMob {
        private final UUID entityId;
        private final String mobId;
        private final LivingEntity entity;
        private final int level;
        private final MobStats stats;
        private final List<String> activeSkills;
        private long lastSkillUse;
        
        public SpawnedMob(UUID entityId, String mobId, LivingEntity entity, int level, MobStats stats) {
            this.entityId = entityId;
            this.mobId = mobId;
            this.entity = entity;
            this.level = level;
            this.stats = stats;
            this.activeSkills = new ArrayList<>();
            this.lastSkillUse = 0;
        }
        
        public UUID getEntityId() { return entityId; }
        public String getMobId() { return mobId; }
        public LivingEntity getEntity() { return entity; }
        public int getLevel() { return level; }
        public MobStats getStats() { return stats; }
        public List<String> getActiveSkills() { return new ArrayList<>(activeSkills); }
        public long getLastSkillUse() { return lastSkillUse; }
        
        public void addActiveSkill(String skillId) {
            activeSkills.add(skillId);
        }
        
        public void removeActiveSkill(String skillId) {
            activeSkills.remove(skillId);
        }
        
        public void updateLastSkillUse() {
            lastSkillUse = System.currentTimeMillis();
        }
    }
    
    /**
     * Statistics for a spawned mob.
     */
    class MobStats {
        private int currentHealth;
        private int maxHealth;
        private int damage;
        private int armor;
        private double speed;
        private int kills;
        private long aliveTime;
        
        public MobStats(int maxHealth, int damage, int armor, double speed) {
            this.currentHealth = maxHealth;
            this.maxHealth = maxHealth;
            this.damage = damage;
            this.armor = armor;
            this.speed = speed;
            this.kills = 0;
            this.aliveTime = 0;
        }
        
        public int getCurrentHealth() { return currentHealth; }
        public int getMaxHealth() { return maxHealth; }
        public int getDamage() { return damage; }
        public int getArmor() { return armor; }
        public double getSpeed() { return speed; }
        public int getKills() { return kills; }
        public long getAliveTime() { return aliveTime; }
        
        public void setCurrentHealth(int health) { this.currentHealth = Math.max(0, Math.min(maxHealth, health)); }
        public void addKill() { this.kills++; }
        public void addAliveTime(long time) { this.aliveTime += time; }
        
        public double getHealthPercent() {
            return (double) currentHealth / maxHealth;
        }
    }
    
    /**
     * Entry in a mob's loot table.
     */
    class LootEntry {
        private final String itemId;
        private final double chance;
        private final int minAmount;
        private final int maxAmount;
        
        public LootEntry(String itemId, double chance, int minAmount, int maxAmount) {
            this.itemId = itemId;
            this.chance = chance;
            this.minAmount = minAmount;
            this.maxAmount = maxAmount;
        }
        
        public String getItemId() { return itemId; }
        public double getChance() { return chance; }
        public int getMinAmount() { return minAmount; }
        public int getMaxAmount() { return maxAmount; }
    }
    
    /**
     * Interface for custom mob skills.
     */
    interface MobSkill {
        /**
         * Execute the skill.
         * 
         * @param mob The spawned mob
         * @param target The target (can be null)
         * @return true if the skill was executed successfully
         */
        boolean execute(SpawnedMob mob, LivingEntity target);
        
        /**
         * Check if the skill can be used.
         * 
         * @param mob The spawned mob
         * @return true if the skill can be used
         */
        boolean canUse(SpawnedMob mob);
        
        /**
         * Get the cooldown for this skill in ticks.
         * 
         * @return The cooldown in ticks
         */
        int getCooldown();
        
        /**
         * Get the skill name.
         * 
         * @return The skill name
         */
        String getName();
    }
}

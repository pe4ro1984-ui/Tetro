package ru.metalpipe.dbdamp.matchmaking;

import java.util.List;
import java.util.UUID;

/**
 * Represents a match being formed from queued players.
 */
public class MatchFormation {
    
    private final UUID formationId;
    private final List<QueuedPlayer> players;
    private final long formationTime;
    private final long timeout;
    
    public MatchFormation(UUID formationId, List<QueuedPlayer> players, 
                         long formationTime, long timeout) {
        this.formationId = formationId;
        this.players = players;
        this.formationTime = formationTime;
        this.timeout = timeout;
    }
    
    // Getters
    public UUID getFormationId() { return formationId; }
    public List<QueuedPlayer> getPlayers() { return players; }
    public long getFormationTime() { return formationTime; }
    public long getTimeout() { return timeout; }
    
    /**
     * Get number of players in formation.
     */
    public int getPlayerCount() {
        return players != null ? players.size() : 0;
    }
    
    /**
     * Check if formation is complete (has all required players).
     */
    public boolean isComplete(int requiredPlayers) {
        return getPlayerCount() >= requiredPlayers;
    }
    
    /**
     * Check if formation has expired.
     */
    public boolean isExpired(long currentTime) {
        return (currentTime - formationTime) > timeout;
    }
    
    /**
     * Get time remaining before expiration.
     */
    public long getTimeRemaining(long currentTime) {
        long elapsed = currentTime - formationTime;
        return Math.max(0, timeout - elapsed);
    }
    
    /**
     * Check if player is in this formation.
     */
    public boolean containsPlayer(UUID playerId) {
        if (players == null) return false;
        for (QueuedPlayer player : players) {
            if (player.getPlayerId().equals(playerId)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Get player by ID.
     */
    public QueuedPlayer getPlayer(UUID playerId) {
        if (players == null) return null;
        for (QueuedPlayer player : players) {
            if (player.getPlayerId().equals(playerId)) {
                return player;
            }
        }
        return null;
    }
    
    /**
     * Remove player from formation.
     */
    public boolean removePlayer(UUID playerId) {
        if (players == null) return false;
        return players.removeIf(player -> player.getPlayerId().equals(playerId));
    }
    
    @Override
    public String toString() {
        return "MatchFormation{" +
               "formationId=" + formationId +
               ", players=" + getPlayerCount() +
               ", formationTime=" + formationTime +
               ", timeout=" + timeout + "ms" +
               '}';
    }
}
package ru.metalpipe.dbdamp.matchmaking;

import ru.metalpipe.dbdamp.gameplay.model.PlayerRole;

import java.util.Map;
import java.util.UUID;

/**
 * Represents a player in the matchmaking queue.
 */
public class QueuedPlayer {
    
    private final int queueId;
    private final UUID playerId;
    private final String playerName;
    private final PlayerRole preferredRole;
    private final int skillRating;
    private final long queueTime;
    private final Map<String, Object> preferences;
    
    private boolean inFormation;
    private UUID formationId;
    private long estimatedWaitTime;
    
    public QueuedPlayer(int queueId, UUID playerId, String playerName, 
                       PlayerRole preferredRole, int skillRating, 
                       long queueTime, Map<String, Object> preferences) {
        this.queueId = queueId;
        this.playerId = playerId;
        this.playerName = playerName;
        this.preferredRole = preferredRole;
        this.skillRating = skillRating;
        this.queueTime = queueTime;
        this.preferences = preferences;
        this.inFormation = false;
        this.formationId = null;
        this.estimatedWaitTime = 0;
    }
    
    // Getters
    public int getQueueId() { return queueId; }
    public UUID getPlayerId() { return playerId; }
    public String getPlayerName() { return playerName; }
    public PlayerRole getPreferredRole() { return preferredRole; }
    public int getSkillRating() { return skillRating; }
    public long getQueueTime() { return queueTime; }
    public Map<String, Object> getPreferences() { return preferences; }
    public boolean isInFormation() { return inFormation; }
    public UUID getFormationId() { return formationId; }
    public long getEstimatedWaitTime() { return estimatedWaitTime; }
    
    // Setters
    public void setInFormation(boolean inFormation) { this.inFormation = inFormation; }
    public void setFormationId(UUID formationId) { this.formationId = formationId; }
    public void setEstimatedWaitTime(long estimatedWaitTime) { 
        this.estimatedWaitTime = estimatedWaitTime; 
    }
    
    /**
     * Calculate wait time in milliseconds.
     */
    public long getWaitTime() {
        return System.currentTimeMillis() - queueTime;
    }
    
    /**
     * Check if player has been waiting too long.
     */
    public boolean isWaitingTooLong(long maxWaitTime) {
        return getWaitTime() > maxWaitTime;
    }
    
    /**
     * Get preference value.
     */
    public Object getPreference(String key) {
        return preferences != null ? preferences.get(key) : null;
    }
    
    /**
     * Get preference value with default.
     */
    public Object getPreference(String key, Object defaultValue) {
        Object value = getPreference(key);
        return value != null ? value : defaultValue;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        QueuedPlayer that = (QueuedPlayer) o;
        return playerId.equals(that.playerId);
    }
    
    @Override
    public int hashCode() {
        return playerId.hashCode();
    }
    
    @Override
    public String toString() {
        return "QueuedPlayer{" +
               "queueId=" + queueId +
               ", playerId=" + playerId +
               ", playerName='" + playerName + '\'' +
               ", preferredRole=" + preferredRole +
               ", skillRating=" + skillRating +
               ", waitTime=" + getWaitTime() + "ms" +
               ", inFormation=" + inFormation +
               '}';
    }
}
package ru.metalpipe.dbdamp.gameplay.model;

import org.bukkit.Location;
import org.bukkit.World;

import java.time.Instant;
import java.util.*;

/**
 * Match data model representing a complete DBD game session.
 */
public class Match {
    
    private UUID matchId;
    private String matchName;
    private GameMode gameMode;
    private Map<UUID, PlayerRole> players;
    private Map<UUID, PlayerRole> playerPreferences;
    private MapState mapState;
    private MatchStatus status;
    private Instant startTime;
    private Instant endTime;
    private Instant lastStatusChange;
    private MatchSettings settings;
    private Random random;
    private long randomSeed;
    
    // Game objects
    private List<Generator> generators;
    private List<Hook> hooks;
    private List<ExitGate> exitGates;
    private List<Chest> chests;
    private List<Locker> lockers;
    
    // Statistics
    private MatchStatistics statistics;
    
    public Match() {
        this.matchId = UUID.randomUUID();
        this.gameMode = GameMode.PUBLIC;
        this.players = new HashMap<>();
        this.playerPreferences = new HashMap<>();
        this.mapState = new MapState();
        this.status = MatchStatus.LOBBY;
        this.startTime = Instant.now();
        this.endTime = null;
        this.lastStatusChange = Instant.now();
        this.settings = new MatchSettings();
        this.randomSeed = System.currentTimeMillis();
        this.random = new Random(randomSeed);
        
        this.generators = new ArrayList<>();
        this.hooks = new ArrayList<>();
        this.exitGates = new ArrayList<>();
        this.chests = new ArrayList<>();
        this.lockers = new ArrayList<>();
        
        this.statistics = new MatchStatistics();
    }
    
    public Match(GameMode gameMode, MatchSettings settings) {
        this();
        this.gameMode = gameMode;
        this.settings = settings != null ? settings : new MatchSettings();
    }
    
    public Match(String matchName) {
        this();
        this.matchName = matchName;
    }
    
    // Getters and setters
    public UUID getMatchId() { return matchId; }
    public void setMatchId(UUID matchId) { this.matchId = matchId; }
    
    public String getMatchName() { return matchName; }
    public void setMatchName(String matchName) { this.matchName = matchName; }
    
    public GameMode getGameMode() { return gameMode; }
    public void setGameMode(GameMode gameMode) { this.gameMode = gameMode; }
    
    public Map<UUID, PlayerRole> getPlayers() { return players; }
    public void setPlayers(Map<UUID, PlayerRole> players) { this.players = players; }
    
    /**
     * Get player roles - alias for getPlayers().
     * @return Map of player UUIDs to their roles
     */
    public Map<UUID, PlayerRole> getPlayerRoles() { return players; }
    
    public Map<UUID, PlayerRole> getPlayerPreferences() { return playerPreferences; }
    public void setPlayerPreferences(Map<UUID, PlayerRole> playerPreferences) { this.playerPreferences = playerPreferences; }
    
    public MapState getMapState() { return mapState; }
    public void setMapState(MapState mapState) { this.mapState = mapState; }
    
    public MatchStatus getStatus() { return status; }
    public void setStatus(MatchStatus status) { 
        this.status = status; 
        this.lastStatusChange = Instant.now();
    }
    
    public Instant getStartTime() { return startTime; }
    public void setStartTime(Instant startTime) { this.startTime = startTime; }
    
    public Instant getEndTime() { return endTime; }
    public void setEndTime(Instant endTime) { this.endTime = endTime; }
    
    public Instant getLastStatusChange() { return lastStatusChange; }
    public void setLastStatusChange(Instant lastStatusChange) { this.lastStatusChange = lastStatusChange; }
    
    public MatchSettings getSettings() { return settings; }
    public void setSettings(MatchSettings settings) { this.settings = settings; }
    
    public Random getRandom() { return random; }
    public void setRandom(Random random) { this.random = random; }
    
    public long getRandomSeed() { return randomSeed; }
    public void setRandomSeed(long randomSeed) { 
        this.randomSeed = randomSeed; 
        this.random = new Random(randomSeed);
    }
    
    public List<Generator> getGenerators() { return generators; }
    public void setGenerators(List<Generator> generators) { this.generators = generators; }
    
    public List<Hook> getHooks() { return hooks; }
    public void setHooks(List<Hook> hooks) { this.hooks = hooks; }
    
    public List<ExitGate> getExitGates() { return exitGates; }
    public void setExitGates(List<ExitGate> exitGates) { this.exitGates = exitGates; }
    
    public List<Chest> getChests() { return chests; }
    public void setChests(List<Chest> chests) { this.chests = chests; }
    
    public List<Locker> getLockers() { return lockers; }
    public void setLockers(List<Locker> lockers) { this.lockers = lockers; }
    
    public MatchStatistics getStatistics() { return statistics; }
    public void setStatistics(MatchStatistics statistics) { this.statistics = statistics; }
    
    // Helper methods
    public void addPlayer(UUID playerId, PlayerRole role) {
        players.put(playerId, role);
        statistics.addPlayer(playerId, role);
    }
    
    public void addPlayer(UUID playerId, String playerName) {
        // Add player without role initially
        players.put(playerId, null);
        // In real implementation, would add to statistics
    }
    
    public void removePlayer(UUID playerId) {
        players.remove(playerId);
        playerPreferences.remove(playerId);
        // In real implementation, would remove from statistics
    }
    
    public PlayerRole getPlayerRole(UUID playerId) {
        return players.get(playerId);
    }
    
    public void setPlayerRole(UUID playerId, PlayerRole role) {
        players.put(playerId, role);
    }
    
    public boolean hasPlayer(UUID playerId) {
        return players.containsKey(playerId);
    }
    
    public void setPlayerPreference(UUID playerId, PlayerRole preference) {
        playerPreferences.put(playerId, preference);
    }
    
    public PlayerRole getPlayerPreference(UUID playerId) {
        return playerPreferences.get(playerId);
    }
    
    public int getPlayerCount() {
        return players.size();
    }
    
    public int getSurvivorCount() {
        return (int) players.values().stream()
            .filter(role -> role == PlayerRole.SURVIVOR)
            .count();
    }
    
    public int getKillerCount() {
        return (int) players.values().stream()
            .filter(role -> role == PlayerRole.KILLER)
            .count();
    }
    
    public List<UUID> getSurvivors() {
        return players.entrySet().stream()
            .filter(entry -> entry.getValue() == PlayerRole.SURVIVOR)
            .map(Map.Entry::getKey)
            .toList();
    }
    
    public List<UUID> getKillers() {
        return players.entrySet().stream()
            .filter(entry -> entry.getValue() == PlayerRole.KILLER)
            .map(Map.Entry::getKey)
            .toList();
    }
    
    public UUID getKillerId() {
        return getKillers().stream().findFirst().orElse(null);
    }
    
    public void addGenerator(Generator generator) {
        generators.add(generator);
    }
    
    public void addHook(Hook hook) {
        hooks.add(hook);
    }
    
    public void addExitGate(ExitGate exitGate) {
        exitGates.add(exitGate);
    }
    
    public void addChest(Chest chest) {
        chests.add(chest);
    }
    
    public void addLocker(Locker locker) {
        lockers.add(locker);
    }
    
    public Generator findGenerator(UUID generatorId) {
        return generators.stream()
            .filter(g -> g.getGeneratorId().equals(generatorId))
            .findFirst()
            .orElse(null);
    }
    
    public Hook findHook(UUID hookId) {
        return hooks.stream()
            .filter(h -> h.getHookId().equals(hookId))
            .findFirst()
            .orElse(null);
    }
    
    public ExitGate findExitGate(UUID gateId) {
        return exitGates.stream()
            .filter(g -> g.getGateId().equals(gateId))
            .findFirst()
            .orElse(null);
    }
    
    public Chest findChest(UUID chestId) {
        return chests.stream()
            .filter(c -> c.getChestId().equals(chestId))
            .findFirst()
            .orElse(null);
    }
    
    public Locker findLocker(UUID lockerId) {
        return lockers.stream()
            .filter(l -> l.getLockerId().equals(lockerId))
            .findFirst()
            .orElse(null);
    }
    
    public Generator findNearestGenerator(Location location) {
        return generators.stream()
            .min(Comparator.comparingDouble(g -> 
                g.getLocation().distanceSquared(location)))
            .orElse(null);
    }
    
    public Hook findNearestHook(Location location) {
        return hooks.stream()
            .min(Comparator.comparingDouble(h -> 
                h.getLocation().distanceSquared(location)))
            .orElse(null);
    }
    
    public ExitGate findNearestExitGate(Location location) {
        return exitGates.stream()
            .min(Comparator.comparingDouble(g -> 
                g.getLocation().distanceSquared(location)))
            .orElse(null);
    }
    
    public int getCompletedGenerators() {
        return (int) generators.stream()
            .filter(Generator::isCompleted)
            .count();
    }
    
    public int getRequiredGenerators() {
        return settings.getGeneratorsRequired();
    }
    
    public boolean areExitGatesPowered() {
        return getCompletedGenerators() >= getRequiredGenerators();
    }
    
    public boolean areExitGatesOpen() {
        return exitGates.stream().anyMatch(ExitGate::isOpen);
    }
    
    public void start() {
        if (status == MatchStatus.LOBBY) {
            status = MatchStatus.STARTING;
            startTime = Instant.now();
        }
    }
    
    public void begin() {
        if (status == MatchStatus.STARTING) {
            status = MatchStatus.IN_PROGRESS;
        }
    }
    
    public void end() {
        if (status == MatchStatus.IN_PROGRESS) {
            status = MatchStatus.ENDING;
            endTime = Instant.now();
        }
    }
    
    public void complete() {
        if (status == MatchStatus.ENDING) {
            status = MatchStatus.COMPLETED;
        }
    }
    
    public long getDuration() {
        if (startTime == null) return 0;
        Instant end = endTime != null ? endTime : Instant.now();
        return end.getEpochSecond() - startTime.getEpochSecond();
    }
    
    public String getFormattedDuration() {
        long seconds = getDuration();
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        seconds = seconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }
    
    public boolean isActive() {
        return status == MatchStatus.IN_PROGRESS || status == MatchStatus.STARTING;
    }
    
    public boolean isEnded() {
        return status == MatchStatus.ENDING || status == MatchStatus.COMPLETED;
    }
    
    public boolean isFull() {
        return getPlayerCount() >= settings.getMaxPlayers();
    }
    
    public boolean canStart() {
        return getPlayerCount() >= settings.getMinPlayers() && 
               status == MatchStatus.LOBBY;
    }
    
    public void reset() {
        players.clear();
        playerPreferences.clear();
        generators.forEach(Generator::reset);
        hooks.forEach(Hook::reset);
        exitGates.forEach(ExitGate::reset);
        chests.forEach(Chest::reset);
        lockers.forEach(Locker::reset);
        statistics.reset();
        status = MatchStatus.LOBBY;
        startTime = Instant.now();
        endTime = null;
        lastStatusChange = Instant.now();
        randomSeed = System.currentTimeMillis();
        random = new Random(randomSeed);
    }
    
    /**
     * Assign roles to all players in the match.
     * Ensures exactly 1 killer and the rest survivors.
     */
    public void assignRoles() {
        if (players.isEmpty()) return;
        
        List<UUID> playerIds = new ArrayList<>(players.keySet());
        
        // Clear existing roles
        for (UUID playerId : playerIds) {
            players.put(playerId, null);
        }
        
        // Check for players with killer preference
        List<UUID> killerPreferencePlayers = playerIds.stream()
            .filter(id -> playerPreferences.get(id) == PlayerRole.KILLER)
            .toList();
        
        UUID killerId;
        if (!killerPreferencePlayers.isEmpty()) {
            // Randomly select from players with killer preference
            killerId = killerPreferencePlayers.get(random.nextInt(killerPreferencePlayers.size()));
        } else {
            // Randomly select any player
            killerId = playerIds.get(random.nextInt(playerIds.size()));
        }
        
        // Assign killer role
        players.put(killerId, PlayerRole.KILLER);
        
        // Assign survivor roles to everyone else
        for (UUID playerId : playerIds) {
            if (!playerId.equals(killerId)) {
                players.put(playerId, PlayerRole.SURVIVOR);
            }
        }
    }
    
    /**
     * Reassign roles randomly.
     */
    public void reassignRoles() {
        assignRoles();
    }
    
    /**
     * Rebalance roles when players join or leave.
     */
    public void rebalanceRoles() {
        int killerCount = getKillerCount();
        
        if (killerCount == 0 && !players.isEmpty()) {
            // Need to assign a killer
            assignRoles();
        } else if (killerCount > 1) {
            // Too many killers, need to reassign
            assignRoles();
        }
        // If exactly 1 killer, no need to rebalance
    }
    
    /**
     * Clean up match resources after completion.
     */
    public void cleanup() {
        // Clear game objects
        generators.clear();
        hooks.clear();
        exitGates.clear();
        chests.clear();
        lockers.clear();
        
        // Clear player data
        players.clear();
        playerPreferences.clear();
        
        // Reset statistics
        statistics = new MatchStatistics(matchId);
    }
    
    public Match copy() {
        Match copy = new Match();
        copy.matchId = this.matchId;
        copy.matchName = this.matchName;
        copy.gameMode = this.gameMode;
        copy.players = new HashMap<>(this.players);
        copy.playerPreferences = new HashMap<>(this.playerPreferences);
        copy.mapState = this.mapState.copy();
        copy.status = this.status;
        copy.startTime = this.startTime;
        copy.endTime = this.endTime;
        copy.lastStatusChange = this.lastStatusChange;
        copy.settings = this.settings.copy();
        copy.randomSeed = this.randomSeed;
        copy.random = new Random(this.randomSeed);
        
        copy.generators = new ArrayList<>();
        this.generators.forEach(g -> copy.generators.add(g.copy()));
        
        copy.hooks = new ArrayList<>();
        this.hooks.forEach(h -> copy.hooks.add(h.copy()));
        
        copy.exitGates = new ArrayList<>();
        this.exitGates.forEach(g -> copy.exitGates.add(g.copy()));
        
        copy.chests = new ArrayList<>();
        this.chests.forEach(c -> copy.chests.add(c.copy()));
        
        copy.lockers = new ArrayList<>();
        this.lockers.forEach(l -> copy.lockers.add(l.copy()));
        
        copy.statistics = this.statistics.copy();
        
        return copy;
    }
    
    @Override
    public String toString() {
        return "Match{" +
               "matchId=" + matchId +
               ", name=" + matchName +
               ", gameMode=" + gameMode +
               ", status=" + status +
               ", players=" + getPlayerCount() +
               " (S:" + getSurvivorCount() + "/K:" + getKillerCount() + ")" +
               ", duration=" + getFormattedDuration() +
               ", generators=" + getCompletedGenerators() + "/" + getRequiredGenerators() +
               ", exitGatesPowered=" + areExitGatesPowered() +
               ", exitGatesOpen=" + areExitGatesOpen() +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Match match = (Match) o;
        return Objects.equals(matchId, match.matchId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(matchId);
    }
}
package ru.metalpipe.dbdamp.gameplay.model;

import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;

import java.time.Instant;
import java.util.*;

/**
 * Chest object for DBD gameplay - survivors can search chests for items.
 */
public class Chest {
    
    private UUID chestId;
    private Location location;
    private boolean searched; // Whether the chest has been searched
    private boolean searching; // Whether someone is currently searching
    private int searchProgress; // 0-10000 (100.00%)
    private UUID searcher;
    private Instant searchStartTime;
    private Instant searchCompleteTime;
    private int searchTime; // Time required to search in ticks
    private ItemStack item; // Item found in the chest
    private ItemStack itemRarity; // Rarity of the item
    private boolean hasItem; // Whether the chest contains an item
    private boolean respawnable; // Whether the chest can respawn items
    private Instant respawnTime; // When the chest will respawn
    private int respawnDelay; // Delay before respawn in seconds
    private Map<String, Object> metadata;
    
    public Chest() {
        this.chestId = UUID.randomUUID();
        this.location = null;
        this.searched = false;
        this.searching = false;
        this.searchProgress = 0;
        this.searcher = null;
        this.searchStartTime = null;
        this.searchCompleteTime = null;
        this.searchTime = 200; // 10 seconds default
        this.item = null;
        this.itemRarity = null;
        this.hasItem = true; // Chests start with items
        this.respawnable = true;
        this.respawnTime = null;
        this.respawnDelay = 300; // 5 minutes default
        this.metadata = new HashMap<>();
    }
    
    public Chest(Location location) {
        this();
        this.location = location;
    }
    
    public Chest(Location location, boolean hasItem) {
        this(location);
        this.hasItem = hasItem;
    }
    
    // Getters and setters
    public UUID getChestId() { return chestId; }
    public void setChestId(UUID chestId) { this.chestId = chestId; }
    
    public Location getLocation() { return location; }
    public void setLocation(Location location) { this.location = location; }
    
    public boolean isSearched() { return searched; }
    public void setSearched(boolean searched) { 
        this.searched = searched;
        if (searched) {
            this.searchProgress = 10000;
            this.searching = false;
        }
    }
    
    public boolean isSearching() { return searching; }
    public void setSearching(boolean searching) { this.searching = searching; }
    
    public int getSearchProgress() { return searchProgress; }
    public void setSearchProgress(int searchProgress) { 
        this.searchProgress = Math.max(0, Math.min(10000, searchProgress));
        if (this.searchProgress >= 10000) {
            completeSearch();
        }
    }
    
    public UUID getSearcher() { return searcher; }
    public void setSearcher(UUID searcher) { this.searcher = searcher; }
    
    public Instant getSearchStartTime() { return searchStartTime; }
    public void setSearchStartTime(Instant searchStartTime) { this.searchStartTime = searchStartTime; }
    
    public Instant getSearchCompleteTime() { return searchCompleteTime; }
    public void setSearchCompleteTime(Instant searchCompleteTime) { this.searchCompleteTime = searchCompleteTime; }
    
    public int getSearchTime() { return searchTime; }
    public void setSearchTime(int searchTime) { this.searchTime = Math.max(0, searchTime); }
    
    public ItemStack getItem() { return item; }
    public void setItem(ItemStack item) { this.item = item; }
    
    public ItemStack getItemRarity() { return itemRarity; }
    public void setItemRarity(ItemStack itemRarity) { this.itemRarity = itemRarity; }
    
    public boolean hasItem() { return hasItem; }
    public void setHasItem(boolean hasItem) { this.hasItem = hasItem; }
    
    public boolean isRespawnable() { return respawnable; }
    public void setRespawnable(boolean respawnable) { this.respawnable = respawnable; }
    
    public Instant getRespawnTime() { return respawnTime; }
    public void setRespawnTime(Instant respawnTime) { this.respawnTime = respawnTime; }
    
    public int getRespawnDelay() { return respawnDelay; }
    public void setRespawnDelay(int respawnDelay) { this.respawnDelay = Math.max(0, respawnDelay); }
    
    public Map<String, Object> getMetadata() { return metadata; }
    public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }
    
    // Helper methods
    public void startSearching(UUID searcherId) {
        if (searched || searching || !hasItem) return;
        
        searching = true;
        searcher = searcherId;
        searchStartTime = Instant.now();
        searchProgress = 0;
    }
    
    public void progressSearch(int amount) {
        if (!searching || !hasItem) return;
        
        searchProgress = Math.min(10000, searchProgress + amount);
        
        if (searchProgress >= 10000) {
            completeSearch();
        }
    }
    
    public void cancelSearch() {
        searching = false;
        searcher = null;
        searchStartTime = null;
        searchProgress = 0;
    }
    
    public void completeSearch() {
        searched = true;
        searching = false;
        searchProgress = 10000;
        searchCompleteTime = Instant.now();
        hasItem = false; // Item is taken
        
        // Set respawn time if respawnable
        if (respawnable) {
            respawnTime = Instant.now().plusSeconds(respawnDelay);
        }
    }
    
    public void respawnItem() {
        if (!respawnable || hasItem) return;
        
        if (respawnTime != null && Instant.now().isAfter(respawnTime)) {
            hasItem = true;
            searched = false;
            searchProgress = 0;
            searchCompleteTime = null;
            respawnTime = Instant.now().plusSeconds(respawnDelay);
        }
    }
    
    public void forceRespawn() {
        hasItem = true;
        searched = false;
        searchProgress = 0;
        searchCompleteTime = null;
        respawnTime = Instant.now().plusSeconds(respawnDelay);
    }
    
    public boolean canBeSearched() {
        return hasItem && !searched && !searching;
    }
    
    public boolean isActive() {
        return hasItem || searching;
    }
    
    public double getSearchProgressPercentage() {
        return searchProgress / 100.0;
    }
    
    public String getSearchProgressFormatted() {
        return String.format("%.1f%%", getSearchProgressPercentage());
    }
    
    public int getRemainingSearchProgress() {
        return 10000 - searchProgress;
    }
    
    public long getTimeSinceSearchStart() {
        if (searchStartTime == null) return 0;
        return Instant.now().getEpochSecond() - searchStartTime.getEpochSecond();
    }
    
    public long getTimeSinceSearchComplete() {
        if (searchCompleteTime == null) return 0;
        return Instant.now().getEpochSecond() - searchCompleteTime.getEpochSecond();
    }
    
    public int getEstimatedTimeRemaining() {
        if (!searching || searchProgress == 0) return searchTime / 20; // Convert ticks to seconds
        
        double progressFraction = searchProgress / 10000.0;
        double timeElapsed = getTimeSinceSearchStart();
        double totalEstimatedTime = timeElapsed / progressFraction;
        return (int) Math.ceil(totalEstimatedTime - timeElapsed);
    }
    
    public Block getBlock() {
        return location != null ? location.getBlock() : null;
    }
    
    public int getSearchProgressPerTick() {
        // Calculate progress per tick
        return 10000 / searchTime;
    }
    
    public double getSearchSpeedMultiplier() {
        // Base search speed
        return 1.0;
    }
    
    public void reset() {
        searched = false;
        searching = false;
        searchProgress = 0;
        searcher = null;
        searchStartTime = null;
        searchCompleteTime = null;
        hasItem = true;
        respawnTime = null;
        metadata.clear();
    }
    
    public void addMetadata(String key, Object value) {
        metadata.put(key, value);
    }
    
    public Object getMetadata(String key) {
        return metadata.get(key);
    }
    
    public void removeMetadata(String key) {
        metadata.remove(key);
    }
    
    public Chest copy() {
        Chest copy = new Chest();
        copy.chestId = this.chestId;
        copy.location = this.location != null ? this.location.clone() : null;
        copy.searched = this.searched;
        copy.searching = this.searching;
        copy.searchProgress = this.searchProgress;
        copy.searcher = this.searcher;
        copy.searchStartTime = this.searchStartTime;
        copy.searchCompleteTime = this.searchCompleteTime;
        copy.searchTime = this.searchTime;
        copy.item = this.item != null ? this.item.clone() : null;
        copy.itemRarity = this.itemRarity != null ? this.itemRarity.clone() : null;
        copy.hasItem = this.hasItem;
        copy.respawnable = this.respawnable;
        copy.respawnTime = this.respawnTime;
        copy.respawnDelay = this.respawnDelay;
        copy.metadata = new HashMap<>(this.metadata);
        return copy;
    }
    
    @Override
    public String toString() {
        return "Chest{" +
               "id=" + chestId +
               ", searched=" + searched +
               ", searching=" + searching +
               ", progress=" + getSearchProgressFormatted() +
               ", hasItem=" + hasItem +
               ", respawnable=" + respawnable +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Chest chest = (Chest) o;
        return Objects.equals(chestId, chest.chestId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(chestId);
    }
}
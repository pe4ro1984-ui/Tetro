package ru.metalpipe.dbdamp.gameplay.model;

import org.bukkit.Location;
import org.bukkit.block.Block;

import java.time.Instant;
import java.util.*;

/**
 * Exit gate object for DBD gameplay - survivors must open exit gates to escape.
 */
public class ExitGate {
    
    private UUID gateId;
    private Location location;
    private boolean powered; // Whether generators have powered the gate
    private boolean open; // Whether the gate is fully open
    private boolean opening; // Whether the gate is being opened
    private int openProgress; // 0-10000 (100.00%)
    private UUID opener;
    private Instant openStartTime;
    private Instant openCompleteTime;
    private int openTime; // Time required to open in ticks
    private boolean emergencyExit; // Whether this is an emergency exit (hatch)
    private boolean used; // Whether this gate has been used to escape
    private Instant useTime;
    private UUID user;
    private Map<String, Object> metadata;
    
    public ExitGate() {
        this.gateId = UUID.randomUUID();
        this.location = null;
        this.powered = false;
        this.open = false;
        this.opening = false;
        this.openProgress = 0;
        this.opener = null;
        this.openStartTime = null;
        this.openCompleteTime = null;
        this.openTime = 400; // 20 seconds default
        this.emergencyExit = false;
        this.used = false;
        this.useTime = null;
        this.user = null;
        this.metadata = new HashMap<>();
    }
    
    public ExitGate(Location location) {
        this();
        this.location = location;
    }
    
    public ExitGate(Location location, boolean emergencyExit) {
        this(location);
        this.emergencyExit = emergencyExit;
        if (emergencyExit) {
            this.openTime = 0; // Emergency exit opens instantly
        }
    }
    
    // Getters and setters
    public UUID getGateId() { return gateId; }
    public void setGateId(UUID gateId) { this.gateId = gateId; }
    
    public Location getLocation() { return location; }
    public void setLocation(Location location) { this.location = location; }
    
    public boolean isPowered() { return powered; }
    public void setPowered(boolean powered) { this.powered = powered; }
    
    public boolean isOpen() { return open; }
    public void setOpen(boolean open) { 
        this.open = open;
        if (open) {
            this.openProgress = 10000;
            this.opening = false;
        }
    }
    
    public boolean isOpening() { return opening; }
    public void setOpening(boolean opening) { this.opening = opening; }
    
    public int getOpenProgress() { return openProgress; }
    public void setOpenProgress(int openProgress) { 
        this.openProgress = Math.max(0, Math.min(10000, openProgress));
        if (this.openProgress >= 10000) {
            completeOpening();
        }
    }
    
    public UUID getOpener() { return opener; }
    public void setOpener(UUID opener) { this.opener = opener; }
    
    public Instant getOpenStartTime() { return openStartTime; }
    public void setOpenStartTime(Instant openStartTime) { this.openStartTime = openStartTime; }
    
    public Instant getOpenCompleteTime() { return openCompleteTime; }
    public void setOpenCompleteTime(Instant openCompleteTime) { this.openCompleteTime = openCompleteTime; }
    
    public int getOpenTime() { return openTime; }
    public void setOpenTime(int openTime) { this.openTime = Math.max(0, openTime); }
    
    public boolean isEmergencyExit() { return emergencyExit; }
    public void setEmergencyExit(boolean emergencyExit) { this.emergencyExit = emergencyExit; }
    
    public boolean isUsed() { return used; }
    public void setUsed(boolean used) { this.used = used; }
    
    public Instant getUseTime() { return useTime; }
    public void setUseTime(Instant useTime) { this.useTime = useTime; }
    
    public UUID getUser() { return user; }
    public void setUser(UUID user) { this.user = user; }
    
    public Map<String, Object> getMetadata() { return metadata; }
    public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }
    
    // Helper methods
    public void powerOn() {
        powered = true;
    }
    
    public void powerOff() {
        powered = false;
        if (opening) {
            cancelOpening();
        }
    }
    
    public void startOpening(UUID openerId) {
        if (!powered || open || used || emergencyExit) return;
        
        opening = true;
        opener = openerId;
        openStartTime = Instant.now();
        openProgress = 0;
    }
    
    public void progressOpening(int amount) {
        if (!opening || !powered) return;
        
        openProgress = Math.min(10000, openProgress + amount);
        
        if (openProgress >= 10000) {
            completeOpening();
        }
    }
    
    public void cancelOpening() {
        opening = false;
        opener = null;
        openStartTime = null;
        openProgress = 0;
    }
    
    public void completeOpening() {
        open = true;
        opening = false;
        openProgress = 10000;
        openCompleteTime = Instant.now();
    }
    
    public void use(UUID userId) {
        if (!open || used) return;
        
        used = true;
        user = userId;
        useTime = Instant.now();
    }
    
    public void openEmergencyExit() {
        if (!emergencyExit) return;
        
        powered = true;
        open = true;
        opening = false;
        openProgress = 10000;
        openCompleteTime = Instant.now();
    }
    
    public boolean canBeOpened() {
        return powered && !open && !used && !emergencyExit;
    }
    
    public boolean canBeUsed() {
        return open && !used;
    }
    
    public boolean isActive() {
        return powered || open || opening;
    }
    
    public double getOpenProgressPercentage() {
        return openProgress / 100.0;
    }
    
    public String getOpenProgressFormatted() {
        return String.format("%.1f%%", getOpenProgressPercentage());
    }
    
    public int getRemainingOpenProgress() {
        return 10000 - openProgress;
    }
    
    public long getTimeSinceOpenStart() {
        if (openStartTime == null) return 0;
        return Instant.now().getEpochSecond() - openStartTime.getEpochSecond();
    }
    
    public long getTimeSinceOpenComplete() {
        if (openCompleteTime == null) return 0;
        return Instant.now().getEpochSecond() - openCompleteTime.getEpochSecond();
    }
    
    public long getTimeSinceUse() {
        if (useTime == null) return 0;
        return Instant.now().getEpochSecond() - useTime.getEpochSecond();
    }
    
    public int getEstimatedTimeRemaining() {
        if (!opening || openProgress == 0) return openTime / 20; // Convert ticks to seconds
        
        double progressFraction = openProgress / 10000.0;
        double timeElapsed = getTimeSinceOpenStart();
        double totalEstimatedTime = timeElapsed / progressFraction;
        return (int) Math.ceil(totalEstimatedTime - timeElapsed);
    }
    
    public Block getBlock() {
        return location != null ? location.getBlock() : null;
    }
    
    public int getOpenProgressPerTick() {
        // Calculate progress per tick
        return 10000 / openTime;
    }
    
    public double getOpenSpeedMultiplier() {
        // Emergency exits open instantly
        if (emergencyExit) return Double.MAX_VALUE;
        
        // Normal gates have fixed speed
        return 1.0;
    }
    
    public void reset() {
        powered = false;
        open = false;
        opening = false;
        openProgress = 0;
        opener = null;
        openStartTime = null;
        openCompleteTime = null;
        used = false;
        useTime = null;
        user = null;
        metadata.clear();
    }
    
    public void addMetadata(String key, Object value) {
        metadata.put(key, value);
    }
    
    public Object getMetadata(String key) {
        return metadata.get(key);
    }
    
    public void removeMetadata(String key) {
        metadata.remove(key);
    }
    
    public ExitGate copy() {
        ExitGate copy = new ExitGate();
        copy.gateId = this.gateId;
        copy.location = this.location != null ? this.location.clone() : null;
        copy.powered = this.powered;
        copy.open = this.open;
        copy.opening = this.opening;
        copy.openProgress = this.openProgress;
        copy.opener = this.opener;
        copy.openStartTime = this.openStartTime;
        copy.openCompleteTime = this.openCompleteTime;
        copy.openTime = this.openTime;
        copy.emergencyExit = this.emergencyExit;
        copy.used = this.used;
        copy.useTime = this.useTime;
        copy.user = this.user;
        copy.metadata = new HashMap<>(this.metadata);
        return copy;
    }
    
    @Override
    public String toString() {
        return "ExitGate{" +
               "id=" + gateId +
               ", powered=" + powered +
               ", open=" + open +
               ", opening=" + opening +
               ", progress=" + getOpenProgressFormatted() +
               ", emergency=" + emergencyExit +
               ", used=" + used +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExitGate exitGate = (ExitGate) o;
        return Objects.equals(gateId, exitGate.gateId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(gateId);
    }
}
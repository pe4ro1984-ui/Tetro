package ru.metalpipe.dbdamp.gameplay.model;

import java.time.Instant;
import java.util.*;

/**
 * Manages state transitions for DBD matches - handles game rule engine for match state changes.
 */
public class MatchStateTransition {
    
    private Match match;
    private MatchStatistics statistics;
    private List<StateTransition> transitionHistory;
    private Instant lastTransitionTime;
    
    public MatchStateTransition(Match match) {
        this.match = match;
        this.statistics = new MatchStatistics(match.getMatchId());
        this.transitionHistory = new ArrayList<>();
        this.lastTransitionTime = Instant.now();
    }
    
    public MatchStateTransition(Match match, MatchStatistics statistics) {
        this.match = match;
        this.statistics = statistics;
        this.transitionHistory = new ArrayList<>();
        this.lastTransitionTime = Instant.now();
    }
    
    // Getters
    public Match getMatch() { return match; }
    public MatchStatistics getStatistics() { return statistics; }
    public List<StateTransition> getTransitionHistory() { return transitionHistory; }
    public Instant getLastTransitionTime() { return lastTransitionTime; }
    
    /**
     * Process a state transition for the match.
     * 
     * @param transitionType Type of transition to process
     * @param playerId Player initiating the transition (if applicable)
     * @param data Additional data for the transition
     * @return true if transition was successful, false otherwise
     */
    public boolean processTransition(TransitionType transitionType, UUID playerId, Map<String, Object> data) {
        if (match == null) return false;
        
        MatchStatus currentStatus = match.getStatus();
        MatchStatus newStatus = determineNewStatus(currentStatus, transitionType, data);
        
        if (newStatus == null || newStatus == currentStatus) {
            // No valid transition
            return false;
        }
        
        // Validate transition
        if (!isValidTransition(currentStatus, newStatus, transitionType, data)) {
            return false;
        }
        
        // Execute pre-transition actions
        if (!executePreTransitionActions(currentStatus, newStatus, transitionType, playerId, data)) {
            return false;
        }
        
        // Update match status
        match.setStatus(newStatus);
        match.setLastStatusChange(Instant.now());
        
        // Record transition
        StateTransition transition = new StateTransition(
            currentStatus, 
            newStatus, 
            transitionType, 
            playerId, 
            data
        );
        transitionHistory.add(transition);
        lastTransitionTime = Instant.now();
        
        // Execute post-transition actions
        executePostTransitionActions(currentStatus, newStatus, transitionType, playerId, data);
        
        // Update statistics
        updateStatistics(transitionType, playerId, data);
        
        // Check for match end conditions
        checkMatchEndConditions();
        
        return true;
    }
    
    /**
     * Determine the new status based on current status and transition type.
     */
    private MatchStatus determineNewStatus(MatchStatus currentStatus, TransitionType transitionType, Map<String, Object> data) {
        switch (currentStatus) {
            case LOBBY:
                if (transitionType == TransitionType.MATCH_START) {
                    return MatchStatus.STARTING;
                }
                break;
                
            case STARTING:
                if (transitionType == TransitionType.MATCH_READY) {
                    return MatchStatus.IN_PROGRESS;
                }
                break;
                
            case IN_PROGRESS:
                if (transitionType == TransitionType.ALL_SURVIVORS_ESCAPED) {
                    return MatchStatus.ENDING_SURVIVOR_VICTORY;
                } else if (transitionType == TransitionType.ALL_SURVIVORS_DEAD) {
                    return MatchStatus.ENDING_KILLER_VICTORY;
                } else if (transitionType == TransitionType.TIME_EXPIRED) {
                    return MatchStatus.ENDING_DRAW;
                } else if (transitionType == TransitionType.EMERGENCY_EXIT_OPENED) {
                    // Check if emergency exit conditions are met
                    if (data != null && data.containsKey("emergencyExit") && (Boolean) data.get("emergencyExit")) {
                        return MatchStatus.ENDING_SURVIVOR_VICTORY;
                    }
                }
                break;
                
            case ENDING_SURVIVOR_VICTORY:
            case ENDING_KILLER_VICTORY:
            case ENDING_DRAW:
                if (transitionType == TransitionType.MATCH_COMPLETE) {
                    return MatchStatus.COMPLETED;
                }
                break;
                
            case COMPLETED:
                // No further transitions from completed
                break;
                
            case CANCELLED:
                // No further transitions from cancelled
                break;
        }
        
        return currentStatus; // No change
    }
    
    /**
     * Check if a transition is valid.
     */
    private boolean isValidTransition(MatchStatus current, MatchStatus next, TransitionType type, Map<String, Object> data) {
        // Basic validation - check if transition is allowed
        switch (current) {
            case LOBBY:
                return next == MatchStatus.STARTING && type == TransitionType.MATCH_START;
                
            case STARTING:
                return next == MatchStatus.IN_PROGRESS && type == TransitionType.MATCH_READY;
                
            case IN_PROGRESS:
                return (next == MatchStatus.ENDING_SURVIVOR_VICTORY && 
                       (type == TransitionType.ALL_SURVIVORS_ESCAPED || type == TransitionType.EMERGENCY_EXIT_OPENED)) ||
                       (next == MatchStatus.ENDING_KILLER_VICTORY && type == TransitionType.ALL_SURVIVORS_DEAD) ||
                       (next == MatchStatus.ENDING_DRAW && type == TransitionType.TIME_EXPIRED);
                
            case ENDING_SURVIVOR_VICTORY:
            case ENDING_KILLER_VICTORY:
            case ENDING_DRAW:
                return next == MatchStatus.COMPLETED && type == TransitionType.MATCH_COMPLETE;
                
            default:
                return false;
        }
    }
    
    /**
     * Execute actions before a transition.
     */
    private boolean executePreTransitionActions(MatchStatus current, MatchStatus next, TransitionType type, 
                                               UUID playerId, Map<String, Object> data) {
        switch (type) {
            case MATCH_START:
                // Validate match can start
                return canMatchStart();
                
            case MATCH_READY:
                // Validate all players are ready
                return areAllPlayersReady();
                
            case ALL_SURVIVORS_ESCAPED:
                // Validate all survivors have escaped
                return haveAllSurvivorsEscaped();
                
            case ALL_SURVIVORS_DEAD:
                // Validate all survivors are dead
                return areAllSurvivorsDead();
                
            case TIME_EXPIRED:
                // Validate match time has expired
                return hasMatchTimeExpired();
                
            case EMERGENCY_EXIT_OPENED:
                // Validate emergency exit conditions
                return canEmergencyExitOpen(data);
                
            case MATCH_COMPLETE:
                // Always allow match completion
                return true;
                
            default:
                return true;
        }
    }
    
    /**
     * Execute actions after a transition.
     */
    private void executePostTransitionActions(MatchStatus current, MatchStatus next, TransitionType type, 
                                             UUID playerId, Map<String, Object> data) {
        switch (type) {
            case MATCH_START:
                onMatchStart();
                break;
                
            case MATCH_READY:
                onMatchReady();
                break;
                
            case ALL_SURVIVORS_ESCAPED:
                onAllSurvivorsEscaped();
                break;
                
            case ALL_SURVIVORS_DEAD:
                onAllSurvivorsDead();
                break;
                
            case TIME_EXPIRED:
                onTimeExpired();
                break;
                
            case EMERGENCY_EXIT_OPENED:
                onEmergencyExitOpened(data);
                break;
                
            case MATCH_COMPLETE:
                onMatchComplete();
                break;
        }
        
        // Notify listeners of state change
        notifyStateChange(current, next, type, playerId);
    }
    
    /**
     * Update statistics based on transition.
     */
    private void updateStatistics(TransitionType type, UUID playerId, Map<String, Object> data) {
        if (statistics == null) return;
        
        switch (type) {
            case GENERATOR_COMPLETED:
                statistics.addGeneratorCompleted();
                if (playerId != null) {
                    MatchStatistics.SurvivorStats stats = statistics.getSurvivorStat(playerId);
                    if (stats != null) {
                        stats.addGeneratorRepaired();
                    }
                }
                break;
                
            case HOOK_USED:
                statistics.addHookUsed();
                statistics.addKillerHook();
                break;
                
            case HOOK_RESCUED:
                if (playerId != null) {
                    MatchStatistics.SurvivorStats stats = statistics.getSurvivorStat(playerId);
                    if (stats != null) {
                        stats.addHookRescued();
                    }
                }
                break;
                
            case CHEST_SEARCHED:
                statistics.addChestSearched();
                if (playerId != null) {
                    MatchStatistics.SurvivorStats stats = statistics.getSurvivorStat(playerId);
                    if (stats != null) {
                        stats.addChestSearched();
                    }
                }
                break;
                
            case LOCKER_USED:
                statistics.addLockerUsed();
                if (playerId != null) {
                    MatchStatistics.SurvivorStats stats = statistics.getSurvivorStat(playerId);
                    if (stats != null) {
                        stats.addLockerUsed();
                    }
                }
                break;
                
            case EXIT_GATE_OPENED:
                statistics.addExitGateOpened();
                break;
                
            case EMERGENCY_EXIT_USED:
                statistics.addEmergencyExitUsed();
                statistics.addSurvivorEscaped();
                if (playerId != null) {
                    MatchStatistics.SurvivorStats stats = statistics.getSurvivorStat(playerId);
                    if (stats != null) {
                        stats.setEscaped(true);
                    }
                }
                break;
                
            case SURVIVOR_HIT:
                statistics.addKillerHit();
                if (playerId != null) {
                    MatchStatistics.SurvivorStats stats = statistics.getSurvivorStat(playerId);
                    if (stats != null) {
                        stats.addTimeHit();
                    }
                }
                break;
                
            case SURVIVOR_DOWNED:
                statistics.addKillerDown();
                if (playerId != null) {
                    MatchStatistics.SurvivorStats stats = statistics.getSurvivorStat(playerId);
                    if (stats != null) {
                        stats.addTimeDowned();
                    }
                }
                break;
                
            case SURVIVOR_ESCAPED:
                statistics.addSurvivorEscaped();
                if (playerId != null) {
                    MatchStatistics.SurvivorStats stats = statistics.getSurvivorStat(playerId);
                    if (stats != null) {
                        stats.setEscaped(true);
                    }
                }
                break;
                
            case SURVIVOR_SACRIFICED:
                statistics.addSurvivorSacrificed();
                statistics.addKillerSacrifice();
                if (playerId != null) {
                    MatchStatistics.SurvivorStats stats = statistics.getSurvivorStat(playerId);
                    if (stats != null) {
                        stats.setSacrificed(true);
                    }
                }
                break;
                
            case SURVIVOR_KILLED:
                statistics.addSurvivorKilled();
                if (playerId != null) {
                    MatchStatistics.SurvivorStats stats = statistics.getSurvivorStat(playerId);
                    if (stats != null) {
                        stats.setKilled(true);
                    }
                }
                break;
                
            case GENERATOR_DAMAGED:
                statistics.addKillerGeneratorDamaged();
                break;
                
            case PALLET_BROKEN:
                statistics.addKillerPalletBroken();
                break;
                
            case LOCKER_BROKEN:
                statistics.addKillerLockerBroken();
                break;
        }
        
        // Record match event
        if (type != TransitionType.UNKNOWN) {
            MatchStatistics.MatchEvent event = new MatchStatistics.MatchEvent(
                convertToEventType(type),
                playerId,
                playerId != null ? "Player" : "System"
            );
            if (data != null) {
                event.setData(new HashMap<>(data));
            }
            statistics.addMatchEvent(event);
        }
    }
    
    /**
     * Check for match end conditions.
     */
    private void checkMatchEndConditions() {
        if (match.getStatus() != MatchStatus.IN_PROGRESS) {
            return;
        }
        
        // Check if all survivors have escaped
        if (haveAllSurvivorsEscaped()) {
            processTransition(TransitionType.ALL_SURVIVORS_ESCAPED, null, null);
            return;
        }
        
        // Check if all survivors are dead
        if (areAllSurvivorsDead()) {
            processTransition(TransitionType.ALL_SURVIVORS_DEAD, null, null);
            return;
        }
        
        // Check if match time has expired
        if (hasMatchTimeExpired()) {
            processTransition(TransitionType.TIME_EXPIRED, null, null);
            return;
        }
        
        // Check for emergency exit conditions
        Map<String, Object> data = new HashMap<>();
        data.put("emergencyExit", true);
        if (canEmergencyExitOpen(data)) {
            processTransition(TransitionType.EMERGENCY_EXIT_OPENED, null, data);
        }
    }
    
    // Validation methods
    private boolean canMatchStart() {
        if (match == null) return false;
        
        // Check minimum players
        int playerCount = match.getPlayers().size();
        int minPlayers = match.getSettings().getMinPlayers();
        
        return playerCount >= minPlayers;
    }
    
    private boolean areAllPlayersReady() {
        if (match == null) return false;
        
        // In a real implementation, check if all players have confirmed ready
        return true;
    }
    
    private boolean haveAllSurvivorsEscaped() {
        if (match == null || statistics == null) return false;
        
        int totalSurvivors = statistics.getTotalSurvivors();
        int escapedSurvivors = statistics.getSurvivorsEscaped();
        
        return totalSurvivors > 0 && escapedSurvivors == totalSurvivors;
    }
    
    private boolean areAllSurvivorsDead() {
        if (match == null || statistics == null) return false;
        
        int totalSurvivors = statistics.getTotalSurvivors();
        int deadSurvivors = statistics.getSurvivorsSacrificed() + statistics.getSurvivorsKilled();
        
        return totalSurvivors > 0 && deadSurvivors == totalSurvivors;
    }
    
    private boolean hasMatchTimeExpired() {
        if (match == null) return false;
        
        Instant startTime = match.getStartTime();
        if (startTime == null) return false;
        
        long matchDuration = match.getSettings().getMatchDuration();
        long elapsedSeconds = Instant.now().getEpochSecond() - startTime.getEpochSecond();
        
        return elapsedSeconds >= matchDuration;
    }
    
    private boolean canEmergencyExitOpen(Map<String, Object> data) {
        if (match == null || statistics == null) return false;
        
        // Emergency exit opens when only one survivor remains alive
        int totalSurvivors = statistics.getTotalSurvivors();
        int aliveSurvivors = statistics.getSurvivorsAlive();
        
        return totalSurvivors > 0 && aliveSurvivors == 1;
    }
    
    // Event handlers
    private void onMatchStart() {
        match.setStartTime(Instant.now());
        statistics.setMatchStartTime(Instant.now());
        
        // Initialize map state
        match.getMapState().initialize();
    }
    
    private void onMatchReady() {
        // Start the match timer
        match.setStartTime(Instant.now());
    }
    
    private void onAllSurvivorsEscaped() {
        match.setEndTime(Instant.now());
        statistics.setMatchEndTime(Instant.now());
        statistics.calculatePerformanceScores();
    }
    
    private void onAllSurvivorsDead() {
        match.setEndTime(Instant.now());
        statistics.setMatchEndTime(Instant.now());
        statistics.calculatePerformanceScores();
    }
    
    private void onTimeExpired() {
        match.setEndTime(Instant.now());
        statistics.setMatchEndTime(Instant.now());
        statistics.calculatePerformanceScores();
    }
    
    private void onEmergencyExitOpened(Map<String, Object> data) {
        match.setEndTime(Instant.now());
        statistics.setMatchEndTime(Instant.now());
        statistics.calculatePerformanceScores();
    }
    
    private void onMatchComplete() {
        // Finalize statistics
        statistics.endMatch();
        statistics.calculatePerformanceScores();
        
        // Clean up match resources
        match.cleanup();
    }
    
    private void notifyStateChange(MatchStatus oldStatus, MatchStatus newStatus, 
                                  TransitionType type, UUID playerId) {
        // In a real implementation, notify listeners (GUI, other systems)
        System.out.println("Match state changed: " + oldStatus + " -> " + newStatus + " (type: " + type + ")");
    }
    
    /**
     * Convert TransitionType to MatchStatistics.EventType.
     */
    private MatchStatistics.EventType convertToEventType(TransitionType transitionType) {
        switch (transitionType) {
            case MATCH_START: return MatchStatistics.EventType.MATCH_START;
            case MATCH_READY: return MatchStatistics.EventType.MATCH_START;
            case ALL_SURVIVORS_ESCAPED: return MatchStatistics.EventType.SURVIVOR_ESCAPED;
            case ALL_SURVIVORS_DEAD: return MatchStatistics.EventType.SURVIVOR_SACRIFICED;
            case TIME_EXPIRED: return MatchStatistics.EventType.MATCH_END;
            case EMERGENCY_EXIT_OPENED: return MatchStatistics.EventType.EMERGENCY_EXIT_OPENED;
            case MATCH_COMPLETE: return MatchStatistics.EventType.MATCH_END;
            case GENERATOR_COMPLETED: return MatchStatistics.EventType.GENERATOR_COMPLETED;
            case GENERATOR_DAMAGED: return MatchStatistics.EventType.GENERATOR_DAMAGED;
            case HOOK_USED: return MatchStatistics.EventType.HOOK_COMPLETED;
            case HOOK_RESCUED: return MatchStatistics.EventType.HOOK_RESCUE;
            case CHEST_SEARCHED: return MatchStatistics.EventType.CHEST_SEARCH_COMPLETED;
            case LOCKER_USED: return MatchStatistics.EventType.LOCKER_ENTERED;
            case LOCKER_BROKEN: return MatchStatistics.EventType.LOCKER_BROKEN;
            case EXIT_GATE_OPENED: return MatchStatistics.EventType.EXIT_GATE_OPENED;
            case EMERGENCY_EXIT_USED: return MatchStatistics.EventType.EMERGENCY_EXIT_USED;
            case SURVIVOR_HIT: return MatchStatistics.EventType.SURVIVOR_HIT;
            case SURVIVOR_DOWNED: return MatchStatistics.EventType.SURVIVOR_DOWNED;
            case SURVIVOR_ESCAPED: return MatchStatistics.EventType.SURVIVOR_ESCAPED;
            case SURVIVOR_SACRIFICED: return MatchStatistics.EventType.SURVIVOR_SACRIFICED;
            case SURVIVOR_KILLED: return MatchStatistics.EventType.SURVIVOR_KILLED;
            case PALLET_BROKEN: return MatchStatistics.EventType.PALLET_BROKEN;
            default: return MatchStatistics.EventType.UNKNOWN;
        }
    }
    
    /**
     * Types of transitions that can occur in a match.
     */
    public enum TransitionType {
        UNKNOWN,
        MATCH_START,
        MATCH_READY,
        ALL_SURVIVORS_ESCAPED,
        ALL_SURVIVORS_DEAD,
        TIME_EXPIRED,
        EMERGENCY_EXIT_OPENED,
        MATCH_COMPLETE,
        GENERATOR_COMPLETED,
        GENERATOR_DAMAGED,
        HOOK_USED,
        HOOK_RESCUED,
        CHEST_SEARCHED,
        LOCKER_USED,
        LOCKER_BROKEN,
        EXIT_GATE_OPENED,
        EMERGENCY_EXIT_USED,
        SURVIVOR_HIT,
        SURVIVOR_DOWNED,
        SURVIVOR_ESCAPED,
        SURVIVOR_SACRIFICED,
        SURVIVOR_KILLED,
        PALLET_BROKEN,
        SKILL_CHECK_SUCCESS,
        SKILL_CHECK_FAILURE,
        BLOODLUST_ACTIVATED,
        MORI_EXECUTION
    }
    
    /**
     * Record of a state transition.
     */
    public static class StateTransition {
        private UUID transitionId;
        private MatchStatus fromStatus;
        private MatchStatus toStatus;
        private TransitionType transitionType;
        private UUID playerId;
        private Map<String, Object> data;
        private Instant timestamp;
        
        public StateTransition(MatchStatus fromStatus, MatchStatus toStatus, 
                              TransitionType transitionType, UUID playerId, Map<String, Object> data) {
            this.transitionId = UUID.randomUUID();
            this.fromStatus = fromStatus;
            this.toStatus = toStatus;
            this.transitionType = transitionType;
            this.playerId = playerId;
            this.data = data != null ? new HashMap<>(data) : new HashMap<>();
            this.timestamp = Instant.now();
        }
        
        // Getters
        public UUID getTransitionId() { return transitionId; }
        public MatchStatus getFromStatus() { return fromStatus; }
        public MatchStatus getToStatus() { return toStatus; }
        public TransitionType getTransitionType() { return transitionType; }
        public UUID getPlayerId() { return playerId; }
        public Map<String, Object> getData() { return data; }
        public Instant getTimestamp() { return timestamp; }
        
        @Override
        public String toString() {
            return String.format("StateTransition{from=%s, to=%s, type=%s, player=%s, time=%s}",
                    fromStatus, toStatus, transitionType, 
                    playerId != null ? playerId.toString().substring(0, 8) : "null",
                    timestamp.toString());
        }
    }
    
    /**
     * Process a game event (simplified interface for common events).
     */
    public boolean processGameEvent(TransitionType eventType, UUID playerId) {
        return processTransition(eventType, playerId, null);
    }
    
    /**
     * Process a game event with data.
     */
    public boolean processGameEvent(TransitionType eventType, UUID playerId, Map<String, Object> data) {
        return processTransition(eventType, playerId, data);
    }
    
    /**
     * Get the current match status.
     */
    public MatchStatus getCurrentStatus() {
        return match != null ? match.getStatus() : null;
    }
    
    /**
     * Check if match is in progress.
     */
    public boolean isMatchInProgress() {
        return match != null && match.getStatus() == MatchStatus.IN_PROGRESS;
    }
    
    /**
     * Check if match is completed.
     */
    public boolean isMatchCompleted() {
        return match != null && match.getStatus() == MatchStatus.COMPLETED;
    }
    
    /**
     * Get match duration in seconds.
     */
    public long getMatchDuration() {
        if (match == null) return 0;
        
        Instant start = match.getStartTime();
        Instant end = match.getEndTime();
        
        if (start == null) return 0;
        if (end == null) return Instant.now().getEpochSecond() - start.getEpochSecond();
        
        return end.getEpochSecond() - start.getEpochSecond();
    }
    
    /**
     * Get time remaining in match (if in progress).
     */
    public long getTimeRemaining() {
        if (!isMatchInProgress() || match == null) return 0;
        
        Instant start = match.getStartTime();
        if (start == null) return 0;
        
        long matchDuration = match.getSettings().getMatchDuration();
        long elapsed = Instant.now().getEpochSecond() - start.getEpochSecond();
        
        return Math.max(0, matchDuration - elapsed);
    }
    
    /**
     * Get formatted time remaining.
     */
    public String getFormattedTimeRemaining() {
        long seconds = getTimeRemaining();
        long minutes = seconds / 60;
        long remainingSeconds = seconds % 60;
        
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }
    
    /**
     * Get match result summary.
     */
    public String getMatchResultSummary() {
        if (match == null || statistics == null) return "No match data";
        
        MatchStatus status = match.getStatus();
        switch (status) {
            case ENDING_SURVIVOR_VICTORY:
                return "Survivor Victory - " + statistics.getSurvivorsEscaped() + " escaped";
            case ENDING_KILLER_VICTORY:
                return "Killer Victory - " + (statistics.getSurvivorsSacrificed() + statistics.getSurvivorsKilled()) + " killed";
            case ENDING_DRAW:
                return "Draw - Time expired";
            case COMPLETED:
                return "Match Completed - " + statistics.getMatchSummary();
            default:
                return "Match in progress - " + getFormattedTimeRemaining() + " remaining";
        }
    }
}
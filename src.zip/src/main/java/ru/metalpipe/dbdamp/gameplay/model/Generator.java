package ru.metalpipe.dbdamp.gameplay.model;

import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.time.Instant;
import java.util.*;

/**
 * Generator object for DBD gameplay - survivors must repair generators to power exit gates.
 */
public class Generator {
    
    private UUID generatorId;
    private Location location;
    private int progress; // 0-10000 (100.00%)
    private boolean completed;
    private boolean regressing;
    private int regressionRate; // progress lost per tick
    private Instant lastRepaired;
    private UUID lastRepairer;
    private List<UUID> repairers;
    private int skillCheckCount;
    private int failedSkillChecks;
    private int successfulSkillChecks;
    private double difficulty; // 0.0 - 1.0
    private boolean damaged; // Damaged by killer
    private int damageCooldown; // Ticks until can be damaged again
    private Map<String, Object> metadata;
    
    public Generator() {
        this.generatorId = UUID.randomUUID();
        this.location = null;
        this.progress = 0;
        this.completed = false;
        this.regressing = false;
        this.regressionRate = 1; // 0.01% per tick
        this.lastRepaired = Instant.now();
        this.lastRepairer = null;
        this.repairers = new ArrayList<>();
        this.skillCheckCount = 0;
        this.failedSkillChecks = 0;
        this.successfulSkillChecks = 0;
        this.difficulty = 0.5;
        this.damaged = false;
        this.damageCooldown = 0;
        this.metadata = new HashMap<>();
    }
    
    public Generator(Location location) {
        this();
        this.location = location;
    }
    
    public Generator(Location location, double difficulty) {
        this(location);
        this.difficulty = Math.max(0.0, Math.min(1.0, difficulty));
    }
    
    // Getters and setters
    public UUID getGeneratorId() { return generatorId; }
    public void setGeneratorId(UUID generatorId) { this.generatorId = generatorId; }
    
    public Location getLocation() { return location; }
    public void setLocation(Location location) { this.location = location; }
    
    public int getProgress() { return progress; }
    public void setProgress(int progress) { 
        this.progress = Math.max(0, Math.min(10000, progress));
        if (this.progress >= 10000) {
            complete();
        }
    }
    
    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { 
        this.completed = completed;
        if (completed) {
            this.progress = 10000;
        }
    }
    
    public boolean isRegressing() { return regressing; }
    public void setRegressing(boolean regressing) { this.regressing = regressing; }
    
    public int getRegressionRate() { return regressionRate; }
    public void setRegressionRate(int regressionRate) { 
        this.regressionRate = Math.max(0, regressionRate); 
    }
    
    public Instant getLastRepaired() { return lastRepaired; }
    public void setLastRepaired(Instant lastRepaired) { this.lastRepaired = lastRepaired; }
    
    public UUID getLastRepairer() { return lastRepairer; }
    public void setLastRepairer(UUID lastRepairer) { this.lastRepairer = lastRepairer; }
    
    public List<UUID> getRepairers() { return repairers; }
    public void setRepairers(List<UUID> repairers) { this.repairers = repairers; }
    
    public int getSkillCheckCount() { return skillCheckCount; }
    public void setSkillCheckCount(int skillCheckCount) { this.skillCheckCount = skillCheckCount; }
    
    public int getFailedSkillChecks() { return failedSkillChecks; }
    public void setFailedSkillChecks(int failedSkillChecks) { this.failedSkillChecks = failedSkillChecks; }
    
    public int getSuccessfulSkillChecks() { return successfulSkillChecks; }
    public void setSuccessfulSkillChecks(int successfulSkillChecks) { this.successfulSkillChecks = successfulSkillChecks; }
    
    public double getDifficulty() { return difficulty; }
    public void setDifficulty(double difficulty) { 
        this.difficulty = Math.max(0.0, Math.min(1.0, difficulty)); 
    }
    
    public boolean isDamaged() { return damaged; }
    public void setDamaged(boolean damaged) { this.damaged = damaged; }
    
    public int getDamageCooldown() { return damageCooldown; }
    public void setDamageCooldown(int damageCooldown) { this.damageCooldown = damageCooldown; }
    
    public Map<String, Object> getMetadata() { return metadata; }
    public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }
    
    // Helper methods
    public void repair(int amount, UUID repairer) {
        if (completed || damaged) return;
        
        progress = Math.min(10000, progress + amount);
        lastRepaired = Instant.now();
        lastRepairer = repairer;
        
        if (!repairers.contains(repairer)) {
            repairers.add(repairer);
        }
        
        if (progress >= 10000) {
            complete();
        }
    }
    
    public void regress() {
        if (completed || !regressing) return;
        
        progress = Math.max(0, progress - regressionRate);
        
        if (progress == 0) {
            regressing = false;
        }
    }
    
    public void complete() {
        completed = true;
        progress = 10000;
        regressing = false;
        damaged = false;
    }
    
    public void damage() {
        if (completed || damaged || damageCooldown > 0) return;
        
        damaged = true;
        regressing = true;
        damageCooldown = 200; // 10 seconds cooldown
    }
    
    public void updateDamageCooldown() {
        if (damageCooldown > 0) {
            damageCooldown--;
        }
    }
    
    public void addSkillCheck(boolean successful) {
        skillCheckCount++;
        if (successful) {
            successfulSkillChecks++;
        } else {
            failedSkillChecks++;
        }
    }
    
    public double getSuccessRate() {
        if (skillCheckCount == 0) return 0.0;
        return (double) successfulSkillChecks / skillCheckCount;
    }
    
    public double getProgressPercentage() {
        return progress / 100.0;
    }
    
    public String getProgressFormatted() {
        return String.format("%.1f%%", getProgressPercentage());
    }
    
    public int getRemainingProgress() {
        return 10000 - progress;
    }
    
    public boolean isBeingRepaired() {
        return !repairers.isEmpty() && !completed && !damaged;
    }
    
    public int getRepairerCount() {
        return repairers.size();
    }
    
    public void addRepairer(UUID playerId) {
        if (!repairers.contains(playerId)) {
            repairers.add(playerId);
        }
    }
    
    public void removeRepairer(UUID playerId) {
        repairers.remove(playerId);
        if (repairers.isEmpty() && !completed) {
            regressing = true;
        }
    }
    
    public void clearRepairers() {
        repairers.clear();
        if (!completed) {
            regressing = true;
        }
    }
    
    public boolean hasRepairer(UUID playerId) {
        return repairers.contains(playerId);
    }
    
    public Block getBlock() {
        return location != null ? location.getBlock() : null;
    }
    
    public double getSkillCheckFrequency() {
        // Higher difficulty = more frequent skill checks
        return 200 - (difficulty * 100); // 100-200 ticks (5-10 seconds)
    }
    
    public int getSkillCheckWindow() {
        // Higher difficulty = smaller skill check window
        return (int) (25 - (difficulty * 15)); // 10-25 ticks (0.5-1.25 seconds)
    }
    
    public double getRepairSpeedMultiplier() {
        // More repairers = faster repair, but with diminishing returns
        int count = repairers.size();
        if (count == 0) return 0.0;
        if (count == 1) return 1.0;
        if (count == 2) return 1.8;
        if (count == 3) return 2.4;
        return 2.8; // Max 4 repairers
    }
    
    public void reset() {
        progress = 0;
        completed = false;
        regressing = false;
        damaged = false;
        damageCooldown = 0;
        repairers.clear();
        lastRepairer = null;
        skillCheckCount = 0;
        failedSkillChecks = 0;
        successfulSkillChecks = 0;
        lastRepaired = Instant.now();
    }
    
    public void addMetadata(String key, Object value) {
        metadata.put(key, value);
    }
    
    public Object getMetadata(String key) {
        return metadata.get(key);
    }
    
    public void removeMetadata(String key) {
        metadata.remove(key);
    }
    
    public Generator copy() {
        Generator copy = new Generator();
        copy.generatorId = this.generatorId;
        copy.location = this.location != null ? this.location.clone() : null;
        copy.progress = this.progress;
        copy.completed = this.completed;
        copy.regressing = this.regressing;
        copy.regressionRate = this.regressionRate;
        copy.lastRepaired = this.lastRepaired;
        copy.lastRepairer = this.lastRepairer;
        copy.repairers = new ArrayList<>(this.repairers);
        copy.skillCheckCount = this.skillCheckCount;
        copy.failedSkillChecks = this.failedSkillChecks;
        copy.successfulSkillChecks = this.successfulSkillChecks;
        copy.difficulty = this.difficulty;
        copy.damaged = this.damaged;
        copy.damageCooldown = this.damageCooldown;
        copy.metadata = new HashMap<>(this.metadata);
        return copy;
    }
    
    @Override
    public String toString() {
        return "Generator{" +
               "id=" + generatorId +
               ", progress=" + getProgressFormatted() +
               ", completed=" + completed +
               ", damaged=" + damaged +
               ", repairers=" + repairers.size() +
               ", difficulty=" + String.format("%.1f", difficulty) +
               ", skillChecks=" + successfulSkillChecks + "/" + skillCheckCount +
               " (" + String.format("%.1f%%", getSuccessRate() * 100) + ")" +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Generator generator = (Generator) o;
        return Objects.equals(generatorId, generator.generatorId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(generatorId);
    }
}
package ru.metalpipe.dbdamp.gameplay.model;

import java.time.Instant;
import java.util.*;

/**
 * Statistics tracking for a DBD match - records all match data for analysis and rewards.
 */
public class MatchStatistics {
    
    private UUID matchId;
    private Instant matchStartTime;
    private Instant matchEndTime;
    private long matchDuration; // in seconds
    
    // Team statistics
    private int survivorsEscaped;
    private int survivorsSacrificed;
    private int survivorsKilled;
    private int survivorsDisconnected;
    private int generatorsCompleted;
    private int generatorsTotal;
    private int hooksUsed;
    private int hooksTotal;
    private int chestsSearched;
    private int chestsTotal;
    private int lockersUsed;
    private int lockersTotal;
    private int exitGatesOpened;
    private int exitGatesTotal;
    private int emergencyExitsUsed;
    
    // Killer statistics
    private int killerHits;
    private int killerDowns;
    private int killerHooks;
    private int killerSacrifices;
    private int killerMoriExecutions;
    private int killerGeneratorsDamaged;
    private int killerPalletsBroken;
    private int killerLockersBroken;
    
    // Survivor statistics (per player)
    private Map<UUID, SurvivorStats> survivorStats;
    
    // Match events
    private List<MatchEvent> matchEvents;
    
    // Performance metrics
    private double matchBalanceScore; // 0.0-1.0, how balanced the match was
    private double killerPerformanceScore; // 0.0-1.0
    private double survivorPerformanceScore; // 0.0-1.0
    private boolean wasCloseMatch; // Whether the match was close (e.g., 3-4 generators)
    private boolean wasStompMatch; // Whether the match was one-sided
    
    public MatchStatistics() {
        this.matchId = UUID.randomUUID();
        this.matchStartTime = Instant.now();
        this.matchEndTime = null;
        this.matchDuration = 0;
        
        this.survivorsEscaped = 0;
        this.survivorsSacrificed = 0;
        this.survivorsKilled = 0;
        this.survivorsDisconnected = 0;
        this.generatorsCompleted = 0;
        this.generatorsTotal = 0;
        this.hooksUsed = 0;
        this.hooksTotal = 0;
        this.chestsSearched = 0;
        this.chestsTotal = 0;
        this.lockersUsed = 0;
        this.lockersTotal = 0;
        this.exitGatesOpened = 0;
        this.exitGatesTotal = 0;
        this.emergencyExitsUsed = 0;
        
        this.killerHits = 0;
        this.killerDowns = 0;
        this.killerHooks = 0;
        this.killerSacrifices = 0;
        this.killerMoriExecutions = 0;
        this.killerGeneratorsDamaged = 0;
        this.killerPalletsBroken = 0;
        this.killerLockersBroken = 0;
        
        this.survivorStats = new HashMap<>();
        this.matchEvents = new ArrayList<>();
        
        this.matchBalanceScore = 0.5;
        this.killerPerformanceScore = 0.5;
        this.survivorPerformanceScore = 0.5;
        this.wasCloseMatch = false;
        this.wasStompMatch = false;
    }
    
    public MatchStatistics(UUID matchId) {
        this();
        this.matchId = matchId;
    }
    
    // Getters and setters
    public UUID getMatchId() { return matchId; }
    public void setMatchId(UUID matchId) { this.matchId = matchId; }
    
    public Instant getMatchStartTime() { return matchStartTime; }
    public void setMatchStartTime(Instant matchStartTime) { this.matchStartTime = matchStartTime; }
    
    public Instant getMatchEndTime() { return matchEndTime; }
    public void setMatchEndTime(Instant matchEndTime) { 
        this.matchEndTime = matchEndTime;
        if (matchStartTime != null && matchEndTime != null) {
            this.matchDuration = matchEndTime.getEpochSecond() - matchStartTime.getEpochSecond();
        }
    }
    
    public long getMatchDuration() { return matchDuration; }
    public void setMatchDuration(long matchDuration) { this.matchDuration = matchDuration; }
    
    public int getSurvivorsEscaped() { return survivorsEscaped; }
    public void setSurvivorsEscaped(int survivorsEscaped) { this.survivorsEscaped = survivorsEscaped; }
    
    public int getSurvivorsSacrificed() { return survivorsSacrificed; }
    public void setSurvivorsSacrificed(int survivorsSacrificed) { this.survivorsSacrificed = survivorsSacrificed; }
    
    public int getSurvivorsKilled() { return survivorsKilled; }
    public void setSurvivorsKilled(int survivorsKilled) { this.survivorsKilled = survivorsKilled; }
    
    public int getSurvivorsDisconnected() { return survivorsDisconnected; }
    public void setSurvivorsDisconnected(int survivorsDisconnected) { this.survivorsDisconnected = survivorsDisconnected; }
    
    public int getGeneratorsCompleted() { return generatorsCompleted; }
    public void setGeneratorsCompleted(int generatorsCompleted) { this.generatorsCompleted = generatorsCompleted; }
    
    public int getGeneratorsTotal() { return generatorsTotal; }
    public void setGeneratorsTotal(int generatorsTotal) { this.generatorsTotal = generatorsTotal; }
    
    public int getHooksUsed() { return hooksUsed; }
    public void setHooksUsed(int hooksUsed) { this.hooksUsed = hooksUsed; }
    
    public int getHooksTotal() { return hooksTotal; }
    public void setHooksTotal(int hooksTotal) { this.hooksTotal = hooksTotal; }
    
    public int getChestsSearched() { return chestsSearched; }
    public void setChestsSearched(int chestsSearched) { this.chestsSearched = chestsSearched; }
    
    public int getChestsTotal() { return chestsTotal; }
    public void setChestsTotal(int chestsTotal) { this.chestsTotal = chestsTotal; }
    
    public int getLockersUsed() { return lockersUsed; }
    public void setLockersUsed(int lockersUsed) { this.lockersUsed = lockersUsed; }
    
    public int getLockersTotal() { return lockersTotal; }
    public void setLockersTotal(int lockersTotal) { this.lockersTotal = lockersTotal; }
    
    public int getExitGatesOpened() { return exitGatesOpened; }
    public void setExitGatesOpened(int exitGatesOpened) { this.exitGatesOpened = exitGatesOpened; }
    
    public int getExitGatesTotal() { return exitGatesTotal; }
    public void setExitGatesTotal(int exitGatesTotal) { this.exitGatesTotal = exitGatesTotal; }
    
    public int getEmergencyExitsUsed() { return emergencyExitsUsed; }
    public void setEmergencyExitsUsed(int emergencyExitsUsed) { this.emergencyExitsUsed = emergencyExitsUsed; }
    
    public int getKillerHits() { return killerHits; }
    public void setKillerHits(int killerHits) { this.killerHits = killerHits; }
    
    public int getKillerDowns() { return killerDowns; }
    public void setKillerDowns(int killerDowns) { this.killerDowns = killerDowns; }
    
    public int getKillerHooks() { return killerHooks; }
    public void setKillerHooks(int killerHooks) { this.killerHooks = killerHooks; }
    
    public int getKillerSacrifices() { return killerSacrifices; }
    public void setKillerSacrifices(int killerSacrifices) { this.killerSacrifices = killerSacrifices; }
    
    public int getKillerMoriExecutions() { return killerMoriExecutions; }
    public void setKillerMoriExecutions(int killerMoriExecutions) { this.killerMoriExecutions = killerMoriExecutions; }
    
    public int getKillerGeneratorsDamaged() { return killerGeneratorsDamaged; }
    public void setKillerGeneratorsDamaged(int killerGeneratorsDamaged) { this.killerGeneratorsDamaged = killerGeneratorsDamaged; }
    
    public int getKillerPalletsBroken() { return killerPalletsBroken; }
    public void setKillerPalletsBroken(int killerPalletsBroken) { this.killerPalletsBroken = killerPalletsBroken; }
    
    public int getKillerLockersBroken() { return killerLockersBroken; }
    public void setKillerLockersBroken(int killerLockersBroken) { this.killerLockersBroken = killerLockersBroken; }
    
    public Map<UUID, SurvivorStats> getSurvivorStats() { return survivorStats; }
    public void setSurvivorStats(Map<UUID, SurvivorStats> survivorStats) { this.survivorStats = survivorStats; }
    
    public List<MatchEvent> getMatchEvents() { return matchEvents; }
    public void setMatchEvents(List<MatchEvent> matchEvents) { this.matchEvents = matchEvents; }
    
    public double getMatchBalanceScore() { return matchBalanceScore; }
    public void setMatchBalanceScore(double matchBalanceScore) { 
        this.matchBalanceScore = Math.max(0.0, Math.min(1.0, matchBalanceScore)); 
    }
    
    public double getKillerPerformanceScore() { return killerPerformanceScore; }
    public void setKillerPerformanceScore(double killerPerformanceScore) { 
        this.killerPerformanceScore = Math.max(0.0, Math.min(1.0, killerPerformanceScore)); 
    }
    
    public double getSurvivorPerformanceScore() { return survivorPerformanceScore; }
    public void setSurvivorPerformanceScore(double survivorPerformanceScore) { 
        this.survivorPerformanceScore = Math.max(0.0, Math.min(1.0, survivorPerformanceScore)); 
    }
    
    public boolean wasCloseMatch() { return wasCloseMatch; }
    public void setWasCloseMatch(boolean wasCloseMatch) { this.wasCloseMatch = wasCloseMatch; }
    
    public boolean wasStompMatch() { return wasStompMatch; }
    public void setWasStompMatch(boolean wasStompMatch) { this.wasStompMatch = wasStompMatch; }
    
    // Helper methods
    public void endMatch() {
        if (matchEndTime == null) {
            matchEndTime = Instant.now();
            matchDuration = matchEndTime.getEpochSecond() - matchStartTime.getEpochSecond();
        }
    }
    
    public void addSurvivorEscaped() {
        survivorsEscaped++;
    }
    
    public void addSurvivorSacrificed() {
        survivorsSacrificed++;
    }
    
    public void addSurvivorKilled() {
        survivorsKilled++;
    }
    
    public void addSurvivorDisconnected() {
        survivorsDisconnected++;
    }
    
    public void addGeneratorCompleted() {
        generatorsCompleted++;
    }
    
    public void addHookUsed() {
        hooksUsed++;
    }
    
    public void addChestSearched() {
        chestsSearched++;
    }
    
    public void addLockerUsed() {
        lockersUsed++;
    }
    
    public void addExitGateOpened() {
        exitGatesOpened++;
    }
    
    public void addEmergencyExitUsed() {
        emergencyExitsUsed++;
    }
    
    public void addKillerHit() {
        killerHits++;
    }
    
    public void addKillerDown() {
        killerDowns++;
    }
    
    public void addKillerHook() {
        killerHooks++;
    }
    
    public void addKillerSacrifice() {
        killerSacrifices++;
    }
    
    public void addKillerMoriExecution() {
        killerMoriExecutions++;
    }
    
    public void addKillerGeneratorDamaged() {
        killerGeneratorsDamaged++;
    }
    
    public void addKillerPalletBroken() {
        killerPalletsBroken++;
    }
    
    public void addKillerLockerBroken() {
        killerLockersBroken++;
    }
    
    public void addSurvivorStat(UUID playerId, SurvivorStats stat) {
        survivorStats.put(playerId, stat);
    }
    
    public SurvivorStats getSurvivorStat(UUID playerId) {
        return survivorStats.get(playerId);
    }
    
    public void addPlayer(UUID playerId, PlayerRole role) {
        if (role == PlayerRole.SURVIVOR) {
            SurvivorStats stats = new SurvivorStats(playerId, "Player");
            survivorStats.put(playerId, stats);
        }
        // For killer, we don't track individual stats in survivorStats
    }
    
    public void removePlayer(UUID playerId) {
        survivorStats.remove(playerId);
    }
    
    public void reset() {
        matchId = UUID.randomUUID();
        matchStartTime = Instant.now();
        matchEndTime = null;
        matchDuration = 0;
        
        survivorsEscaped = 0;
        survivorsSacrificed = 0;
        survivorsKilled = 0;
        survivorsDisconnected = 0;
        generatorsCompleted = 0;
        generatorsTotal = 0;
        hooksUsed = 0;
        hooksTotal = 0;
        chestsSearched = 0;
        chestsTotal = 0;
        lockersUsed = 0;
        lockersTotal = 0;
        exitGatesOpened = 0;
        exitGatesTotal = 0;
        emergencyExitsUsed = 0;
        
        killerHits = 0;
        killerDowns = 0;
        killerHooks = 0;
        killerSacrifices = 0;
        killerMoriExecutions = 0;
        killerGeneratorsDamaged = 0;
        killerPalletsBroken = 0;
        killerLockersBroken = 0;
        
        survivorStats.clear();
        matchEvents.clear();
        
        matchBalanceScore = 0.5;
        killerPerformanceScore = 0.5;
        survivorPerformanceScore = 0.5;
        wasCloseMatch = false;
        wasStompMatch = false;
    }
    
    public void addMatchEvent(MatchEvent event) {
        matchEvents.add(event);
    }
    
    public int getTotalSurvivors() {
        return survivorsEscaped + survivorsSacrificed + survivorsKilled + survivorsDisconnected;
    }
    
    public int getSurvivorsAlive() {
        return getTotalSurvivors() - (survivorsSacrificed + survivorsKilled + survivorsDisconnected);
    }
    
    public double getGeneratorCompletionRate() {
        if (generatorsTotal == 0) return 0.0;
        return (double) generatorsCompleted / generatorsTotal;
    }
    
    public double getHookUsageRate() {
        if (hooksTotal == 0) return 0.0;
        return (double) hooksUsed / hooksTotal;
    }
    
    public int getTotalHooks() {
        return hooksTotal;
    }
    
    public double getChestSearchRate() {
        if (chestsTotal == 0) return 0.0;
        return (double) chestsSearched / chestsTotal;
    }
    
    public double getLockerUsageRate() {
        if (lockersTotal == 0) return 0.0;
        return (double) lockersUsed / lockersTotal;
    }
    
    public double getExitGateOpenRate() {
        if (exitGatesTotal == 0) return 0.0;
        return (double) exitGatesOpened / exitGatesTotal;
    }
    
    public double getKillerEfficiency() {
        int totalSurvivors = getTotalSurvivors();
        if (totalSurvivors == 0) return 0.0;
        return (double) (survivorsSacrificed + survivorsKilled) / totalSurvivors;
    }
    
    public double getSurvivorEscapeRate() {
        int totalSurvivors = getTotalSurvivors();
        if (totalSurvivors == 0) return 0.0;
        return (double) survivorsEscaped / totalSurvivors;
    }
    
    public void calculatePerformanceScores() {
        // Calculate killer performance score
        double killerScore = 0.0;
        int totalSurvivors = getTotalSurvivors();
        
        if (totalSurvivors > 0) {
            // Base score from kills/sacrifices (0-0.5)
            double killScore = (double) (survivorsSacrificed + survivorsKilled) / totalSurvivors * 0.5;
            
            // Bonus for hooks and downs (0-0.3)
            double actionScore = Math.min(0.3, (killerHooks + killerDowns) / 20.0);
            
            // Bonus for generator pressure (0-0.2)
            double pressureScore = Math.min(0.2, killerGeneratorsDamaged / 10.0);
            
            killerScore = killScore + actionScore + pressureScore;
        }
        
        killerPerformanceScore = Math.min(1.0, killerScore);
        
        // Calculate survivor performance score
        double survivorScore = 0.0;
        
        if (generatorsTotal > 0) {
            // Base score from generator completion (0-0.4)
            double generatorScore = getGeneratorCompletionRate() * 0.4;
            
            // Bonus for escapes (0-0.4)
            double escapeScore = getSurvivorEscapeRate() * 0.4;
            
            // Bonus for teamwork (hooks, healing, etc.) (0-0.2)
            double teamworkScore = Math.min(0.2, (hooksUsed + chestsSearched) / 30.0);
            
            survivorScore = generatorScore + escapeScore + teamworkScore;
        }
        
        survivorPerformanceScore = Math.min(1.0, survivorScore);
        
        // Calculate match balance score
        matchBalanceScore = 1.0 - Math.abs(killerPerformanceScore - survivorPerformanceScore);
        
        // Determine if match was close or stomp
        wasCloseMatch = matchBalanceScore > 0.6;
        wasStompMatch = matchBalanceScore < 0.3;
    }
    
    public String getMatchSummary() {
        return String.format("Match %s: %d survivors escaped, %d sacrificed/killed, %d generators completed, duration: %d seconds",
                matchId.toString().substring(0, 8),
                survivorsEscaped,
                survivorsSacrificed + survivorsKilled,
                generatorsCompleted,
                matchDuration);
    }
    
    public MatchStatistics copy() {
        MatchStatistics copy = new MatchStatistics();
        copy.matchId = this.matchId;
        copy.matchStartTime = this.matchStartTime;
        copy.matchEndTime = this.matchEndTime;
        copy.matchDuration = this.matchDuration;
        
        copy.survivorsEscaped = this.survivorsEscaped;
        copy.survivorsSacrificed = this.survivorsSacrificed;
        copy.survivorsKilled = this.survivorsKilled;
        copy.survivorsDisconnected = this.survivorsDisconnected;
        copy.generatorsCompleted = this.generatorsCompleted;
        copy.generatorsTotal = this.generatorsTotal;
        copy.hooksUsed = this.hooksUsed;
        copy.hooksTotal = this.hooksTotal;
        copy.chestsSearched = this.chestsSearched;
        copy.chestsTotal = this.chestsTotal;
        copy.lockersUsed = this.lockersUsed;
        copy.lockersTotal = this.lockersTotal;
        copy.exitGatesOpened = this.exitGatesOpened;
        copy.exitGatesTotal = this.exitGatesTotal;
        copy.emergencyExitsUsed = this.emergencyExitsUsed;
        
        copy.killerHits = this.killerHits;
        copy.killerDowns = this.killerDowns;
        copy.killerHooks = this.killerHooks;
        copy.killerSacrifices = this.killerSacrifices;
        copy.killerMoriExecutions = this.killerMoriExecutions;
        copy.killerGeneratorsDamaged = this.killerGeneratorsDamaged;
        copy.killerPalletsBroken = this.killerPalletsBroken;
        copy.killerLockersBroken = this.killerLockersBroken;
        
        copy.survivorStats = new HashMap<>(this.survivorStats);
        copy.matchEvents = new ArrayList<>(this.matchEvents);
        
        copy.matchBalanceScore = this.matchBalanceScore;
        copy.killerPerformanceScore = this.killerPerformanceScore;
        copy.survivorPerformanceScore = this.survivorPerformanceScore;
        copy.wasCloseMatch = this.wasCloseMatch;
        copy.wasStompMatch = this.wasStompMatch;
        
        return copy;
    }
    
    @Override
    public String toString() {
        return getMatchSummary();
    }
    
    /**
     * Statistics for an individual survivor in a match.
     */
    public static class SurvivorStats {
        private UUID playerId;
        private String playerName;
        private int generatorsRepaired;
        private int hooksRescued;
        private int healsPerformed;
        private int healsReceived;
        private int chestsSearched;
        private int lockersUsed;
        private int palletsDropped;
        private int timesHooked;
        private int timesDowned;
        private int timesHit;
        private boolean escaped;
        private boolean sacrificed;
        private boolean killed;
        private boolean disconnected;
        private long timeAlive; // in seconds
        private long timeInChase; // in seconds
        private int bloodpointsEarned;
        
        public SurvivorStats() {
            this.playerId = UUID.randomUUID();
            this.playerName = "";
            this.generatorsRepaired = 0;
            this.hooksRescued = 0;
            this.healsPerformed = 0;
            this.healsReceived = 0;
            this.chestsSearched = 0;
            this.lockersUsed = 0;
            this.palletsDropped = 0;
            this.timesHooked = 0;
            this.timesDowned = 0;
            this.timesHit = 0;
            this.escaped = false;
            this.sacrificed = false;
            this.killed = false;
            this.disconnected = false;
            this.timeAlive = 0;
            this.timeInChase = 0;
            this.bloodpointsEarned = 0;
        }
        
        public SurvivorStats(UUID playerId, String playerName) {
            this();
            this.playerId = playerId;
            this.playerName = playerName;
        }
        
        // Getters and setters
        public UUID getPlayerId() { return playerId; }
        public void setPlayerId(UUID playerId) { this.playerId = playerId; }
        
        public String getPlayerName() { return playerName; }
        public void setPlayerName(String playerName) { this.playerName = playerName; }
        
        public int getGeneratorsRepaired() { return generatorsRepaired; }
        public void setGeneratorsRepaired(int generatorsRepaired) { this.generatorsRepaired = generatorsRepaired; }
        
        public int getHooksRescued() { return hooksRescued; }
        public void setHooksRescued(int hooksRescued) { this.hooksRescued = hooksRescued; }
        
        public int getHealsPerformed() { return healsPerformed; }
        public void setHealsPerformed(int healsPerformed) { this.healsPerformed = healsPerformed; }
        
        public int getHealsReceived() { return healsReceived; }
        public void setHealsReceived(int healsReceived) { this.healsReceived = healsReceived; }
        
        public int getChestsSearched() { return chestsSearched; }
        public void setChestsSearched(int chestsSearched) { this.chestsSearched = chestsSearched; }
        
        public int getLockersUsed() { return lockersUsed; }
        public void setLockersUsed(int lockersUsed) { this.lockersUsed = lockersUsed; }
        
        public int getPalletsDropped() { return palletsDropped; }
        public void setPalletsDropped(int palletsDropped) { this.palletsDropped = palletsDropped; }
        
        public int getTimesHooked() { return timesHooked; }
        public void setTimesHooked(int timesHooked) { this.timesHooked = timesHooked; }
        
        public int getTimesDowned() { return timesDowned; }
        public void setTimesDowned(int timesDowned) { this.timesDowned = timesDowned; }
        
        public int getTimesHit() { return timesHit; }
        public void setTimesHit(int timesHit) { this.timesHit = timesHit; }
        
        public boolean isEscaped() { return escaped; }
        public void setEscaped(boolean escaped) { this.escaped = escaped; }
        
        public boolean isSacrificed() { return sacrificed; }
        public void setSacrificed(boolean sacrificed) { this.sacrificed = sacrificed; }
        
        public boolean isKilled() { return killed; }
        public void setKilled(boolean killed) { this.killed = killed; }
        
        public boolean isDisconnected() { return disconnected; }
        public void setDisconnected(boolean disconnected) { this.disconnected = disconnected; }
        
        public long getTimeAlive() { return timeAlive; }
        public void setTimeAlive(long timeAlive) { this.timeAlive = timeAlive; }
        
        public long getTimeInChase() { return timeInChase; }
        public void setTimeInChase(long timeInChase) { this.timeInChase = timeInChase; }
        
        public int getBloodpointsEarned() { return bloodpointsEarned; }
        public void setBloodpointsEarned(int bloodpointsEarned) { this.bloodpointsEarned = bloodpointsEarned; }
        
        // Helper methods
        public void addGeneratorRepaired() {
            generatorsRepaired++;
        }
        
        public void addHookRescued() {
            hooksRescued++;
        }
        
        public void addHealPerformed() {
            healsPerformed++;
        }
        
        public void addHealReceived() {
            healsReceived++;
        }
        
        public void addChestSearched() {
            chestsSearched++;
        }
        
        public void addLockerUsed() {
            lockersUsed++;
        }
        
        public void addPalletDropped() {
            palletsDropped++;
        }
        
        public void addTimeHooked() {
            timesHooked++;
        }
        
        public void addTimeDowned() {
            timesDowned++;
        }
        
        public void addTimeHit() {
            timesHit++;
        }
        
        public void addBloodpoints(int amount) {
            bloodpointsEarned += amount;
        }
        
        public double getSurvivalScore() {
            double score = 0.0;
            
            // Base survival (0-0.4)
            if (escaped) score += 0.4;
            else if (sacrificed || killed) score += 0.1;
            
            // Generator contribution (0-0.3)
            score += Math.min(0.3, generatorsRepaired * 0.1);
            
            // Teamwork (0-0.2)
            score += Math.min(0.2, (hooksRescued + healsPerformed) * 0.05);
            
            // Survival time bonus (0-0.1)
            score += Math.min(0.1, timeAlive / 600.0); // 10 minutes = 0.1
            
            return Math.min(1.0, score);
        }
        
        public SurvivorStats copy() {
            SurvivorStats copy = new SurvivorStats();
            copy.playerId = this.playerId;
            copy.playerName = this.playerName;
            copy.generatorsRepaired = this.generatorsRepaired;
            copy.hooksRescued = this.hooksRescued;
            copy.healsPerformed = this.healsPerformed;
            copy.healsReceived = this.healsReceived;
            copy.chestsSearched = this.chestsSearched;
            copy.lockersUsed = this.lockersUsed;
            copy.palletsDropped = this.palletsDropped;
            copy.timesHooked = this.timesHooked;
            copy.timesDowned = this.timesDowned;
            copy.timesHit = this.timesHit;
            copy.escaped = this.escaped;
            copy.sacrificed = this.sacrificed;
            copy.killed = this.killed;
            copy.disconnected = this.disconnected;
            copy.timeAlive = this.timeAlive;
            copy.timeInChase = this.timeInChase;
            copy.bloodpointsEarned = this.bloodpointsEarned;
            return copy;
        }
        
        @Override
        public String toString() {
            return String.format("SurvivorStats{player=%s, escaped=%s, generators=%d, hooksRescued=%d, bloodpoints=%d}",
                    playerName, escaped, generatorsRepaired, hooksRescued, bloodpointsEarned);
        }
    }
    
    /**
     * Record of a significant event in a match.
     */
    public static class MatchEvent {
        private UUID eventId;
        private Instant timestamp;
        private EventType eventType;
        private UUID playerId;
        private String playerName;
        private UUID targetId;
        private String targetName;
        private String description;
        private Map<String, Object> data;
        
        public MatchEvent() {
            this.eventId = UUID.randomUUID();
            this.timestamp = Instant.now();
            this.eventType = EventType.UNKNOWN;
            this.playerId = null;
            this.playerName = "";
            this.targetId = null;
            this.targetName = "";
            this.description = "";
            this.data = new HashMap<>();
        }
        
        public MatchEvent(EventType eventType, UUID playerId, String playerName) {
            this();
            this.eventType = eventType;
            this.playerId = playerId;
            this.playerName = playerName;
        }
        
        // Getters and setters
        public UUID getEventId() { return eventId; }
        public void setEventId(UUID eventId) { this.eventId = eventId; }
        
        public Instant getTimestamp() { return timestamp; }
        public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }
        
        public EventType getEventType() { return eventType; }
        public void setEventType(EventType eventType) { this.eventType = eventType; }
        
        public UUID getPlayerId() { return playerId; }
        public void setPlayerId(UUID playerId) { this.playerId = playerId; }
        
        public String getPlayerName() { return playerName; }
        public void setPlayerName(String playerName) { this.playerName = playerName; }
        
        public UUID getTargetId() { return targetId; }
        public void setTargetId(UUID targetId) { this.targetId = targetId; }
        
        public String getTargetName() { return targetName; }
        public void setTargetName(String targetName) { this.targetName = targetName; }
        
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        
        public Map<String, Object> getData() { return data; }
        public void setData(Map<String, Object> data) { this.data = data; }
        
        public void addData(String key, Object value) {
            data.put(key, value);
        }
        
        public Object getData(String key) {
            return data.get(key);
        }
        
        public MatchEvent copy() {
            MatchEvent copy = new MatchEvent();
            copy.eventId = this.eventId;
            copy.timestamp = this.timestamp;
            copy.eventType = this.eventType;
            copy.playerId = this.playerId;
            copy.playerName = this.playerName;
            copy.targetId = this.targetId;
            copy.targetName = this.targetName;
            copy.description = this.description;
            copy.data = new HashMap<>(this.data);
            return copy;
        }
        
        @Override
        public String toString() {
            return String.format("MatchEvent{type=%s, player=%s, time=%s}", 
                    eventType, playerName, timestamp.toString());
        }
    }
    
    /**
     * Types of match events that can be recorded.
     */
    public enum EventType {
        UNKNOWN,
        MATCH_START,
        MATCH_END,
        GENERATOR_STARTED,
        GENERATOR_COMPLETED,
        GENERATOR_DAMAGED,
        HOOK_STARTED,
        HOOK_COMPLETED,
        HOOK_RESCUE,
        CHEST_SEARCH_STARTED,
        CHEST_SEARCH_COMPLETED,
        LOCKER_ENTERED,
        LOCKER_EXITED,
        LOCKER_BROKEN,
        EXIT_GATE_STARTED,
        EXIT_GATE_OPENED,
        EXIT_GATE_USED,
        EMERGENCY_EXIT_OPENED,
        EMERGENCY_EXIT_USED,
        SURVIVOR_HIT,
        SURVIVOR_DOWNED,
        SURVIVOR_HEALED,
        SURVIVOR_ESCAPED,
        SURVIVOR_SACRIFICED,
        SURVIVOR_KILLED,
        SURVIVOR_DISCONNECTED,
        KILLER_POWER_USED,
        PALLET_DROPPED,
        PALLET_BROKEN,
        SKILL_CHECK_SUCCESS,
        SKILL_CHECK_FAILURE,
        BLOODLUST_ACTIVATED,
        MORI_EXECUTION
    }
}
package ru.metalpipe.dbdamp.gameplay.model;

import java.util.Objects;

/**
 * Match settings for configuring DBD gameplay.
 */
public class MatchSettings {
    
    private int matchDuration; // in seconds
    private int generatorsRequired;
    private int totalGenerators;
    private int hookSacrificeTime; // in seconds
    private int generatorRepairTime; // in seconds
    private int skillCheckFrequency; // in ticks
    private int skillCheckWindow; // in ticks
    private double survivorBaseSpeed;
    private double killerBaseSpeed;
    private double injuredSpeedPenalty;
    private double terrorRadiusBase; // in blocks
    private int healingTime; // in seconds
    private int selfHealingTime; // in seconds
    private int attackCooldown; // in ticks
    private int bloodlustMaxStacks;
    private double bloodlustSpeedPerStack;
    
    private int minPlayers;
    private int maxPlayers;
    private boolean allowSpectators;
    private boolean friendlyFire;
    private boolean collisionEnabled;
    private boolean environmentalDamage;
    private boolean fallDamage;
    private boolean drowningEnabled;
    private boolean exhaustionEnabled;
    private boolean hungerEnabled;
    
    private boolean perksEnabled;
    private boolean itemsEnabled;
    private boolean offeringsEnabled;
    private boolean bloodwebEnabled;
    private boolean escapeEnabled;
    private boolean moriEnabled;
    private boolean skillChecksEnabled;
    private boolean struggleEnabled;
    private boolean wiggleEnabled;
    
    private String mapId;
    private String mapTheme;
    private long mapSeed;
    private boolean randomMap;
    private boolean mapVoting;
    private int mapVotingTime; // in seconds
    
    public MatchSettings() {
        // Default DBD-like values
        this.matchDuration = 900; // 15 minutes
        this.generatorsRequired = 5;
        this.totalGenerators = 7;
        this.hookSacrificeTime = 180; // 3 minutes
        this.generatorRepairTime = 90; // 1.5 minutes
        this.skillCheckFrequency = 200; // ~10 seconds
        this.skillCheckWindow = 20; // 1 second
        this.survivorBaseSpeed = 0.3; // 4.0 m/s in Minecraft units
        this.killerBaseSpeed = 0.35; // 4.6 m/s
        this.injuredSpeedPenalty = 0.15; // 15% slower
        this.terrorRadiusBase = 32.0; // 32 blocks
        this.healingTime = 16; // 16 seconds
        this.selfHealingTime = 32; // 32 seconds
        this.attackCooldown = 40; // 2 seconds
        this.bloodlustMaxStacks = 3;
        this.bloodlustSpeedPerStack = 0.05; // 5% per stack
        
        this.minPlayers = 5; // 1 killer + 4 survivors
        this.maxPlayers = 5;
        this.allowSpectators = true;
        this.friendlyFire = false;
        this.collisionEnabled = true;
        this.environmentalDamage = true;
        this.fallDamage = true;
        this.drowningEnabled = true;
        this.exhaustionEnabled = true;
        this.hungerEnabled = false;
        
        this.perksEnabled = true;
        this.itemsEnabled = true;
        this.offeringsEnabled = true;
        this.bloodwebEnabled = true;
        this.escapeEnabled = true;
        this.moriEnabled = true;
        this.skillChecksEnabled = true;
        this.struggleEnabled = true;
        this.wiggleEnabled = true;
        
        this.mapId = "";
        this.mapTheme = "forest";
        this.mapSeed = System.currentTimeMillis();
        this.randomMap = true;
        this.mapVoting = false;
        this.mapVotingTime = 30; // 30 seconds
    }
    
    // Getters and setters for gameplay mechanics
    public int getMatchDuration() { return matchDuration; }
    public void setMatchDuration(int matchDuration) { this.matchDuration = Math.max(60, matchDuration); }
    
    public int getGeneratorsRequired() { return generatorsRequired; }
    public void setGeneratorsRequired(int generatorsRequired) { 
        this.generatorsRequired = Math.max(1, generatorsRequired); 
    }
    
    public int getTotalGenerators() { return totalGenerators; }
    public void setTotalGenerators(int totalGenerators) { 
        this.totalGenerators = Math.max(getGeneratorsRequired(), totalGenerators); 
    }
    
    public int getHookSacrificeTime() { return hookSacrificeTime; }
    public void setHookSacrificeTime(int hookSacrificeTime) { 
        this.hookSacrificeTime = Math.max(30, hookSacrificeTime); 
    }
    
    public int getGeneratorRepairTime() { return generatorRepairTime; }
    public void setGeneratorRepairTime(int generatorRepairTime) { 
        this.generatorRepairTime = Math.max(10, generatorRepairTime); 
    }
    
    public int getSkillCheckFrequency() { return skillCheckFrequency; }
    public void setSkillCheckFrequency(int skillCheckFrequency) { 
        this.skillCheckFrequency = Math.max(10, skillCheckFrequency); 
    }
    
    public int getSkillCheckWindow() { return skillCheckWindow; }
    public void setSkillCheckWindow(int skillCheckWindow) { 
        this.skillCheckWindow = Math.max(5, skillCheckWindow); 
    }
    
    public double getSurvivorBaseSpeed() { return survivorBaseSpeed; }
    public void setSurvivorBaseSpeed(double survivorBaseSpeed) { 
        this.survivorBaseSpeed = Math.max(0.1, Math.min(1.0, survivorBaseSpeed)); 
    }
    
    public double getKillerBaseSpeed() { return killerBaseSpeed; }
    public void setKillerBaseSpeed(double killerBaseSpeed) { 
        this.killerBaseSpeed = Math.max(0.1, Math.min(1.0, killerBaseSpeed)); 
    }
    
    public double getInjuredSpeedPenalty() { return injuredSpeedPenalty; }
    public void setInjuredSpeedPenalty(double injuredSpeedPenalty) { 
        this.injuredSpeedPenalty = Math.max(0.0, Math.min(0.5, injuredSpeedPenalty)); 
    }
    
    public double getTerrorRadiusBase() { return terrorRadiusBase; }
    public void setTerrorRadiusBase(double terrorRadiusBase) { 
        this.terrorRadiusBase = Math.max(1.0, Math.min(100.0, terrorRadiusBase)); 
    }
    
    public int getHealingTime() { return healingTime; }
    public void setHealingTime(int healingTime) { 
        this.healingTime = Math.max(1, healingTime); 
    }
    
    public int getSelfHealingTime() { return selfHealingTime; }
    public void setSelfHealingTime(int selfHealingTime) { 
        this.selfHealingTime = Math.max(1, selfHealingTime); 
    }
    
    public int getAttackCooldown() { return attackCooldown; }
    public void setAttackCooldown(int attackCooldown) { 
        this.attackCooldown = Math.max(10, attackCooldown); 
    }
    
    public int getBloodlustMaxStacks() { return bloodlustMaxStacks; }
    public void setBloodlustMaxStacks(int bloodlustMaxStacks) { 
        this.bloodlustMaxStacks = Math.max(0, Math.min(10, bloodlustMaxStacks)); 
    }
    
    public double getBloodlustSpeedPerStack() { return bloodlustSpeedPerStack; }
    public void setBloodlustSpeedPerStack(double bloodlustSpeedPerStack) { 
        this.bloodlustSpeedPerStack = Math.max(0.0, Math.min(0.2, bloodlustSpeedPerStack)); 
    }
    
    // Getters and setters for player settings
    public int getMinPlayers() { return minPlayers; }
    public void setMinPlayers(int minPlayers) { 
        this.minPlayers = Math.max(1, Math.min(maxPlayers, minPlayers)); 
    }
    
    public int getMaxPlayers() { return maxPlayers; }
    public void setMaxPlayers(int maxPlayers) { 
        this.maxPlayers = Math.max(minPlayers, Math.min(20, maxPlayers)); 
    }
    
    public boolean isAllowSpectators() { return allowSpectators; }
    public void setAllowSpectators(boolean allowSpectators) { this.allowSpectators = allowSpectators; }
    
    public boolean isFriendlyFire() { return friendlyFire; }
    public void setFriendlyFire(boolean friendlyFire) { this.friendlyFire = friendlyFire; }
    
    public boolean isCollisionEnabled() { return collisionEnabled; }
    public void setCollisionEnabled(boolean collisionEnabled) { this.collisionEnabled = collisionEnabled; }
    
    public boolean isEnvironmentalDamage() { return environmentalDamage; }
    public void setEnvironmentalDamage(boolean environmentalDamage) { this.environmentalDamage = environmentalDamage; }
    
    public boolean isFallDamage() { return fallDamage; }
    public void setFallDamage(boolean fallDamage) { this.fallDamage = fallDamage; }
    
    public boolean isDrowningEnabled() { return drowningEnabled; }
    public void setDrowningEnabled(boolean drowningEnabled) { this.drowningEnabled = drowningEnabled; }
    
    public boolean isExhaustionEnabled() { return exhaustionEnabled; }
    public void setExhaustionEnabled(boolean exhaustionEnabled) { this.exhaustionEnabled = exhaustionEnabled; }
    
    public boolean isHungerEnabled() { return hungerEnabled; }
    public void setHungerEnabled(boolean hungerEnabled) { this.hungerEnabled = hungerEnabled; }
    
    // Getters and setters for feature toggles
    public boolean isPerksEnabled() { return perksEnabled; }
    public void setPerksEnabled(boolean perksEnabled) { this.perksEnabled = perksEnabled; }
    
    public boolean isItemsEnabled() { return itemsEnabled; }
    public void setItemsEnabled(boolean itemsEnabled) { this.itemsEnabled = itemsEnabled; }
    
    public boolean isOfferingsEnabled() { return offeringsEnabled; }
    public void setOfferingsEnabled(boolean offeringsEnabled) { this.offeringsEnabled = offeringsEnabled; }
    
    public boolean isBloodwebEnabled() { return bloodwebEnabled; }
    public void setBloodwebEnabled(boolean bloodwebEnabled) { this.bloodwebEnabled = bloodwebEnabled; }
    
    public boolean isEscapeEnabled() { return escapeEnabled; }
    public void setEscapeEnabled(boolean escapeEnabled) { this.escapeEnabled = escapeEnabled; }
    
    public boolean isMoriEnabled() { return moriEnabled; }
    public void setMoriEnabled(boolean moriEnabled) { this.moriEnabled = moriEnabled; }
    
    public boolean isSkillChecksEnabled() { return skillChecksEnabled; }
    public void setSkillChecksEnabled(boolean skillChecksEnabled) { this.skillChecksEnabled = skillChecksEnabled; }
    
    public boolean isStruggleEnabled() { return struggleEnabled; }
    public void setStruggleEnabled(boolean struggleEnabled) { this.struggleEnabled = struggleEnabled; }
    
    public boolean isWiggleEnabled() { return wiggleEnabled; }
    public void setWiggleEnabled(boolean wiggleEnabled) { this.wiggleEnabled = wiggleEnabled; }
    
    // Getters and setters for map settings
    public String getMapId() { return mapId; }
    public void setMapId(String mapId) { this.mapId = mapId; }
    
    public String getMapTheme() { return mapTheme; }
    public void setMapTheme(String mapTheme) { this.mapTheme = mapTheme; }
    
    public long getMapSeed() { return mapSeed; }
    public void setMapSeed(long mapSeed) { this.mapSeed = mapSeed; }
    
    public boolean isRandomMap() { return randomMap; }
    public void setRandomMap(boolean randomMap) { this.randomMap = randomMap; }
    
    public boolean isMapVoting() { return mapVoting; }
    public void setMapVoting(boolean mapVoting) { this.mapVoting = mapVoting; }
    
    public int getMapVotingTime() { return mapVotingTime; }
    public void setMapVotingTime(int mapVotingTime) { 
        this.mapVotingTime = Math.max(10, Math.min(120, mapVotingTime)); 
    }
    
    // Helper methods
    public double getSurvivorInjuredSpeed() {
        return survivorBaseSpeed * (1.0 - injuredSpeedPenalty);
    }
    
    public double getKillerBloodlustSpeed(int stacks) {
        int effectiveStacks = Math.min(stacks, bloodlustMaxStacks);
        return killerBaseSpeed * (1.0 + (effectiveStacks * bloodlustSpeedPerStack));
    }
    
    public double getTerrorRadius(double multiplier) {
        return terrorRadiusBase * multiplier;
    }
    
    public int getGeneratorRepairProgressPerTick() {
        // Calculate progress per tick (20 ticks = 1 second)
        int totalTicks = generatorRepairTime * 20;
        return 10000 / totalTicks; // 10000 = 100% * 100 for precision
    }
    
    public int getHookSacrificeProgressPerTick() {
        int totalTicks = hookSacrificeTime * 20;
        return 10000 / totalTicks;
    }
    
    public int getHealingProgressPerTick() {
        int totalTicks = healingTime * 20;
        return 10000 / totalTicks;
    }
    
    public int getSelfHealingProgressPerTick() {
        int totalTicks = selfHealingTime * 20;
        return 10000 / totalTicks;
    }
    
    public boolean isValid() {
        return minPlayers <= maxPlayers &&
               generatorsRequired <= totalGenerators &&
               matchDuration > 0 &&
               generatorRepairTime > 0 &&
               hookSacrificeTime > 0;
    }
    
    public String getFormattedDuration() {
        int seconds = matchDuration;
        int hours = seconds / 3600;
        int minutes = (seconds % 3600) / 60;
        seconds = seconds % 60;
        
        if (hours > 0) {
            return String.format("%d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%d:%02d", minutes, seconds);
        }
    }
    
    public MatchSettings copy() {
        MatchSettings copy = new MatchSettings();
        
        // Copy gameplay mechanics
        copy.matchDuration = this.matchDuration;
        copy.generatorsRequired = this.generatorsRequired;
        copy.totalGenerators = this.totalGenerators;
        copy.hookSacrificeTime = this.hookSacrificeTime;
        copy.generatorRepairTime = this.generatorRepairTime;
        copy.skillCheckFrequency = this.skillCheckFrequency;
        copy.skillCheckWindow = this.skillCheckWindow;
        copy.survivorBaseSpeed = this.survivorBaseSpeed;
        copy.killerBaseSpeed = this.killerBaseSpeed;
        copy.injuredSpeedPenalty = this.injuredSpeedPenalty;
        copy.terrorRadiusBase = this.terrorRadiusBase;
        copy.healingTime = this.healingTime;
        copy.selfHealingTime = this.selfHealingTime;
        copy.attackCooldown = this.attackCooldown;
        copy.bloodlustMaxStacks = this.bloodlustMaxStacks;
        copy.bloodlustSpeedPerStack = this.bloodlustSpeedPerStack;
        
        // Copy player settings
        copy.minPlayers = this.minPlayers;
        copy.maxPlayers = this.maxPlayers;
        copy.allowSpectators = this.allowSpectators;
        copy.friendlyFire = this.friendlyFire;
        copy.collisionEnabled = this.collisionEnabled;
        copy.environmentalDamage = this.environmentalDamage;
        copy.fallDamage = this.fallDamage;
        copy.drowningEnabled = this.drowningEnabled;
        copy.exhaustionEnabled = this.exhaustionEnabled;
        copy.hungerEnabled = this.hungerEnabled;
        
        // Copy feature toggles
        copy.perksEnabled = this.perksEnabled;
        copy.itemsEnabled = this.itemsEnabled;
        copy.offeringsEnabled = this.offeringsEnabled;
        copy.bloodwebEnabled = this.bloodwebEnabled;
        copy.escapeEnabled = this.escapeEnabled;
        copy.moriEnabled = this.moriEnabled;
        copy.skillChecksEnabled = this.skillChecksEnabled;
        copy.struggleEnabled = this.struggleEnabled;
        copy.wiggleEnabled = this.wiggleEnabled;
        
        // Copy map settings
        copy.mapId = this.mapId;
        copy.mapTheme = this.mapTheme;
        copy.mapSeed = this.mapSeed;
        copy.randomMap = this.randomMap;
        copy.mapVoting = this.mapVoting;
        copy.mapVotingTime = this.mapVotingTime;
        
        return copy;
    }
    
    public static MatchSettings getDefault() {
        return new MatchSettings();
    }
    
    public static MatchSettings getQuickPlay() {
        MatchSettings settings = new MatchSettings();
        settings.setMatchDuration(600); // 10 minutes
        settings.setGeneratorsRequired(3);
        settings.setTotalGenerators(5);
        settings.setHookSacrificeTime(120); // 2 minutes
        settings.setGeneratorRepairTime(60); // 1 minute
        return settings;
    }
    
    public static MatchSettings getCompetitive() {
        MatchSettings settings = new MatchSettings();
        settings.setMatchDuration(1200); // 20 minutes
        settings.setGeneratorsRequired(7);
        settings.setTotalGenerators(10);
        settings.setHookSacrificeTime(240); // 4 minutes
        settings.setGeneratorRepairTime(120); // 2 minutes
        settings.setSkillCheckWindow(15); // Harder skill checks
        return settings;
    }
    
    public static MatchSettings getCasual() {
        MatchSettings settings = new MatchSettings();
        settings.setMatchDuration(1800); // 30 minutes
        settings.setGeneratorsRequired(3);
        settings.setTotalGenerators(5);
        settings.setHookSacrificeTime(300); // 5 minutes
        settings.setGeneratorRepairTime(180); // 3 minutes
        settings.setSkillChecksEnabled(false); // No skill checks
        settings.setPerksEnabled(false); // No perks
        return settings;
    }
    
    @Override
    public String toString() {
        return "MatchSettings{" +
               "duration=" + getFormattedDuration() +
               ", generators=" + generatorsRequired + "/" + totalGenerators +
               ", players=" + minPlayers + "-" + maxPlayers +
               ", perks=" + perksEnabled +
               ", items=" + itemsEnabled +
               ", skillChecks=" + skillChecksEnabled +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MatchSettings that = (MatchSettings) o;
        return matchDuration == that.matchDuration &&
               generatorsRequired == that.generatorsRequired &&
               totalGenerators == that.totalGenerators &&
               hookSacrificeTime == that.hookSacrificeTime &&
               generatorRepairTime == that.generatorRepairTime &&
               skillCheckFrequency == that.skillCheckFrequency &&
               skillCheckWindow == that.skillCheckWindow &&
               Double.compare(survivorBaseSpeed, that.survivorBaseSpeed) == 0 &&
               Double.compare(killerBaseSpeed, that.killerBaseSpeed) == 0 &&
               Double.compare(injuredSpeedPenalty, that.injuredSpeedPenalty) == 0 &&
               Double.compare(terrorRadiusBase, that.terrorRadiusBase) == 0 &&
               healingTime == that.healingTime &&
               selfHealingTime == that.selfHealingTime &&
               attackCooldown == that.attackCooldown &&
               bloodlustMaxStacks == that.bloodlustMaxStacks &&
               Double.compare(bloodlustSpeedPerStack, that.bloodlustSpeedPerStack) == 0 &&
               minPlayers == that.minPlayers &&
               maxPlayers == that.maxPlayers &&
               allowSpectators == that.allowSpectators &&
               friendlyFire == that.friendlyFire &&
               collisionEnabled == that.collisionEnabled &&
               environmentalDamage == that.environmentalDamage &&
               fallDamage == that.fallDamage &&
               drowningEnabled == that.drowningEnabled &&
               exhaustionEnabled == that.exhaustionEnabled &&
               hungerEnabled == that.hungerEnabled &&
               perksEnabled == that.perksEnabled &&
               itemsEnabled == that.itemsEnabled &&
               offeringsEnabled == that.offeringsEnabled &&
               bloodwebEnabled == that.bloodwebEnabled &&
               escapeEnabled == that.escapeEnabled &&
               moriEnabled == that.moriEnabled &&
               skillChecksEnabled == that.skillChecksEnabled &&
               struggleEnabled == that.struggleEnabled &&
               wiggleEnabled == that.wiggleEnabled &&
               mapSeed == that.mapSeed &&
               randomMap == that.randomMap &&
               mapVoting == that.mapVoting &&
               mapVotingTime == that.mapVotingTime &&
               Objects.equals(mapId, that.mapId) &&
               Objects.equals(mapTheme, that.mapTheme);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(matchDuration, generatorsRequired, totalGenerators, hookSacrificeTime,
                generatorRepairTime, skillCheckFrequency, skillCheckWindow, survivorBaseSpeed,
                killerBaseSpeed, injuredSpeedPenalty, terrorRadiusBase, healingTime, selfHealingTime,
                attackCooldown, bloodlustMaxStacks, bloodlustSpeedPerStack, minPlayers, maxPlayers,
                allowSpectators, friendlyFire, collisionEnabled, environmentalDamage, fallDamage,
                drowningEnabled, exhaustionEnabled, hungerEnabled, perksEnabled, itemsEnabled,
                offeringsEnabled, bloodwebEnabled, escapeEnabled, moriEnabled, skillChecksEnabled,
                struggleEnabled, wiggleEnabled, mapId, mapTheme, mapSeed, randomMap, mapVoting,
                mapVotingTime);
    }
}
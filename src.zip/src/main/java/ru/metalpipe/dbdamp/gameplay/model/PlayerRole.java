package ru.metalpipe.dbdamp.gameplay.model;

/**
 * Player roles in DBD gameplay.
 */
public enum PlayerRole {
    
    SURVIVOR("Survivor", "SURVIVOR", "Survivor role - repair generators and escape"),
    KILLER("Killer", "KILLER", "Killer role - hunt and sacrifice survivors");
    
    private final String displayName;
    private final String permissionNode;
    private final String description;
    
    PlayerRole(String displayName, String permissionNode, String description) {
        this.displayName = displayName;
        this.permissionNode = permissionNode;
        this.description = description;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    public String getPermissionNode() {
        return "dbdamp.role." + permissionNode.toLowerCase();
    }
    
    public String getDescription() {
        return description;
    }
    
    public boolean isSurvivor() {
        return this == SURVIVOR;
    }
    
    public boolean isKiller() {
        return this == KILLER;
    }
    
    public PlayerRole opposite() {
        return this == SURVIVOR ? KILLER : SURVIVOR;
    }
    
    public static PlayerRole fromString(String role) {
        if (role == null) return null;
        
        try {
            return PlayerRole.valueOf(role.toUpperCase());
        } catch (IllegalArgumentException e) {
            // Try case-insensitive match
            for (PlayerRole r : values()) {
                if (r.name().equalsIgnoreCase(role) || 
                    r.getDisplayName().equalsIgnoreCase(role)) {
                    return r;
                }
            }
            return null;
        }
    }
    
    public static PlayerRole getDefault() {
        return SURVIVOR;
    }
    
    public static PlayerRole[] getAvailableRoles() {
        return values();
    }
    
    public static String[] getDisplayNames() {
        return new String[] { SURVIVOR.getDisplayName(), KILLER.getDisplayName() };
    }
    
    public static PlayerRole getByIndex(int index) {
        PlayerRole[] roles = values();
        if (index >= 0 && index < roles.length) {
            return roles[index];
        }
        return getDefault();
    }
    
    public int getIndex() {
        return ordinal();
    }
    
    @Override
    public String toString() {
        return displayName;
    }
}
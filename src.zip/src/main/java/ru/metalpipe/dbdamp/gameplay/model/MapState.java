package ru.metalpipe.dbdamp.gameplay.model;

import org.bukkit.Location;
import org.bukkit.World;

import java.util.Objects;

/**
 * Map state representing the current state of a DBD map.
 */
public class MapState {
    
    private String mapId;
    private String mapName;
    private String theme;
    private World world;
    private Location spawnPoint;
    private Location killerSpawn;
    private Location[] survivorSpawns;
    private Bounds bounds;
    private boolean loaded;
    private long seed;
    
    public MapState() {
        this.mapId = "";
        this.mapName = "Unknown Map";
        this.theme = "forest";
        this.world = null;
        this.spawnPoint = null;
        this.killerSpawn = null;
        this.survivorSpawns = new Location[0];
        this.bounds = new Bounds();
        this.loaded = false;
        this.seed = System.currentTimeMillis();
    }
    
    public MapState(String mapId, String mapName, String theme) {
        this();
        this.mapId = mapId;
        this.mapName = mapName;
        this.theme = theme;
    }
    
    // Getters and setters
    public String getMapId() { return mapId; }
    public void setMapId(String mapId) { this.mapId = mapId; }
    
    public String getMapName() { return mapName; }
    public void setMapName(String mapName) { this.mapName = mapName; }
    
    public String getTheme() { return theme; }
    public void setTheme(String theme) { this.theme = theme; }
    
    public World getWorld() { return world; }
    public void setWorld(World world) { this.world = world; }
    
    public Location getSpawnPoint() { return spawnPoint; }
    public void setSpawnPoint(Location spawnPoint) { this.spawnPoint = spawnPoint; }
    
    public Location getKillerSpawn() { return killerSpawn; }
    public void setKillerSpawn(Location killerSpawn) { this.killerSpawn = killerSpawn; }
    
    public Location[] getSurvivorSpawns() { return survivorSpawns; }
    public void setSurvivorSpawns(Location[] survivorSpawns) { 
        this.survivorSpawns = survivorSpawns != null ? survivorSpawns : new Location[0];
    }
    
    public Bounds getBounds() { return bounds; }
    public void setBounds(Bounds bounds) { this.bounds = bounds; }
    
    public boolean isLoaded() { return loaded; }
    public void setLoaded(boolean loaded) { this.loaded = loaded; }
    
    public long getSeed() { return seed; }
    public void setSeed(long seed) { this.seed = seed; }
    
    // Helper methods
    public boolean isValid() {
        return world != null && spawnPoint != null && killerSpawn != null && 
               survivorSpawns.length >= 4 && bounds.isValid();
    }
    
    public boolean isInBounds(Location location) {
        return bounds.contains(location);
    }
    
    public Location getRandomSurvivorSpawn() {
        if (survivorSpawns.length == 0) return spawnPoint;
        int index = (int) (Math.random() * survivorSpawns.length);
        return survivorSpawns[index];
    }
    
    public Location getSurvivorSpawn(int index) {
        if (survivorSpawns.length == 0) return spawnPoint;
        if (index < 0 || index >= survivorSpawns.length) {
            index = index % survivorSpawns.length;
        }
        return survivorSpawns[index];
    }
    
    public int getSurvivorSpawnCount() {
        return survivorSpawns.length;
    }
    
    public void addSurvivorSpawn(Location location) {
        Location[] newSpawns = new Location[survivorSpawns.length + 1];
        System.arraycopy(survivorSpawns, 0, newSpawns, 0, survivorSpawns.length);
        newSpawns[survivorSpawns.length] = location;
        survivorSpawns = newSpawns;
    }
    
    public void removeSurvivorSpawn(int index) {
        if (index < 0 || index >= survivorSpawns.length) return;
        
        Location[] newSpawns = new Location[survivorSpawns.length - 1];
        for (int i = 0, j = 0; i < survivorSpawns.length; i++) {
            if (i != index) {
                newSpawns[j++] = survivorSpawns[i];
            }
        }
        survivorSpawns = newSpawns;
    }
    
    public void clearSurvivorSpawns() {
        survivorSpawns = new Location[0];
    }
    
    public double getArea() {
        return bounds.getArea();
    }
    
    public String getFormattedArea() {
        return bounds.getFormattedArea();
    }
    
    public Location getCenter() {
        return bounds.getCenter();
    }
    
    public void load() {
        loaded = true;
    }
    
    public void unload() {
        loaded = false;
    }
    
    public void initialize() {
        // Initialize map state - set loaded to true
        loaded = true;
    }
    
    public MapState copy() {
        MapState copy = new MapState();
        copy.mapId = this.mapId;
        copy.mapName = this.mapName;
        copy.theme = this.theme;
        copy.world = this.world;
        copy.spawnPoint = this.spawnPoint != null ? this.spawnPoint.clone() : null;
        copy.killerSpawn = this.killerSpawn != null ? this.killerSpawn.clone() : null;
        
        copy.survivorSpawns = new Location[this.survivorSpawns.length];
        for (int i = 0; i < this.survivorSpawns.length; i++) {
            copy.survivorSpawns[i] = this.survivorSpawns[i] != null ? 
                this.survivorSpawns[i].clone() : null;
        }
        
        copy.bounds = this.bounds.copy();
        copy.loaded = this.loaded;
        copy.seed = this.seed;
        
        return copy;
    }
    
    @Override
    public String toString() {
        return "MapState{" +
               "mapId='" + mapId + '\'' +
               ", mapName='" + mapName + '\'' +
               ", theme='" + theme + '\'' +
               ", world=" + (world != null ? world.getName() : "null") +
               ", loaded=" + loaded +
               ", survivorSpawns=" + survivorSpawns.length +
               ", area=" + getFormattedArea() +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MapState mapState = (MapState) o;
        return Objects.equals(mapId, mapState.mapId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(mapId);
    }
    
    /**
     * Bounds for the map area.
     */
    public static class Bounds {
        private Location min;
        private Location max;
        
        public Bounds() {
            this.min = null;
            this.max = null;
        }
        
        public Bounds(Location min, Location max) {
            this.min = min;
            this.max = max;
        }
        
        public Location getMin() { return min; }
        public void setMin(Location min) { this.min = min; }
        
        public Location getMax() { return max; }
        public void setMax(Location max) { this.max = max; }
        
        public boolean isValid() {
            return min != null && max != null && 
                   min.getWorld() != null && 
                   min.getWorld().equals(max.getWorld());
        }
        
        public boolean contains(Location location) {
            if (!isValid() || location == null || location.getWorld() == null) {
                return false;
            }
            
            if (!location.getWorld().equals(min.getWorld())) {
                return false;
            }
            
            double x = location.getX();
            double y = location.getY();
            double z = location.getZ();
            
            double minX = Math.min(min.getX(), max.getX());
            double maxX = Math.max(min.getX(), max.getX());
            double minY = Math.min(min.getY(), max.getY());
            double maxY = Math.max(min.getY(), max.getY());
            double minZ = Math.min(min.getZ(), max.getZ());
            double maxZ = Math.max(min.getZ(), max.getZ());
            
            return x >= minX && x <= maxX &&
                   y >= minY && y <= maxY &&
                   z >= minZ && z <= maxZ;
        }
        
        public double getWidth() {
            if (!isValid()) return 0;
            return Math.abs(max.getX() - min.getX());
        }
        
        public double getHeight() {
            if (!isValid()) return 0;
            return Math.abs(max.getY() - min.getY());
        }
        
        public double getDepth() {
            if (!isValid()) return 0;
            return Math.abs(max.getZ() - min.getZ());
        }
        
        public double getArea() {
            if (!isValid()) return 0;
            return getWidth() * getDepth();
        }
        
        public double getVolume() {
            if (!isValid()) return 0;
            return getWidth() * getHeight() * getDepth();
        }
        
        public String getFormattedArea() {
            double area = getArea();
            if (area >= 1_000_000) {
                return String.format("%.1f km²", area / 1_000_000);
            } else if (area >= 10_000) {
                return String.format("%.1f ha", area / 10_000);
            } else {
                return String.format("%.0f m²", area);
            }
        }
        
        public Location getCenter() {
            if (!isValid()) return null;
            
            double centerX = (min.getX() + max.getX()) / 2;
            double centerY = (min.getY() + max.getY()) / 2;
            double centerZ = (min.getZ() + max.getZ()) / 2;
            
            return new Location(min.getWorld(), centerX, centerY, centerZ);
        }
        
        public void expand(double amount) {
            if (!isValid()) return;
            
            min.subtract(amount, amount, amount);
            max.add(amount, amount, amount);
        }
        
        public void contract(double amount) {
            if (!isValid()) return;
            
            min.add(amount, amount, amount);
            max.subtract(amount, amount, amount);
        }
        
        public Bounds copy() {
            return new Bounds(
                min != null ? min.clone() : null,
                max != null ? max.clone() : null
            );
        }
        
        @Override
        public String toString() {
            return "Bounds{" +
                   "min=" + (min != null ? String.format("(%.1f, %.1f, %.1f)", 
                       min.getX(), min.getY(), min.getZ()) : "null") +
                   ", max=" + (max != null ? String.format("(%.1f, %.1f, %.1f)", 
                       max.getX(), max.getY(), max.getZ()) : "null") +
                   ", area=" + getFormattedArea() +
                   '}';
        }
    }
}
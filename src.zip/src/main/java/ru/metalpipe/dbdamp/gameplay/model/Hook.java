package ru.metalpipe.dbdamp.gameplay.model;

import org.bukkit.Location;
import org.bukkit.block.Block;

import java.time.Instant;
import java.util.*;

/**
 * Hook object for DBD gameplay - killers hang survivors on hooks for sacrifice.
 */
public class Hook {
    
    private UUID hookId;
    private Location location;
    private UUID hookedSurvivor;
    private Instant hookTime;
    private int sacrificeProgress; // 0-10000 (100.00%)
    private boolean sacrificeComplete;
    private int struggleProgress; // 0-10000 (100.00%)
    private boolean struggling;
    private int struggleCooldown;
    private UUID rescuer;
    private Instant rescueTime;
    private boolean beingRescued;
    private int rescueProgress; // 0-10000 (100.00%)
    private int hookStage; // 1 = first hook, 2 = second hook, 3 = sacrifice
    private boolean basementHook;
    private double rescueSpeedMultiplier;
    private Map<String, Object> metadata;
    
    public Hook() {
        this.hookId = UUID.randomUUID();
        this.location = null;
        this.hookedSurvivor = null;
        this.hookTime = null;
        this.sacrificeProgress = 0;
        this.sacrificeComplete = false;
        this.struggleProgress = 0;
        this.struggling = false;
        this.struggleCooldown = 0;
        this.rescuer = null;
        this.rescueTime = null;
        this.beingRescued = false;
        this.rescueProgress = 0;
        this.hookStage = 1;
        this.basementHook = false;
        this.rescueSpeedMultiplier = 1.0;
        this.metadata = new HashMap<>();
    }
    
    public Hook(Location location) {
        this();
        this.location = location;
    }
    
    public Hook(Location location, boolean basementHook) {
        this(location);
        this.basementHook = basementHook;
    }
    
    // Getters and setters
    public UUID getHookId() { return hookId; }
    public void setHookId(UUID hookId) { this.hookId = hookId; }
    
    public Location getLocation() { return location; }
    public void setLocation(Location location) { this.location = location; }
    
    public UUID getHookedSurvivor() { return hookedSurvivor; }
    public void setHookedSurvivor(UUID hookedSurvivor) { this.hookedSurvivor = hookedSurvivor; }
    
    public Instant getHookTime() { return hookTime; }
    public void setHookTime(Instant hookTime) { this.hookTime = hookTime; }
    
    public int getSacrificeProgress() { return sacrificeProgress; }
    public void setSacrificeProgress(int sacrificeProgress) { 
        this.sacrificeProgress = Math.max(0, Math.min(10000, sacrificeProgress));
        if (this.sacrificeProgress >= 10000) {
            sacrificeComplete = true;
        }
    }
    
    public boolean isSacrificeComplete() { return sacrificeComplete; }
    public void setSacrificeComplete(boolean sacrificeComplete) { 
        this.sacrificeComplete = sacrificeComplete;
        if (sacrificeComplete) {
            this.sacrificeProgress = 10000;
        }
    }
    
    public int getStruggleProgress() { return struggleProgress; }
    public void setStruggleProgress(int struggleProgress) { 
        this.struggleProgress = Math.max(0, Math.min(10000, struggleProgress)); 
    }
    
    public boolean isStruggling() { return struggling; }
    public void setStruggling(boolean struggling) { this.struggling = struggling; }
    
    public int getStruggleCooldown() { return struggleCooldown; }
    public void setStruggleCooldown(int struggleCooldown) { this.struggleCooldown = struggleCooldown; }
    
    public UUID getRescuer() { return rescuer; }
    public void setRescuer(UUID rescuer) { this.rescuer = rescuer; }
    
    public Instant getRescueTime() { return rescueTime; }
    public void setRescueTime(Instant rescueTime) { this.rescueTime = rescueTime; }
    
    public boolean isBeingRescued() { return beingRescued; }
    public void setBeingRescued(boolean beingRescued) { this.beingRescued = beingRescued; }
    
    public int getRescueProgress() { return rescueProgress; }
    public void setRescueProgress(int rescueProgress) { 
        this.rescueProgress = Math.max(0, Math.min(10000, rescueProgress)); 
    }
    
    public int getHookStage() { return hookStage; }
    public void setHookStage(int hookStage) { 
        this.hookStage = Math.max(1, Math.min(3, hookStage)); 
    }
    
    public boolean isBasementHook() { return basementHook; }
    public void setBasementHook(boolean basementHook) { this.basementHook = basementHook; }
    
    public double getRescueSpeedMultiplier() { return rescueSpeedMultiplier; }
    public void setRescueSpeedMultiplier(double rescueSpeedMultiplier) { 
        this.rescueSpeedMultiplier = Math.max(0.1, Math.min(2.0, rescueSpeedMultiplier)); 
    }
    
    public Map<String, Object> getMetadata() { return metadata; }
    public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }
    
    // Helper methods
    public void hookSurvivor(UUID survivorId) {
        hookedSurvivor = survivorId;
        hookTime = Instant.now();
        sacrificeProgress = 0;
        sacrificeComplete = false;
        struggleProgress = 0;
        struggling = false;
        struggleCooldown = 0;
        beingRescued = false;
        rescueProgress = 0;
        rescuer = null;
        rescueTime = null;
    }
    
    public void unhookSurvivor() {
        hookedSurvivor = null;
        hookTime = null;
        beingRescued = false;
        rescueProgress = 0;
        rescuer = null;
        rescueTime = null;
        
        // Advance hook stage if survivor was sacrificed
        if (sacrificeComplete) {
            hookStage = Math.min(3, hookStage + 1);
        }
    }
    
    public void progressSacrifice(int amount) {
        if (hookedSurvivor == null || sacrificeComplete || beingRescued) return;
        
        sacrificeProgress = Math.min(10000, sacrificeProgress + amount);
        
        if (sacrificeProgress >= 10000) {
            sacrificeComplete = true;
        }
    }
    
    public void regressSacrifice(int amount) {
        if (hookedSurvivor == null || sacrificeComplete) return;
        
        sacrificeProgress = Math.max(0, sacrificeProgress - amount);
    }
    
    public void startRescue(UUID rescuerId) {
        if (hookedSurvivor == null || sacrificeComplete || beingRescued) return;
        
        beingRescued = true;
        rescuer = rescuerId;
        rescueTime = Instant.now();
        rescueProgress = 0;
    }
    
    public void progressRescue(int amount) {
        if (!beingRescued || rescuer == null) return;
        
        rescueProgress = Math.min(10000, rescueProgress + amount);
        
        if (rescueProgress >= 10000) {
            completeRescue();
        }
    }
    
    public void cancelRescue() {
        beingRescued = false;
        rescuer = null;
        rescueTime = null;
        rescueProgress = 0;
    }
    
    public void completeRescue() {
        beingRescued = false;
        rescueProgress = 10000;
        // Survivor is unhooked by the game system
    }
    
    public void startStruggle() {
        if (hookedSurvivor == null || sacrificeComplete || struggling) return;
        
        struggling = true;
        struggleProgress = 0;
        struggleCooldown = 0;
    }
    
    public void progressStruggle(int amount) {
        if (!struggling) return;
        
        struggleProgress = Math.min(10000, struggleProgress + amount);
        
        if (struggleProgress >= 10000) {
            completeStruggle();
        }
    }
    
    public void completeStruggle() {
        struggling = false;
        struggleProgress = 10000;
        // Survivor escapes hook by struggling
    }
    
    public void updateStruggleCooldown() {
        if (struggleCooldown > 0) {
            struggleCooldown--;
        }
    }
    
    public boolean canStruggle() {
        return hookedSurvivor != null && !sacrificeComplete && !struggling && struggleCooldown == 0;
    }
    
    public boolean canBeRescued() {
        return hookedSurvivor != null && !sacrificeComplete && !beingRescued;
    }
    
    public boolean isOccupied() {
        return hookedSurvivor != null;
    }
    
    public boolean isAvailable() {
        return hookedSurvivor == null && hookStage < 3;
    }
    
    public double getSacrificeProgressPercentage() {
        return sacrificeProgress / 100.0;
    }
    
    public double getRescueProgressPercentage() {
        return rescueProgress / 100.0;
    }
    
    public double getStruggleProgressPercentage() {
        return struggleProgress / 100.0;
    }
    
    public String getSacrificeProgressFormatted() {
        return String.format("%.1f%%", getSacrificeProgressPercentage());
    }
    
    public String getRescueProgressFormatted() {
        return String.format("%.1f%%", getRescueProgressPercentage());
    }
    
    public String getStruggleProgressFormatted() {
        return String.format("%.1f%%", getStruggleProgressPercentage());
    }
    
    public long getTimeSinceHooked() {
        if (hookTime == null) return 0;
        return Instant.now().getEpochSecond() - hookTime.getEpochSecond();
    }
    
    public long getTimeSinceRescueStart() {
        if (rescueTime == null) return 0;
        return Instant.now().getEpochSecond() - rescueTime.getEpochSecond();
    }
    
    public int getRemainingSacrificeProgress() {
        return 10000 - sacrificeProgress;
    }
    
    public int getRemainingRescueProgress() {
        return 10000 - rescueProgress;
    }
    
    public int getRemainingStruggleProgress() {
        return 10000 - struggleProgress;
    }
    
    public Block getBlock() {
        return location != null ? location.getBlock() : null;
    }
    
    public double getSacrificeSpeed() {
        // Basement hooks sacrifice faster
        double baseSpeed = 1.0;
        if (basementHook) {
            baseSpeed *= 1.25;
        }
        return baseSpeed;
    }
    
    public double getRescueSpeed() {
        // Basement hooks rescue slower
        double baseSpeed = rescueSpeedMultiplier;
        if (basementHook) {
            baseSpeed *= 0.75;
        }
        return baseSpeed;
    }
    
    public double getStruggleSpeed() {
        // Later hook stages struggle slower
        double baseSpeed = 1.0;
        if (hookStage == 2) {
            baseSpeed *= 0.8;
        } else if (hookStage == 3) {
            baseSpeed *= 0.6;
        }
        return baseSpeed;
    }
    
    public void reset() {
        hookedSurvivor = null;
        hookTime = null;
        sacrificeProgress = 0;
        sacrificeComplete = false;
        struggleProgress = 0;
        struggling = false;
        struggleCooldown = 0;
        beingRescued = false;
        rescueProgress = 0;
        rescuer = null;
        rescueTime = null;
        hookStage = 1;
        metadata.clear();
    }
    
    public void addMetadata(String key, Object value) {
        metadata.put(key, value);
    }
    
    public Object getMetadata(String key) {
        return metadata.get(key);
    }
    
    public void removeMetadata(String key) {
        metadata.remove(key);
    }
    
    public Hook copy() {
        Hook copy = new Hook();
        copy.hookId = this.hookId;
        copy.location = this.location != null ? this.location.clone() : null;
        copy.hookedSurvivor = this.hookedSurvivor;
        copy.hookTime = this.hookTime;
        copy.sacrificeProgress = this.sacrificeProgress;
        copy.sacrificeComplete = this.sacrificeComplete;
        copy.struggleProgress = this.struggleProgress;
        copy.struggling = this.struggling;
        copy.struggleCooldown = this.struggleCooldown;
        copy.rescuer = this.rescuer;
        copy.rescueTime = this.rescueTime;
        copy.beingRescued = this.beingRescued;
        copy.rescueProgress = this.rescueProgress;
        copy.hookStage = this.hookStage;
        copy.basementHook = this.basementHook;
        copy.rescueSpeedMultiplier = this.rescueSpeedMultiplier;
        copy.metadata = new HashMap<>(this.metadata);
        return copy;
    }
    
    @Override
    public String toString() {
        return "Hook{" +
               "id=" + hookId +
               ", occupied=" + (hookedSurvivor != null) +
               ", stage=" + hookStage +
               ", basement=" + basementHook +
               ", sacrifice=" + getSacrificeProgressFormatted() +
               ", rescue=" + getRescueProgressFormatted() +
               ", struggle=" + getStruggleProgressFormatted() +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Hook hook = (Hook) o;
        return Objects.equals(hookId, hook.hookId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(hookId);
    }
}
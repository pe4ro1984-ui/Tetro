package ru.metalpipe.dbdamp.gameplay.model;

/**
 * Match status representing the current state of a DBD match.
 */
public enum MatchStatus {
    
    LOBBY("Lobby", "Players are in lobby, match hasn't started"),
    STARTING("Starting", "Match is starting countdown"),
    IN_PROGRESS("In Progress", "Match is actively being played"),
    ENDING("Ending", "Match is ending, showing results"),
    ENDING_SURVIVOR_VICTORY("Survivor Victory", "Match ending with survivor victory"),
    ENDING_KILLER_VICTORY("Killer Victory", "Match ending with killer victory"),
    ENDING_DRAW("Draw", "Match ending in a draw"),
    COMPLETED("Completed", "Match has ended and results are final"),
    CANCELLED("Cancelled", "Match was cancelled before starting"),
    ABORTED("Aborted", "Match was aborted during gameplay");
    
    private final String displayName;
    private final String description;
    
    MatchStatus(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    public String getDescription() {
        return description;
    }
    
    public boolean isPreGame() {
        return this == LOBBY || this == STARTING;
    }
    
    public boolean isActive() {
        return this == IN_PROGRESS;
    }
    
    public boolean isPostGame() {
        return this == ENDING || this == ENDING_SURVIVOR_VICTORY || 
               this == ENDING_KILLER_VICTORY || this == ENDING_DRAW || 
               this == COMPLETED;
    }
    
    public boolean isEnded() {
        return this == COMPLETED || this == CANCELLED || this == ABORTED;
    }
    
    public boolean canJoin() {
        return this == LOBBY;
    }
    
    public boolean canStart() {
        return this == LOBBY;
    }
    
    public boolean canEnd() {
        return this == IN_PROGRESS;
    }
    
    public boolean canCancel() {
        return this == LOBBY || this == STARTING;
    }
    
    public boolean canAbort() {
        return this == IN_PROGRESS;
    }
    
    public MatchStatus next() {
        switch (this) {
            case LOBBY: return STARTING;
            case STARTING: return IN_PROGRESS;
            case IN_PROGRESS: return ENDING;
            case ENDING: return ENDING_SURVIVOR_VICTORY;
            case ENDING_SURVIVOR_VICTORY: return ENDING_KILLER_VICTORY;
            case ENDING_KILLER_VICTORY: return ENDING_DRAW;
            case ENDING_DRAW: return COMPLETED;
            default: return this;
        }
    }
    
    public MatchStatus previous() {
        switch (this) {
            case STARTING: return LOBBY;
            case IN_PROGRESS: return STARTING;
            case ENDING: return IN_PROGRESS;
            case ENDING_SURVIVOR_VICTORY: return ENDING;
            case ENDING_KILLER_VICTORY: return ENDING_SURVIVOR_VICTORY;
            case ENDING_DRAW: return ENDING_KILLER_VICTORY;
            case COMPLETED: return ENDING_DRAW;
            default: return this;
        }
    }
    
    public static MatchStatus fromString(String status) {
        if (status == null) return null;
        
        try {
            return MatchStatus.valueOf(status.toUpperCase());
        } catch (IllegalArgumentException e) {
            // Try case-insensitive match
            for (MatchStatus s : values()) {
                if (s.name().equalsIgnoreCase(status) || 
                    s.getDisplayName().equalsIgnoreCase(status)) {
                    return s;
                }
            }
            return null;
        }
    }
    
    public static MatchStatus getDefault() {
        return LOBBY;
    }
    
    public static MatchStatus[] getActiveStatuses() {
        return new MatchStatus[] { LOBBY, STARTING, IN_PROGRESS };
    }
    
    public static MatchStatus[] getEndedStatuses() {
        return new MatchStatus[] { COMPLETED, CANCELLED, ABORTED };
    }
    
    public static String[] getDisplayNames() {
        MatchStatus[] statuses = values();
        String[] names = new String[statuses.length];
        for (int i = 0; i < statuses.length; i++) {
            names[i] = statuses[i].getDisplayName();
        }
        return names;
    }
    
    public static MatchStatus getByIndex(int index) {
        MatchStatus[] statuses = values();
        if (index >= 0 && index < statuses.length) {
            return statuses[index];
        }
        return getDefault();
    }
    
    public int getIndex() {
        return ordinal();
    }
    
    @Override
    public String toString() {
        return displayName;
    }
}
package ru.metalpipe.dbdamp.gameplay.model;

import org.bukkit.Location;
import org.bukkit.block.Block;

import java.time.Instant;
import java.util.*;

/**
 * Locker object for DBD gameplay - survivors can hide in lockers to avoid the killer.
 */
public class Locker {
    
    private UUID lockerId;
    private Location location;
    private boolean occupied; // Whether someone is hiding in the locker
    private boolean entering; // Whether someone is entering the locker
    private boolean exiting; // Whether someone is exiting the locker
    private int enterProgress; // 0-10000 (100.00%) for entering
    private int exitProgress; // 0-10000 (100.00%) for exiting
    private UUID occupant;
    private Instant enterStartTime;
    private Instant exitStartTime;
    private int enterTime; // Time required to enter in ticks
    private int exitTime; // Time required to exit in ticks
    private boolean broken; // Whether the locker is broken (killer can break it)
    private boolean canBeBroken; // Whether the locker can be broken
    private Instant breakTime; // When the locker was broken
    private int breakCooldown; // Cooldown before locker can be used again after breaking
    private Instant repairTime; // When the locker will be repaired
    private boolean providesImmunity; // Whether locker provides terror radius immunity
    private boolean providesHealing; // Whether locker provides healing bonus
    private Map<String, Object> metadata;
    
    public Locker() {
        this.lockerId = UUID.randomUUID();
        this.location = null;
        this.occupied = false;
        this.entering = false;
        this.exiting = false;
        this.enterProgress = 0;
        this.exitProgress = 0;
        this.occupant = null;
        this.enterStartTime = null;
        this.exitStartTime = null;
        this.enterTime = 40; // 2 seconds default
        this.exitTime = 40; // 2 seconds default
        this.broken = false;
        this.canBeBroken = true;
        this.breakTime = null;
        this.breakCooldown = 30; // 30 seconds default
        this.repairTime = null;
        this.providesImmunity = true;
        this.providesHealing = false;
        this.metadata = new HashMap<>();
    }
    
    public Locker(Location location) {
        this();
        this.location = location;
    }
    
    public Locker(Location location, boolean canBeBroken) {
        this(location);
        this.canBeBroken = canBeBroken;
    }
    
    // Getters and setters
    public UUID getLockerId() { return lockerId; }
    public void setLockerId(UUID lockerId) { this.lockerId = lockerId; }
    
    public Location getLocation() { return location; }
    public void setLocation(Location location) { this.location = location; }
    
    public boolean isOccupied() { return occupied; }
    public void setOccupied(boolean occupied) { 
        this.occupied = occupied;
        if (!occupied) {
            this.occupant = null;
        }
    }
    
    public boolean isEntering() { return entering; }
    public void setEntering(boolean entering) { this.entering = entering; }
    
    public boolean isExiting() { return exiting; }
    public void setExiting(boolean exiting) { this.exiting = exiting; }
    
    public int getEnterProgress() { return enterProgress; }
    public void setEnterProgress(int enterProgress) { 
        this.enterProgress = Math.max(0, Math.min(10000, enterProgress));
        if (this.enterProgress >= 10000) {
            completeEnter();
        }
    }
    
    public int getExitProgress() { return exitProgress; }
    public void setExitProgress(int exitProgress) { 
        this.exitProgress = Math.max(0, Math.min(10000, exitProgress));
        if (this.exitProgress >= 10000) {
            completeExit();
        }
    }
    
    public UUID getOccupant() { return occupant; }
    public void setOccupant(UUID occupant) { this.occupant = occupant; }
    
    public Instant getEnterStartTime() { return enterStartTime; }
    public void setEnterStartTime(Instant enterStartTime) { this.enterStartTime = enterStartTime; }
    
    public Instant getExitStartTime() { return exitStartTime; }
    public void setExitStartTime(Instant exitStartTime) { this.exitStartTime = exitStartTime; }
    
    public int getEnterTime() { return enterTime; }
    public void setEnterTime(int enterTime) { this.enterTime = Math.max(0, enterTime); }
    
    public int getExitTime() { return exitTime; }
    public void setExitTime(int exitTime) { this.exitTime = Math.max(0, exitTime); }
    
    public boolean isBroken() { return broken; }
    public void setBroken(boolean broken) { this.broken = broken; }
    
    public boolean canBeBroken() { return canBeBroken; }
    public void setCanBeBroken(boolean canBeBroken) { this.canBeBroken = canBeBroken; }
    
    public Instant getBreakTime() { return breakTime; }
    public void setBreakTime(Instant breakTime) { this.breakTime = breakTime; }
    
    public int getBreakCooldown() { return breakCooldown; }
    public void setBreakCooldown(int breakCooldown) { this.breakCooldown = Math.max(0, breakCooldown); }
    
    public Instant getRepairTime() { return repairTime; }
    public void setRepairTime(Instant repairTime) { this.repairTime = repairTime; }
    
    public boolean providesImmunity() { return providesImmunity; }
    public void setProvidesImmunity(boolean providesImmunity) { this.providesImmunity = providesImmunity; }
    
    public boolean providesHealing() { return providesHealing; }
    public void setProvidesHealing(boolean providesHealing) { this.providesHealing = providesHealing; }
    
    public Map<String, Object> getMetadata() { return metadata; }
    public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }
    
    // Helper methods
    public void startEntering(UUID occupantId) {
        if (occupied || entering || exiting || broken) return;
        
        entering = true;
        occupant = occupantId;
        enterStartTime = Instant.now();
        enterProgress = 0;
    }
    
    public void progressEnter(int amount) {
        if (!entering || broken) return;
        
        enterProgress = Math.min(10000, enterProgress + amount);
        
        if (enterProgress >= 10000) {
            completeEnter();
        }
    }
    
    public void cancelEnter() {
        entering = false;
        occupant = null;
        enterStartTime = null;
        enterProgress = 0;
    }
    
    public void completeEnter() {
        occupied = true;
        entering = false;
        enterProgress = 10000;
        exitProgress = 0;
    }
    
    public void startExiting() {
        if (!occupied || exiting || entering || broken) return;
        
        exiting = true;
        exitStartTime = Instant.now();
        exitProgress = 0;
    }
    
    public void progressExit(int amount) {
        if (!exiting || broken) return;
        
        exitProgress = Math.min(10000, exitProgress + amount);
        
        if (exitProgress >= 10000) {
            completeExit();
        }
    }
    
    public void cancelExit() {
        exiting = false;
        exitStartTime = null;
        exitProgress = 0;
    }
    
    public void completeExit() {
        occupied = false;
        exiting = false;
        exitProgress = 10000;
        enterProgress = 0;
        occupant = null;
    }
    
    public void breakLocker() {
        if (!canBeBroken || broken) return;
        
        broken = true;
        breakTime = Instant.now();
        
        // If someone is inside, force them out
        if (occupied) {
            forceExit();
        }
        
        // Set repair time
        repairTime = Instant.now().plusSeconds(breakCooldown);
    }
    
    public void repairLocker() {
        if (!broken) return;
        
        if (repairTime != null && Instant.now().isAfter(repairTime)) {
            broken = false;
            breakTime = null;
            repairTime = null;
        }
    }
    
    public void forceRepair() {
        broken = false;
        breakTime = null;
        repairTime = null;
    }
    
    public void forceExit() {
        if (occupied) {
            occupied = false;
            entering = false;
            exiting = false;
            enterProgress = 0;
            exitProgress = 0;
            occupant = null;
            enterStartTime = null;
            exitStartTime = null;
        }
    }
    
    public boolean canBeEntered() {
        return !occupied && !entering && !exiting && !broken;
    }
    
    public boolean canBeExited() {
        return occupied && !entering && !exiting && !broken;
    }
    
    public boolean canBeBrokenNow() {
        return canBeBroken && !broken && (!occupied || canBreakWithOccupant());
    }
    
    public boolean canBreakWithOccupant() {
        // Some lockers can be broken even with someone inside (causing damage)
        return false; // Default: cannot break with occupant
    }
    
    public boolean isActive() {
        return occupied || entering || exiting;
    }
    
    public double getEnterProgressPercentage() {
        return enterProgress / 100.0;
    }
    
    public double getExitProgressPercentage() {
        return exitProgress / 100.0;
    }
    
    public String getEnterProgressFormatted() {
        return String.format("%.1f%%", getEnterProgressPercentage());
    }
    
    public String getExitProgressFormatted() {
        return String.format("%.1f%%", getExitProgressPercentage());
    }
    
    public int getRemainingEnterProgress() {
        return 10000 - enterProgress;
    }
    
    public int getRemainingExitProgress() {
        return 10000 - exitProgress;
    }
    
    public long getTimeSinceEnterStart() {
        if (enterStartTime == null) return 0;
        return Instant.now().getEpochSecond() - enterStartTime.getEpochSecond();
    }
    
    public long getTimeSinceExitStart() {
        if (exitStartTime == null) return 0;
        return Instant.now().getEpochSecond() - exitStartTime.getEpochSecond();
    }
    
    public long getTimeSinceBreak() {
        if (breakTime == null) return 0;
        return Instant.now().getEpochSecond() - breakTime.getEpochSecond();
    }
    
    public int getEstimatedEnterTimeRemaining() {
        if (!entering || enterProgress == 0) return enterTime / 20; // Convert ticks to seconds
        
        double progressFraction = enterProgress / 10000.0;
        double timeElapsed = getTimeSinceEnterStart();
        double totalEstimatedTime = timeElapsed / progressFraction;
        return (int) Math.ceil(totalEstimatedTime - timeElapsed);
    }
    
    public int getEstimatedExitTimeRemaining() {
        if (!exiting || exitProgress == 0) return exitTime / 20; // Convert ticks to seconds
        
        double progressFraction = exitProgress / 10000.0;
        double timeElapsed = getTimeSinceExitStart();
        double totalEstimatedTime = timeElapsed / progressFraction;
        return (int) Math.ceil(totalEstimatedTime - timeElapsed);
    }
    
    public Block getBlock() {
        return location != null ? location.getBlock() : null;
    }
    
    public int getEnterProgressPerTick() {
        // Calculate progress per tick
        return 10000 / enterTime;
    }
    
    public int getExitProgressPerTick() {
        // Calculate progress per tick
        return 10000 / exitTime;
    }
    
    public double getEnterSpeedMultiplier() {
        // Base enter speed
        return 1.0;
    }
    
    public double getExitSpeedMultiplier() {
        // Base exit speed
        return 1.0;
    }
    
    public void reset() {
        occupied = false;
        entering = false;
        exiting = false;
        enterProgress = 0;
        exitProgress = 0;
        occupant = null;
        enterStartTime = null;
        exitStartTime = null;
        broken = false;
        breakTime = null;
        repairTime = null;
        metadata.clear();
    }
    
    public void addMetadata(String key, Object value) {
        metadata.put(key, value);
    }
    
    public Object getMetadata(String key) {
        return metadata.get(key);
    }
    
    public void removeMetadata(String key) {
        metadata.remove(key);
    }
    
    public Locker copy() {
        Locker copy = new Locker();
        copy.lockerId = this.lockerId;
        copy.location = this.location != null ? this.location.clone() : null;
        copy.occupied = this.occupied;
        copy.entering = this.entering;
        copy.exiting = this.exiting;
        copy.enterProgress = this.enterProgress;
        copy.exitProgress = this.exitProgress;
        copy.occupant = this.occupant;
        copy.enterStartTime = this.enterStartTime;
        copy.exitStartTime = this.exitStartTime;
        copy.enterTime = this.enterTime;
        copy.exitTime = this.exitTime;
        copy.broken = this.broken;
        copy.canBeBroken = this.canBeBroken;
        copy.breakTime = this.breakTime;
        copy.breakCooldown = this.breakCooldown;
        copy.repairTime = this.repairTime;
        copy.providesImmunity = this.providesImmunity;
        copy.providesHealing = this.providesHealing;
        copy.metadata = new HashMap<>(this.metadata);
        return copy;
    }
    
    @Override
    public String toString() {
        return "Locker{" +
               "id=" + lockerId +
               ", occupied=" + occupied +
               ", entering=" + entering +
               ", exiting=" + exiting +
               ", enterProgress=" + getEnterProgressFormatted() +
               ", exitProgress=" + getExitProgressFormatted() +
               ", broken=" + broken +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Locker locker = (Locker) o;
        return Objects.equals(lockerId, locker.lockerId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(lockerId);
    }
}
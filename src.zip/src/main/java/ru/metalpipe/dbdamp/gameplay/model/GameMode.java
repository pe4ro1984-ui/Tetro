package ru.metalpipe.dbdamp.gameplay.model;

/**
 * Game modes for DBD matches.
 */
public enum GameMode {
    
    PUBLIC("Public", "PUBLIC", "Public matchmaking with random players", true, false, 5, 10),
    RANKED("Ranked", "RANKED", "Competitive matchmaking with skill-based matchmaking", true, true, 5, 10),
    CUSTOM("Custom", "CUSTOM", "Custom match with configurable settings", false, false, 1, 20),
    TUTORIAL("Tutorial", "TUTORIAL", "Tutorial mode for new players", false, false, 1, 1),
    PRACTICE("Practice", "PRACTICE", "Practice mode against bots", false, false, 1, 5),
    EVENT("Event", "EVENT", "Special event mode with unique rules", true, false, 5, 10);
    
    private final String displayName;
    private final String permissionNode;
    private final String description;
    private final boolean matchmaking;
    private final boolean ranked;
    private final int minPlayers;
    private final int maxPlayers;
    
    GameMode(String displayName, String permissionNode, String description, 
             boolean matchmaking, boolean ranked, int minPlayers, int maxPlayers) {
        this.displayName = displayName;
        this.permissionNode = permissionNode;
        this.description = description;
        this.matchmaking = matchmaking;
        this.ranked = ranked;
        this.minPlayers = minPlayers;
        this.maxPlayers = maxPlayers;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    public String getPermissionNode() {
        return "dbdamp.mode." + permissionNode.toLowerCase();
    }
    
    public String getDescription() {
        return description;
    }
    
    public boolean hasMatchmaking() {
        return matchmaking;
    }
    
    public boolean isRanked() {
        return ranked;
    }
    
    public int getMinPlayers() {
        return minPlayers;
    }
    
    public int getMaxPlayers() {
        return maxPlayers;
    }
    
    public boolean isPublic() {
        return this == PUBLIC;
    }
    
    public boolean isCustom() {
        return this == CUSTOM;
    }
    
    public boolean isTutorial() {
        return this == TUTORIAL;
    }
    
    public boolean isPractice() {
        return this == PRACTICE;
    }
    
    public boolean isEvent() {
        return this == EVENT;
    }
    
    public boolean requiresFullTeam() {
        return this == PUBLIC || this == RANKED;
    }
    
    public boolean allowsBots() {
        return this == PRACTICE || this == TUTORIAL;
    }
    
    public boolean hasLeaderboards() {
        return this == RANKED;
    }
    
    public boolean hasRewards() {
        return this != PRACTICE && this != TUTORIAL;
    }
    
    public int getDefaultSurvivorCount() {
        switch (this) {
            case PUBLIC:
            case RANKED:
            case CUSTOM:
            case EVENT:
                return 4;
            case PRACTICE:
                return 3; // Practice with bots
            case TUTORIAL:
                return 1; // Solo tutorial
            default:
                return 4;
        }
    }
    
    public int getDefaultKillerCount() {
        switch (this) {
            case PUBLIC:
            case RANKED:
            case CUSTOM:
            case EVENT:
                return 1;
            case PRACTICE:
                return 1; // One bot killer
            case TUTORIAL:
                return 0; // No killer in tutorial
            default:
                return 1;
        }
    }
    
    public static GameMode fromString(String mode) {
        if (mode == null) return null;
        
        try {
            return GameMode.valueOf(mode.toUpperCase());
        } catch (IllegalArgumentException e) {
            // Try case-insensitive match
            for (GameMode m : values()) {
                if (m.name().equalsIgnoreCase(mode) || 
                    m.getDisplayName().equalsIgnoreCase(mode)) {
                    return m;
                }
            }
            return null;
        }
    }
    
    public static GameMode getDefault() {
        return PUBLIC;
    }
    
    public static GameMode[] getMatchmakingModes() {
        return new GameMode[] { PUBLIC, RANKED };
    }
    
    public static GameMode[] getCustomModes() {
        return new GameMode[] { CUSTOM, PRACTICE, TUTORIAL };
    }
    
    public static GameMode[] getAvailableModes() {
        return values();
    }
    
    public static String[] getDisplayNames() {
        GameMode[] modes = values();
        String[] names = new String[modes.length];
        for (int i = 0; i < modes.length; i++) {
            names[i] = modes[i].getDisplayName();
        }
        return names;
    }
    
    public static GameMode getByIndex(int index) {
        GameMode[] modes = values();
        if (index >= 0 && index < modes.length) {
            return modes[index];
        }
        return getDefault();
    }
    
    public int getIndex() {
        return ordinal();
    }
    
    public GameModeSettings getDefaultSettings() {
        return new GameModeSettings(this);
    }
    
    @Override
    public String toString() {
        return displayName;
    }
    
    /**
     * Default settings for each game mode.
     */
    public static class GameModeSettings {
        private final GameMode gameMode;
        private int matchDuration = 900; // 15 minutes
        private int generatorsRequired = 5;
        private int totalGenerators = 7;
        private boolean skillChecksEnabled = true;
        private boolean perksEnabled = true;
        private boolean itemsEnabled = true;
        private boolean offeringsEnabled = true;
        private boolean bloodwebEnabled = true;
        private boolean escapeEnabled = true;
        private boolean moriEnabled = false;
        
        public GameModeSettings(GameMode gameMode) {
            this.gameMode = gameMode;
            
            // Set defaults based on game mode
            switch (gameMode) {
                case TUTORIAL:
                    matchDuration = 300; // 5 minutes
                    generatorsRequired = 1;
                    totalGenerators = 1;
                    skillChecksEnabled = false;
                    perksEnabled = false;
                    itemsEnabled = false;
                    offeringsEnabled = false;
                    bloodwebEnabled = false;
                    escapeEnabled = true;
                    moriEnabled = false;
                    break;
                    
                case PRACTICE:
                    matchDuration = 600; // 10 minutes
                    generatorsRequired = 3;
                    totalGenerators = 5;
                    skillChecksEnabled = true;
                    perksEnabled = false;
                    itemsEnabled = true;
                    offeringsEnabled = false;
                    bloodwebEnabled = false;
                    escapeEnabled = true;
                    moriEnabled = false;
                    break;
                    
                case EVENT:
                    matchDuration = 1200; // 20 minutes
                    generatorsRequired = 7;
                    totalGenerators = 10;
                    skillChecksEnabled = true;
                    perksEnabled = true;
                    itemsEnabled = true;
                    offeringsEnabled = true;
                    bloodwebEnabled = true;
                    escapeEnabled = true;
                    moriEnabled = true;
                    break;
                    
                default:
                    // Use defaults
                    break;
            }
        }
        
        // Getters and setters
        public GameMode getGameMode() { return gameMode; }
        public int getMatchDuration() { return matchDuration; }
        public void setMatchDuration(int matchDuration) { this.matchDuration = matchDuration; }
        public int getGeneratorsRequired() { return generatorsRequired; }
        public void setGeneratorsRequired(int generatorsRequired) { this.generatorsRequired = generatorsRequired; }
        public int getTotalGenerators() { return totalGenerators; }
        public void setTotalGenerators(int totalGenerators) { this.totalGenerators = totalGenerators; }
        public boolean isSkillChecksEnabled() { return skillChecksEnabled; }
        public void setSkillChecksEnabled(boolean skillChecksEnabled) { this.skillChecksEnabled = skillChecksEnabled; }
        public boolean isPerksEnabled() { return perksEnabled; }
        public void setPerksEnabled(boolean perksEnabled) { this.perksEnabled = perksEnabled; }
        public boolean isItemsEnabled() { return itemsEnabled; }
        public void setItemsEnabled(boolean itemsEnabled) { this.itemsEnabled = itemsEnabled; }
        public boolean isOfferingsEnabled() { return offeringsEnabled; }
        public void setOfferingsEnabled(boolean offeringsEnabled) { this.offeringsEnabled = offeringsEnabled; }
        public boolean isBloodwebEnabled() { return bloodwebEnabled; }
        public void setBloodwebEnabled(boolean bloodwebEnabled) { this.bloodwebEnabled = bloodwebEnabled; }
        public boolean isEscapeEnabled() { return escapeEnabled; }
        public void setEscapeEnabled(boolean escapeEnabled) { this.escapeEnabled = escapeEnabled; }
        public boolean isMoriEnabled() { return moriEnabled; }
        public void setMoriEnabled(boolean moriEnabled) { this.moriEnabled = moriEnabled; }
    }
}
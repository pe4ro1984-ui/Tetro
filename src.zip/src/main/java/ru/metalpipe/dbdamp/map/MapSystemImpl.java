package ru.metalpipe.dbdamp.map;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import ru.metalpipe.dbdamp.gameplay.model.MapState;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Implementation of the map system.
 * Handles procedural generation, loading, and management of DBD maps.
 */
public class MapSystemImpl implements MapSystem {
    
    private final Logger logger;
    private final Random random;
    
    // Available map themes
    private final List<String> availableThemes;
    
    // Map rotation
    private final List<String> mapRotation;
    private int currentRotationIndex;
    
    // Active map votes
    private final Map<UUID, MapVote> activeVotes;
    
    // Configuration
    private static final int DEFAULT_GENERATORS = 5;
    private static final int DEFAULT_HOOKS = 8;
    private static final int DEFAULT_EXIT_GATES = 2;
    private static final int DEFAULT_CHESTS = 4;
    private static final int DEFAULT_LOCKERS = 12;
    
    // Balance constraints
    private static final double MIN_DISTANCE_BETWEEN_GENERATORS = 20.0;
    private static final double MIN_DISTANCE_BETWEEN_HOOKS = 10.0;
    private static final double MIN_DISTANCE_EXIT_GATE_FROM_CENTER = 50.0;
    
    public MapSystemImpl() {
        this.logger = Logger.getLogger(getClass().getName());
        this.random = new Random();
        this.availableThemes = new ArrayList<>();
        this.mapRotation = new ArrayList<>();
        this.activeVotes = new ConcurrentHashMap<>();
        this.currentRotationIndex = 0;
        
        // Initialize default themes
        initializeDefaultThemes();
    }
    
    @Override
    public MapState generateMap(UUID matchId, String theme, long seed) {
        MapState mapState = new MapState();
        mapState.setMapId(matchId.toString());
        mapState.setMapName(generateMapName(theme));
        mapState.setTheme(theme);
        mapState.setSeed(seed);
        
        // Set random with seed for deterministic generation
        Random mapRandom = new Random(seed);
        
        // Calculate map bounds (example: 200x200 blocks)
        Location center = new Location(null, 0, 64, 0); // World will be set later
        mapState.setBounds(new MapState.Bounds(
            center.clone().subtract(100, 0, 100),
            center.clone().add(100, 0, 100)
        ));
        
        // Place game objects
        placeGenerators(mapState, DEFAULT_GENERATORS);
        placeHooks(mapState, DEFAULT_HOOKS);
        placeExitGates(mapState, DEFAULT_EXIT_GATES);
        placeChests(mapState, DEFAULT_CHESTS);
        placeLockers(mapState, DEFAULT_LOCKERS);
        
        mapState.setLoaded(false);
        
        logger.info("Generated map for match " + matchId + " with theme " + theme + " and seed " + seed);
        return mapState;
    }
    
    @Override
    public boolean loadMap(MapState mapState) {
        if (mapState == null || mapState.getBounds() == null) {
            return false;
        }
        
        // In a real implementation, this would:
        // 1. Create or load the world
        // 2. Generate terrain based on theme
        // 3. Place structures and game objects
        
        mapState.setLoaded(true);
        logger.info("Loaded map " + mapState.getMapId());
        return true;
    }
    
    @Override
    public boolean unloadMap(MapState mapState) {
        if (mapState == null) {
            return false;
        }
        
        mapState.setLoaded(false);
        logger.info("Unloaded map " + mapState.getMapId());
        return true;
    }
    
    @Override
    public List<String> getAvailableThemes() {
        return new ArrayList<>(availableThemes);
    }
    
    @Override
    public List<Location> placeGenerators(MapState mapState, int count) {
        List<Location> locations = new ArrayList<>();
        MapState.Bounds bounds = mapState.getBounds();
        
        for (int i = 0; i < count; i++) {
            Location loc = generateBalancedLocation(bounds, locations, MIN_DISTANCE_BETWEEN_GENERATORS);
            if (loc != null) {
                locations.add(loc);
            }
        }
        
        return locations;
    }
    
    @Override
    public List<Location> placeHooks(MapState mapState, int count) {
        List<Location> locations = new ArrayList<>();
        MapState.Bounds bounds = mapState.getBounds();
        
        for (int i = 0; i < count; i++) {
            Location loc = generateBalancedLocation(bounds, locations, MIN_DISTANCE_BETWEEN_HOOKS);
            if (loc != null) {
                locations.add(loc);
            }
        }
        
        return locations;
    }
    
    @Override
    public List<Location> placeExitGates(MapState mapState, int count) {
        List<Location> locations = new ArrayList<>();
        MapState.Bounds bounds = mapState.getBounds();
        Location center = bounds.getCenter();
        
        for (int i = 0; i < count; i++) {
            // Place exit gates at map edges
            double angle = (2 * Math.PI * i) / count;
            double distance = MIN_DISTANCE_EXIT_GATE_FROM_CENTER;
            
            Location loc = center.clone().add(
                Math.cos(angle) * distance,
                0,
                Math.sin(angle) * distance
            );
            
            locations.add(loc);
        }
        
        return locations;
    }
    
    @Override
    public List<Location> placeChests(MapState mapState, int count) {
        List<Location> locations = new ArrayList<>();
        MapState.Bounds bounds = mapState.getBounds();
        
        for (int i = 0; i < count; i++) {
            Location loc = generateRandomLocation(bounds);
            locations.add(loc);
        }
        
        return locations;
    }
    
    @Override
    public List<Location> placeLockers(MapState mapState, int count) {
        List<Location> locations = new ArrayList<>();
        MapState.Bounds bounds = mapState.getBounds();
        
        for (int i = 0; i < count; i++) {
            Location loc = generateRandomLocation(bounds);
            locations.add(loc);
        }
        
        return locations;
    }
    
    @Override
    public List<String> getMapRotation() {
        return new ArrayList<>(mapRotation);
    }
    
    @Override
    public String getNextMap() {
        if (mapRotation.isEmpty()) {
            return availableThemes.isEmpty() ? "default" : availableThemes.get(0);
        }
        
        String nextMap = mapRotation.get(currentRotationIndex);
        currentRotationIndex = (currentRotationIndex + 1) % mapRotation.size();
        return nextMap;
    }
    
    @Override
    public void startMapVote(UUID matchId, List<String> options) {
        MapVote vote = new MapVote(matchId, options);
        activeVotes.put(matchId, vote);
        logger.info("Started map vote for match " + matchId + " with options: " + options);
    }
    
    @Override
    public boolean castVote(UUID matchId, UUID playerId, String mapTheme) {
        MapVote vote = activeVotes.get(matchId);
        if (vote == null) {
            return false;
        }
        
        return vote.castVote(playerId, mapTheme);
    }
    
    @Override
    public String getVoteWinner(UUID matchId) {
        MapVote vote = activeVotes.get(matchId);
        if (vote == null) {
            return null;
        }
        
        return vote.getWinner();
    }
    
    @Override
    public boolean validateMap(MapState mapState) {
        if (mapState == null) return false;
        if (mapState.getMapId() == null || mapState.getMapId().isEmpty()) return false;
        if (mapState.getBounds() == null || !mapState.getBounds().isValid()) return false;
        
        return true;
    }
    
    // Helper methods
    private void initializeDefaultThemes() {
        availableThemes.add("forest");
        availableThemes.add("industrial");
        availableThemes.add("asylum");
        availableThemes.add("junkyard");
        availableThemes.add("laboratory");
        
        mapRotation.addAll(availableThemes);
    }
    
    private String generateMapName(String theme) {
        String[] prefixes = {"Old", "New", "Abandoned", "Forgotten", "Haunted"};
        String[] suffixes = {"Grounds", "Woods", "Facility", "Complex", "Ruins"};
        
        String prefix = prefixes[random.nextInt(prefixes.length)];
        String suffix = suffixes[random.nextInt(suffixes.length)];
        
        return prefix + " " + theme.substring(0, 1).toUpperCase() + theme.substring(1) + " " + suffix;
    }
    
    private Location generateBalancedLocation(MapState.Bounds bounds, List<Location> existing, double minDistance) {
        int maxAttempts = 100;
        
        for (int attempt = 0; attempt < maxAttempts; attempt++) {
            Location loc = generateRandomLocation(bounds);
            
            boolean valid = true;
            for (Location existingLoc : existing) {
                if (loc.distance(existingLoc) < minDistance) {
                    valid = false;
                    break;
                }
            }
            
            if (valid) {
                return loc;
            }
        }
        
        // Fallback to random location if balanced placement fails
        return generateRandomLocation(bounds);
    }
    
    private Location generateRandomLocation(MapState.Bounds bounds) {
        if (bounds == null || !bounds.isValid()) {
            return new Location(null, 0, 64, 0);
        }
        
        double minX = Math.min(bounds.getMin().getX(), bounds.getMax().getX());
        double maxX = Math.max(bounds.getMin().getX(), bounds.getMax().getX());
        double minZ = Math.min(bounds.getMin().getZ(), bounds.getMax().getZ());
        double maxZ = Math.max(bounds.getMin().getZ(), bounds.getMax().getZ());
        
        double x = minX + random.nextDouble() * (maxX - minX);
        double z = minZ + random.nextDouble() * (maxZ - minZ);
        double y = 64; // Ground level, would be determined by terrain in real implementation
        
        return new Location(bounds.getMin().getWorld(), x, y, z);
    }
    
    /**
     * Represents an active map vote.
     */
    private static class MapVote {
        private final UUID matchId;
        private final List<String> options;
        private final Map<String, Integer> votes;
        private final Map<UUID, String> playerVotes;
        
        public MapVote(UUID matchId, List<String> options) {
            this.matchId = matchId;
            this.options = new ArrayList<>(options);
            this.votes = new HashMap<>();
            this.playerVotes = new HashMap<>();
            
            // Initialize vote counts
            for (String option : options) {
                votes.put(option, 0);
            }
        }
        
        public boolean castVote(UUID playerId, String mapTheme) {
            if (!options.contains(mapTheme)) {
                return false;
            }
            
            // Remove previous vote if exists
            String previousVote = playerVotes.get(playerId);
            if (previousVote != null) {
                votes.put(previousVote, votes.get(previousVote) - 1);
            }
            
            // Record new vote
            playerVotes.put(playerId, mapTheme);
            votes.put(mapTheme, votes.get(mapTheme) + 1);
            
            return true;
        }
        
        public String getWinner() {
            String winner = null;
            int maxVotes = -1;
            
            for (Map.Entry<String, Integer> entry : votes.entrySet()) {
                if (entry.getValue() > maxVotes) {
                    maxVotes = entry.getValue();
                    winner = entry.getKey();
                }
            }
            
            // If tie, pick random from tied options
            List<String> tied = new ArrayList<>();
            for (Map.Entry<String, Integer> entry : votes.entrySet()) {
                if (entry.getValue() == maxVotes) {
                    tied.add(entry.getKey());
                }
            }
            
            if (tied.size() > 1) {
                Random random = new Random();
                winner = tied.get(random.nextInt(tied.size()));
            }
            
            return winner;
        }
    }
}
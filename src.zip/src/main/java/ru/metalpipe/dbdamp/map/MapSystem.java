package ru.metalpipe.dbdamp.map;

import org.bukkit.Location;
import ru.metalpipe.dbdamp.gameplay.model.GameMode;
import ru.metalpipe.dbdamp.gameplay.model.MapState;

import java.util.List;
import java.util.UUID;

/**
 * Interface for procedural map generation and management.
 */
public interface MapSystem {
    
    /**
     * Generate a new map for a match.
     * 
     * @param matchId The match UUID
     * @param theme The map theme
     * @param seed The generation seed (for deterministic generation)
     * @return The generated map state
     */
    MapState generateMap(UUID matchId, String theme, long seed);
    
    /**
     * Load a map into the world.
     * 
     * @param mapState The map state to load
     * @return true if loaded successfully
     */
    boolean loadMap(MapState mapState);
    
    /**
     * Unload a map from the world.
     * 
     * @param mapState The map state to unload
     * @return true if unloaded successfully
     */
    boolean unloadMap(MapState mapState);
    
    /**
     * Get available map themes.
     * 
     * @return List of theme names
     */
    List<String> getAvailableThemes();
    
    /**
     * Place generators on the map.
     * 
     * @param mapState The map state
     * @param count Number of generators to place
     * @return List of generator locations
     */
    List<Location> placeGenerators(MapState mapState, int count);
    
    /**
     * Place hooks on the map.
     * 
     * @param mapState The map state
     * @param count Number of hooks to place
     * @return List of hook locations
     */
    List<Location> placeHooks(MapState mapState, int count);
    
    /**
     * Place exit gates on the map.
     * 
     * @param mapState The map state
     * @param count Number of exit gates to place
     * @return List of exit gate locations
     */
    List<Location> placeExitGates(MapState mapState, int count);
    
    /**
     * Place chests on the map.
     * 
     * @param mapState The map state
     * @param count Number of chests to place
     * @return List of chest locations
     */
    List<Location> placeChests(MapState mapState, int count);
    
    /**
     * Place lockers on the map.
     * 
     * @param mapState The map state
     * @param count Number of lockers to place
     * @return List of locker locations
     */
    List<Location> placeLockers(MapState mapState, int count);
    
    /**
     * Get the current map rotation.
     * 
     * @return List of map theme names in rotation
     */
    List<String> getMapRotation();
    
    /**
     * Get the next map in rotation.
     * 
     * @return The next map theme name
     */
    String getNextMap();
    
    /**
     * Start a map vote.
     * 
     * @param matchId The match UUID
     * @param options List of map options to vote on
     */
    void startMapVote(UUID matchId, List<String> options);
    
    /**
     * Cast a vote for a map.
     * 
     * @param matchId The match UUID
     * @param playerId The voting player's UUID
     * @param mapTheme The voted map theme
     * @return true if vote was recorded
     */
    boolean castVote(UUID matchId, UUID playerId, String mapTheme);
    
    /**
     * Get the winning map from a vote.
     * 
     * @param matchId The match UUID
     * @return The winning map theme
     */
    String getVoteWinner(UUID matchId);
    
    /**
     * Validate that a map meets minimum requirements.
     * 
     * @param mapState The map state to validate
     * @return true if map is valid
     */
    boolean validateMap(MapState mapState);
}
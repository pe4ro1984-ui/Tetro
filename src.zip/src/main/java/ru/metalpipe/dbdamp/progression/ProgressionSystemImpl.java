package ru.metalpipe.dbdamp.progression;

import ru.metalpipe.dbdamp.database.model.PlayerLevel;
import ru.metalpipe.dbdamp.database.model.PrestigeRank;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Implementation of the progression system.
 * Manages player levels, prestige ranks, and unlockable content.
 */
public class ProgressionSystemImpl implements ProgressionSystem {
    
    private final Logger logger;
    
    // Player progression data
    private final Map<UUID, PlayerLevel> playerLevels;
    private final Map<UUID, PrestigeRank> playerPrestige;
    private final Map<UUID, Set<String>> playerUnlocks;
    
    // Configuration
    private static final int MAX_LEVEL = 50;
    private static final int BASE_XP_REQUIREMENT = 100;
    private static final double XP_SCALING = 1.5;
    private static final int PRESTIGE_LEVEL_REQUIREMENT = 50;
    private static final int MAX_PRESTIGE = 100;
    
    public ProgressionSystemImpl() {
        this.logger = Logger.getLogger(getClass().getName());
        this.playerLevels = new ConcurrentHashMap<>();
        this.playerPrestige = new ConcurrentHashMap<>();
        this.playerUnlocks = new ConcurrentHashMap<>();
    }
    
    @Override
    public int getLevel(UUID playerId) {
        PlayerLevel level = playerLevels.get(playerId);
        return level != null ? level.getLevel() : 1;
    }
    
    @Override
    public int getExperience(UUID playerId) {
        PlayerLevel level = playerLevels.get(playerId);
        return level != null ? level.getExperience() : 0;
    }
    
    @Override
    public boolean addExperience(UUID playerId, int amount) {
        PlayerLevel level = getOrCreateLevel(playerId);
        
        int oldLevel = level.getLevel();
        level.setExperience(level.getExperience() + amount);
        
        // Check for level up
        while (level.getLevel() < MAX_LEVEL && canLevelUp(level)) {
            performLevelUp(level);
        }
        
        boolean leveledUp = level.getLevel() > oldLevel;
        
        if (leveledUp) {
            logger.info("Player " + playerId + " leveled up to " + level.getLevel());
            checkUnlocks(playerId, level.getLevel());
        }
        
        return leveledUp;
    }
    
    @Override
    public int getExperienceToNextLevel(UUID playerId) {
        PlayerLevel level = playerLevels.get(playerId);
        if (level == null || level.getLevel() >= MAX_LEVEL) {
            return 0;
        }
        
        int required = calculateXpRequirement(level.getLevel() + 1);
        return required - level.getExperience();
    }
    
    @Override
    public int getPrestigeRank(UUID playerId) {
        PrestigeRank prestige = playerPrestige.get(playerId);
        return prestige != null ? prestige.getRank() : 0;
    }
    
    @Override
    public boolean canPrestige(UUID playerId) {
        int level = getLevel(playerId);
        int currentPrestige = getPrestigeRank(playerId);
        
        return level >= PRESTIGE_LEVEL_REQUIREMENT && currentPrestige < MAX_PRESTIGE;
    }
    
    @Override
    public boolean prestige(UUID playerId) {
        if (!canPrestige(playerId)) {
            return false;
        }
        
        // Get current prestige
        PrestigeRank prestige = getOrCreatePrestige(playerId);
        int newRank = prestige.getRank() + 1;
        prestige.setRank(newRank);
        
        // Reset level
        PlayerLevel level = playerLevels.get(playerId);
        if (level != null) {
            level.setLevel(1);
            level.setExperience(0);
        }
        
        // Award prestige rewards
        awardPrestigeRewards(playerId, newRank);
        
        logger.info("Player " + playerId + " prestiged to rank " + newRank);
        return true;
    }
    
    @Override
    public List<String> getUnlocksForLevel(int level) {
        List<String> unlocks = new ArrayList<>();
        
        // Add perk slot unlocks
        if (level >= 10) unlocks.add("perk_slot_2");
        if (level >= 20) unlocks.add("perk_slot_3");
        if (level >= 35) unlocks.add("perk_slot_4");
        
        // Add item unlocks (example)
        if (level >= 5) unlocks.add("item_medkit");
        if (level >= 15) unlocks.add("item_flashlight");
        if (level >= 25) unlocks.add("item_toolbox");
        
        return unlocks;
    }
    
    @Override
    public boolean hasUnlocked(UUID playerId, String contentId) {
        Set<String> unlocks = playerUnlocks.get(playerId);
        return unlocks != null && unlocks.contains(contentId);
    }
    
    @Override
    public boolean unlockContent(UUID playerId, String contentId) {
        Set<String> unlocks = getOrCreateUnlocks(playerId);
        
        if (unlocks.contains(contentId)) {
            return false;
        }
        
        unlocks.add(contentId);
        logger.fine("Unlocked content " + contentId + " for player " + playerId);
        return true;
    }
    
    @Override
    public List<String> getPrestigeRewards(int prestigeRank) {
        List<String> rewards = new ArrayList<>();
        
        // Example prestige rewards
        if (prestigeRank >= 1) rewards.add("prestige_icon_1");
        if (prestigeRank >= 5) rewards.add("prestige_charm_1");
        if (prestigeRank >= 10) rewards.add("prestige_outfit_1");
        if (prestigeRank >= 25) rewards.add("prestige_effect_1");
        if (prestigeRank >= 50) rewards.add("prestige_aura_1");
        if (prestigeRank >= 100) rewards.add("prestige_legendary");
        
        return rewards;
    }
    
    @Override
    public int getTotalPower(UUID playerId) {
        int level = getLevel(playerId);
        int prestige = getPrestigeRank(playerId);
        return (prestige * MAX_LEVEL) + level;
    }
    
    // Helper methods
    private PlayerLevel getOrCreateLevel(UUID playerId) {
        return playerLevels.computeIfAbsent(playerId, id -> {
            PlayerLevel level = new PlayerLevel();
            level.setLevel(1);
            level.setExperience(0);
            return level;
        });
    }
    
    private PrestigeRank getOrCreatePrestige(UUID playerId) {
        return playerPrestige.computeIfAbsent(playerId, id -> {
            PrestigeRank prestige = new PrestigeRank();
            prestige.setRank(0);
            return prestige;
        });
    }
    
    private Set<String> getOrCreateUnlocks(UUID playerId) {
        return playerUnlocks.computeIfAbsent(playerId, id -> new HashSet<>());
    }
    
    private int calculateXpRequirement(int level) {
        return (int) (BASE_XP_REQUIREMENT * Math.pow(XP_SCALING, level - 1));
    }
    
    private boolean canLevelUp(PlayerLevel level) {
        int required = calculateXpRequirement(level.getLevel() + 1);
        return level.getExperience() >= required;
    }
    
    private void performLevelUp(PlayerLevel level) {
        int required = calculateXpRequirement(level.getLevel() + 1);
        level.setExperience(level.getExperience() - required);
        level.setLevel(level.getLevel() + 1);
    }
    
    private void checkUnlocks(UUID playerId, int newLevel) {
        List<String> unlocks = getUnlocksForLevel(newLevel);
        for (String unlockId : unlocks) {
            unlockContent(playerId, unlockId);
        }
    }
    
    private void awardPrestigeRewards(UUID playerId, int prestigeRank) {
        List<String> rewards = getPrestigeRewards(prestigeRank);
        for (String rewardId : rewards) {
            unlockContent(playerId, rewardId);
        }
    }
}
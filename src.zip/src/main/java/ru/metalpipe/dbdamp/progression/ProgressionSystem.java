package ru.metalpipe.dbdamp.progression;

import java.util.List;
import java.util.UUID;

/**
 * Interface for managing player leveling, prestige ranks, and unlockable content.
 */
public interface ProgressionSystem {
    
    /**
     * Get a player's current level.
     * 
     * @param playerId The player's UUID
     * @return Current level (1-50 per prestige)
     */
    int getLevel(UUID playerId);
    
    /**
     * Get a player's total experience.
     * 
     * @param playerId The player's UUID
     * @return Total experience points
     */
    int getExperience(UUID playerId);
    
    /**
     * Add experience to a player.
     * 
     * @param playerId The player's UUID
     * @param amount Amount of experience to add
     * @return true if player leveled up
     */
    boolean addExperience(UUID playerId, int amount);
    
    /**
     * Get experience required for the next level.
     * 
     * @param playerId The player's UUID
     * @return Experience required
     */
    int getExperienceToNextLevel(UUID playerId);
    
    /**
     * Get a player's prestige rank.
     * 
     * @param playerId The player's UUID
     * @return Prestige rank (0-100)
     */
    int getPrestigeRank(UUID playerId);
    
    /**
     * Check if a player can prestige.
     * 
     * @param playerId The player's UUID
     * @return true if player can prestige
     */
    boolean canPrestige(UUID playerId);
    
    /**
     * Prestige a player.
     * 
     * @param playerId The player's UUID
     * @return true if prestige was successful
     */
    boolean prestige(UUID playerId);
    
    /**
     * Get unlockable content for a level.
     * 
     * @param level The level
     * @return List of unlockable IDs
     */
    List<String> getUnlocksForLevel(int level);
    
    /**
     * Check if a player has unlocked content.
     * 
     * @param playerId The player's UUID
     * @param contentId The content ID
     * @return true if unlocked
     */
    boolean hasUnlocked(UUID playerId, String contentId);
    
    /**
     * Unlock content for a player.
     * 
     * @param playerId The player's UUID
     * @param contentId The content ID
     * @return true if unlocked successfully
     */
    boolean unlockContent(UUID playerId, String contentId);
    
    /**
     * Get prestige rewards for a rank.
     * 
     * @param prestigeRank The prestige rank
     * @return List of reward IDs
     */
    List<String> getPrestigeRewards(int prestigeRank);
    
    /**
     * Calculate total player power (combined level and prestige).
     * 
     * @param playerId The player's UUID
     * @return Total power level
     */
    int getTotalPower(UUID playerId);
}
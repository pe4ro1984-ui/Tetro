package ru.metalpipe.dbdamp;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;
import java.util.logging.Logger;

/**
 * Main event listener for DBD-AMP gameplay events.
 */
public class DBDGameListener implements Listener {
    
    private final DBDAMPPlugin plugin;
    private final Logger logger;
    
    public DBDGameListener(DBDAMPPlugin plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
    }
    
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        
        // Initialize player data
        // ProgressionSystem handles player data internally
        
        logger.fine("Player joined: " + player.getName());
    }
    
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        
        // Save and cleanup player data
        // ProgressionSystem handles player data internally
        
        // Remove from any active matches
        // MatchSystem handles player removal internally
        
        logger.fine("Player quit: " + player.getName());
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        
        // Handle death in match context if player is in a match
        if (plugin.getMatchSystem() != null) {
            var match = plugin.getMatchSystem().getPlayerMatch(victim.getUniqueId());
            if (match != null) {
                logger.fine("Player " + victim.getName() + " died in match " + match.getMatchId());
                
                // Play kill effect
                if (plugin.getIntegrationManager() != null && 
                    plugin.getIntegrationManager().isIntegrationEnabled("KillEffect")) {
                    var killEffect = plugin.getIntegrationManager().<ru.metalpipe.dbdamp.integration.KillEffectIntegration>getIntegration("KillEffect");
                    if (killEffect != null) {
                        killEffect.playKillEffect(victim, killer, 
                            ru.metalpipe.dbdamp.integration.KillEffectIntegration.KillEffectType.BLOOD_EXPLOSION);
                    }
                }
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;
        
        Player attacker = (Player) event.getDamager();
        Player victim = (Player) event.getEntity();
        
        // Check if both players are in the same match
        if (plugin.getMatchSystem() != null) {
            var attackerMatch = plugin.getMatchSystem().getPlayerMatch(attacker.getUniqueId());
            var victimMatch = plugin.getMatchSystem().getPlayerMatch(victim.getUniqueId());
            
            if (attackerMatch != null && victimMatch != null && 
                attackerMatch.getMatchId().equals(victimMatch.getMatchId())) {
                // Handle damage in match context
                // This would integrate with the killer/survivor systems
            }
        }
    }
    
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        
        // Check if player is using a custom item
        if (plugin.getCustomItemSystem() != null && event.getItem() != null) {
            var itemSystem = plugin.getCustomItemSystem();
            var itemId = itemSystem.getItemId(event.getItem());
            
            if (itemId.isPresent()) {
                boolean handled = itemSystem.handleInteract(event, itemId.get());
                if (handled) {
                    event.setCancelled(true);
                }
            }
        }
    }
}

package ru.metalpipe.dbdamp.scoreboard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import ru.metalpipe.dbdamp.gameplay.model.Match;
import ru.metalpipe.dbdamp.gameplay.model.MatchStatus;
import ru.metalpipe.dbdamp.gameplay.model.PlayerRole;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Implementation of the dynamic scoreboard system.
 * Provides real-time match information to players.
 */
public class ScoreboardSystemImpl implements ScoreboardSystem {
    
    private final Logger logger;
    
    // Player scoreboards
    private final Map<UUID, Scoreboard> playerScoreboards;
    private final Map<UUID, PlayerRole> playerRoles;
    
    // Scoreboard title
    private static final String TITLE = ChatColor.DARK_RED + "Dead by Daylight";
    
    public ScoreboardSystemImpl() {
        this.logger = Logger.getLogger(getClass().getName());
        this.playerScoreboards = new ConcurrentHashMap<>();
        this.playerRoles = new ConcurrentHashMap<>();
    }
    
    @Override
    public void createScoreboard(UUID playerId, PlayerRole role) {
        Player player = Bukkit.getPlayer(playerId);
        if (player == null) return;
        
        Scoreboard scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective = scoreboard.registerNewObjective("dbd", "dummy", TITLE);
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        
        // Store scoreboard
        playerScoreboards.put(playerId, scoreboard);
        playerRoles.put(playerId, role);
        
        // Apply to player
        player.setScoreboard(scoreboard);
        
        logger.fine("Created scoreboard for player " + playerId);
    }
    
    @Override
    public void updateScoreboard(UUID playerId, Match match) {
        Scoreboard scoreboard = playerScoreboards.get(playerId);
        PlayerRole role = playerRoles.get(playerId);
        
        if (scoreboard == null || role == null || match == null) {
            return;
        }
        
        Objective objective = scoreboard.getObjective("dbd");
        if (objective == null) return;
        
        // Clear existing scores
        for (String entry : scoreboard.getEntries()) {
            scoreboard.resetScores(entry);
        }
        
        int scoreValue = 15;
        
        // Match status
        Score statusScore = objective.getScore(ChatColor.GRAY + "Status: " + ChatColor.WHITE + 
            match.getStatus().getDisplayName());
        statusScore.setScore(scoreValue--);
        
        // Blank line
        Score blank1 = objective.getScore(" ");
        blank1.setScore(scoreValue--);
        
        // Role-specific information
        if (role == PlayerRole.SURVIVOR) {
            scoreValue = addSurvivorInfo(objective, match, scoreValue);
        } else {
            scoreValue = addKillerInfo(objective, match, scoreValue);
        }
        
        // Blank line
        Score blank2 = objective.getScore("  ");
        blank2.setScore(scoreValue--);
        
        // Match time
        long durationSeconds = 0;
        if (match.getStartTime() != null) {
            durationSeconds = (System.currentTimeMillis() - match.getStartTime().toEpochMilli()) / 1000;
        }
        String timeStr = formatTime(durationSeconds);
        Score timeScore = objective.getScore(ChatColor.YELLOW + "Time: " + ChatColor.WHITE + timeStr);
        timeScore.setScore(scoreValue--);
    }
    
    @Override
    public void removeScoreboard(UUID playerId) {
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
        
        playerScoreboards.remove(playerId);
        playerRoles.remove(playerId);
    }
    
    @Override
    public void updateGeneratorProgress(Match match) {
        if (match == null || match.getStatistics() == null) return;
        
        int completed = match.getStatistics().getGeneratorsCompleted();
        
        for (UUID playerId : playerScoreboards.keySet()) {
            PlayerRole role = playerRoles.get(playerId);
            if (role == PlayerRole.SURVIVOR) {
                updateScoreboard(playerId, match);
            }
        }
    }
    
    @Override
    public void updateSurvivorStatus(Match match) {
        if (match == null) return;
        
        for (UUID playerId : playerScoreboards.keySet()) {
            updateScoreboard(playerId, match);
        }
    }
    
    @Override
    public void updateTimer(Match match) {
        for (UUID playerId : playerScoreboards.keySet()) {
            updateScoreboard(playerId, match);
        }
    }
    
    @Override
    public void showEventAnimation(UUID matchId, String eventType, Object data) {
        String message = getEventMessage(eventType, data);
        
        // Send title to all players in the match
        for (UUID playerId : playerScoreboards.keySet()) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendTitle(message, "", 10, 40, 10);
                player.playSound(player.getLocation(), 
                    org.bukkit.Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 1.0f);
            }
        }
    }
    
    @Override
    public void showPostGameStats(UUID playerId, Object results) {
        Player player = Bukkit.getPlayer(playerId);
        if (player == null) return;
        
        // Display post-game statistics
        player.sendTitle(ChatColor.GOLD + "Match Complete!", 
            ChatColor.YELLOW + "See chat for details", 20, 60, 20);
    }
    
    @Override
    public void clearMatchScoreboards(UUID matchId) {
        // Remove all scoreboards (would filter by match in real implementation)
        for (UUID playerId : playerScoreboards.keySet()) {
            removeScoreboard(playerId);
        }
    }
    
    @Override
    public void updateAll() {
        // Update all active scoreboards
        // This would iterate through all active matches and update their scoreboards
    }
    
    // Helper methods
    private int addSurvivorInfo(Objective objective, Match match, int scoreValue) {
        // Generator progress
        int completed = match.getStatistics() != null ? match.getStatistics().getGeneratorsCompleted() : 0;
        Score genScore = objective.getScore(ChatColor.GREEN + "Generators: " + ChatColor.WHITE + 
            completed + "/5");
        genScore.setScore(scoreValue--);
        
        // Survivor status
        int alive = countAliveSurvivors(match);
        int hooked = match.getStatistics() != null ? 
            (match.getStatistics().getSurvivorsSacrificed() + match.getStatistics().getSurvivorsKilled()) : 0;
        
        Score aliveScore = objective.getScore(ChatColor.GREEN + "Survivors: " + ChatColor.WHITE + 
            alive + " alive");
        aliveScore.setScore(scoreValue--);
        
        // Exit gates
        boolean gatesOpen = completed >= 5;
        String gateStatus = gatesOpen ? ChatColor.GREEN + "OPEN" : ChatColor.RED + "LOCKED";
        Score gateScore = objective.getScore(ChatColor.DARK_PURPLE + "Exit Gates: " + gateStatus);
        gateScore.setScore(scoreValue--);
        
        return scoreValue;
    }
    
    private int addKillerInfo(Objective objective, Match match, int scoreValue) {
        // Sacrifices
        int sacrificed = match.getStatistics() != null ? match.getStatistics().getSurvivorsSacrificed() : 0;
        Score sacScore = objective.getScore(ChatColor.RED + "Sacrifices: " + ChatColor.WHITE + sacrificed);
        sacScore.setScore(scoreValue--);
        
        // Survivors remaining
        int alive = countAliveSurvivors(match);
        Score aliveScore = objective.getScore(ChatColor.RED + "Survivors: " + ChatColor.WHITE + 
            alive + " remaining");
        aliveScore.setScore(scoreValue--);
        
        // Generators
        int completed = match.getStatistics() != null ? match.getStatistics().getGeneratorsCompleted() : 0;
        Score genScore = objective.getScore(ChatColor.RED + "Generators: " + ChatColor.WHITE + 
            completed + "/5 done");
        genScore.setScore(scoreValue--);
        
        return scoreValue;
    }
    
    private int countAliveSurvivors(Match match) {
        int totalSurvivors = 0;
        for (PlayerRole role : match.getPlayerRoles().values()) {
            if (role == PlayerRole.SURVIVOR) {
                totalSurvivors++;
            }
        }
        
        int eliminated = match.getStatistics() != null ? 
            match.getStatistics().getSurvivorsEscaped() + 
            match.getStatistics().getSurvivorsSacrificed() + 
            match.getStatistics().getSurvivorsKilled() : 0;
        
        return Math.max(0, totalSurvivors - eliminated);
    }
    
    private String formatTime(long seconds) {
        long minutes = seconds / 60;
        long secs = seconds % 60;
        return String.format("%02d:%02d", minutes, secs);
    }
    
    private String getEventMessage(String eventType, Object data) {
        switch (eventType) {
            case "generator_complete":
                return ChatColor.GREEN + "Generator Completed!";
            case "survivor_hooked":
                return ChatColor.RED + "Survivor Hooked!";
            case "survivor_unhooked":
                return ChatColor.GREEN + "Survivor Unhooked!";
            case "survivor_escaped":
                return ChatColor.GREEN + "Survivor Escaped!";
            case "survivor_sacrificed":
                return ChatColor.RED + "Survivor Sacrificed!";
            case "exit_gate_opened":
                return ChatColor.DARK_PURPLE + "Exit Gate Opened!";
            case "all_generators_complete":
                return ChatColor.DARK_PURPLE + "Exit Gates Powered!";
            default:
                return ChatColor.YELLOW + "Event Occurred";
        }
    }
}
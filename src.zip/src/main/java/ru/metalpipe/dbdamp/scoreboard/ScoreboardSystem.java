package ru.metalpipe.dbdamp.scoreboard;

import org.bukkit.entity.Player;
import ru.metalpipe.dbdamp.gameplay.model.Match;
import ru.metalpipe.dbdamp.gameplay.model.PlayerRole;

import java.util.UUID;

/**
 * Interface for dynamic scoreboard display with real-time match information.
 */
public interface ScoreboardSystem {
    
    /**
     * Create a scoreboard for a player.
     * 
     * @param playerId The player's UUID
     * @param role The player's role (survivor or killer)
     */
    void createScoreboard(UUID playerId, PlayerRole role);
    
    /**
     * Update the scoreboard for a player.
     * 
     * @param playerId The player's UUID
     * @param match The current match
     */
    void updateScoreboard(UUID playerId, Match match);
    
    /**
     * Remove the scoreboard for a player.
     * 
     * @param playerId The player's UUID
     */
    void removeScoreboard(UUID playerId);
    
    /**
     * Update generator progress display.
     * 
     * @param match The current match
     */
    void updateGeneratorProgress(Match match);
    
    /**
     * Update survivor status display.
     * 
     * @param match The current match
     */
    void updateSurvivorStatus(Match match);
    
    /**
     * Update match timer display.
     * 
     * @param match The current match
     */
    void updateTimer(Match match);
    
    /**
     * Show an animation for an important event.
     * 
     * @param matchId The match UUID
     * @param eventType The event type
     * @param data Additional event data
     */
    void showEventAnimation(UUID matchId, String eventType, Object data);
    
    /**
     * Display post-game statistics.
     * 
     * @param playerId The player's UUID
     * @param results The match results
     */
    void showPostGameStats(UUID playerId, Object results);
    
    /**
     * Clear all scoreboards for a match.
     * 
     * @param matchId The match UUID
     */
    void clearMatchScoreboards(UUID matchId);
    
    /**
     * Update all active scoreboards.
     */
    void updateAll();
}
package ru.metalpipe.dbdamp.match;

import ru.metalpipe.dbdamp.database.model.PlayerStatistics;
import ru.metalpipe.dbdamp.gameplay.model.GameMode;
import ru.metalpipe.dbdamp.gameplay.model.Match;
import ru.metalpipe.dbdamp.gameplay.model.PlayerRole;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Interface for managing match lifecycle and results calculation.
 */
public interface MatchSystem {
    
    /**
     * Start a new match.
     * 
     * @param lobbyId The lobby ID to start from
     * @return The created match
     */
    Match startMatch(UUID lobbyId);
    
    /**
     * Get an active match by ID.
     * 
     * @param matchId The match's UUID
     * @return The match, or null if not found
     */
    Match getMatch(UUID matchId);
    
    /**
     * Get the match a player is currently in.
     * 
     * @param playerId The player's UUID
     * @return The match, or null if not in a match
     */
    Match getPlayerMatch(UUID playerId);
    
    /**
     * Get all active matches.
     * 
     * @return List of active matches
     */
    List<Match> getActiveMatches();
    
    /**
     * End a match.
     * 
     * @param matchId The match's UUID
     * @return The match results
     */
    MatchResult endMatch(UUID matchId);
    
    /**
     * Calculate match results.
     * 
     * @param match The match to calculate results for
     * @return The match results
     */
    MatchResult calculateResults(Match match);
    
    /**
     * Distribute rewards based on match results.
     * 
     * @param matchId The match's UUID
     * @param results The match results
     */
    void distributeRewards(UUID matchId, MatchResult results);
    
    /**
     * Update player statistics based on match results.
     * 
     * @param matchId The match's UUID
     * @param results The match results
     */
    void updateStatistics(UUID matchId, MatchResult results);
    
    /**
     * Record a player escape.
     * 
     * @param matchId The match's UUID
     * @param playerId The escaping player's UUID
     */
    void recordEscape(UUID matchId, UUID playerId);
    
    /**
     * Record a player sacrifice.
     * 
     * @param matchId The match's UUID
     * @param playerId The sacrificed player's UUID
     */
    void recordSacrifice(UUID matchId, UUID playerId);
    
    /**
     * Record a player death.
     * 
     * @param matchId The match's UUID
     * @param playerId The killed player's UUID
     */
    void recordDeath(UUID matchId, UUID playerId);
    
    /**
     * Record a generator completion.
     * 
     * @param matchId The match's UUID
     * @param playerId The completing player's UUID
     */
    void recordGeneratorComplete(UUID matchId, UUID playerId);
    
    /**
     * Get match duration in seconds.
     * 
     * @param matchId The match's UUID
     * @return Duration in seconds, or -1 if not found
     */
    long getMatchDuration(UUID matchId);
    
    /**
     * Update all active matches.
     * Called every tick.
     */
    void updateMatches();
}
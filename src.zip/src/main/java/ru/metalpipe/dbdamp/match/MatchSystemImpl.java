package ru.metalpipe.dbdamp.match;

import ru.metalpipe.dbdamp.database.model.PlayerStatistics;
import ru.metalpipe.dbdamp.economy.EconomySystem;
import ru.metalpipe.dbdamp.gameplay.model.*;
import ru.metalpipe.dbdamp.lobby.Lobby;
import ru.metalpipe.dbdamp.lobby.LobbySystem;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Implementation of the match system.
 * Manages match lifecycle, results calculation, and reward distribution.
 */
public class MatchSystemImpl implements MatchSystem {
    
    private final Logger logger;
    private final LobbySystem lobbySystem;
    private final EconomySystem economySystem;
    
    // Active matches
    private final Map<UUID, Match> activeMatches;
    
    // Player to match mapping
    private final Map<UUID, UUID> playerMatches;
    
    // Completed match results
    private final Map<UUID, MatchResult> matchResults;
    
    // Configuration
    private static final int BASE_ESCAPE_BLOODPOINTS = 5000;
    private static final int BASE_SACRIFICE_BLOODPOINTS = 5000;
    private static final int BASE_PARTICIPATION_BLOODPOINTS = 1000;
    private static final int GENERATOR_BONUS = 100;
    private static final int HEAL_BONUS = 50;
    private static final int HOOK_BONUS = 100;
    private static final int CHASE_BONUS = 10;
    
    public MatchSystemImpl(LobbySystem lobbySystem, EconomySystem economySystem) {
        this.logger = Logger.getLogger(getClass().getName());
        this.lobbySystem = lobbySystem;
        this.economySystem = economySystem;
        this.activeMatches = new ConcurrentHashMap<>();
        this.playerMatches = new ConcurrentHashMap<>();
        this.matchResults = new ConcurrentHashMap<>();
    }
    
    @Override
    public Match startMatch(UUID lobbyId) {
        Lobby lobby = lobbySystem.getLobby(lobbyId);
        if (lobby == null || !lobby.canStart()) {
            return null;
        }
        
        // Create match
        Match match = new Match(lobby.getGameMode(), null);
        match.setStatus(MatchStatus.STARTING);
        match.setStartTime(Instant.now());
        
        // Add players with their roles
        for (Map.Entry<UUID, Lobby.LobbyPlayer> entry : lobby.getPlayers().entrySet()) {
            UUID playerId = entry.getKey();
            PlayerRole role = lobby.getRolePreference(playerId);
            if (role == null) {
                role = PlayerRole.SURVIVOR;
            }
            match.addPlayer(playerId, role);
            
            // Track player's match
            playerMatches.put(playerId, match.getMatchId());
        }
        
        // Register match
        activeMatches.put(match.getMatchId(), match);
        
        // Initialize map state
        initializeMapState(match);
        
        // Start match
        match.setStatus(MatchStatus.IN_PROGRESS);
        
        logger.info("Started match " + match.getMatchId() + " with " + match.getPlayerRoles().size() + " players");
        return match;
    }
    
    @Override
    public Match getMatch(UUID matchId) {
        return activeMatches.get(matchId);
    }
    
    @Override
    public Match getPlayerMatch(UUID playerId) {
        UUID matchId = playerMatches.get(playerId);
        return matchId != null ? activeMatches.get(matchId) : null;
    }
    
    @Override
    public List<Match> getActiveMatches() {
        return new ArrayList<>(activeMatches.values());
    }
    
    @Override
    public MatchResult endMatch(UUID matchId) {
        Match match = activeMatches.get(matchId);
        if (match == null) {
            return null;
        }
        
        // Calculate results
        MatchResult results = calculateResults(match);
        
        // Set end time
        match.setEndTime(Instant.now());
        match.setStatus(MatchStatus.ENDING);
        
        // Distribute rewards
        distributeRewards(matchId, results);
        
        // Update statistics
        updateStatistics(matchId, results);
        
        // Store results
        matchResults.put(matchId, results);
        
        // Remove from active matches
        activeMatches.remove(matchId);
        
        // Remove player mappings
        for (UUID playerId : match.getPlayerRoles().keySet()) {
            playerMatches.remove(playerId);
        }
        
        // Final status
        match.setStatus(MatchStatus.COMPLETED);
        
        logger.info("Ended match " + matchId + " with outcome: " + results.getOutcome());
        return results;
    }
    
    @Override
    public MatchResult calculateResults(Match match) {
        MatchResult results = new MatchResult(match.getMatchId());
        
        MatchStatistics stats = match.getStatistics();
        if (stats != null) {
            results.setGeneratorsCompleted(stats.getGeneratorsCompleted());
            results.setSurvivorsEscaped(stats.getSurvivorsEscaped());
            results.setSurvivorsSacrificed(stats.getSurvivorsSacrificed());
            results.setSurvivorsKilled(stats.getSurvivorsKilled());
            results.setTotalHooks(stats.getTotalHooks());
        }
        
        // Calculate duration
        if (match.getStartTime() != null) {
            long duration = Duration.between(match.getStartTime(), Instant.now()).getSeconds();
            results.setDurationSeconds(duration);
        }
        
        // Determine outcome
        int escaped = results.getSurvivorsEscaped();
        int sacrificed = results.getSurvivorsSacrificed();
        int killed = results.getSurvivorsKilled();
        int totalSurvivors = escaped + sacrificed + killed;
        
        if (escaped >= totalSurvivors * 0.75) {
            results.setOutcome(MatchResult.MatchOutcome.SURVIVOR_VICTORY);
            results.setWinningTeam("Survivors");
        } else if (escaped >= 1) {
            results.setOutcome(MatchResult.MatchOutcome.PARTIAL_SURVIVOR_VICTORY);
            results.setWinningTeam("Survivors");
        } else if (sacrificed + killed >= totalSurvivors) {
            results.setOutcome(MatchResult.MatchOutcome.KILLER_DOMINATION);
            results.setWinningTeam("Killer");
        } else {
            results.setOutcome(MatchResult.MatchOutcome.KILLER_VICTORY);
            results.setWinningTeam("Killer");
        }
        
        // Calculate individual player results
        for (Map.Entry<UUID, PlayerRole> entry : match.getPlayerRoles().entrySet()) {
            UUID playerId = entry.getKey();
            PlayerRole role = entry.getValue();
            
            MatchResult.PlayerResult playerResult = new MatchResult.PlayerResult(playerId, role);
            
            if (role == PlayerRole.SURVIVOR) {
                calculateSurvivorResult(playerResult, match, playerId);
            } else {
                calculateKillerResult(playerResult, match, playerId);
            }
            
            results.addPlayerResult(playerId, playerResult);
        }
        
        return results;
    }
    
    @Override
    public void distributeRewards(UUID matchId, MatchResult results) {
        for (MatchResult.PlayerResult playerResult : results.getPlayerResults().values()) {
            int bloodpoints = calculateBloodpoints(playerResult, results);
            playerResult.setBloodpointsEarned(bloodpoints);
            
            // Award through economy system
            if (economySystem != null) {
                economySystem.addBloodpoints(playerResult.getPlayerId(), bloodpoints);
            }
        }
        
        logger.info("Distributed rewards for match " + matchId);
    }
    
    @Override
    public void updateStatistics(UUID matchId, MatchResult results) {
        for (MatchResult.PlayerResult playerResult : results.getPlayerResults().values()) {
            UUID playerId = playerResult.getPlayerId();
            
            // Update player statistics
            // This would integrate with the statistics system
            // For now, we'll just log the update
            logger.fine("Updated statistics for player " + playerId + 
                       " - BP: " + playerResult.getBloodpointsEarned());
        }
    }
    
    @Override
    public void recordEscape(UUID matchId, UUID playerId) {
        Match match = activeMatches.get(matchId);
        if (match == null) return;
        
        MatchStatistics stats = match.getStatistics();
        if (stats != null) {
            stats.setSurvivorsEscaped(stats.getSurvivorsEscaped() + 1);
        }
        
        logger.info("Player " + playerId + " escaped in match " + matchId);
        
        // Check if match should end
        checkMatchEnd(matchId);
    }
    
    @Override
    public void recordSacrifice(UUID matchId, UUID playerId) {
        Match match = activeMatches.get(matchId);
        if (match == null) return;
        
        MatchStatistics stats = match.getStatistics();
        if (stats != null) {
            stats.setSurvivorsSacrificed(stats.getSurvivorsSacrificed() + 1);
        }
        
        logger.info("Player " + playerId + " was sacrificed in match " + matchId);
        
        // Check if match should end
        checkMatchEnd(matchId);
    }
    
    @Override
    public void recordDeath(UUID matchId, UUID playerId) {
        Match match = activeMatches.get(matchId);
        if (match == null) return;
        
        MatchStatistics stats = match.getStatistics();
        if (stats != null) {
            stats.setSurvivorsKilled(stats.getSurvivorsKilled() + 1);
        }
        
        logger.info("Player " + playerId + " was killed in match " + matchId);
        
        // Check if match should end
        checkMatchEnd(matchId);
    }
    
    @Override
    public void recordGeneratorComplete(UUID matchId, UUID playerId) {
        Match match = activeMatches.get(matchId);
        if (match == null) return;
        
        MatchStatistics stats = match.getStatistics();
        if (stats != null) {
            stats.addGeneratorCompleted();
        }
        
        logger.fine("Generator completed by " + playerId + " in match " + matchId);
    }
    
    @Override
    public long getMatchDuration(UUID matchId) {
        Match match = activeMatches.get(matchId);
        if (match == null || match.getStartTime() == null) {
            return -1;
        }
        
        return Duration.between(match.getStartTime(), Instant.now()).getSeconds();
    }
    
    @Override
    public void updateMatches() {
        for (UUID matchId : activeMatches.keySet()) {
            Match match = activeMatches.get(matchId);
            
            // Check for match end conditions
            if (match.getStatus() == MatchStatus.IN_PROGRESS) {
                checkMatchEnd(matchId);
            }
        }
    }
    
    // Helper methods
    private void initializeMapState(Match match) {
        MapState mapState = new MapState();
        mapState.setMapId(UUID.randomUUID().toString());
        mapState.setMapName("Procedural Map");
        mapState.setTheme("forest");
        
        match.setMapState(mapState);
        
        // Initialize generators (5 for standard match)
        for (int i = 0; i < 5; i++) {
            Generator gen = new Generator();
            gen.setGeneratorId(UUID.randomUUID());
            match.getGenerators().add(gen);
        }
        
        // Initialize hooks (8 for standard match)
        for (int i = 0; i < 8; i++) {
            Hook hook = new Hook();
            hook.setHookId(UUID.randomUUID());
            match.getHooks().add(hook);
        }
        
        // Initialize exit gates (2 for standard match)
        for (int i = 0; i < 2; i++) {
            ExitGate gate = new ExitGate();
            gate.setGateId(UUID.randomUUID());
            match.getExitGates().add(gate);
        }
    }
    
    private void checkMatchEnd(UUID matchId) {
        Match match = activeMatches.get(matchId);
        if (match == null) return;
        
        MatchStatistics stats = match.getStatistics();
        if (stats == null) return;
        
        // Count total survivors
        int totalSurvivors = 0;
        for (PlayerRole role : match.getPlayerRoles().values()) {
            if (role == PlayerRole.SURVIVOR) {
                totalSurvivors++;
            }
        }
        
        // Check if all survivors have escaped or been eliminated
        int eliminated = stats.getSurvivorsSacrificed() + stats.getSurvivorsKilled();
        int finished = stats.getSurvivorsEscaped() + eliminated;
        
        if (finished >= totalSurvivors) {
            // End match
            endMatch(matchId);
        }
    }
    
    private void calculateSurvivorResult(MatchResult.PlayerResult result, Match match, UUID playerId) {
        MatchStatistics stats = match.getStatistics();
        
        // Determine escape status
        if (stats != null) {
            // Check if this player escaped
            // This would be tracked individually
        }
        
        // Calculate scores
        int objectiveScore = 0;
        int survivalScore = 0;
        int altruismScore = 0;
        
        // Objective: Generators repaired
        objectiveScore += result.getGeneratorsCompleted() * GENERATOR_BONUS;
        
        // Survival: Escaped, chases survived
        if (result.isEscaped()) {
            survivalScore += 2000;
        }
        survivalScore += result.getChasesSurvived() * CHASE_BONUS;
        
        // Altruism: Heals, unhooks
        altruismScore += result.getSurvivorsHealed() * HEAL_BONUS;
        
        result.setObjectiveScore(objectiveScore);
        result.setSurvivalScore(survivalScore);
        result.setAltruismScore(altruismScore);
        
        // Calculate bloodpoints
        int totalScore = objectiveScore + survivalScore + altruismScore;
        result.setBloodpointsEarned(totalScore);
    }
    
    private void calculateKillerResult(MatchResult.PlayerResult result, Match match, UUID playerId) {
        // Calculate scores
        int brutalityScore = 0;
        int deviousnessScore = 0;
        
        // Brutality: Hits, hooks, sacrifices
        brutalityScore += result.getHitsLanded() * 50;
        brutalityScore += result.getHooksPerformed() * HOOK_BONUS;
        
        // Deviousness: Chases, special abilities
        deviousnessScore += result.getTimeChased() * CHASE_BONUS;
        
        result.setBrutalityScore(brutalityScore);
        result.setDeviousnessScore(deviousnessScore);
        
        // Calculate bloodpoints
        int totalScore = brutalityScore + deviousnessScore;
        result.setBloodpointsEarned(totalScore);
    }
    
    private int calculateBloodpoints(MatchResult.PlayerResult playerResult, MatchResult matchResult) {
        int base = BASE_PARTICIPATION_BLOODPOINTS;
        
        if (playerResult.getRole() == PlayerRole.SURVIVOR) {
            if (playerResult.isEscaped()) {
                base += BASE_ESCAPE_BLOODPOINTS;
            }
            base += playerResult.getTotalSurvivorScore();
        } else {
            // Killer bonus based on kills
            int kills = matchResult.getSurvivorsSacrificed() + matchResult.getSurvivorsKilled();
            base += kills * 1000;
            base += playerResult.getTotalKillerScore();
        }
        
        // Cap at maximum
        return Math.min(base, 8000);
    }
}
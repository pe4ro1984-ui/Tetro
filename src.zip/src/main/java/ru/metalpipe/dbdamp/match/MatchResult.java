package ru.metalpipe.dbdamp.match;

import ru.metalpipe.dbdamp.gameplay.model.PlayerRole;

import java.time.Instant;
import java.util.*;

/**
 * Represents the results of a completed match.
 */
public class MatchResult {
    
    private UUID matchId;
    private Instant endTime;
    private long durationSeconds;
    
    // Match outcome
    private MatchOutcome outcome;
    private String winningTeam; // "Survivors" or "Killer"
    
    // Player results
    private Map<UUID, PlayerResult> playerResults;
    
    // Statistics
    private int generatorsCompleted;
    private int survivorsEscaped;
    private int survivorsSacrificed;
    private int survivorsKilled;
    private int totalHooks;
    private int totalChases;
    
    // Rewards
    private int baseBloodpoints;
    
    public MatchResult() {
        this.playerResults = new HashMap<>();
        this.endTime = Instant.now();
    }
    
    public MatchResult(UUID matchId) {
        this();
        this.matchId = matchId;
    }
    
    // Getters and setters
    public UUID getMatchId() { return matchId; }
    public void setMatchId(UUID matchId) { this.matchId = matchId; }
    
    public Instant getEndTime() { return endTime; }
    public void setEndTime(Instant endTime) { this.endTime = endTime; }
    
    public long getDurationSeconds() { return durationSeconds; }
    public void setDurationSeconds(long durationSeconds) { this.durationSeconds = durationSeconds; }
    
    public MatchOutcome getOutcome() { return outcome; }
    public void setOutcome(MatchOutcome outcome) { this.outcome = outcome; }
    
    public String getWinningTeam() { return winningTeam; }
    public void setWinningTeam(String winningTeam) { this.winningTeam = winningTeam; }
    
    public Map<UUID, PlayerResult> getPlayerResults() { return playerResults; }
    public void setPlayerResults(Map<UUID, PlayerResult> playerResults) { this.playerResults = playerResults; }
    
    public int getGeneratorsCompleted() { return generatorsCompleted; }
    public void setGeneratorsCompleted(int generatorsCompleted) { this.generatorsCompleted = generatorsCompleted; }
    
    public int getSurvivorsEscaped() { return survivorsEscaped; }
    public void setSurvivorsEscaped(int survivorsEscaped) { this.survivorsEscaped = survivorsEscaped; }
    
    public int getSurvivorsSacrificed() { return survivorsSacrificed; }
    public void setSurvivorsSacrificed(int survivorsSacrificed) { this.survivorsSacrificed = survivorsSacrificed; }
    
    public int getSurvivorsKilled() { return survivorsKilled; }
    public void setSurvivorsKilled(int survivorsKilled) { this.survivorsKilled = survivorsKilled; }
    
    public int getTotalHooks() { return totalHooks; }
    public void setTotalHooks(int totalHooks) { this.totalHooks = totalHooks; }
    
    public int getTotalChases() { return totalChases; }
    public void setTotalChases(int totalChases) { this.totalChases = totalChases; }
    
    public int getBaseBloodpoints() { return baseBloodpoints; }
    public void setBaseBloodpoints(int baseBloodpoints) { this.baseBloodpoints = baseBloodpoints; }
    
    // Player result management
    public void addPlayerResult(UUID playerId, PlayerResult result) {
        playerResults.put(playerId, result);
    }
    
    public PlayerResult getPlayerResult(UUID playerId) {
        return playerResults.get(playerId);
    }
    
    // Outcome determination
    public boolean isSurvivorVictory() {
        return outcome == MatchOutcome.SURVIVOR_VICTORY || 
               outcome == MatchOutcome.PARTIAL_SURVIVOR_VICTORY;
    }
    
    public boolean isKillerVictory() {
        return outcome == MatchOutcome.KILLER_VICTORY || 
               outcome == MatchOutcome.KILLER_DOMINATION;
    }
    
    // Summary
    public String getSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("Match ").append(matchId).append("\n");
        sb.append("Duration: ").append(durationSeconds).append("s\n");
        sb.append("Outcome: ").append(outcome.getDisplayName()).append("\n");
        sb.append("Generators: ").append(generatorsCompleted).append("/5\n");
        sb.append("Escaped: ").append(survivorsEscaped).append("\n");
        sb.append("Sacrificed: ").append(survivorsSacrificed).append("\n");
        sb.append("Killed: ").append(survivorsKilled).append("\n");
        return sb.toString();
    }
    
    @Override
    public String toString() {
        return "MatchResult{" +
               "matchId=" + matchId +
               ", outcome=" + outcome +
               ", duration=" + durationSeconds + "s" +
               ", escaped=" + survivorsEscaped +
               ", sacrificed=" + survivorsSacrificed +
               '}';
    }
    
    /**
     * Represents an individual player's result in a match.
     */
    public static class PlayerResult {
        private UUID playerId;
        private PlayerRole role;
        private boolean escaped;
        private boolean sacrificed;
        private boolean killed;
        
        // Statistics
        private int generatorsCompleted;
        private int skillChecksHit;
        private int skillChecksMissed;
        private int survivorsHealed;
        private int chasesSurvived;
        private int timeChased;
        private int hooksPerformed;
        private int hitsLanded;
        
        // Score and rewards
        private int bloodpointsEarned;
        private int experienceEarned;
        
        // Category scores
        private int objectiveScore;
        private int survivalScore;
        private int altruismScore;
        private int brutalityScore;
        private int deviousnessScore;
        
        public PlayerResult(UUID playerId, PlayerRole role) {
            this.playerId = playerId;
            this.role = role;
        }
        
        // Getters and setters
        public UUID getPlayerId() { return playerId; }
        public void setPlayerId(UUID playerId) { this.playerId = playerId; }
        
        public PlayerRole getRole() { return role; }
        public void setRole(PlayerRole role) { this.role = role; }
        
        public boolean isEscaped() { return escaped; }
        public void setEscaped(boolean escaped) { this.escaped = escaped; }
        
        public boolean isSacrificed() { return sacrificed; }
        public void setSacrificed(boolean sacrificed) { this.sacrificed = sacrificed; }
        
        public boolean isKilled() { return killed; }
        public void setKilled(boolean killed) { this.killed = killed; }
        
        public int getGeneratorsCompleted() { return generatorsCompleted; }
        public void setGeneratorsCompleted(int generatorsCompleted) { this.generatorsCompleted = generatorsCompleted; }
        
        public int getSkillChecksHit() { return skillChecksHit; }
        public void setSkillChecksHit(int skillChecksHit) { this.skillChecksHit = skillChecksHit; }
        
        public int getSkillChecksMissed() { return skillChecksMissed; }
        public void setSkillChecksMissed(int skillChecksMissed) { this.skillChecksMissed = skillChecksMissed; }
        
        public int getSurvivorsHealed() { return survivorsHealed; }
        public void setSurvivorsHealed(int survivorsHealed) { this.survivorsHealed = survivorsHealed; }
        
        public int getChasesSurvived() { return chasesSurvived; }
        public void setChasesSurvived(int chasesSurvived) { this.chasesSurvived = chasesSurvived; }
        
        public int getTimeChased() { return timeChased; }
        public void setTimeChased(int timeChased) { this.timeChased = timeChased; }
        
        public int getHooksPerformed() { return hooksPerformed; }
        public void setHooksPerformed(int hooksPerformed) { this.hooksPerformed = hooksPerformed; }
        
        public int getHitsLanded() { return hitsLanded; }
        public void setHitsLanded(int hitsLanded) { this.hitsLanded = hitsLanded; }
        
        public int getBloodpointsEarned() { return bloodpointsEarned; }
        public void setBloodpointsEarned(int bloodpointsEarned) { this.bloodpointsEarned = bloodpointsEarned; }
        
        public int getExperienceEarned() { return experienceEarned; }
        public void setExperienceEarned(int experienceEarned) { this.experienceEarned = experienceEarned; }
        
        public int getObjectiveScore() { return objectiveScore; }
        public void setObjectiveScore(int objectiveScore) { this.objectiveScore = objectiveScore; }
        
        public int getSurvivalScore() { return survivalScore; }
        public void setSurvivalScore(int survivalScore) { this.survivalScore = survivalScore; }
        
        public int getAltruismScore() { return altruismScore; }
        public void setAltruismScore(int altruismScore) { this.altruismScore = altruismScore; }
        
        public int getBrutalityScore() { return brutalityScore; }
        public void setBrutalityScore(int brutalityScore) { this.brutalityScore = brutalityScore; }
        
        public int getDeviousnessScore() { return deviousnessScore; }
        public void setDeviousnessScore(int deviousnessScore) { this.deviousnessScore = deviousnessScore; }
        
        /**
         * Calculate total score for survivors.
         */
        public int getTotalSurvivorScore() {
            return objectiveScore + survivalScore + altruismScore;
        }
        
        /**
         * Calculate total score for killers.
         */
        public int getTotalKillerScore() {
            return brutalityScore + deviousnessScore;
        }
    }
    
    /**
     * Match outcome enum.
     */
    public enum MatchOutcome {
        SURVIVOR_VICTORY("Survivor Victory", "All survivors escaped!"),
        PARTIAL_SURVIVOR_VICTORY("Partial Survivor Victory", "Some survivors escaped"),
        KILLER_VICTORY("Killer Victory", "Killer eliminated all survivors"),
        KILLER_DOMINATION("Killer Domination", "Killer sacrificed all survivors"),
        DRAW("Draw", "Match ended in a draw");
        
        private final String displayName;
        private final String description;
        
        MatchOutcome(String displayName, String description) {
            this.displayName = displayName;
            this.description = description;
        }
        
        public String getDisplayName() { return displayName; }
        public String getDescription() { return description; }
    }
}
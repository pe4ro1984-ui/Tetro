package ru.metalpipe.dbdamp.economy;

import java.util.UUID;

/**
 * Interface for managing virtual currency (bloodpoints) and transactions.
 */
public interface EconomySystem {
    
    /**
     * Get a player's bloodpoint balance.
     * 
     * @param playerId The player's UUID
     * @return Current balance
     */
    int getBloodpoints(UUID playerId);
    
    /**
     * Add bloodpoints to a player's balance.
     * 
     * @param playerId The player's UUID
     * @param amount Amount to add
     * @return New balance
     */
    int addBloodpoints(UUID playerId, int amount);
    
    /**
     * Remove bloodpoints from a player's balance.
     * 
     * @param playerId The player's UUID
     * @param amount Amount to remove
     * @return true if successful, false if insufficient balance
     */
    boolean removeBloodpoints(UUID playerId, int amount);
    
    /**
     * Set a player's bloodpoint balance.
     * 
     * @param playerId The player's UUID
     * @param amount New balance
     */
    void setBloodpoints(UUID playerId, int amount);
    
    /**
     * Check if a player can afford a purchase.
     * 
     * @param playerId The player's UUID
     * @param amount Required amount
     * @return true if player can afford
     */
    boolean canAfford(UUID playerId, int amount);
    
    /**
     * Transfer bloodpoints between players.
     * 
     * @param fromId Source player's UUID
     * @param toId Target player's UUID
     * @param amount Amount to transfer
     * @return true if successful
     */
    boolean transfer(UUID fromId, UUID toId, int amount);
    
    /**
     * Purchase an item from the shop.
     * 
     * @param playerId The player's UUID
     * @param itemId The item's ID
     * @return true if purchase successful
     */
    boolean purchase(UUID playerId, String itemId);
    
    /**
     * Get the price of an item.
     * 
     * @param itemId The item's ID
     * @return Price in bloodpoints
     */
    int getItemPrice(String itemId);
    
    /**
     * Record a transaction for logging.
     * 
     * @param playerId The player's UUID
     * @param type Transaction type
     * @param amount Amount involved
     * @param description Transaction description
     */
    void recordTransaction(UUID playerId, String type, int amount, String description);
}
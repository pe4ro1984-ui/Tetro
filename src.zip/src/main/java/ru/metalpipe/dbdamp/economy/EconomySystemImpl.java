package ru.metalpipe.dbdamp.economy;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Implementation of the EconomySystem interface.
 * Manages bloodpoints (virtual currency) for players.
 */
public class EconomySystemImpl implements EconomySystem {
    
    // In-memory storage for bloodpoints (would normally use database)
    private final Map<UUID, Integer> bloodpointBalances;
    
    // Item prices (would normally come from configuration)
    private final Map<String, Integer> itemPrices;
    
    // Transaction history (would normally use database)
    private final Map<UUID, Map<Long, Transaction>> transactionHistory;
    
    public EconomySystemImpl() {
        this.bloodpointBalances = new ConcurrentHashMap<>();
        this.itemPrices = new ConcurrentHashMap<>();
        this.transactionHistory = new ConcurrentHashMap<>();
        
        // Initialize default item prices
        initializeDefaultPrices();
    }
    
    private void initializeDefaultPrices() {
        // Perks
        itemPrices.put("perk_self_care", 5000);
        itemPrices.put("perk_sprint_burst", 5000);
        itemPrices.put("perk_decisive_strike", 6000);
        itemPrices.put("perk_brutal_strength", 5000);
        itemPrices.put("perk_enduring", 5000);
        itemPrices.put("perk_noed", 6000);
        
        // Cosmetics
        itemPrices.put("cosmetic_survivor_outfit_1", 2500);
        itemPrices.put("cosmetic_killer_outfit_1", 2500);
        
        // Items
        itemPrices.put("item_medkit", 1000);
        itemPrices.put("item_toolbox", 1000);
        itemPrices.put("item_flashlight", 1500);
        itemPrices.put("item_map", 2000);
    }
    
    @Override
    public int getBloodpoints(UUID playerId) {
        return bloodpointBalances.getOrDefault(playerId, 0);
    }
    
    @Override
    public int addBloodpoints(UUID playerId, int amount) {
        if (amount < 0) {
            return getBloodpoints(playerId);
        }
        
        int newBalance = getBloodpoints(playerId) + amount;
        // Cap at maximum bloodpoints (like in the real game)
        newBalance = Math.min(newBalance, 1000000);
        
        bloodpointBalances.put(playerId, newBalance);
        recordTransaction(playerId, "EARN", amount, "Bloodpoints earned");
        
        return newBalance;
    }
    
    @Override
    public boolean removeBloodpoints(UUID playerId, int amount) {
        int currentBalance = getBloodpoints(playerId);
        
        if (currentBalance < amount) {
            return false;
        }
        
        int newBalance = currentBalance - amount;
        bloodpointBalances.put(playerId, newBalance);
        recordTransaction(playerId, "SPEND", amount, "Bloodpoints spent");
        
        return true;
    }
    
    @Override
    public void setBloodpoints(UUID playerId, int amount) {
        int validAmount = Math.max(0, Math.min(amount, 1000000));
        bloodpointBalances.put(playerId, validAmount);
        recordTransaction(playerId, "SET", validAmount, "Balance set");
    }
    
    @Override
    public boolean canAfford(UUID playerId, int amount) {
        return getBloodpoints(playerId) >= amount;
    }
    
    @Override
    public boolean transfer(UUID fromId, UUID toId, int amount) {
        if (!canAfford(fromId, amount)) {
            return false;
        }
        
        removeBloodpoints(fromId, amount);
        addBloodpoints(toId, amount);
        recordTransaction(fromId, "TRANSFER_OUT", amount, "Transfer to " + toId);
        recordTransaction(toId, "TRANSFER_IN", amount, "Transfer from " + fromId);
        
        return true;
    }
    
    @Override
    public boolean purchase(UUID playerId, String itemId) {
        Integer price = itemPrices.get(itemId);
        if (price == null) {
            return false;
        }
        
        if (!canAfford(playerId, price)) {
            return false;
        }
        
        removeBloodpoints(playerId, price);
        recordTransaction(playerId, "PURCHASE", price, "Purchased: " + itemId);
        
        return true;
    }
    
    @Override
    public int getItemPrice(String itemId) {
        return itemPrices.getOrDefault(itemId, -1);
    }
    
    @Override
    public void recordTransaction(UUID playerId, String type, int amount, String description) {
        Map<Long, Transaction> playerHistory = transactionHistory.computeIfAbsent(
            playerId, k -> new ConcurrentHashMap<>());
        
        long timestamp = System.currentTimeMillis();
        Transaction transaction = new Transaction(timestamp, type, amount, description);
        playerHistory.put(timestamp, transaction);
    }
    
    /**
     * Set a custom item price.
     * 
     * @param itemId The item ID
     * @param price The price in bloodpoints
     */
    public void setItemPrice(String itemId, int price) {
        itemPrices.put(itemId, price);
    }
    
    /**
     * Get transaction history for a player.
     * 
     * @param playerId The player's UUID
     * @return Map of timestamps to transactions
     */
    public Map<Long, Transaction> getTransactionHistory(UUID playerId) {
        return transactionHistory.getOrDefault(playerId, new ConcurrentHashMap<>());
    }
    
    /**
     * Clear a player's transaction history.
     * 
     * @param playerId The player's UUID
     */
    public void clearTransactionHistory(UUID playerId) {
        transactionHistory.remove(playerId);
    }
    
    /**
     * Transaction record for logging.
     */
    public static class Transaction {
        private final long timestamp;
        private final String type;
        private final int amount;
        private final String description;
        
        public Transaction(long timestamp, String type, int amount, String description) {
            this.timestamp = timestamp;
            this.type = type;
            this.amount = amount;
            this.description = description;
        }
        
        public long getTimestamp() { return timestamp; }
        public String getType() { return type; }
        public int getAmount() { return amount; }
        public String getDescription() { return description; }
        
        @Override
        public String toString() {
            return String.format("[%d] %s: %d BP - %s", timestamp, type, amount, description);
        }
    }
}

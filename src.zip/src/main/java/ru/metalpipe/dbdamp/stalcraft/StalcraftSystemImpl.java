package ru.metalpipe.dbdamp.stalcraft;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Implementation of Stalcraft X event features.
 * Manages weapon cases, event currency, and special rewards.
 */
public class StalcraftSystemImpl implements StalcraftSystem {
    
    private final Logger logger;
    
    // Active weapon cases
    private final Map<UUID, WeaponCase> activeCases;
    
    // Player event data
    private final Map<UUID, PlayerEventData> playerEventData;
    
    // Event state
    private boolean eventActive;
    private long eventStartTime;
    private long eventEndTime;
    
    // Event shop items
    private final List<EventShopItem> shopItems;
    
    // Configuration
    private static final int DEFAULT_EVENT_DURATION_HOURS = 168; // 1 week
    private static final int MAX_ACTIVE_CASES = 10;
    
    public StalcraftSystemImpl() {
        this.logger = Logger.getLogger(getClass().getName());
        this.activeCases = new ConcurrentHashMap<>();
        this.playerEventData = new ConcurrentHashMap<>();
        this.shopItems = new ArrayList<>();
        this.eventActive = false;
        this.eventStartTime = 0;
        this.eventEndTime = 0;
        
        initializeShopItems();
    }
    
    private void initializeShopItems() {
        // Add default shop items
        shopItems.add(new EventShopItem("event_key", "§eEvent Key", 
            createKeyItem(), 100, -1));
        shopItems.add(new EventShopItem("rare_case", "§bRare Case", 
            createCaseItem(CaseRarity.RARE), 250, 50));
        shopItems.add(new EventShopItem("epic_case", "§dEpic Case", 
            createCaseItem(CaseRarity.EPIC), 500, 20));
        shopItems.add(new EventShopItem("legendary_case", "§6Legendary Case", 
            createCaseItem(CaseRarity.LEGENDARY), 1000, 5));
    }
    
    private ItemStack createKeyItem() {
        ItemStack key = new ItemStack(Material.TRIPWIRE_HOOK);
        ItemMeta meta = key.getItemMeta();
        meta.setDisplayName("§eStalcraft Key");
        meta.setLore(Arrays.asList("§7Use this key to open", "§7weapon cases!"));
        key.setItemMeta(meta);
        return key;
    }
    
    private ItemStack createCaseItem(CaseRarity rarity) {
        ItemStack caseItem = new ItemStack(Material.CHEST);
        ItemMeta meta = caseItem.getItemMeta();
        meta.setDisplayName(rarity.getDisplayName() + " Case");
        meta.setLore(Arrays.asList("§7A special weapon case", "§7from Stalcraft X event!"));
        caseItem.setItemMeta(meta);
        return caseItem;
    }
    
    @Override
    public UUID spawnWeaponCase(Location location, CaseRarity rarity) {
        if (activeCases.size() >= MAX_ACTIVE_CASES) {
            logger.warning("Cannot spawn more cases - maximum reached");
            return null;
        }
        
        // Create visual representation (armor stand with chest)
        ArmorStand stand = (ArmorStand) location.getWorld().spawnEntity(location, EntityType.ARMOR_STAND);
        stand.setGravity(false);
        stand.setVisible(false);
        stand.setCustomName(rarity.getDisplayName() + " Case");
        stand.setCustomNameVisible(true);
        stand.setHelmet(new ItemStack(Material.CHEST));
        
        WeaponCase weaponCase = new WeaponCase(UUID.randomUUID(), location, rarity, stand.getUniqueId());
        activeCases.put(weaponCase.caseId, weaponCase);
        
        // Particle effect
        location.getWorld().spawnParticle(Particle.TOTEM, location.clone().add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0.1);
        
        logger.info("Spawned " + rarity.getDisplayName() + " case at " + location);
        return weaponCase.caseId;
    }
    
    @Override
    public boolean removeWeaponCase(UUID caseId) {
        WeaponCase weaponCase = activeCases.remove(caseId);
        if (weaponCase == null) {
            return false;
        }
        
        // Remove the armor stand
        Entity entity = Bukkit.getEntity(weaponCase.entityId);
        if (entity != null) {
            entity.remove();
        }
        
        logger.fine("Removed case " + caseId);
        return true;
    }
    
    @Override
    public Optional<ItemStack> openWeaponCase(UUID playerId, UUID caseId) {
        WeaponCase weaponCase = activeCases.get(caseId);
        if (weaponCase == null) {
            return Optional.empty();
        }
        
        // Check if player has a key
        if (!hasKey(playerId)) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendMessage("§cYou need a key to open this case!");
            }
            return Optional.empty();
        }
        
        // Consume the key
        if (!consumeKey(playerId)) {
            return Optional.empty();
        }
        
        // Generate reward based on rarity
        ItemStack reward = generateReward(weaponCase.rarity);
        
        // Remove the case
        removeWeaponCase(caseId);
        
        // Update player event data
        PlayerEventData data = getOrCreateEventData(playerId);
        data.casesOpened++;
        data.eventCurrency += weaponCase.rarity.getEventCurrencyValue();
        
        // Notify player
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.0f, 1.0f);
            player.sendMessage("§aYou opened a " + weaponCase.rarity.getDisplayName() + " §acase!");
            player.sendMessage("§7+ " + weaponCase.rarity.getEventCurrencyValue() + " Event Currency");
        }
        
        logger.info("Player " + playerId + " opened " + weaponCase.rarity.getDisplayName() + " case");
        return Optional.of(reward);
    }
    
    private ItemStack generateReward(CaseRarity rarity) {
        // Generate a random reward based on rarity
        // This would integrate with the custom item system
        Material[] weapons = {Material.DIAMOND_SWORD, Material.IRON_SWORD, Material.NETHERITE_SWORD};
        Material material = weapons[new Random().nextInt(weapons.length)];
        
        ItemStack reward = new ItemStack(material);
        ItemMeta meta = reward.getItemMeta();
        meta.setDisplayName(rarity.getDisplayName() + " Weapon");
        meta.setLore(Arrays.asList(
            "§7A special weapon from the",
            "§7Stalcraft X event!",
            "",
            rarity.getDisplayName()
        ));
        reward.setItemMeta(meta);
        
        return reward;
    }
    
    @Override
    public Map<UUID, Location> getActiveCases() {
        Map<UUID, Location> result = new HashMap<>();
        for (Map.Entry<UUID, WeaponCase> entry : activeCases.entrySet()) {
            result.put(entry.getKey(), entry.getValue().location);
        }
        return result;
    }
    
    @Override
    public boolean hasKey(UUID playerId) {
        Player player = Bukkit.getPlayer(playerId);
        if (player == null) {
            return false;
        }
        
        // Check inventory for key item
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.hasItemMeta()) {
                String name = item.getItemMeta().getDisplayName();
                if (name != null && name.contains("Stalcraft Key")) {
                    return true;
                }
            }
        }
        return false;
    }
    
    @Override
    public boolean consumeKey(UUID playerId) {
        Player player = Bukkit.getPlayer(playerId);
        if (player == null) {
            return false;
        }
        
        // Find and remove one key
        for (int i = 0; i < player.getInventory().getSize(); i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (item != null && item.hasItemMeta()) {
                String name = item.getItemMeta().getDisplayName();
                if (name != null && name.contains("Stalcraft Key")) {
                    item.setAmount(item.getAmount() - 1);
                    return true;
                }
            }
        }
        return false;
    }
    
    @Override
    public void giveEventCurrency(UUID playerId, int amount) {
        PlayerEventData data = getOrCreateEventData(playerId);
        data.eventCurrency += amount;
        
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.sendMessage("§a+ " + amount + " Event Currency");
        }
    }
    
    @Override
    public int getEventCurrency(UUID playerId) {
        PlayerEventData data = playerEventData.get(playerId);
        return data != null ? data.eventCurrency : 0;
    }
    
    @Override
    public boolean spendEventCurrency(UUID playerId, int amount) {
        PlayerEventData data = playerEventData.get(playerId);
        if (data == null || data.eventCurrency < amount) {
            return false;
        }
        
        data.eventCurrency -= amount;
        return true;
    }
    
    @Override
    public boolean purchaseEventItem(UUID playerId, String itemId) {
        EventShopItem item = shopItems.stream()
            .filter(i -> i.getItemId().equals(itemId))
            .findFirst()
            .orElse(null);
        
        if (item == null) {
            return false;
        }
        
        if (!spendEventCurrency(playerId, item.getCost())) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                player.sendMessage("§cNot enough Event Currency!");
            }
            return false;
        }
        
        // Give item to player
        Player player = Bukkit.getPlayer(playerId);
        if (player != null) {
            player.getInventory().addItem(item.getItem());
            player.sendMessage("§aPurchased " + item.getDisplayName() + "!");
        }
        
        logger.fine("Player " + playerId + " purchased " + itemId);
        return true;
    }
    
    @Override
    public List<EventShopItem> getEventShopItems() {
        return new ArrayList<>(shopItems);
    }
    
    @Override
    public boolean isEventActive() {
        if (!eventActive) {
            return false;
        }
        
        // Check if event has expired
        if (eventEndTime > 0 && System.currentTimeMillis() > eventEndTime) {
            eventActive = false;
            return false;
        }
        
        return true;
    }
    
    @Override
    public void startEvent() {
        eventActive = true;
        eventStartTime = System.currentTimeMillis();
        eventEndTime = eventStartTime + (DEFAULT_EVENT_DURATION_HOURS * 60 * 60 * 1000L);
        
        logger.info("Stalcraft X event started!");
        
        // Broadcast to all players
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendMessage("§6§l=== STALCRAFT X EVENT ===");
            player.sendMessage("§eThe event has begun! Find weapon cases and earn rewards!");
            player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
        }
    }
    
    @Override
    public void endEvent() {
        eventActive = false;
        
        // Remove all active cases
        for (UUID caseId : new ArrayList<>(activeCases.keySet())) {
            removeWeaponCase(caseId);
        }
        
        logger.info("Stalcraft X event ended!");
        
        // Broadcast to all players
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendMessage("§6§l=== STALCRAFT X EVENT ENDED ===");
            player.sendMessage("§eThank you for participating!");
        }
    }
    
    @Override
    public double getEventProgress(UUID playerId) {
        PlayerEventData data = playerEventData.get(playerId);
        if (data == null) {
            return 0.0;
        }
        
        // Progress based on cases opened
        return Math.min(1.0, data.casesOpened / 50.0);
    }
    
    @Override
    public List<EventLeaderboardEntry> getEventLeaderboard(int limit) {
        List<EventLeaderboardEntry> entries = new ArrayList<>();
        
        // Sort players by event currency
        List<Map.Entry<UUID, PlayerEventData>> sorted = playerEventData.entrySet().stream()
            .sorted((a, b) -> Integer.compare(b.getValue().eventCurrency, a.getValue().eventCurrency))
            .limit(limit)
            .toList();
        
        int rank = 1;
        for (Map.Entry<UUID, PlayerEventData> entry : sorted) {
            Player player = Bukkit.getPlayer(entry.getKey());
            String name = player != null ? player.getName() : "Unknown";
            entries.add(new EventLeaderboardEntry(
                entry.getKey(),
                name,
                entry.getValue().eventCurrency,
                entry.getValue().casesOpened,
                rank++
            ));
        }
        
        return entries;
    }
    
    private PlayerEventData getOrCreateEventData(UUID playerId) {
        return playerEventData.computeIfAbsent(playerId, id -> new PlayerEventData());
    }
    
    /**
     * Internal class to track weapon cases.
     */
    private static class WeaponCase {
        final UUID caseId;
        final Location location;
        final CaseRarity rarity;
        final UUID entityId;
        
        WeaponCase(UUID caseId, Location location, CaseRarity rarity, UUID entityId) {
            this.caseId = caseId;
            this.location = location;
            this.rarity = rarity;
            this.entityId = entityId;
        }
    }
    
    /**
     * Internal class to track player event data.
     */
    private static class PlayerEventData {
        int eventCurrency = 0;
        int casesOpened = 0;
    }
}

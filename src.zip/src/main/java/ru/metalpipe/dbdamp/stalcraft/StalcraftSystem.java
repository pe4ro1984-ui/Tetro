package ru.metalpipe.dbdamp.stalcraft;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * System for managing Stalcraft X event features.
 * Handles weapon cases, event currency, and special rewards.
 */
public interface StalcraftSystem {
    
    /**
     * Spawn a weapon case at a specific location.
     * 
     * @param location The location to spawn the case
     * @param rarity The rarity tier of the case
     * @return The unique ID of the spawned case
     */
    UUID spawnWeaponCase(Location location, CaseRarity rarity);
    
    /**
     * Remove a weapon case.
     * 
     * @param caseId The case ID to remove
     * @return true if the case was removed
     */
    boolean removeWeaponCase(UUID caseId);
    
    /**
     * Open a weapon case for a player.
     * 
     * @param playerId The player opening the case
     * @param caseId The case to open
     * @return The reward item, or empty if failed
     */
    Optional<ItemStack> openWeaponCase(UUID playerId, UUID caseId);
    
    /**
     * Get all active weapon cases.
     * 
     * @return Map of case IDs to their locations
     */
    Map<UUID, Location> getActiveCases();
    
    /**
     * Check if a player has a key to open cases.
     * 
     * @param playerId The player to check
     * @return true if the player has at least one key
     */
    boolean hasKey(UUID playerId);
    
    /**
     * Consume a key from a player's inventory.
     * 
     * @param playerId The player to consume from
     * @return true if a key was consumed
     */
    boolean consumeKey(UUID playerId);
    
    /**
     * Give a player event currency.
     * 
     * @param playerId The player to give currency to
     * @param amount The amount to give
     */
    void giveEventCurrency(UUID playerId, int amount);
    
    /**
     * Get a player's event currency balance.
     * 
     * @param playerId The player to check
     * @return The player's event currency balance
     */
    int getEventCurrency(UUID playerId);
    
    /**
     * Spend event currency.
     * 
     * @param playerId The player spending currency
     * @param amount The amount to spend
     * @return true if the transaction was successful
     */
    boolean spendEventCurrency(UUID playerId, int amount);
    
    /**
     * Purchase an item from the event shop.
     * 
     * @param playerId The player making the purchase
     * @param itemId The item ID to purchase
     * @return true if the purchase was successful
     */
    boolean purchaseEventItem(UUID playerId, String itemId);
    
    /**
     * Get available event shop items.
     * 
     * @return List of available shop items
     */
    List<EventShopItem> getEventShopItems();
    
    /**
     * Check if the event is currently active.
     * 
     * @return true if the event is active
     */
    boolean isEventActive();
    
    /**
     * Start the event.
     */
    void startEvent();
    
    /**
     * End the event.
     */
    void endEvent();
    
    /**
     * Get the event progress for a player.
     * 
     * @param playerId The player to check
     * @return The player's event progress (0.0 to 1.0)
     */
    double getEventProgress(UUID playerId);
    
    /**
     * Get the leaderboard for the event.
     * 
     * @param limit Maximum number of entries to return
     * @return List of leaderboard entries
     */
    List<EventLeaderboardEntry> getEventLeaderboard(int limit);
    
    /**
     * Rarity tiers for weapon cases.
     */
    enum CaseRarity {
        COMMON("§fCommon", 0.5, 100),
        UNCOMMON("§aUncommon", 0.3, 75),
        RARE("§bRare", 0.15, 50),
        EPIC("§dEpic", 0.04, 25),
        LEGENDARY("§6Legendary", 0.01, 10);
        
        private final String displayName;
        private final double dropChance;
        private final int eventCurrencyValue;
        
        CaseRarity(String displayName, double dropChance, int eventCurrencyValue) {
            this.displayName = displayName;
            this.dropChance = dropChance;
            this.eventCurrencyValue = eventCurrencyValue;
        }
        
        public String getDisplayName() { return displayName; }
        public double getDropChance() { return dropChance; }
        public int getEventCurrencyValue() { return eventCurrencyValue; }
    }
    
    /**
     * Represents an item in the event shop.
     */
    class EventShopItem {
        private final String itemId;
        private final String displayName;
        private final ItemStack item;
        private final int cost;
        private final int stock; // -1 for unlimited
        private final boolean isLimited;
        
        public EventShopItem(String itemId, String displayName, ItemStack item, int cost, int stock) {
            this.itemId = itemId;
            this.displayName = displayName;
            this.item = item;
            this.cost = cost;
            this.stock = stock;
            this.isLimited = stock > 0;
        }
        
        public String getItemId() { return itemId; }
        public String getDisplayName() { return displayName; }
        public ItemStack getItem() { return item.clone(); }
        public int getCost() { return cost; }
        public int getStock() { return stock; }
        public boolean isLimited() { return isLimited; }
    }
    
    /**
     * Represents an entry in the event leaderboard.
     */
    class EventLeaderboardEntry {
        private final UUID playerId;
        private final String playerName;
        private final int eventCurrency;
        private final int casesOpened;
        private final int rank;
        
        public EventLeaderboardEntry(UUID playerId, String playerName, int eventCurrency, int casesOpened, int rank) {
            this.playerId = playerId;
            this.playerName = playerName;
            this.eventCurrency = eventCurrency;
            this.casesOpened = casesOpened;
            this.rank = rank;
        }
        
        public UUID getPlayerId() { return playerId; }
        public String getPlayerName() { return playerName; }
        public int getEventCurrency() { return eventCurrency; }
        public int getCasesOpened() { return casesOpened; }
        public int getRank() { return rank; }
    }
}

package ru.metalpipe.dbdamp.killer;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import ru.metalpipe.dbdamp.gameplay.model.Match;

import java.util.UUID;

/**
 * Interface for killer-specific mechanics and abilities.
 * Implements attacking, bloodlust, power usage, and carrying mechanics.
 */
public interface KillerSystem {
    
    /**
     * Perform a basic attack against a target.
     * 
     * @param killerId The killer's UUID
     * @param targetId The target survivor's UUID
     * @return true if attack was successful
     */
    boolean basicAttack(UUID killerId, UUID targetId);
    
    /**
     * Perform a lunge attack (extended range attack).
     * 
     * @param killerId The killer's UUID
     * @return true if lunge attack hit a target
     */
    boolean lungeAttack(UUID killerId);
    
    /**
     * Get the attack cooldown remaining.
     * 
     * @param killerId The killer's UUID
     * @return Cooldown in ticks, 0 if ready
     */
    int getAttackCooldown(UUID killerId);
    
    /**
     * Check if killer can attack.
     * 
     * @param killerId The killer's UUID
     * @return true if killer can attack
     */
    boolean canAttack(UUID killerId);
    
    /**
     * Get current bloodlust level.
     * Bloodlust increases movement speed during prolonged chases.
     * 
     * @param killerId The killer's UUID
     * @return Bloodlust level (0-3)
     */
    int getBloodlustLevel(UUID killerId);
    
    /**
     * Increase bloodlust level (called during chases).
     * 
     * @param killerId The killer's UUID
     */
    void increaseBloodlust(UUID killerId);
    
    /**
     * Reset bloodlust level (called when chase ends).
     * 
     * @param killerId The killer's UUID
     */
    void resetBloodlust(UUID killerId);
    
    /**
     * Break a pallet at the specified location.
     * 
     * @param killerId The killer's UUID
     * @param palletLocation The pallet location
     * @return true if pallet was broken
     */
    boolean breakPallet(UUID killerId, Location palletLocation);
    
    /**
     * Damage a generator (regress its progress).
     * 
     * @param killerId The killer's UUID
     * @param generatorId The generator's UUID
     * @return true if generator was damaged
     */
    boolean damageGenerator(UUID killerId, UUID generatorId);
    
    /**
     * Pick up a downed survivor.
     * 
     * @param killerId The killer's UUID
     * @param survivorId The survivor's UUID
     * @return true if survivor was picked up
     */
    boolean pickUpSurvivor(UUID killerId, UUID survivorId);
    
    /**
     * Drop a carried survivor.
     * 
     * @param killerId The killer's UUID
     * @return true if survivor was dropped
     */
    boolean dropSurvivor(UUID killerId);
    
    /**
     * Check if killer is carrying a survivor.
     * 
     * @param killerId The killer's UUID
     * @return true if carrying a survivor
     */
    boolean isCarrying(UUID killerId);
    
    /**
     * Get the UUID of the carried survivor.
     * 
     * @param killerId The killer's UUID
     * @return Survivor UUID, or null if not carrying
     */
    UUID getCarriedSurvivor(UUID killerId);
    
    /**
     * Hook a carried survivor.
     * 
     * @param killerId The killer's UUID
     * @param hookLocation The hook location
     * @return true if survivor was hooked
     */
    boolean hookSurvivor(UUID killerId, Location hookLocation);
    
    /**
     * Use killer power (special ability).
     * 
     * @param killerId The killer's UUID
     * @return true if power was activated
     */
    boolean usePower(UUID killerId);
    
    /**
     * Check if killer power is ready.
     * 
     * @param killerId The killer's UUID
     * @return true if power is ready
     */
    boolean isPowerReady(UUID killerId);
    
    /**
     * Get power cooldown remaining.
     * 
     * @param killerId The killer's UUID
     * @return Cooldown in ticks, 0 if ready
     */
    int getPowerCooldown(UUID killerId);
    
    /**
     * Perform mori execution on a dying survivor.
     * 
     * @param killerId The killer's UUID
     * @param survivorId The survivor's UUID
     * @return true if mori was successful
     */
    boolean performMori(UUID killerId, UUID survivorId);
    
    /**
     * Get the chase duration for a killer.
     * 
     * @param killerId The killer's UUID
     * @return Chase duration in ticks, 0 if not in chase
     */
    int getChaseDuration(UUID killerId);
    
    /**
     * Start a chase with a survivor.
     * 
     * @param killerId The killer's UUID
     * @param survivorId The survivor's UUID
     */
    void startChase(UUID killerId, UUID survivorId);
    
    /**
     * End the current chase.
     * 
     * @param killerId The killer's UUID
     */
    void endChase(UUID killerId);
    
    /**
     * Get the terror radius for a killer.
     * 
     * @param killerId The killer's UUID
     * @return Terror radius in blocks
     */
    double getTerrorRadius(UUID killerId);
    
    /**
     * Update killer state (called every tick).
     * 
     * @param match The current match
     */
    void update(Match match);
    
    /**
     * Reset killer state for a new match.
     * 
     * @param killerId The killer's UUID
     */
    void resetKiller(UUID killerId);
}
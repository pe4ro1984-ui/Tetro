package ru.metalpipe.dbdamp.killer;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ru.metalpipe.dbdamp.gameplay.model.Match;
import ru.metalpipe.dbdamp.survivor.SurvivorSystem;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Implementation of killer-specific mechanics and abilities.
 * Manages attacking, bloodlust, power usage, and carrying.
 */
public class KillerSystemImpl implements KillerSystem {
    
    private final Logger logger;
    private final SurvivorSystem survivorSystem;
    
    // Killer state tracking
    private final Map<UUID, KillerState> killerStates;
    
    // Configuration values
    private static final int ATTACK_COOLDOWN_TICKS = 40; // 2 seconds
    private static final int LUNGE_COOLDOWN_TICKS = 60; // 3 seconds
    private static final double LUNGE_RANGE = 4.5;
    private static final double BASIC_ATTACK_RANGE = 3.0;
    
    // Bloodlust configuration
    private static final int BLOODLUST_1_TIME = 300; // 15 seconds of chase
    private static final int BLOODLUST_2_TIME = 600; // 30 seconds of chase
    private static final int BLOODLUST_3_TIME = 900; // 45 seconds of chase
    private static final int BLOODLUST_1_SPEED = 1;
    private static final int BLOODLUST_2_SPEED = 2;
    private static final int BLOODLUST_3_SPEED = 3;
    
    // Terror radius
    private static final double BASE_TERROR_RADIUS = 32.0;
    
    // Power configuration
    private static final int POWER_COOLDOWN_TICKS = 1200; // 60 seconds
    
    public KillerSystemImpl(SurvivorSystem survivorSystem) {
        this.logger = Logger.getLogger(getClass().getName());
        this.survivorSystem = survivorSystem;
        this.killerStates = new ConcurrentHashMap<>();
    }
    
    // Attack mechanics
    @Override
    public boolean basicAttack(UUID killerId, UUID targetId) {
        KillerState state = getOrCreateState(killerId);
        
        if (!canAttack(killerId)) {
            return false;
        }
        
        // Check if target is in range
        Player killer = Bukkit.getPlayer(killerId);
        Player target = Bukkit.getPlayer(targetId);
        if (killer == null || target == null) return false;
        
        if (killer.getLocation().distance(target.getLocation()) > BASIC_ATTACK_RANGE) {
            return false;
        }
        
        // Apply damage
        survivorSystem.applyInjury(targetId, "basic_attack");
        
        // Set cooldown
        state.attackCooldown = ATTACK_COOLDOWN_TICKS;
        
        // Play effects
        target.playSound(target.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        killer.playSound(killer.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 1.0f);
        
        logger.fine("Killer " + killerId + " hit survivor " + targetId);
        return true;
    }
    
    @Override
    public boolean lungeAttack(UUID killerId) {
        KillerState state = getOrCreateState(killerId);
        
        if (state.attackCooldown > 0) {
            return false;
        }
        
        Player killer = Bukkit.getPlayer(killerId);
        if (killer == null) return false;
        
        // Find nearest survivor in range
        Player nearestSurvivor = null;
        double nearestDistance = LUNGE_RANGE;
        
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.equals(killer)) continue;
            
            double distance = killer.getLocation().distance(player.getLocation());
            if (distance <= LUNGE_RANGE && distance < nearestDistance) {
                nearestSurvivor = player;
                nearestDistance = distance;
            }
        }
        
        if (nearestSurvivor != null) {
            // Apply damage
            survivorSystem.applyInjury(nearestSurvivor.getUniqueId(), "lunge_attack");
            
            // Set longer cooldown
            state.attackCooldown = LUNGE_COOLDOWN_TICKS;
            
            // Play effects
            nearestSurvivor.playSound(nearestSurvivor.getLocation(), 
                org.bukkit.Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 1.5f);
            killer.playSound(killer.getLocation(), 
                org.bukkit.Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 1.5f);
            
            logger.fine("Killer " + killerId + " lunged at survivor " + nearestSurvivor.getUniqueId());
            return true;
        }
        
        return false;
    }
    
    @Override
    public int getAttackCooldown(UUID killerId) {
        KillerState state = getState(killerId);
        return state != null ? state.attackCooldown : 0;
    }
    
    @Override
    public boolean canAttack(UUID killerId) {
        KillerState state = getState(killerId);
        return state != null && state.attackCooldown <= 0 && !state.isCarrying;
    }
    
    // Bloodlust mechanics
    @Override
    public int getBloodlustLevel(UUID killerId) {
        KillerState state = getState(killerId);
        if (state == null || !state.isInChase) {
            return 0;
        }
        
        int chaseTime = state.chaseDuration;
        if (chaseTime >= BLOODLUST_3_TIME) return 3;
        if (chaseTime >= BLOODLUST_2_TIME) return 2;
        if (chaseTime >= BLOODLUST_1_TIME) return 1;
        return 0;
    }
    
    @Override
    public void increaseBloodlust(UUID killerId) {
        KillerState state = getOrCreateState(killerId);
        int oldLevel = getBloodlustLevel(killerId);
        state.chaseDuration++;
        int newLevel = getBloodlustLevel(killerId);
        
        if (newLevel > oldLevel) {
            applyBloodlustEffects(killerId, newLevel);
            logger.fine("Bloodlust increased to " + newLevel + " for killer " + killerId);
        }
    }
    
    @Override
    public void resetBloodlust(UUID killerId) {
        KillerState state = getState(killerId);
        if (state != null) {
            state.chaseDuration = 0;
            removeBloodlustEffects(killerId);
        }
    }
    
    // Pallet breaking
    @Override
    public boolean breakPallet(UUID killerId, Location palletLocation) {
        KillerState state = getOrCreateState(killerId);
        
        if (state.palletBreakCooldown > 0) {
            return false;
        }
        
        // Break the pallet (integrate with map system)
        // This would destroy the pallet entity
        
        state.palletBreakCooldown = 50; // 2.5 seconds
        
        Player killer = Bukkit.getPlayer(killerId);
        if (killer != null) {
            killer.playSound(palletLocation, org.bukkit.Sound.BLOCK_WOOD_BREAK, 1.0f, 0.8f);
        }
        
        logger.fine("Killer " + killerId + " broke pallet at " + palletLocation);
        return true;
    }
    
    // Generator damage
    @Override
    public boolean damageGenerator(UUID killerId, UUID generatorId) {
        KillerState state = getOrCreateState(killerId);
        
        if (state.generatorDamageCooldown > 0) {
            return false;
        }
        
        // Damage generator (integrate with generator system)
        // This would reduce generator progress
        
        state.generatorDamageCooldown = 40; // 2 seconds
        
        logger.fine("Killer " + killerId + " damaged generator " + generatorId);
        return true;
    }
    
    // Carrying mechanics
    @Override
    public boolean pickUpSurvivor(UUID killerId, UUID survivorId) {
        KillerState state = getOrCreateState(killerId);
        
        if (state.isCarrying) {
            return false;
        }
        
        // Check if survivor is dying
        if (!survivorSystem.isDying(survivorId)) {
            return false;
        }
        
        state.isCarrying = true;
        state.carriedSurvivor = survivorId;
        
        // Apply carrying penalty
        Player killer = Bukkit.getPlayer(killerId);
        if (killer != null) {
            killer.addPotionEffect(new PotionEffect(
                PotionEffectType.SLOW,
                Integer.MAX_VALUE,
                1,
                false,
                false
            ));
        }
        
        // Hide survivor
        Player survivor = Bukkit.getPlayer(survivorId);
        if (survivor != null) {
            // Hide the survivor using invisibility
            survivor.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
        }
        
        logger.fine("Killer " + killerId + " picked up survivor " + survivorId);
        return true;
    }
    
    @Override
    public boolean dropSurvivor(UUID killerId) {
        KillerState state = getState(killerId);
        if (state == null || !state.isCarrying) {
            return false;
        }
        
        UUID survivorId = state.carriedSurvivor;
        state.isCarrying = false;
        state.carriedSurvivor = null;
        
        // Remove carrying penalty
        Player killer = Bukkit.getPlayer(killerId);
        if (killer != null) {
            killer.removePotionEffect(PotionEffectType.SLOW);
        }
        
        // Show survivor at killer's location
        Player survivor = Bukkit.getPlayer(survivorId);
        if (survivor != null && killer != null) {
            // Remove invisibility
            survivor.removePotionEffect(PotionEffectType.INVISIBILITY);
            survivor.teleport(killer.getLocation());
        }
        
        logger.fine("Killer " + killerId + " dropped survivor " + survivorId);
        return true;
    }
    
    @Override
    public boolean isCarrying(UUID killerId) {
        KillerState state = getState(killerId);
        return state != null && state.isCarrying;
    }
    
    @Override
    public UUID getCarriedSurvivor(UUID killerId) {
        KillerState state = getState(killerId);
        return state != null ? state.carriedSurvivor : null;
    }
    
    @Override
    public boolean hookSurvivor(UUID killerId, Location hookLocation) {
        KillerState state = getState(killerId);
        if (state == null || !state.isCarrying) {
            return false;
        }
        
        // Check if there's a hook at location
        if (!isHookAt(hookLocation)) {
            return false;
        }
        
        UUID survivorId = state.carriedSurvivor;
        
        // Hook the survivor (integrate with hook system)
        state.isCarrying = false;
        state.carriedSurvivor = null;
        
        // Remove carrying penalty
        Player killer = Bukkit.getPlayer(killerId);
        if (killer != null) {
            killer.removePotionEffect(PotionEffectType.SLOW);
        }
        
        // Teleport survivor to hook
        Player survivor = Bukkit.getPlayer(survivorId);
        if (survivor != null) {
            // Remove invisibility
            survivor.removePotionEffect(PotionEffectType.INVISIBILITY);
            survivor.teleport(hookLocation);
        }
        
        logger.info("Killer " + killerId + " hooked survivor " + survivorId);
        return true;
    }
    
    // Power mechanics
    @Override
    public boolean usePower(UUID killerId) {
        KillerState state = getOrCreateState(killerId);
        
        if (state.powerCooldown > 0) {
            return false;
        }
        
        // Activate power (specific implementation depends on killer type)
        // This would be extended by specific killer types
        
        state.powerCooldown = POWER_COOLDOWN_TICKS;
        state.powerActive = true;
        
        logger.fine("Killer " + killerId + " used power");
        return true;
    }
    
    @Override
    public boolean isPowerReady(UUID killerId) {
        KillerState state = getState(killerId);
        return state != null && state.powerCooldown <= 0;
    }
    
    @Override
    public int getPowerCooldown(UUID killerId) {
        KillerState state = getState(killerId);
        return state != null ? state.powerCooldown : 0;
    }
    
    // Mori mechanics
    @Override
    public boolean performMori(UUID killerId, UUID survivorId) {
        KillerState state = getOrCreateState(killerId);
        
        // Check if survivor is dying and can be moried
        if (!survivorSystem.isDying(survivorId)) {
            return false;
        }
        
        // Check mori conditions (e.g., all other survivors dead, or specific perk)
        if (!canPerformMori(state)) {
            return false;
        }
        
        // Kill the survivor instantly
        // This would integrate with the match system
        
        Player survivor = Bukkit.getPlayer(survivorId);
        Player killer = Bukkit.getPlayer(killerId);
        if (survivor != null && killer != null) {
            survivor.playSound(survivor.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_DEATH, 1.0f, 0.5f);
            killer.playSound(killer.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_DEATH, 1.0f, 1.0f);
        }
        
        logger.info("Killer " + killerId + " performed mori on survivor " + survivorId);
        return true;
    }
    
    // Chase mechanics
    @Override
    public int getChaseDuration(UUID killerId) {
        KillerState state = getState(killerId);
        return state != null ? state.chaseDuration : 0;
    }
    
    @Override
    public void startChase(UUID killerId, UUID survivorId) {
        KillerState state = getOrCreateState(killerId);
        state.isInChase = true;
        state.chaseTarget = survivorId;
        state.chaseDuration = 0;
        
        logger.fine("Killer " + killerId + " started chasing survivor " + survivorId);
    }
    
    @Override
    public void endChase(UUID killerId) {
        KillerState state = getState(killerId);
        if (state != null && state.isInChase) {
            logger.fine("Killer " + killerId + " ended chase (duration: " + state.chaseDuration + " ticks)");
            state.isInChase = false;
            state.chaseTarget = null;
            resetBloodlust(killerId);
        }
    }
    
    // Terror radius
    @Override
    public double getTerrorRadius(UUID killerId) {
        // Could be modified by perks or killer type
        return BASE_TERROR_RADIUS;
    }
    
    // Update loop
    @Override
    public void update(Match match) {
        for (UUID killerId : killerStates.keySet()) {
            KillerState state = killerStates.get(killerId);
            
            // Update cooldowns
            if (state.attackCooldown > 0) state.attackCooldown--;
            if (state.powerCooldown > 0) state.powerCooldown--;
            if (state.palletBreakCooldown > 0) state.palletBreakCooldown--;
            if (state.generatorDamageCooldown > 0) state.generatorDamageCooldown--;
            
            // Update chase and bloodlust
            if (state.isInChase) {
                increaseBloodlust(killerId);
            }
            
            // Update carried survivor position
            if (state.isCarrying && state.carriedSurvivor != null) {
                Player killer = Bukkit.getPlayer(killerId);
                Player survivor = Bukkit.getPlayer(state.carriedSurvivor);
                if (killer != null && survivor != null) {
                    survivor.teleport(killer.getLocation());
                }
            }
        }
    }
    
    @Override
    public void resetKiller(UUID killerId) {
        killerStates.remove(killerId);
        
        Player killer = Bukkit.getPlayer(killerId);
        if (killer != null) {
            killer.removePotionEffect(PotionEffectType.SPEED);
            killer.removePotionEffect(PotionEffectType.SLOW);
        }
    }
    
    // Helper methods
    private KillerState getOrCreateState(UUID killerId) {
        return killerStates.computeIfAbsent(killerId, id -> new KillerState());
    }
    
    private KillerState getState(UUID killerId) {
        return killerStates.get(killerId);
    }
    
    private void applyBloodlustEffects(UUID killerId, int level) {
        Player killer = Bukkit.getPlayer(killerId);
        if (killer == null) return;
        
        killer.removePotionEffect(PotionEffectType.SPEED);
        
        int amplifier = 0;
        switch (level) {
            case 1: amplifier = BLOODLUST_1_SPEED; break;
            case 2: amplifier = BLOODLUST_2_SPEED; break;
            case 3: amplifier = BLOODLUST_3_SPEED; break;
        }
        
        if (amplifier > 0) {
            killer.addPotionEffect(new PotionEffect(
                PotionEffectType.SPEED,
                Integer.MAX_VALUE,
                amplifier,
                false,
                false
            ));
        }
    }
    
    private void removeBloodlustEffects(UUID killerId) {
        Player killer = Bukkit.getPlayer(killerId);
        if (killer != null) {
            killer.removePotionEffect(PotionEffectType.SPEED);
        }
    }
    
    private boolean isHookAt(Location location) {
        // Check if there's a hook at location
        // This would integrate with the map system
        return true; // Placeholder
    }
    
    private boolean canPerformMori(KillerState state) {
        // Check mori conditions
        // This would check for perks like "Devour Hope" or "Hex: No One Escapes Death"
        return true; // Placeholder
    }
    
    /**
     * Internal state for each killer.
     */
    private static class KillerState {
        // Attack state
        int attackCooldown = 0;
        
        // Bloodlust state
        boolean isInChase = false;
        UUID chaseTarget = null;
        int chaseDuration = 0;
        
        // Carrying state
        boolean isCarrying = false;
        UUID carriedSurvivor = null;
        
        // Power state
        int powerCooldown = 0;
        boolean powerActive = false;
        
        // Cooldowns
        int palletBreakCooldown = 0;
        int generatorDamageCooldown = 0;
    }
}
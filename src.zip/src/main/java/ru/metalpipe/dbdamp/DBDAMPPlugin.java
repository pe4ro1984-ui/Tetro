package ru.metalpipe.dbdamp;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import ru.metalpipe.dbdamp.config.ConfigurationManager;
import ru.metalpipe.dbdamp.config.DatabaseConfig;
import ru.metalpipe.dbdamp.config.PluginConfig;
import ru.metalpipe.dbdamp.config.YamlConfigurationManager;
import ru.metalpipe.dbdamp.database.DatabaseManager;
import ru.metalpipe.dbdamp.database.HikariDatabaseManager;
import ru.metalpipe.dbdamp.economy.EconomySystem;
import ru.metalpipe.dbdamp.economy.EconomySystemImpl;
import ru.metalpipe.dbdamp.integration.PluginIntegrationManager;
import ru.metalpipe.dbdamp.item.CustomItemSystem;
import ru.metalpipe.dbdamp.item.CustomItemSystemImpl;
import ru.metalpipe.dbdamp.killer.KillerSystem;
import ru.metalpipe.dbdamp.killer.KillerSystemImpl;
import ru.metalpipe.dbdamp.lobby.LobbySystem;
import ru.metalpipe.dbdamp.lobby.LobbySystemImpl;
import ru.metalpipe.dbdamp.map.MapSystem;
import ru.metalpipe.dbdamp.map.MapSystemImpl;
import ru.metalpipe.dbdamp.match.MatchSystem;
import ru.metalpipe.dbdamp.match.MatchSystemImpl;
import ru.metalpipe.dbdamp.mob.CustomMobSystem;
import ru.metalpipe.dbdamp.mob.CustomMobSystemImpl;
import ru.metalpipe.dbdamp.perk.PerkSystem;
import ru.metalpipe.dbdamp.perk.PerkSystemImpl;
import ru.metalpipe.dbdamp.progression.ProgressionSystem;
import ru.metalpipe.dbdamp.progression.ProgressionSystemImpl;
import ru.metalpipe.dbdamp.scoreboard.ScoreboardSystem;
import ru.metalpipe.dbdamp.scoreboard.ScoreboardSystemImpl;
import ru.metalpipe.dbdamp.stalcraft.StalcraftSystem;
import ru.metalpipe.dbdamp.stalcraft.StalcraftSystemImpl;
import ru.metalpipe.dbdamp.survivor.*;

import java.util.logging.Logger;

/**
 * Main plugin class for DBD-AMP (Dead by Daylight - Advanced Minecraft Plugin).
 */
public class DBDAMPPlugin extends JavaPlugin {
    
    private static DBDAMPPlugin instance;
    private final Logger logger;
    
    // Configuration
    private ConfigurationManager configurationManager;
    private PluginConfig pluginConfig;
    
    // Database
    private DatabaseManager databaseManager;
    
    // Core Systems
    private SurvivorSystem survivorSystem;
    private KillerSystem killerSystem;
    private HealthSystem healthSystem;
    private TerrorRadiusSystem terrorRadiusSystem;
    private SkillCheckSystem skillCheckSystem;
    
    // Game Systems
    private PerkSystem perkSystem;
    private LobbySystem lobbySystem;
    private MatchSystem matchSystem;
    private MapSystem mapSystem;
    
    // Progression Systems
    private ProgressionSystem progressionSystem;
    private ScoreboardSystem scoreboardSystem;
    private EconomySystem economySystem;
    
    // Content Systems
    private CustomItemSystem customItemSystem;
    private CustomMobSystem customMobSystem;
    private StalcraftSystem stalcraftSystem;
    
    // Integration
    private PluginIntegrationManager integrationManager;
    
    public DBDAMPPlugin() {
        this.logger = getLogger();
    }
    
    @Override
    public void onEnable() {
        instance = this;
        
        logger.info("========================================");
        logger.info("  DBD-AMP - Dead by Daylight Minecraft");
        logger.info("========================================");
        logger.info("Starting plugin initialization...");
        
        try {
            initializeConfiguration();
            initializeDatabase();
            initializeIntegration();
            initializeCoreSystems();
            initializeProgressionSystems();  // Сначала создаём economySystem
            initializeGameSystems();          // Потом используем в matchSystem
            initializeContentSystems();
            registerListeners();
            
            logger.info("========================================");
            logger.info("  DBD-AMP enabled successfully!");
            logger.info("  Version: " + getDescription().getVersion());
            logger.info("========================================");
            
        } catch (Exception e) {
            logger.severe("Failed to initialize DBD-AMP: " + e.getMessage());
            e.printStackTrace();
            setEnabled(false);
        }
    }
    
    @Override
    public void onDisable() {
        logger.info("Shutting down DBD-AMP...");
        
        shutdownContentSystems();
        shutdownProgressionSystems();
        shutdownGameSystems();
        shutdownCoreSystems();
        shutdownIntegration();
        shutdownDatabase();
        shutdownConfiguration();
        
        instance = null;
        logger.info("DBD-AMP disabled. Goodbye!");
    }
    
    private void initializeConfiguration() {
        logger.info("[1/8] Initializing configuration...");
        saveDefaultConfig();
        configurationManager = new YamlConfigurationManager(this);
        try {
            pluginConfig = configurationManager.loadOrCreateConfig("config.yml", PluginConfig.class);
        } catch (Exception e) {
            logger.warning("Could not load config.yml, using defaults: " + e.getMessage());
            pluginConfig = new PluginConfig();
        }
        logger.info("Configuration loaded successfully");
    }
    
    private void initializeDatabase() {
        logger.info("[2/8] Initializing database...");
        try {
            DatabaseConfig dbConfig = pluginConfig != null ? pluginConfig.getDatabase() : new DatabaseConfig();
            databaseManager = new HikariDatabaseManager(logger, dbConfig);
            ((HikariDatabaseManager) databaseManager).initialize();
            logger.info("Database connection established");
        } catch (Exception e) {
            logger.warning("Database initialization failed, using local storage: " + e.getMessage());
        }
    }
    
    private void initializeIntegration() {
        logger.info("[3/8] Initializing plugin integrations...");
        integrationManager = new PluginIntegrationManager();
        integrationManager.initializeIntegrations();
        logger.info("Plugin integrations initialized");
    }
    
    private void initializeCoreSystems() {
        logger.info("[4/8] Initializing core gameplay systems...");
        survivorSystem = new SurvivorSystemImpl();
        killerSystem = new KillerSystemImpl(survivorSystem);
        healthSystem = new HealthSystem();
        terrorRadiusSystem = new TerrorRadiusSystem();
        skillCheckSystem = new SkillCheckSystem();
        logger.info("Core systems initialized");
    }
    
    private void initializeGameSystems() {
        logger.info("[5/8] Initializing game systems...");
        perkSystem = new PerkSystemImpl();
        lobbySystem = new LobbySystemImpl();
        matchSystem = new MatchSystemImpl(lobbySystem, economySystem);
        mapSystem = new MapSystemImpl();
        logger.info("Game systems initialized");
    }
    
    private void initializeProgressionSystems() {
        logger.info("[6/8] Initializing progression systems...");
        economySystem = new EconomySystemImpl();
        progressionSystem = new ProgressionSystemImpl();
        scoreboardSystem = new ScoreboardSystemImpl();
        logger.info("Progression systems initialized");
    }
    
    private void initializeContentSystems() {
        logger.info("[7/8] Initializing content systems...");
        customItemSystem = new CustomItemSystemImpl();
        customMobSystem = new CustomMobSystemImpl();
        stalcraftSystem = new StalcraftSystemImpl();
        logger.info("Content systems initialized");
    }
    
    private void registerListeners() {
        logger.info("[8/8] Registering listeners...");
        Bukkit.getPluginManager().registerEvents(new DBDGameListener(this), this);
        logger.info("Listeners registered");
    }
    
    private void shutdownContentSystems() {
        if (stalcraftSystem != null && stalcraftSystem.isEventActive()) {
            stalcraftSystem.endEvent();
        }
        customItemSystem = null;
        customMobSystem = null;
        stalcraftSystem = null;
    }
    
    private void shutdownProgressionSystems() {
        progressionSystem = null;
        scoreboardSystem = null;
    }
    
    private void shutdownGameSystems() {
        if (matchSystem != null) {
            matchSystem.getActiveMatches().forEach(match -> 
                matchSystem.endMatch(match.getMatchId()));
        }
        matchSystem = null;
        lobbySystem = null;
        perkSystem = null;
        mapSystem = null;
    }
    
    private void shutdownCoreSystems() {
        survivorSystem = null;
        killerSystem = null;
        healthSystem = null;
        terrorRadiusSystem = null;
        if (skillCheckSystem != null) {
            skillCheckSystem.clearAll();
        }
        skillCheckSystem = null;
    }
    
    private void shutdownIntegration() {
        if (integrationManager != null) {
            integrationManager.disableIntegrations();
        }
        integrationManager = null;
    }
    
    private void shutdownDatabase() {
        if (databaseManager != null) {
            databaseManager.shutdown();
        }
        databaseManager = null;
    }
    
    private void shutdownConfiguration() {
        configurationManager = null;
        pluginConfig = null;
    }
    
    // Getters
    public static DBDAMPPlugin getInstance() { return instance; }
    public ConfigurationManager getConfigurationManager() { return configurationManager; }
    public PluginConfig getPluginConfig() { return pluginConfig; }
    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public SurvivorSystem getSurvivorSystem() { return survivorSystem; }
    public KillerSystem getKillerSystem() { return killerSystem; }
    public HealthSystem getHealthSystem() { return healthSystem; }
    public TerrorRadiusSystem getTerrorRadiusSystem() { return terrorRadiusSystem; }
    public SkillCheckSystem getSkillCheckSystem() { return skillCheckSystem; }
    public PerkSystem getPerkSystem() { return perkSystem; }
    public LobbySystem getLobbySystem() { return lobbySystem; }
    public MatchSystem getMatchSystem() { return matchSystem; }
    public MapSystem getMapSystem() { return mapSystem; }
    public ProgressionSystem getProgressionSystem() { return progressionSystem; }
    public ScoreboardSystem getScoreboardSystem() { return scoreboardSystem; }
    public EconomySystem getEconomySystem() { return economySystem; }
    public CustomItemSystem getCustomItemSystem() { return customItemSystem; }
    public CustomMobSystem getCustomMobSystem() { return customMobSystem; }
    public StalcraftSystem getStalcraftSystem() { return stalcraftSystem; }
    public PluginIntegrationManager getIntegrationManager() { return integrationManager; }
}

package ru.metalpipe.dbdamp.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import ru.metalpipe.dbdamp.config.DatabaseConfig;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

/**
 * HikariCP-based implementation of DatabaseManager with MySQL and SQLite support.
 * Implements connection pooling, retry logic, and migration support.
 */
public class HikariDatabaseManager implements DatabaseManager {
    
    private final Logger logger;
    private final DatabaseConfig dbConfig;
    private HikariDataSource dataSource;
    private final Map<SchemaVersion, List<Migration>> migrations;
    private final AtomicLong queryCount;
    private final AtomicLong updateCount;
    private final AtomicLong errorCount;
    private final AtomicLong totalQueryTime;
    private final ReentrantLock migrationLock;
    private volatile boolean initialized;
    private volatile boolean shutdown;
    
    public HikariDatabaseManager(Logger logger, DatabaseConfig dbConfig) {
        this.logger = logger;
        this.dbConfig = dbConfig;
        this.migrations = new ConcurrentHashMap<>();
        this.queryCount = new AtomicLong(0);
        this.updateCount = new AtomicLong(0);
        this.errorCount = new AtomicLong(0);
        this.totalQueryTime = new AtomicLong(0);
        this.migrationLock = new ReentrantLock();
        this.initialized = false;
        this.shutdown = false;
    }
    
    /**
     * Initialize the database manager and establish connection pool.
     * 
     * @throws DatabaseException If initialization fails
     */
    public void initialize() throws DatabaseException {
        if (initialized) {
            return;
        }
        
        migrationLock.lock();
        try {
            if (initialized) {
                return;
            }
            
            logger.info("Initializing database manager for " + dbConfig.getType());
            
            HikariConfig config = new HikariConfig();
            
            // Configure connection pool
            config.setPoolName("DBD-AMP-Pool");
            config.setMaximumPoolSize(dbConfig.getConnectionPoolSize());
            config.setMinimumIdle(Math.min(3, dbConfig.getConnectionPoolSize() / 2));
            config.setConnectionTimeout(dbConfig.getConnectionTimeout());
            config.setIdleTimeout(dbConfig.getIdleTimeout());
            config.setMaxLifetime(dbConfig.getMaxLifetime());
            config.setConnectionTestQuery("SELECT 1");
            config.setAutoCommit(true);
            
            // Configure database-specific settings
            if (dbConfig.getType() == DatabaseConfig.DatabaseType.MYSQL) {
                config.setJdbcUrl(dbConfig.getConnectionString());
                config.setUsername(dbConfig.getUsername());
                config.setPassword(dbConfig.getPassword());
                config.setDriverClassName("com.mysql.cj.jdbc.Driver");
                
                // MySQL-specific optimizations
                config.addDataSourceProperty("cachePrepStmts", "true");
                config.addDataSourceProperty("prepStmtCacheSize", "250");
                config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
                config.addDataSourceProperty("useServerPrepStmts", "true");
                config.addDataSourceProperty("useLocalSessionState", "true");
                config.addDataSourceProperty("rewriteBatchedStatements", "true");
                config.addDataSourceProperty("cacheResultSetMetadata", "true");
                config.addDataSourceProperty("cacheServerConfiguration", "true");
                config.addDataSourceProperty("elideSetAutoCommits", "true");
                config.addDataSourceProperty("maintainTimeStats", "false");
                
            } else { // SQLite
                config.setJdbcUrl(dbConfig.getConnectionString());
                config.setDriverClassName("org.sqlite.JDBC");
                
                // SQLite-specific optimizations
                config.addDataSourceProperty("journal_mode", "WAL");
                config.addDataSourceProperty("synchronous", "NORMAL");
                config.addDataSourceProperty("foreign_keys", "true");
                config.addDataSourceProperty("busy_timeout", "5000");
            }
            
            // Create data source with retry logic
            dataSource = createDataSourceWithRetry(config);
            
            // Test connection
            testConnection();
            
            // Initialize schema version table
            initializeSchemaVersion();
            
            // Run migrations if needed
            runMigrations();
            
            initialized = true;
            logger.info("Database manager initialized successfully");
            
        } catch (Exception e) {
            throw new DatabaseException("Failed to initialize database manager", e);
        } finally {
            migrationLock.unlock();
        }
    }
    
    @Override
    public Connection getConnection() throws SQLException {
        try {
            checkInitialized();
            checkShutdown();
        } catch (DatabaseException e) {
            throw new SQLException(e.getMessage(), e);
        }
        
        return dataSource.getConnection();
    }
    
    @Override
    public void executeTransaction(Transaction transaction) throws DatabaseException {
        executeTransaction(conn -> {
            transaction.execute(conn);
            return null;
        });
    }
    
    @Override
    public <T> T executeTransaction(ReturningTransaction<T> transaction) throws DatabaseException {
        checkInitialized();
        checkShutdown();
        
        Connection connection = null;
        boolean originalAutoCommit = true;
        
        try {
            connection = getConnection();
            originalAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            
            T result = transaction.execute(connection);
            connection.commit();
            
            return result;
            
        } catch (SQLException e) {
            if (connection != null) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackEx) {
                    logger.warning("Failed to rollback transaction: " + rollbackEx.getMessage());
                }
            }
            errorCount.incrementAndGet();
            throw new DatabaseException("Transaction failed", e);
            
        } finally {
            if (connection != null) {
                try {
                    connection.setAutoCommit(originalAutoCommit);
                    connection.close();
                } catch (SQLException closeEx) {
                    logger.warning("Failed to close connection: " + closeEx.getMessage());
                }
            }
        }
    }
    
    @Override
    public <T> T query(String sql, ResultSetMapper<T> mapper, Object... params) throws DatabaseException {
        checkInitialized();
        checkShutdown();
        
        long startTime = System.currentTimeMillis();
        queryCount.incrementAndGet();
        
        try (Connection connection = getConnection();
             PreparedStatement stmt = prepareStatement(connection, sql, params);
             ResultSet rs = stmt.executeQuery()) {
            
            T result = mapper.map(rs);
            long queryTime = System.currentTimeMillis() - startTime;
            totalQueryTime.addAndGet(queryTime);
            
            return result;
            
        } catch (SQLException e) {
            errorCount.incrementAndGet();
            throw new DatabaseException("Query failed: " + sql, e);
        }
    }
    
    @Override
    public int update(String sql, Object... params) throws DatabaseException {
        checkInitialized();
        checkShutdown();
        
        long startTime = System.currentTimeMillis();
        updateCount.incrementAndGet();
        
        try (Connection connection = getConnection();
             PreparedStatement stmt = prepareStatement(connection, sql, params)) {
            
            int result = stmt.executeUpdate();
            long queryTime = System.currentTimeMillis() - startTime;
            totalQueryTime.addAndGet(queryTime);
            
            return result;
            
        } catch (SQLException e) {
            errorCount.incrementAndGet();
            throw new DatabaseException("Update failed: " + sql, e);
        }
    }
    
    @Override
    public int[] batchUpdate(String sql, Object[][] batchParams) throws DatabaseException {
        checkInitialized();
        checkShutdown();
        
        long startTime = System.currentTimeMillis();
        updateCount.incrementAndGet();
        
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            
            for (Object[] params : batchParams) {
                setParameters(stmt, params);
                stmt.addBatch();
            }
            
            int[] result = stmt.executeBatch();
            long queryTime = System.currentTimeMillis() - startTime;
            totalQueryTime.addAndGet(queryTime);
            
            return result;
            
        } catch (SQLException e) {
            errorCount.incrementAndGet();
            throw new DatabaseException("Batch update failed: " + sql, e);
        }
    }
    
    @Override
    public <T> T callProcedure(String procedure, ResultSetMapper<T> mapper, Object... params) throws DatabaseException {
        checkInitialized();
        checkShutdown();
        
        long startTime = System.currentTimeMillis();
        queryCount.incrementAndGet();
        
        try (Connection connection = getConnection();
             CallableStatement stmt = connection.prepareCall(procedure)) {
            
            setParameters(stmt, params);
            
            boolean hasResultSet = stmt.execute();
            T result = null;
            
            if (hasResultSet) {
                try (ResultSet rs = stmt.getResultSet()) {
                    result = mapper.map(rs);
                }
            }
            
            long queryTime = System.currentTimeMillis() - startTime;
            totalQueryTime.addAndGet(queryTime);
            
            return result;
            
        } catch (SQLException e) {
            errorCount.incrementAndGet();
            throw new DatabaseException("Procedure call failed: " + procedure, e);
        }
    }
    
    @Override
    public void migrate(SchemaVersion from, SchemaVersion to) throws DatabaseException {
        checkInitialized();
        checkShutdown();
        
        migrationLock.lock();
        try {
            logger.info("Migrating database from " + from + " to " + to);
            
            // Get all migrations between from and to versions
            List<Migration> applicableMigrations = getMigrationsBetween(from, to);
            
            if (applicableMigrations.isEmpty()) {
                logger.info("No migrations needed");
                return;
            }
            
            // Execute each migration in a transaction
            for (Migration migration : applicableMigrations) {
                logger.info("Applying migration: " + migration.getName() + " to version " + migration.getTargetVersion());
                
                executeTransaction(conn -> {
                    // Execute migration SQL
                    for (String sql : migration.getSqlStatements()) {
                        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                            stmt.execute();
                        }
                    }
                    
                    // Update schema version
                    updateSchemaVersion(conn, migration.getTargetVersion());
                });
                
                logger.info("Migration " + migration.getName() + " applied successfully");
            }
            
            logger.info("Database migration completed successfully");
            
        } catch (Exception e) {
            throw new DatabaseException("Migration failed from " + from + " to " + to, e);
        } finally {
            migrationLock.unlock();
        }
    }
    
    @Override
    public SchemaVersion getCurrentVersion() throws DatabaseException {
        checkInitialized();
        checkShutdown();
        
        String sql = "SELECT version FROM dbd_schema_version ORDER BY applied_at DESC LIMIT 1";
        
        try {
            return query(sql, rs -> {
                if (rs.next()) {
                    return SchemaVersion.parse(rs.getString("version"));
                }
                return new SchemaVersion(0, 0, 0);
            });
        } catch (DatabaseException e) {
            // Table might not exist yet
            return new SchemaVersion(0, 0, 0);
        }
    }
    
    @Override
    public boolean isConnected() {
        if (!initialized || shutdown) {
            return false;
        }
        
        try (Connection conn = getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }
    
    @Override
    public boolean isInitialized() {
        return initialized && !shutdown;
    }
    
    @Override
    public void shutdown() {
        if (shutdown) {
            return;
        }
        
        shutdown = true;
        
        if (dataSource != null) {
            dataSource.close();
            logger.info("Database manager shutdown completed");
        }
    }
    
    @Override
    public DatabaseStats getStats() {
        if (dataSource == null) {
            return new DatabaseStats(0, 0, 0, 0, 0, 0, 0, 0);
        }
        
        long totalQueries = queryCount.get() + updateCount.get();
        long avgTime = totalQueries > 0 ? totalQueryTime.get() / totalQueries : 0;
        
        return new DatabaseStats(
            dataSource.getHikariPoolMXBean().getActiveConnections(),
            dataSource.getHikariPoolMXBean().getIdleConnections(),
            dataSource.getHikariPoolMXBean().getTotalConnections(),
            queryCount.get(),
            updateCount.get(),
            errorCount.get(),
            totalQueryTime.get(),
            avgTime
        );
    }
    
    /**
     * Register a database migration.
     * 
     * @param migration The migration to register
     */
    public void registerMigration(Migration migration) {
        migrations.computeIfAbsent(migration.getTargetVersion(), k -> new ArrayList<>()).add(migration);
    }
    
    // Private helper methods
    
    private HikariDataSource createDataSourceWithRetry(HikariConfig config) throws DatabaseException {
        final int maxRetries = 3;
        final long retryDelay = 5000; // 5 seconds
        
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                logger.info("Attempting to create data source (attempt " + attempt + "/" + maxRetries + ")");
                return new HikariDataSource(config);
                
            } catch (Exception e) {
                if (attempt == maxRetries) {
                    throw new DatabaseException("Failed to create data source after " + maxRetries + " attempts", e);
                }
                
                logger.warning("Data source creation failed, retrying in " + (retryDelay / 1000) + " seconds: " + e.getMessage());
                
                try {
                    Thread.sleep(retryDelay);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new DatabaseException("Data source creation interrupted", ie);
                }
            }
        }
        
        throw new DatabaseException("Failed to create data source");
    }
    
    private void testConnection() throws DatabaseException {
        final int maxRetries = 3;
        
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try (Connection conn = dataSource.getConnection();
                 Statement stmt = conn.createStatement()) {
                
                stmt.executeQuery("SELECT 1");
                logger.info("Database connection test successful");
                return;
                
            } catch (SQLException e) {
                if (attempt == maxRetries) {
                    throw new DatabaseException("Database connection test failed after " + maxRetries + " attempts", e);
                }
                
                logger.warning("Connection test failed (attempt " + attempt + "/" + maxRetries + "): " + e.getMessage());
                
                try {
                    Thread.sleep(2000 * attempt); // Exponential backoff
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new DatabaseException("Connection test interrupted", ie);
                }
            }
        }
    }
    
    private void initializeSchemaVersion() throws DatabaseException {
        String createTableSql;
        
        if (dbConfig.getType() == DatabaseConfig.DatabaseType.MYSQL) {
            createTableSql = """
                CREATE TABLE IF NOT EXISTS dbd_schema_version (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    version VARCHAR(20) NOT NULL,
                    name VARCHAR(100) NOT NULL,
                    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_version (version)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                """;
        } else {
            createTableSql = """
                CREATE TABLE IF NOT EXISTS dbd_schema_version (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    version TEXT NOT NULL,
                    name TEXT NOT NULL,
                    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """;
        }
        
        update(createTableSql);
    }
    
    private void updateSchemaVersion(Connection conn, SchemaVersion version) throws SQLException {
        String sql = "INSERT INTO dbd_schema_version (version, name) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, version.toString());
            stmt.setString(2, "Migration to " + version);
            stmt.executeUpdate();
        }
    }
    
    private void runMigrations() throws DatabaseException {
        SchemaVersion currentVersion = getCurrentVersion();
        SchemaVersion latestVersion = getLatestMigrationVersion();
        
        if (currentVersion.compareTo(latestVersion) < 0) {
            migrate(currentVersion, latestVersion);
        }
    }
    
    private SchemaVersion getLatestMigrationVersion() {
        return migrations.keySet().stream()
            .max(SchemaVersion::compareTo)
            .orElse(new SchemaVersion(0, 0, 0));
    }
    
    private List<Migration> getMigrationsBetween(SchemaVersion from, SchemaVersion to) {
        List<Migration> result = new ArrayList<>();
        
        for (Map.Entry<SchemaVersion, List<Migration>> entry : migrations.entrySet()) {
            SchemaVersion version = entry.getKey();
            if (version.compareTo(from) > 0 && version.compareTo(to) <= 0) {
                result.addAll(entry.getValue());
            }
        }
        
        // Sort by target version
        result.sort(Comparator.comparing(Migration::getTargetVersion));
        return result;
    }
    
    private PreparedStatement prepareStatement(Connection connection, String sql, Object[] params) throws SQLException {
        PreparedStatement stmt = connection.prepareStatement(sql);
        setParameters(stmt, params);
        return stmt;
    }
    
    private void setParameters(PreparedStatement stmt, Object[] params) throws SQLException {
        if (params == null) {
            return;
        }
        
        for (int i = 0; i < params.length; i++) {
            Object param = params[i];
            int paramIndex = i + 1;
            
            if (param == null) {
                stmt.setNull(paramIndex, Types.NULL);
            } else if (param instanceof String) {
                stmt.setString(paramIndex, (String) param);
            } else if (param instanceof Integer) {
                stmt.setInt(paramIndex, (Integer) param);
            } else if (param instanceof Long) {
                stmt.setLong(paramIndex, (Long) param);
            } else if (param instanceof Double) {
                stmt.setDouble(paramIndex, (Double) param);
            } else if (param instanceof Float) {
                stmt.setFloat(paramIndex, (Float) param);
            } else if (param instanceof Boolean) {
                stmt.setBoolean(paramIndex, (Boolean) param);
            } else if (param instanceof java.sql.Date) {
                stmt.setDate(paramIndex, (java.sql.Date) param);
            } else if (param instanceof Timestamp) {
                stmt.setTimestamp(paramIndex, (Timestamp) param);
            } else if (param instanceof java.util.Date) {
                stmt.setTimestamp(paramIndex, new Timestamp(((java.util.Date) param).getTime()));
            } else if (param instanceof byte[]) {
                stmt.setBytes(paramIndex, (byte[]) param);
            } else {
                stmt.setObject(paramIndex, param);
            }
        }
    }
    
    private void checkInitialized() throws DatabaseException {
        if (!initialized) {
            throw new DatabaseException("Database manager not initialized");
        }
    }
    
    private void checkShutdown() throws DatabaseException {
        if (shutdown) {
            throw new DatabaseException("Database manager is shutdown");
        }
    }
    
    /**
     * Database migration definition.
     */
    public static class Migration {
        private final SchemaVersion targetVersion;
        private final String name;
        private final List<String> sqlStatements;
        
        public Migration(SchemaVersion targetVersion, String name, List<String> sqlStatements) {
            this.targetVersion = targetVersion;
            this.name = name;
            this.sqlStatements = new ArrayList<>(sqlStatements);
        }
        
        public SchemaVersion getTargetVersion() { return targetVersion; }
        public String getName() { return name; }
        public List<String> getSqlStatements() { return sqlStatements; }
        
        public static Builder builder(SchemaVersion targetVersion, String name) {
            return new Builder(targetVersion, name);
        }
        
        public static class Builder {
            private final SchemaVersion targetVersion;
            private final String name;
            private final List<String> sqlStatements = new ArrayList<>();
            
            public Builder(SchemaVersion targetVersion, String name) {
                this.targetVersion = targetVersion;
                this.name = name;
            }
            
            public Builder addSql(String sql) {
                sqlStatements.add(sql);
                return this;
            }
            
            public Migration build() {
                return new Migration(targetVersion, name, sqlStatements);
            }
        }
    }
}
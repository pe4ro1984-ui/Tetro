package ru.metalpipe.dbdamp.database.model;

import java.time.Instant;
import java.util.Objects;

/**
 * Perk progression tracking for individual perks.
 */
public class PerkProgress {
    
    private String perkId;
    private int tier; // 1-3
    private boolean unlocked;
    private Instant unlockTime;
    private int timesUsed;
    private int successCount;
    private int failureCount;
    private Instant lastUsed;
    private double effectiveness; // 0.0 - 1.0
    private boolean favorite;
    
    public PerkProgress() {
        this.perkId = "";
        this.tier = 1;
        this.unlocked = false;
        this.unlockTime = Instant.now();
        this.timesUsed = 0;
        this.successCount = 0;
        this.failureCount = 0;
        this.lastUsed = Instant.now();
        this.effectiveness = 0.5; // Default
        this.favorite = false;
    }
    
    public PerkProgress(String perkId, int tier, boolean unlocked, Instant unlockTime) {
        this();
        this.perkId = perkId;
        this.tier = Math.max(1, Math.min(3, tier));
        this.unlocked = unlocked;
        this.unlockTime = unlockTime != null ? unlockTime : Instant.now();
    }
    
    // Getters and setters
    public String getPerkId() { return perkId; }
    public void setPerkId(String perkId) { this.perkId = perkId; }
    
    public int getTier() { return tier; }
    public void setTier(int tier) { 
        this.tier = Math.max(1, Math.min(3, tier));
    }
    
    public boolean isUnlocked() { return unlocked; }
    public void setUnlocked(boolean unlocked) { 
        this.unlocked = unlocked;
        if (unlocked && unlockTime == null) {
            unlockTime = Instant.now();
        }
    }
    
    public Instant getUnlockTime() { return unlockTime; }
    public void setUnlockTime(Instant unlockTime) { this.unlockTime = unlockTime; }
    
    public int getTimesUsed() { return timesUsed; }
    public void setTimesUsed(int timesUsed) { this.timesUsed = Math.max(0, timesUsed); }
    
    public int getSuccessCount() { return successCount; }
    public void setSuccessCount(int successCount) { this.successCount = Math.max(0, successCount); }
    
    public int getFailureCount() { return failureCount; }
    public void setFailureCount(int failureCount) { this.failureCount = Math.max(0, failureCount); }
    
    public Instant getLastUsed() { return lastUsed; }
    public void setLastUsed(Instant lastUsed) { this.lastUsed = lastUsed; }
    
    public double getEffectiveness() { return effectiveness; }
    public void setEffectiveness(double effectiveness) { 
        this.effectiveness = Math.max(0.0, Math.min(1.0, effectiveness));
    }
    
    public boolean isFavorite() { return favorite; }
    public void setFavorite(boolean favorite) { this.favorite = favorite; }
    
    // Helper methods
    public void unlock() {
        if (!unlocked) {
            unlocked = true;
            unlockTime = Instant.now();
            tier = 1; // Start at tier 1
        }
    }
    
    public boolean canUpgrade() {
        return unlocked && tier < 3;
    }
    
    public boolean upgrade() {
        if (canUpgrade()) {
            tier++;
            return true;
        }
        return false;
    }
    
    public void use(boolean success) {
        timesUsed++;
        if (success) {
            successCount++;
        } else {
            failureCount++;
        }
        lastUsed = Instant.now();
        
        // Update effectiveness based on success rate
        if (timesUsed > 0) {
            effectiveness = (double) successCount / timesUsed;
        }
    }
    
    public double getSuccessRate() {
        if (timesUsed == 0) return 0.0;
        return (double) successCount / timesUsed;
    }
    
    public int getTotalUses() {
        return timesUsed;
    }
    
    public long getDaysSinceUnlock() {
        if (unlockTime == null) return 0;
        return Instant.now().getEpochSecond() - unlockTime.getEpochSecond() / (24 * 3600);
    }
    
    public long getDaysSinceLastUse() {
        if (lastUsed == null) return Long.MAX_VALUE;
        return Instant.now().getEpochSecond() - lastUsed.getEpochSecond() / (24 * 3600);
    }
    
    public boolean isRecentlyUsed(int daysThreshold) {
        return getDaysSinceLastUse() <= daysThreshold;
    }
    
    public double getTierEffectiveness() {
        // Base effectiveness modified by tier
        return effectiveness * (0.8 + (tier * 0.1)); // Tier 1: 90%, Tier 2: 100%, Tier 3: 110%
    }
    
    public String getTierName() {
        switch (tier) {
            case 1: return "I";
            case 2: return "II";
            case 3: return "III";
            default: return String.valueOf(tier);
        }
    }
    
    public String getStatus() {
        if (!unlocked) return "LOCKED";
        if (timesUsed == 0) return "NEW";
        if (getSuccessRate() > 0.8) return "MASTERED";
        if (getSuccessRate() > 0.6) return "PROFICIENT";
        if (getSuccessRate() > 0.4) return "LEARNING";
        return "BEGINNER";
    }
    
    public void resetStats() {
        timesUsed = 0;
        successCount = 0;
        failureCount = 0;
        effectiveness = 0.5;
        lastUsed = Instant.now();
    }
    
    public PerkProgress copy() {
        PerkProgress copy = new PerkProgress();
        copy.perkId = this.perkId;
        copy.tier = this.tier;
        copy.unlocked = this.unlocked;
        copy.unlockTime = this.unlockTime;
        copy.timesUsed = this.timesUsed;
        copy.successCount = this.successCount;
        copy.failureCount = this.failureCount;
        copy.lastUsed = this.lastUsed;
        copy.effectiveness = this.effectiveness;
        copy.favorite = this.favorite;
        return copy;
    }
    
    @Override
    public String toString() {
        return "PerkProgress{" +
               "perkId='" + perkId + '\'' +
               ", tier=" + getTierName() +
               ", unlocked=" + unlocked +
               ", status='" + getStatus() + '\'' +
               ", successRate=" + String.format("%.1f%%", getSuccessRate() * 100) +
               ", timesUsed=" + timesUsed +
               ", effectiveness=" + String.format("%.1f%%", effectiveness * 100) +
               ", favorite=" + favorite +
               ", daysSinceUnlock=" + getDaysSinceUnlock() +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PerkProgress that = (PerkProgress) o;
        return Objects.equals(perkId, that.perkId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(perkId);
    }
}
package ru.metalpipe.dbdamp.database.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Prestige rank system for advanced player progression.
 */
public class PrestigeRank {
    
    private int rank;
    private int timesPrestiged;
    private Instant lastPrestigeTime;
    private List<PrestigeReward> rewards;
    private int prestigePoints;
    private int totalPrestigeExperience;
    
    public PrestigeRank() {
        this.rank = 0;
        this.timesPrestiged = 0;
        this.lastPrestigeTime = Instant.now();
        this.rewards = new ArrayList<>();
        this.prestigePoints = 0;
        this.totalPrestigeExperience = 0;
    }
    
    // Getters and setters
    public int getRank() { return rank; }
    public void setRank(int rank) { this.rank = Math.max(0, rank); }
    
    public int getTimesPrestiged() { return timesPrestiged; }
    public void setTimesPrestiged(int timesPrestiged) { this.timesPrestiged = Math.max(0, timesPrestiged); }
    
    public Instant getLastPrestigeTime() { return lastPrestigeTime; }
    public void setLastPrestigeTime(Instant lastPrestigeTime) { this.lastPrestigeTime = lastPrestigeTime; }
    
    public List<PrestigeReward> getRewards() { return rewards; }
    public void setRewards(List<PrestigeReward> rewards) { this.rewards = rewards; }
    
    public int getPrestigePoints() { return prestigePoints; }
    public void setPrestigePoints(int prestigePoints) { this.prestigePoints = Math.max(0, prestigePoints); }
    
    public int getTotalPrestigeExperience() { return totalPrestigeExperience; }
    public void setTotalPrestigeExperience(int totalPrestigeExperience) { 
        this.totalPrestigeExperience = Math.max(0, totalPrestigeExperience); 
    }
    
    // Helper methods
    public boolean canPrestige(PlayerLevel playerLevel) {
        return playerLevel.getLevel() >= getMaxLevelForPrestige() && 
               rank < getMaxPrestigeRank();
    }
    
    public void prestige(PlayerLevel playerLevel) {
        if (!canPrestige(playerLevel)) {
            return;
        }
        
        // Reset player level but keep some benefits
        int oldLevel = playerLevel.getLevel();
        playerLevel.reset();
        
        // Increment prestige
        this.rank++;
        this.timesPrestiged++;
        this.lastPrestigeTime = Instant.now();
        
        // Calculate prestige rewards
        int prestigeExperience = calculatePrestigeExperience(oldLevel);
        this.totalPrestigeExperience += prestigeExperience;
        this.prestigePoints += calculatePrestigePoints(rank);
        
        // Grant prestige rewards
        PrestigeReward reward = createPrestigeReward(rank);
        if (reward != null) {
            rewards.add(reward);
        }
    }
    
    public void addPrestigePoints(int points) {
        this.prestigePoints += Math.max(0, points);
    }
    
    public boolean spendPrestigePoints(int points) {
        if (prestigePoints >= points) {
            prestigePoints -= points;
            return true;
        }
        return false;
    }
    
    public void addPrestigeExperience(int experience) {
        this.totalPrestigeExperience += Math.max(0, experience);
    }
    
    public int getPrestigeLevel() {
        // Calculate prestige level based on total experience
        return (int) Math.floor(Math.sqrt(totalPrestigeExperience / 1000.0));
    }
    
    public double getPrestigeProgress() {
        int currentLevel = getPrestigeLevel();
        int nextLevelExp = (int) Math.pow(currentLevel + 1, 2) * 1000;
        int currentLevelExp = (int) Math.pow(currentLevel, 2) * 1000;
        
        if (nextLevelExp == currentLevelExp) return 1.0;
        
        return (double) (totalPrestigeExperience - currentLevelExp) / 
               (nextLevelExp - currentLevelExp);
    }
    
    public boolean hasPrestigeReward(String rewardId) {
        return rewards.stream().anyMatch(r -> r.getRewardId().equals(rewardId));
    }
    
    public PrestigeReward getPrestigeReward(String rewardId) {
        return rewards.stream()
            .filter(r -> r.getRewardId().equals(rewardId))
            .findFirst()
            .orElse(null);
    }
    
    public void claimReward(String rewardId) {
        PrestigeReward reward = getPrestigeReward(rewardId);
        if (reward != null && !reward.isClaimed()) {
            reward.setClaimed(true);
            reward.setClaimedAt(Instant.now());
        }
    }
    
    // Static helper methods
    public static int getMaxPrestigeRank() {
        return 100; // Configurable
    }
    
    public static int getMaxLevelForPrestige() {
        return 50; // Configurable - level required to prestige
    }
    
    public static int calculatePrestigeExperience(int playerLevel) {
        // More experience for higher levels
        return playerLevel * 100;
    }
    
    public static int calculatePrestigePoints(int prestigeRank) {
        // More points for higher prestige ranks
        return prestigeRank * 10;
    }
    
    private PrestigeReward createPrestigeReward(int prestigeRank) {
        PrestigeReward reward = new PrestigeReward();
        reward.setRewardId("prestige_" + prestigeRank);
        reward.setPrestigeRank(prestigeRank);
        reward.setRewardType(getRewardTypeForPrestige(prestigeRank));
        reward.setRewardData(getRewardDataForPrestige(prestigeRank));
        reward.setClaimed(false);
        reward.setCreatedAt(Instant.now());
        return reward;
    }
    
    private String getRewardTypeForPrestige(int prestigeRank) {
        if (prestigeRank % 10 == 0) {
            return "EXCLUSIVE_COSMETIC";
        } else if (prestigeRank % 5 == 0) {
            return "PERK_UNLOCK";
        } else if (prestigeRank % 3 == 0) {
            return "BLOODPOINT_MULTIPLIER";
        } else {
            return "PRESTIGE_POINTS";
        }
    }
    
    private String getRewardDataForPrestige(int prestigeRank) {
        switch (getRewardTypeForPrestige(prestigeRank)) {
            case "EXCLUSIVE_COSMETIC":
                return "exclusive_prestige_" + prestigeRank;
            case "PERK_UNLOCK":
                return "prestige_perk_" + (prestigeRank / 5);
            case "BLOODPOINT_MULTIPLIER":
                return String.valueOf(1.0 + (prestigeRank * 0.01));
            case "PRESTIGE_POINTS":
                return String.valueOf(prestigeRank * 5);
            default:
                return "";
        }
    }
    
    @Override
    public String toString() {
        return "PrestigeRank{" +
               "rank=" + rank +
               ", timesPrestiged=" + timesPrestiged +
               ", lastPrestigeTime=" + lastPrestigeTime +
               ", prestigePoints=" + prestigePoints +
               ", totalPrestigeExperience=" + totalPrestigeExperience +
               ", prestigeLevel=" + getPrestigeLevel() +
               ", progress=" + String.format("%.1f%%", getPrestigeProgress() * 100) +
               ", rewards=" + rewards.size() +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PrestigeRank that = (PrestigeRank) o;
        return rank == that.rank && timesPrestiged == that.timesPrestiged;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(rank, timesPrestiged);
    }
}
package ru.metalpipe.dbdamp.database.dao;

import ru.metalpipe.dbdamp.database.DatabaseManager;
import ru.metalpipe.dbdamp.database.model.*;
import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.logging.Logger;

/**
 * Data Access Object for PlayerProfile entities.
 * Provides CRUD operations and specialized queries for player data.
 */
public class PlayerProfileDAO {
    
    private final DatabaseManager dbManager;
    private final Logger logger;
    
    public PlayerProfileDAO(DatabaseManager dbManager, Logger logger) {
        this.dbManager = dbManager;
        this.logger = logger;
        initializeTables();
    }
    
    /**
     * Initialize database tables if they don't exist.
     */
    private void initializeTables() {
        try {
            // Create player_profiles table
            String createProfilesTable = """
                CREATE TABLE IF NOT EXISTS player_profiles (
                    player_id VARCHAR(36) PRIMARY KEY,
                    username VARCHAR(32) NOT NULL,
                    level INT NOT NULL DEFAULT 1,
                    experience INT NOT NULL DEFAULT 0,
                    prestige_rank INT NOT NULL DEFAULT 0,
                    prestige_points INT NOT NULL DEFAULT 0,
                    bloodpoints_amount INT NOT NULL DEFAULT 0,
                    bloodpoints_earned INT NOT NULL DEFAULT 0,
                    bloodpoints_spent INT NOT NULL DEFAULT 0,
                    created_at TIMESTAMP NOT NULL,
                    last_played TIMESTAMP NOT NULL,
                    metadata TEXT,
                    INDEX idx_username (username),
                    INDEX idx_last_played (last_played)
                )
                """;
            
            dbManager.update(createProfilesTable);
            
            // Create player_perks table
            String createPerksTable = """
                CREATE TABLE IF NOT EXISTS player_perks (
                    id VARCHAR(36) PRIMARY KEY,
                    player_id VARCHAR(36) NOT NULL,
                    perk_id VARCHAR(64) NOT NULL,
                    tier INT NOT NULL DEFAULT 1,
                    unlocked BOOLEAN NOT NULL DEFAULT FALSE,
                    unlock_time TIMESTAMP,
                    times_used INT NOT NULL DEFAULT 0,
                    success_count INT NOT NULL DEFAULT 0,
                    failure_count INT NOT NULL DEFAULT 0,
                    last_used TIMESTAMP,
                    effectiveness FLOAT NOT NULL DEFAULT 0.5,
                    favorite BOOLEAN NOT NULL DEFAULT FALSE,
                    FOREIGN KEY (player_id) REFERENCES player_profiles(player_id) ON DELETE CASCADE,
                    INDEX idx_player_perk (player_id, perk_id),
                    INDEX idx_unlocked (unlocked)
                )
                """;
            
            dbManager.update(createPerksTable);
            
            // Create player_unlocks table
            String createUnlocksTable = """
                CREATE TABLE IF NOT EXISTS player_unlocks (
                    id VARCHAR(36) PRIMARY KEY,
                    player_id VARCHAR(36) NOT NULL,
                    content_id VARCHAR(64) NOT NULL,
                    unlocked_at TIMESTAMP NOT NULL,
                    FOREIGN KEY (player_id) REFERENCES player_profiles(player_id) ON DELETE CASCADE,
                    UNIQUE KEY unique_player_content (player_id, content_id)
                )
                """;
            
            dbManager.update(createUnlocksTable);
            
            // Create player_statistics table
            String createStatsTable = """
                CREATE TABLE IF NOT EXISTS player_statistics (
                    player_id VARCHAR(36) PRIMARY KEY,
                    matches_played INT NOT NULL DEFAULT 0,
                    matches_won INT NOT NULL DEFAULT 0,
                    matches_lost INT NOT NULL DEFAULT 0,
                    escapes INT NOT NULL DEFAULT 0,
                    kills INT NOT NULL DEFAULT 0,
                    generators_repaired INT NOT NULL DEFAULT 0,
                    hooks INT NOT NULL DEFAULT 0,
                    rescues INT NOT NULL DEFAULT 0,
                    heals INT NOT NULL DEFAULT 0,
                    stuns INT NOT NULL DEFAULT 0,
                    time_played BIGINT NOT NULL DEFAULT 0,
                    best_match_score INT NOT NULL DEFAULT 0,
                    average_match_score FLOAT NOT NULL DEFAULT 0.0,
                    FOREIGN KEY (player_id) REFERENCES player_profiles(player_id) ON DELETE CASCADE
                )
                """;
            
            dbManager.update(createStatsTable);
            
            logger.info("Player profile tables initialized successfully");
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.severe("Failed to initialize player profile tables: " + e.getMessage());
        }
    }
    
    /**
     * Create or update a player profile.
     * 
     * @param profile The player profile to save
     * @return true if successful, false otherwise
     */
    public boolean save(PlayerProfile profile) {
        try {
            return dbManager.executeTransaction(conn -> {
                // Update last played timestamp
                profile.updateLastPlayed();
                
                // Save main profile
                saveProfile(conn, profile);
                
                // Save perks
                savePerks(conn, profile);
                
                // Save unlocks
                saveUnlocks(conn, profile);
                
                // Save statistics
                saveStatistics(conn, profile);
                
                return true;
            });
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to save player profile: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Find a player profile by player ID.
     * 
     * @param playerId The player UUID
     * @return The player profile or null if not found
     */
    public PlayerProfile findById(UUID playerId) {
        String sql = "SELECT * FROM player_profiles WHERE player_id = ?";
        
        try {
            return dbManager.query(sql, rs -> {
                if (rs.next()) {
                    return mapProfile(rs);
                }
                return null;
            }, playerId.toString());
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to find player profile by ID: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Find a player profile by username.
     * 
     * @param username The player username
     * @return The player profile or null if not found
     */
    public PlayerProfile findByUsername(String username) {
        String sql = "SELECT * FROM player_profiles WHERE username = ?";
        
        try {
            return dbManager.query(sql, rs -> {
                if (rs.next()) {
                    return mapProfile(rs);
                }
                return null;
            }, username);
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to find player profile by username: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Check if a player profile exists.
     * 
     * @param playerId The player UUID
     * @return true if exists, false otherwise
     */
    public boolean exists(UUID playerId) {
        String sql = "SELECT COUNT(*) as count FROM player_profiles WHERE player_id = ?";
        
        try {
            Integer count = dbManager.query(sql, rs -> {
                if (rs.next()) {
                    return rs.getInt("count");
                }
                return 0;
            }, playerId.toString());
            
            return count != null && count > 0;
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to check if player exists: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Delete a player profile.
     * 
     * @param playerId The player UUID
     * @return true if deleted, false otherwise
     */
    public boolean delete(UUID playerId) {
        String sql = "DELETE FROM player_profiles WHERE player_id = ?";
        
        try {
            int affected = dbManager.update(sql, playerId.toString());
            return affected > 0;
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to delete player profile: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get all player profiles (paginated).
     * 
     * @param offset The offset for pagination
     * @param limit The limit for pagination
     * @return List of player profiles
     */
    public List<PlayerProfile> findAll(int offset, int limit) {
        String sql = "SELECT * FROM player_profiles ORDER BY last_played DESC LIMIT ? OFFSET ?";
        
        try {
            return dbManager.query(sql, rs -> {
                List<PlayerProfile> profiles = new ArrayList<>();
                while (rs.next()) {
                    profiles.add(mapProfile(rs));
                }
                return profiles;
            }, limit, offset);
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to find all player profiles: " + e.getMessage());
            return Collections.emptyList();
        }
    }
    
    /**
     * Count total player profiles.
     * 
     * @return Total count
     */
    public int countAll() {
        String sql = "SELECT COUNT(*) as count FROM player_profiles";
        
        try {
            Integer count = dbManager.query(sql, rs -> {
                if (rs.next()) {
                    return rs.getInt("count");
                }
                return 0;
            });
            
            return count != null ? count : 0;
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to count player profiles: " + e.getMessage());
            return 0;
        }
    }
    
    /**
     * Search player profiles by username (partial match).
     * 
     * @param usernamePartial Partial username to search for
     * @param limit Maximum results to return
     * @return List of matching player profiles
     */
    public List<PlayerProfile> searchByUsername(String usernamePartial, int limit) {
        String sql = "SELECT * FROM player_profiles WHERE username LIKE ? ORDER BY username LIMIT ?";
        
        try {
            return dbManager.query(sql, rs -> {
                List<PlayerProfile> profiles = new ArrayList<>();
                while (rs.next()) {
                    profiles.add(mapProfile(rs));
                }
                return profiles;
            }, "%" + usernamePartial + "%", limit);
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to search player profiles: " + e.getMessage());
            return Collections.emptyList();
        }
    }
    
    /**
     * Get top players by bloodpoints.
     * 
     * @param limit Maximum results to return
     * @return List of top players
     */
    public List<PlayerProfile> getTopByBloodpoints(int limit) {
        String sql = "SELECT * FROM player_profiles ORDER BY bloodpoints_amount DESC LIMIT ?";
        
        try {
            return dbManager.query(sql, rs -> {
                List<PlayerProfile> profiles = new ArrayList<>();
                while (rs.next()) {
                    profiles.add(mapProfile(rs));
                }
                return profiles;
            }, limit);
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to get top players by bloodpoints: " + e.getMessage());
            return Collections.emptyList();
        }
    }
    
    /**
     * Get top players by level.
     * 
     * @param limit Maximum results to return
     * @return List of top players
     */
    public List<PlayerProfile> getTopByLevel(int limit) {
        String sql = "SELECT * FROM player_profiles ORDER BY level DESC, experience DESC LIMIT ?";
        
        try {
            return dbManager.query(sql, rs -> {
                List<PlayerProfile> profiles = new ArrayList<>();
                while (rs.next()) {
                    profiles.add(mapProfile(rs));
                }
                return profiles;
            }, limit);
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to get top players by level: " + e.getMessage());
            return Collections.emptyList();
        }
    }
    
    /**
     * Get recently active players.
     * 
     * @param days Number of days to look back
     * @param limit Maximum results to return
     * @return List of recently active players
     */
    public List<PlayerProfile> getRecentlyActive(int days, int limit) {
        String sql = """
            SELECT * FROM player_profiles 
            WHERE last_played >= DATE_SUB(NOW(), INTERVAL ? DAY)
            ORDER BY last_played DESC LIMIT ?
            """;
        
        try {
            return dbManager.query(sql, rs -> {
                List<PlayerProfile> profiles = new ArrayList<>();
                while (rs.next()) {
                    profiles.add(mapProfile(rs));
                }
                return profiles;
            }, days, limit);
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to get recently active players: " + e.getMessage());
            return Collections.emptyList();
        }
    }
    
    /**
     * Update player's last played timestamp.
     * 
     * @param playerId The player UUID
     * @return true if updated, false otherwise
     */
    public boolean updateLastPlayed(UUID playerId) {
        String sql = "UPDATE player_profiles SET last_played = ? WHERE player_id = ?";
        
        try {
            int affected = dbManager.update(sql, Timestamp.from(Instant.now()), playerId.toString());
            return affected > 0;
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to update last played: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Add bloodpoints to a player.
     * 
     * @param playerId The player UUID
     * @param amount Amount to add
     * @return true if successful, false otherwise
     */
    public boolean addBloodpoints(UUID playerId, int amount) {
        if (amount <= 0) return true;
        
        String sql = """
            UPDATE player_profiles 
            SET bloodpoints_amount = bloodpoints_amount + ?, 
                bloodpoints_earned = bloodpoints_earned + ?
            WHERE player_id = ?
            """;
        
        try {
            int affected = dbManager.update(sql, amount, amount, playerId.toString());
            return affected > 0;
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to add bloodpoints: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Spend bloodpoints from a player.
     * 
     * @param playerId The player UUID
     * @param amount Amount to spend
     * @return true if successful (player had enough), false otherwise
     */
    public boolean spendBloodpoints(UUID playerId, int amount) {
        if (amount <= 0) return true;
        
        String sql = """
            UPDATE player_profiles 
            SET bloodpoints_amount = bloodpoints_amount - ?, 
                bloodpoints_spent = bloodpoints_spent + ?
            WHERE player_id = ? AND bloodpoints_amount >= ?
            """;
        
        try {
            int affected = dbManager.update(sql, amount, amount, playerId.toString(), amount);
            return affected > 0;
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to spend bloodpoints: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Add experience to a player.
     * 
     * @param playerId The player UUID
     * @param experience Amount to add
     * @return true if successful, false otherwise
     */
    public boolean addExperience(UUID playerId, int experience) {
        if (experience <= 0) return true;
        
        String sql = "UPDATE player_profiles SET experience = experience + ? WHERE player_id = ?";
        
        try {
            int affected = dbManager.update(sql, experience, playerId.toString());
            return affected > 0;
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to add experience: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Level up a player.
     * 
     * @param playerId The player UUID
     * @return true if leveled up, false otherwise
     */
    public boolean levelUp(UUID playerId) {
        String sql = """
            UPDATE player_profiles 
            SET level = level + 1, 
                experience = experience - experience_to_next,
                bloodpoints_amount = bloodpoints_amount + (level * 100)
            WHERE player_id = ? AND experience >= experience_to_next
            """;
        
        try {
            int affected = dbManager.update(sql, playerId.toString());
            return affected > 0;
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to level up player: " + e.getMessage());
            return false;
        }
    }
    
    // Private helper methods
    
    private void saveProfile(Connection conn, PlayerProfile profile) throws SQLException {
        String sql = """
            INSERT INTO player_profiles (
                player_id, username, level, experience, prestige_rank, prestige_points,
                bloodpoints_amount, bloodpoints_earned, bloodpoints_spent,
                created_at, last_played, metadata
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                username = VALUES(username),
                level = VALUES(level),
                experience = VALUES(experience),
                prestige_rank = VALUES(prestige_rank),
                prestige_points = VALUES(prestige_points),
                bloodpoints_amount = VALUES(bloodpoints_amount),
                bloodpoints_earned = VALUES(bloodpoints_earned),
                bloodpoints_spent = VALUES(bloodpoints_spent),
                last_played = VALUES(last_played),
                metadata = VALUES(metadata)
            """;
        
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            int idx = 1;
            stmt.setString(idx++, profile.getPlayerId().toString());
            stmt.setString(idx++, profile.getUsername());
            stmt.setInt(idx++, profile.getLevel().getLevel());
            stmt.setInt(idx++, profile.getLevel().getExperience());
            stmt.setInt(idx++, profile.getPrestige().getRank());
            stmt.setInt(idx++, profile.getPrestige().getPrestigePoints());
            stmt.setInt(idx++, profile.getBalance().getAmount());
            stmt.setInt(idx++, profile.getBalance().getTotalEarned());
            stmt.setInt(idx++, profile.getBalance().getTotalSpent());
            stmt.setTimestamp(idx++, Timestamp.from(profile.getCreatedAt()));
            stmt.setTimestamp(idx++, Timestamp.from(profile.getLastPlayed()));
            stmt.setString(idx, serializeMetadata(profile.getMetadata()));
            
            stmt.executeUpdate();
        }
    }
    
    private void savePerks(Connection conn, PlayerProfile profile) throws SQLException {
        // First, delete existing perks for this player
        String deleteSql = "DELETE FROM player_perks WHERE player_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(deleteSql)) {
            stmt.setString(1, profile.getPlayerId().toString());
            stmt.executeUpdate();
        }
        
        // Then insert current perks
        String insertSql = """
            INSERT INTO player_perks (
                id, player_id, perk_id, tier, unlocked, unlock_time,
                times_used, success_count, failure_count, last_used,
                effectiveness, favorite
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;
        
        try (PreparedStatement stmt = conn.prepareStatement(insertSql)) {
            for (PerkProgress perk : profile.getPerkProgress().values()) {
                int idx = 1;
                stmt.setString(idx++, UUID.randomUUID().toString());
                stmt.setString(idx++, profile.getPlayerId().toString());
                stmt.setString(idx++, perk.getPerkId());
                stmt.setInt(idx++, perk.getTier());
                stmt.setBoolean(idx++, perk.isUnlocked());
                stmt.setTimestamp(idx++, perk.getUnlockTime() != null ? 
                    Timestamp.from(perk.getUnlockTime()) : null);
                stmt.setInt(idx++, perk.getTimesUsed());
                stmt.setInt(idx++, perk.getSuccessCount());
                stmt.setInt(idx++, perk.getFailureCount());
                stmt.setTimestamp(idx++, perk.getLastUsed() != null ? 
                    Timestamp.from(perk.getLastUsed()) : null);
                stmt.setDouble(idx++, perk.getEffectiveness());
                stmt.setBoolean(idx, perk.isFavorite());
                
                stmt.addBatch();
            }
            
            stmt.executeBatch();
        }
    }
    
    private void saveUnlocks(Connection conn, PlayerProfile profile) throws SQLException {
        // First, delete existing unlocks for this player
        String deleteSql = "DELETE FROM player_unlocks WHERE player_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(deleteSql)) {
            stmt.setString(1, profile.getPlayerId().toString());
            stmt.executeUpdate();
        }
        
        // Then insert current unlocks
        String insertSql = "INSERT INTO player_unlocks (id, player_id, content_id, unlocked_at) VALUES (?, ?, ?, ?)";
        
        try (PreparedStatement stmt = conn.prepareStatement(insertSql)) {
            for (String contentId : profile.getUnlockedContent()) {
                int idx = 1;
                stmt.setString(idx++, UUID.randomUUID().toString());
                stmt.setString(idx++, profile.getPlayerId().toString());
                stmt.setString(idx++, contentId);
                stmt.setTimestamp(idx, Timestamp.from(Instant.now()));
                
                stmt.addBatch();
            }
            
            stmt.executeBatch();
        }
    }
    
    private void saveStatistics(Connection conn, PlayerProfile profile) throws SQLException {
        PlayerStatistics stats = profile.getStatistics();
        
        String sql = """
            INSERT INTO player_statistics (
                player_id, matches_played, matches_won, matches_lost,
                escapes, kills, generators_repaired, hooks, rescues, heals, stuns,
                time_played, best_match_score, average_match_score
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                matches_played = VALUES(matches_played),
                matches_won = VALUES(matches_won),
                matches_lost = VALUES(matches_lost),
                escapes = VALUES(escapes),
                kills = VALUES(kills),
                generators_repaired = VALUES(generators_repaired),
                hooks = VALUES(hooks),
                rescues = VALUES(rescues),
                heals = VALUES(heals),
                stuns = VALUES(stuns),
                time_played = VALUES(time_played),
                best_match_score = VALUES(best_match_score),
                average_match_score = VALUES(average_match_score)
            """;
        
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            int idx = 1;
            stmt.setString(idx++, profile.getPlayerId().toString());
            stmt.setInt(idx++, stats.getMatchesPlayed());
            stmt.setInt(idx++, stats.getMatchesWon());
            stmt.setInt(idx++, stats.getMatchesLost());
            stmt.setInt(idx++, stats.getEscapes());
            stmt.setInt(idx++, stats.getKills());
            stmt.setInt(idx++, stats.getGeneratorsRepaired());
            stmt.setInt(idx++, stats.getHooks());
            stmt.setInt(idx++, stats.getRescues());
            stmt.setInt(idx++, stats.getHeals());
            stmt.setInt(idx++, stats.getStuns());
            stmt.setLong(idx++, stats.getTimePlayed());
            stmt.setInt(idx++, stats.getBestMatchScore());
            stmt.setDouble(idx, stats.getAverageMatchScore());
            
            stmt.executeUpdate();
        }
    }
    
    private PlayerProfile mapProfile(ResultSet rs) throws SQLException {
        UUID playerId = UUID.fromString(rs.getString("player_id"));
        PlayerProfile profile = new PlayerProfile(playerId, rs.getString("username"));
        
        // Map level
        PlayerLevel level = new PlayerLevel(
            rs.getInt("level"),
            rs.getInt("experience")
        );
        profile.setLevel(level);
        
        // Map prestige
        PrestigeRank prestige = new PrestigeRank();
        prestige.setRank(rs.getInt("prestige_rank"));
        prestige.setPrestigePoints(rs.getInt("prestige_points"));
        profile.setPrestige(prestige);
        
        // Map bloodpoints
        Bloodpoints balance = new Bloodpoints();
        balance.setAmount(rs.getInt("bloodpoints_amount"));
        balance.setTotalEarned(rs.getInt("bloodpoints_earned"));
        balance.setTotalSpent(rs.getInt("bloodpoints_spent"));
        profile.setBalance(balance);
        
        // Map timestamps
        profile.setCreatedAt(rs.getTimestamp("created_at").toInstant());
        profile.setLastPlayed(rs.getTimestamp("last_played").toInstant());
        
        // Map metadata
        String metadataJson = rs.getString("metadata");
        if (metadataJson != null && !metadataJson.isEmpty()) {
            // In a real implementation, you would deserialize the JSON
            // For now, we'll leave it empty
        }
        
        // Load related data
        loadPerks(profile);
        loadUnlocks(profile);
        loadStatistics(profile);
        
        return profile;
    }
    
    private void loadPerks(PlayerProfile profile) {
        String sql = "SELECT * FROM player_perks WHERE player_id = ?";
        
        try {
            Map<String, PerkProgress> perks = dbManager.query(sql, rs -> {
                Map<String, PerkProgress> result = new HashMap<>();
                while (rs.next()) {
                    PerkProgress perk = new PerkProgress();
                    perk.setPerkId(rs.getString("perk_id"));
                    perk.setTier(rs.getInt("tier"));
                    perk.setUnlocked(rs.getBoolean("unlocked"));
                    
                    Timestamp unlockTime = rs.getTimestamp("unlock_time");
                    if (unlockTime != null) {
                        perk.setUnlockTime(unlockTime.toInstant());
                    }
                    
                    perk.setTimesUsed(rs.getInt("times_used"));
                    perk.setSuccessCount(rs.getInt("success_count"));
                    perk.setFailureCount(rs.getInt("failure_count"));
                    
                    Timestamp lastUsed = rs.getTimestamp("last_used");
                    if (lastUsed != null) {
                        perk.setLastUsed(lastUsed.toInstant());
                    }
                    
                    perk.setEffectiveness(rs.getDouble("effectiveness"));
                    perk.setFavorite(rs.getBoolean("favorite"));
                    
                    result.put(perk.getPerkId(), perk);
                }
                return result;
            }, profile.getPlayerId().toString());
            
            profile.setPerkProgress(perks);
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to load perks for player: " + e.getMessage());
        }
    }
    
    private void loadUnlocks(PlayerProfile profile) {
        String sql = "SELECT content_id FROM player_unlocks WHERE player_id = ?";
        
        try {
            Set<String> unlocks = dbManager.query(sql, rs -> {
                Set<String> result = new HashSet<>();
                while (rs.next()) {
                    result.add(rs.getString("content_id"));
                }
                return result;
            }, profile.getPlayerId().toString());
            
            profile.setUnlockedContent(unlocks);
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to load unlocks for player: " + e.getMessage());
        }
    }
    
    private void loadStatistics(PlayerProfile profile) {
        String sql = "SELECT * FROM player_statistics WHERE player_id = ?";
        
        try {
            PlayerStatistics stats = dbManager.query(sql, rs -> {
                if (rs.next()) {
                    PlayerStatistics result = new PlayerStatistics();
                    result.setMatchesPlayed(rs.getInt("matches_played"));
                    result.setMatchesWon(rs.getInt("matches_won"));
                    result.setMatchesLost(rs.getInt("matches_lost"));
                    result.setEscapes(rs.getInt("escapes"));
                    result.setKills(rs.getInt("kills"));
                    result.setGeneratorsRepaired(rs.getInt("generators_repaired"));
                    result.setHooks(rs.getInt("hooks"));
                    result.setRescues(rs.getInt("rescues"));
                    result.setHeals(rs.getInt("heals"));
                    result.setStuns(rs.getInt("stuns"));
                    result.setTimePlayed(rs.getLong("time_played"));
                    result.setBestMatchScore(rs.getInt("best_match_score"));
                    result.setAverageMatchScore(rs.getDouble("average_match_score"));
                    return result;
                }
                return new PlayerStatistics();
            }, profile.getPlayerId().toString());
            
            profile.setStatistics(stats);
            
        } catch (DatabaseManager.DatabaseException e) {
            logger.warning("Failed to load statistics for player: " + e.getMessage());
        }
    }
    
    private String serializeMetadata(Map<String, Object> metadata) {
        // In a real implementation, you would serialize to JSON
        // For now, return empty string
        return "";
    }
}
package ru.metalpipe.dbdamp.database.model;

import java.time.Instant;
import java.util.*;

/**
 * Player profile data model representing a player's progression, statistics, and unlocks.
 */
public class PlayerProfile {
    
    private UUID playerId;
    private String username;
    private PlayerLevel level;
    private PrestigeRank prestige;
    private Bloodpoints balance;
    private Map<String, PerkProgress> perkProgress;
    private PlayerStatistics statistics;
    private Set<String> unlockedContent;
    private Instant createdAt;
    private Instant lastPlayed;
    private Map<String, Object> metadata;
    
    public PlayerProfile() {
        this.playerId = UUID.randomUUID();
        this.username = "";
        this.level = new PlayerLevel();
        this.prestige = new PrestigeRank();
        this.balance = new Bloodpoints();
        this.perkProgress = new HashMap<>();
        this.statistics = new PlayerStatistics();
        this.unlockedContent = new HashSet<>();
        this.createdAt = Instant.now();
        this.lastPlayed = Instant.now();
        this.metadata = new HashMap<>();
    }
    
    public PlayerProfile(UUID playerId, String username) {
        this();
        this.playerId = playerId;
        this.username = username;
    }
    
    // Getters and setters
    public UUID getPlayerId() { return playerId; }
    public void setPlayerId(UUID playerId) { this.playerId = playerId; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public PlayerLevel getLevel() { return level; }
    public void setLevel(PlayerLevel level) { this.level = level; }
    
    public PrestigeRank getPrestige() { return prestige; }
    public void setPrestige(PrestigeRank prestige) { this.prestige = prestige; }
    
    public Bloodpoints getBalance() { return balance; }
    public void setBalance(Bloodpoints balance) { this.balance = balance; }
    
    public Map<String, PerkProgress> getPerkProgress() { return perkProgress; }
    public void setPerkProgress(Map<String, PerkProgress> perkProgress) { this.perkProgress = perkProgress; }
    
    public PlayerStatistics getStatistics() { return statistics; }
    public void setStatistics(PlayerStatistics statistics) { this.statistics = statistics; }
    
    public Set<String> getUnlockedContent() { return unlockedContent; }
    public void setUnlockedContent(Set<String> unlockedContent) { this.unlockedContent = unlockedContent; }
    
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    
    public Instant getLastPlayed() { return lastPlayed; }
    public void setLastPlayed(Instant lastPlayed) { this.lastPlayed = lastPlayed; }
    
    public Map<String, Object> getMetadata() { return metadata; }
    public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }
    
    // Helper methods
    public void addExperience(int experience) {
        level.addExperience(experience);
    }
    
    public void levelUp() {
        level.levelUp();
        // Grant level rewards
        balance.add(level.getLevel() * 100); // Example: 100 bloodpoints per level
    }
    
    public void addBloodpoints(int amount) {
        balance.add(amount);
    }
    
    public boolean spendBloodpoints(int amount) {
        return balance.spend(amount);
    }
    
    public void unlockPerk(String perkId) {
        PerkProgress progress = new PerkProgress(perkId, 1, true, Instant.now());
        perkProgress.put(perkId, progress);
    }
    
    public void upgradePerk(String perkId, int tier) {
        PerkProgress progress = perkProgress.get(perkId);
        if (progress != null && progress.getTier() < tier) {
            progress.setTier(tier);
        }
    }
    
    public void unlockContent(String contentId) {
        unlockedContent.add(contentId);
    }
    
    public boolean hasUnlockedContent(String contentId) {
        return unlockedContent.contains(contentId);
    }
    
    public void updateLastPlayed() {
        this.lastPlayed = Instant.now();
    }
    
    public void addMetadata(String key, Object value) {
        metadata.put(key, value);
    }
    
    public Object getMetadata(String key) {
        return metadata.get(key);
    }
    
    public void removeMetadata(String key) {
        metadata.remove(key);
    }
    
    @Override
    public String toString() {
        return "PlayerProfile{" +
               "playerId=" + playerId +
               ", username='" + username + '\'' +
               ", level=" + level +
               ", prestige=" + prestige +
               ", balance=" + balance +
               ", perkProgress=" + perkProgress.size() + " perks" +
               ", statistics=" + statistics +
               ", unlockedContent=" + unlockedContent.size() + " items" +
               ", createdAt=" + createdAt +
               ", lastPlayed=" + lastPlayed +
               ", metadata=" + metadata.size() + " entries" +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PlayerProfile that = (PlayerProfile) o;
        return Objects.equals(playerId, that.playerId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(playerId);
    }
}
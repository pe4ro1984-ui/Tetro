package ru.metalpipe.dbdamp.database.model;

import java.time.Instant;
import java.util.Objects;

/**
 * Prestige reward for advanced player progression.
 */
public class PrestigeReward {
    
    private String rewardId;
    private int prestigeRank;
    private String rewardType;
    private String rewardData;
    private boolean claimed;
    private Instant claimedAt;
    private Instant createdAt;
    
    public PrestigeReward() {
        this.rewardId = "";
        this.prestigeRank = 1;
        this.rewardType = "";
        this.rewardData = "";
        this.claimed = false;
        this.claimedAt = Instant.now();
        this.createdAt = Instant.now();
    }
    
    public PrestigeReward(String rewardId, int prestigeRank, String rewardType, String rewardData) {
        this();
        this.rewardId = rewardId;
        this.prestigeRank = Math.max(1, prestigeRank);
        this.rewardType = rewardType;
        this.rewardData = rewardData;
    }
    
    // Getters and setters
    public String getRewardId() { return rewardId; }
    public void setRewardId(String rewardId) { this.rewardId = rewardId; }
    
    public int getPrestigeRank() { return prestigeRank; }
    public void setPrestigeRank(int prestigeRank) { this.prestigeRank = Math.max(1, prestigeRank); }
    
    public String getRewardType() { return rewardType; }
    public void setRewardType(String rewardType) { this.rewardType = rewardType; }
    
    public String getRewardData() { return rewardData; }
    public void setRewardData(String rewardData) { this.rewardData = rewardData; }
    
    public boolean isClaimed() { return claimed; }
    public void setClaimed(boolean claimed) { 
        this.claimed = claimed;
        if (claimed && claimedAt == null) {
            claimedAt = Instant.now();
        }
    }
    
    public Instant getClaimedAt() { return claimedAt; }
    public void setClaimedAt(Instant claimedAt) { this.claimedAt = claimedAt; }
    
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    
    // Helper methods
    public void claim() {
        if (!claimed) {
            claimed = true;
            claimedAt = Instant.now();
        }
    }
    
    public boolean canClaim(int playerPrestigeRank) {
        return !claimed && playerPrestigeRank >= prestigeRank;
    }
    
    public String getDisplayName() {
        switch (rewardType) {
            case "EXCLUSIVE_COSMETIC":
                return "Exclusive Prestige " + prestigeRank + " Cosmetic";
            case "PERK_UNLOCK":
                return "Prestige Perk Unlock";
            case "BLOODPOINT_MULTIPLIER":
                return "Bloodpoint Multiplier: " + rewardData + "x";
            case "PRESTIGE_POINTS":
                return "Prestige Points: " + rewardData;
            case "TITLE":
                return "Prestige Title: " + rewardData;
            case "EMOTE":
                return "Prestige Emote: " + rewardData;
            case "ANIMATION":
                return "Prestige Animation: " + rewardData;
            default:
                return "Prestige Reward " + prestigeRank;
        }
    }
    
    public String getDescription() {
        switch (rewardType) {
            case "EXCLUSIVE_COSMETIC":
                return "An exclusive cosmetic item only available at prestige rank " + prestigeRank;
            case "PERK_UNLOCK":
                return "Unlocks a special prestige perk";
            case "BLOODPOINT_MULTIPLIER":
                return "Permanently increases bloodpoint earnings by " + rewardData + "x";
            case "PRESTIGE_POINTS":
                return "Grants " + rewardData + " prestige points for the prestige shop";
            case "TITLE":
                return "Unlocks the title: " + rewardData;
            case "EMOTE":
                return "Unlocks a special emote: " + rewardData;
            case "ANIMATION":
                return "Unlocks a special animation: " + rewardData;
            default:
                return "A reward for reaching prestige rank " + prestigeRank;
        }
    }
    
    public int getPrestigePointsAmount() {
        if ("PRESTIGE_POINTS".equals(rewardType)) {
            try {
                return Integer.parseInt(rewardData);
            } catch (NumberFormatException e) {
                return 0;
            }
        }
        return 0;
    }
    
    public double getMultiplierAmount() {
        if ("BLOODPOINT_MULTIPLIER".equals(rewardType)) {
            try {
                return Double.parseDouble(rewardData);
            } catch (NumberFormatException e) {
                return 1.0;
            }
        }
        return 1.0;
    }
    
    public boolean isExclusive() {
        return "EXCLUSIVE_COSMETIC".equals(rewardType) || 
               "TITLE".equals(rewardType) || 
               "EMOTE".equals(rewardType) || 
               "ANIMATION".equals(rewardType);
    }
    
    public boolean isPermanent() {
        return !"PRESTIGE_POINTS".equals(rewardType);
    }
    
    public long getDaysSinceCreated() {
        return (Instant.now().getEpochSecond() - createdAt.getEpochSecond()) / (24 * 3600);
    }
    
    public long getDaysSinceClaimed() {
        if (claimedAt == null) return 0;
        return (Instant.now().getEpochSecond() - claimedAt.getEpochSecond()) / (24 * 3600);
    }
    
    public String getRarity() {
        if (prestigeRank >= 50) return "LEGENDARY";
        if (prestigeRank >= 25) return "EPIC";
        if (prestigeRank >= 10) return "RARE";
        if (prestigeRank >= 5) return "UNCOMMON";
        return "COMMON";
    }
    
    public String getStatus() {
        if (claimed) {
            return "CLAIMED (" + getDaysSinceClaimed() + " days ago)";
        } else {
            return "AVAILABLE (Requires Prestige " + prestigeRank + ")";
        }
    }
    
    public boolean isSpecial() {
        return prestigeRank % 10 == 0 || prestigeRank % 25 == 0 || prestigeRank == 100;
    }
    
    public String getSpecialType() {
        if (prestigeRank == 100) return "MAX_PRESTIGE";
        if (prestigeRank % 25 == 0) return "QUARTER_CENTURY";
        if (prestigeRank % 10 == 0) return "DECADE";
        return "REGULAR";
    }
    
    public PrestigeReward copy() {
        PrestigeReward copy = new PrestigeReward();
        copy.rewardId = this.rewardId;
        copy.prestigeRank = this.prestigeRank;
        copy.rewardType = this.rewardType;
        copy.rewardData = this.rewardData;
        copy.claimed = this.claimed;
        copy.claimedAt = this.claimedAt;
        copy.createdAt = this.createdAt;
        return copy;
    }
    
    @Override
    public String toString() {
        return "PrestigeReward{" +
               "rewardId='" + rewardId + '\'' +
               ", prestigeRank=" + prestigeRank +
               ", rewardType='" + rewardType + '\'' +
               ", rarity='" + getRarity() + '\'' +
               ", claimed=" + claimed +
               ", status='" + getStatus() + '\'' +
               ", displayName='" + getDisplayName() + '\'' +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PrestigeReward that = (PrestigeReward) o;
        return Objects.equals(rewardId, that.rewardId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(rewardId);
    }
}
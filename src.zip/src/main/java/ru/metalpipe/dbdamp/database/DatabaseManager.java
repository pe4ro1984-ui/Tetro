package ru.metalpipe.dbdamp.database;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Interface for database management with connection pooling, retry logic, and migration support.
 * Supports MySQL and SQLite backends.
 */
public interface DatabaseManager {
    
    /**
     * Get a database connection from the pool.
     * 
     * @return A database connection
     * @throws SQLException If a connection cannot be obtained
     */
    Connection getConnection() throws SQLException;
    
    /**
     * Execute a database transaction.
     * 
     * @param transaction The transaction to execute
     * @throws DatabaseException If the transaction fails
     */
    void executeTransaction(Transaction transaction) throws DatabaseException;
    
    /**
     * Execute a database transaction with a return value.
     * 
     * @param <T> The type of the return value
     * @param transaction The transaction to execute
     * @return The result of the transaction
     * @throws DatabaseException If the transaction fails
     */
    <T> T executeTransaction(ReturningTransaction<T> transaction) throws DatabaseException;
    
    /**
     * Execute a SQL query and map the result set.
     * 
     * @param <T> The type of the result
     * @param sql The SQL query to execute
     * @param mapper The mapper function for the result set
     * @param params The query parameters
     * @return The mapped result
     * @throws DatabaseException If the query fails
     */
    <T> T query(String sql, ResultSetMapper<T> mapper, Object... params) throws DatabaseException;
    
    /**
     * Execute a SQL update statement.
     * 
     * @param sql The SQL update statement
     * @param params The statement parameters
     * @return The number of affected rows
     * @throws DatabaseException If the update fails
     */
    int update(String sql, Object... params) throws DatabaseException;
    
    /**
     * Execute a SQL batch update.
     * 
     * @param sql The SQL update statement
     * @param batchParams Array of parameter arrays for batch execution
     * @return Array of update counts
     * @throws DatabaseException If the batch update fails
     */
    int[] batchUpdate(String sql, Object[][] batchParams) throws DatabaseException;
    
    /**
     * Execute a stored procedure or function.
     * 
     * @param procedure The procedure name
     * @param params The procedure parameters
     * @return The result set mapper for the procedure output
     * @throws DatabaseException If the procedure execution fails
     */
    <T> T callProcedure(String procedure, ResultSetMapper<T> mapper, Object... params) throws DatabaseException;
    
    /**
     * Migrate the database schema from one version to another.
     * 
     * @param fromVersion The current schema version
     * @param toVersion The target schema version
     * @throws DatabaseException If migration fails
     */
    void migrate(SchemaVersion from, SchemaVersion to) throws DatabaseException;
    
    /**
     * Get the current schema version.
     * 
     * @return The current schema version
     * @throws DatabaseException If version cannot be determined
     */
    SchemaVersion getCurrentVersion() throws DatabaseException;
    
    /**
     * Check if the database is connected and accessible.
     * 
     * @return true if the database is accessible, false otherwise
     */
    boolean isConnected();
    
    /**
     * Initialize the database connection and schema.
     * 
     * @throws DatabaseException If initialization fails
     */
    void initialize() throws DatabaseException;
    
    /**
     * Check if the database manager has been initialized.
     * 
     * @return true if initialized, false otherwise
     */
    boolean isInitialized();
    
    /**
     * Close all database connections and release resources.
     */
    void shutdown();
    
    /**
     * Get database statistics.
     * 
     * @return Database statistics
     */
    DatabaseStats getStats();
    
    /**
     * Interface for database transactions without return value.
     */
    @FunctionalInterface
    interface Transaction {
        /**
         * Execute the transaction.
         * 
         * @param connection The database connection
         * @throws SQLException If the transaction fails
         */
        void execute(Connection connection) throws SQLException;
    }
    
    /**
     * Interface for database transactions with return value.
     * 
     * @param <T> The return type
     */
    @FunctionalInterface
    interface ReturningTransaction<T> {
        /**
         * Execute the transaction and return a value.
         * 
         * @param connection The database connection
         * @return The transaction result
         * @throws SQLException If the transaction fails
         */
        T execute(Connection connection) throws SQLException;
    }
    
    /**
     * Interface for mapping result sets to objects.
     * 
     * @param <T> The type to map to
     */
    @FunctionalInterface
    interface ResultSetMapper<T> {
        /**
         * Map a result set to an object.
         * 
         * @param rs The result set
         * @return The mapped object
         * @throws SQLException If mapping fails
         */
        T map(java.sql.ResultSet rs) throws SQLException;
    }
    
    /**
     * Database schema version.
     */
    class SchemaVersion implements Comparable<SchemaVersion> {
        private final int major;
        private final int minor;
        private final int patch;
        
        public SchemaVersion(int major, int minor, int patch) {
            this.major = major;
            this.minor = minor;
            this.patch = patch;
        }
        
        public int getMajor() { return major; }
        public int getMinor() { return minor; }
        public int getPatch() { return patch; }
        
        public static SchemaVersion parse(String version) {
            String[] parts = version.split("\\.");
            int major = parts.length > 0 ? Integer.parseInt(parts[0]) : 0;
            int minor = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;
            int patch = parts.length > 2 ? Integer.parseInt(parts[2]) : 0;
            return new SchemaVersion(major, minor, patch);
        }
        
        @Override
        public String toString() {
            return major + "." + minor + "." + patch;
        }
        
        @Override
        public int compareTo(SchemaVersion other) {
            if (this.major != other.major) {
                return Integer.compare(this.major, other.major);
            }
            if (this.minor != other.minor) {
                return Integer.compare(this.minor, other.minor);
            }
            return Integer.compare(this.patch, other.patch);
        }
        
        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            SchemaVersion that = (SchemaVersion) obj;
            return major == that.major && minor == that.minor && patch == that.patch;
        }
        
        @Override
        public int hashCode() {
            int result = major;
            result = 31 * result + minor;
            result = 31 * result + patch;
            return result;
        }
    }
    
    /**
     * Database statistics.
     */
    class DatabaseStats {
        private final int activeConnections;
        private final int idleConnections;
        private final int totalConnections;
        private final long queryCount;
        private final long updateCount;
        private final long errorCount;
        private final long totalQueryTime;
        private final long avgQueryTime;
        
        public DatabaseStats(int activeConnections, int idleConnections, int totalConnections,
                            long queryCount, long updateCount, long errorCount,
                            long totalQueryTime, long avgQueryTime) {
            this.activeConnections = activeConnections;
            this.idleConnections = idleConnections;
            this.totalConnections = totalConnections;
            this.queryCount = queryCount;
            this.updateCount = updateCount;
            this.errorCount = errorCount;
            this.totalQueryTime = totalQueryTime;
            this.avgQueryTime = avgQueryTime;
        }
        
        public int getActiveConnections() { return activeConnections; }
        public int getIdleConnections() { return idleConnections; }
        public int getTotalConnections() { return totalConnections; }
        public long getQueryCount() { return queryCount; }
        public long getUpdateCount() { return updateCount; }
        public long getErrorCount() { return errorCount; }
        public long getTotalQueryTime() { return totalQueryTime; }
        public long getAvgQueryTime() { return avgQueryTime; }
        
        @Override
        public String toString() {
            return "DatabaseStats{" +
                   "activeConnections=" + activeConnections +
                   ", idleConnections=" + idleConnections +
                   ", totalConnections=" + totalConnections +
                   ", queryCount=" + queryCount +
                   ", updateCount=" + updateCount +
                   ", errorCount=" + errorCount +
                   ", totalQueryTime=" + totalQueryTime +
                   ", avgQueryTime=" + avgQueryTime +
                   '}';
        }
    }
    
    /**
     * Exception thrown when database operations fail.
     */
    class DatabaseException extends Exception {
        public DatabaseException(String message) {
            super(message);
        }
        
        public DatabaseException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
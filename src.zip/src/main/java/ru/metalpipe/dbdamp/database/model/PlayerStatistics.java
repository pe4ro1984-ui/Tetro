package ru.metalpipe.dbdamp.database.model;

import java.util.Objects;

/**
 * Player statistics and performance tracking.
 */
public class PlayerStatistics {
    
    private int matchesPlayed;
    private int matchesWon;
    private int matchesLost;
    private int escapes;
    private int kills;
    private int generatorsRepaired;
    private int hooks;
    private int rescues;
    private int heals;
    private int stuns;
    private long timePlayed; // in seconds
    private int bestMatchScore;
    private double averageMatchScore;
    
    public PlayerStatistics() {
        this.matchesPlayed = 0;
        this.matchesWon = 0;
        this.matchesLost = 0;
        this.escapes = 0;
        this.kills = 0;
        this.generatorsRepaired = 0;
        this.hooks = 0;
        this.rescues = 0;
        this.heals = 0;
        this.stuns = 0;
        this.timePlayed = 0;
        this.bestMatchScore = 0;
        this.averageMatchScore = 0.0;
    }
    
    // Getters and setters
    public int getMatchesPlayed() { return matchesPlayed; }
    public void setMatchesPlayed(int matchesPlayed) { this.matchesPlayed = Math.max(0, matchesPlayed); }
    
    public int getMatchesWon() { return matchesWon; }
    public void setMatchesWon(int matchesWon) { this.matchesWon = Math.max(0, matchesWon); }
    
    public int getMatchesLost() { return matchesLost; }
    public void setMatchesLost(int matchesLost) { this.matchesLost = Math.max(0, matchesLost); }
    
    public int getEscapes() { return escapes; }
    public void setEscapes(int escapes) { this.escapes = Math.max(0, escapes); }
    
    public int getKills() { return kills; }
    public void setKills(int kills) { this.kills = Math.max(0, kills); }
    
    public int getGeneratorsRepaired() { return generatorsRepaired; }
    public void setGeneratorsRepaired(int generatorsRepaired) { this.generatorsRepaired = Math.max(0, generatorsRepaired); }
    
    public int getHooks() { return hooks; }
    public void setHooks(int hooks) { this.hooks = Math.max(0, hooks); }
    
    public int getRescues() { return rescues; }
    public void setRescues(int rescues) { this.rescues = Math.max(0, rescues); }
    
    public int getHeals() { return heals; }
    public void setHeals(int heals) { this.heals = Math.max(0, heals); }
    
    public int getStuns() { return stuns; }
    public void setStuns(int stuns) { this.stuns = Math.max(0, stuns); }
    
    public long getTimePlayed() { return timePlayed; }
    public void setTimePlayed(long timePlayed) { this.timePlayed = Math.max(0, timePlayed); }
    
    public int getBestMatchScore() { return bestMatchScore; }
    public void setBestMatchScore(int bestMatchScore) { this.bestMatchScore = Math.max(0, bestMatchScore); }
    
    public double getAverageMatchScore() { return averageMatchScore; }
    public void setAverageMatchScore(double averageMatchScore) { this.averageMatchScore = Math.max(0.0, averageMatchScore); }
    
    // Helper methods
    public void addMatch(boolean won, int score, long matchTime) {
        matchesPlayed++;
        if (won) {
            matchesWon++;
        } else {
            matchesLost++;
        }
        
        timePlayed += matchTime;
        
        // Update best score
        if (score > bestMatchScore) {
            bestMatchScore = score;
        }
        
        // Update average score
        averageMatchScore = ((averageMatchScore * (matchesPlayed - 1)) + score) / matchesPlayed;
    }
    
    public void addEscape() {
        escapes++;
    }
    
    public void addKill() {
        kills++;
    }
    
    public void addGeneratorRepaired() {
        generatorsRepaired++;
    }
    
    public void addHook() {
        hooks++;
    }
    
    public void addRescue() {
        rescues++;
    }
    
    public void addHeal() {
        heals++;
    }
    
    public void addStun() {
        stuns++;
    }
    
    public double getWinRate() {
        if (matchesPlayed == 0) return 0.0;
        return (double) matchesWon / matchesPlayed;
    }
    
    public double getEscapeRate() {
        if (matchesPlayed == 0) return 0.0;
        return (double) escapes / matchesPlayed;
    }
    
    public double getKillRate() {
        if (matchesPlayed == 0) return 0.0;
        return (double) kills / matchesPlayed;
    }
    
    public double getGeneratorsPerMatch() {
        if (matchesPlayed == 0) return 0.0;
        return (double) generatorsRepaired / matchesPlayed;
    }
    
    public double getHooksPerMatch() {
        if (matchesPlayed == 0) return 0.0;
        return (double) hooks / matchesPlayed;
    }
    
    public double getRescuesPerMatch() {
        if (matchesPlayed == 0) return 0.0;
        return (double) rescues / matchesPlayed;
    }
    
    public double getHealsPerMatch() {
        if (matchesPlayed == 0) return 0.0;
        return (double) heals / matchesPlayed;
    }
    
    public double getStunsPerMatch() {
        if (matchesPlayed == 0) return 0.0;
        return (double) stuns / matchesPlayed;
    }
    
    public String getFormattedTimePlayed() {
        long seconds = timePlayed;
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        seconds = seconds % 60;
        
        if (hours > 0) {
            return String.format("%dh %dm %ds", hours, minutes, seconds);
        } else if (minutes > 0) {
            return String.format("%dm %ds", minutes, seconds);
        } else {
            return String.format("%ds", seconds);
        }
    }
    
    public int getTotalActions() {
        return escapes + kills + generatorsRepaired + hooks + rescues + heals + stuns;
    }
    
    public double getActionsPerMinute() {
        if (timePlayed == 0) return 0.0;
        double minutes = timePlayed / 60.0;
        return getTotalActions() / minutes;
    }
    
    public String getPerformanceRating() {
        double rating = calculatePerformanceRating();
        
        if (rating >= 90) return "S+";
        if (rating >= 80) return "S";
        if (rating >= 70) return "A";
        if (rating >= 60) return "B";
        if (rating >= 50) return "C";
        if (rating >= 40) return "D";
        return "F";
    }
    
    private double calculatePerformanceRating() {
        // Calculate a composite performance rating
        double winRateScore = getWinRate() * 30; // 30% weight
        double escapeRateScore = getEscapeRate() * 20; // 20% weight
        double killRateScore = getKillRate() * 20; // 20% weight
        double actionsScore = Math.min(getActionsPerMinute() * 5, 20); // 20% weight, capped
        double averageScore = (averageMatchScore / 10000.0) * 10; // 10% weight, assuming 10k max score
        
        return winRateScore + escapeRateScore + killRateScore + actionsScore + averageScore;
    }
    
    public void reset() {
        matchesPlayed = 0;
        matchesWon = 0;
        matchesLost = 0;
        escapes = 0;
        kills = 0;
        generatorsRepaired = 0;
        hooks = 0;
        rescues = 0;
        heals = 0;
        stuns = 0;
        timePlayed = 0;
        bestMatchScore = 0;
        averageMatchScore = 0.0;
    }
    
    public PlayerStatistics copy() {
        PlayerStatistics copy = new PlayerStatistics();
        copy.matchesPlayed = this.matchesPlayed;
        copy.matchesWon = this.matchesWon;
        copy.matchesLost = this.matchesLost;
        copy.escapes = this.escapes;
        copy.kills = this.kills;
        copy.generatorsRepaired = this.generatorsRepaired;
        copy.hooks = this.hooks;
        copy.rescues = this.rescues;
        copy.heals = this.heals;
        copy.stuns = this.stuns;
        copy.timePlayed = this.timePlayed;
        copy.bestMatchScore = this.bestMatchScore;
        copy.averageMatchScore = this.averageMatchScore;
        return copy;
    }
    
    @Override
    public String toString() {
        return "PlayerStatistics{" +
               "matchesPlayed=" + matchesPlayed +
               ", winRate=" + String.format("%.1f%%", getWinRate() * 100) +
               ", escapes=" + escapes +
               ", kills=" + kills +
               ", generatorsRepaired=" + generatorsRepaired +
               ", hooks=" + hooks +
               ", rescues=" + rescues +
               ", heals=" + heals +
               ", stuns=" + stuns +
               ", timePlayed=" + getFormattedTimePlayed() +
               ", bestMatchScore=" + bestMatchScore +
               ", averageMatchScore=" + String.format("%.1f", averageMatchScore) +
               ", performanceRating=" + getPerformanceRating() +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PlayerStatistics that = (PlayerStatistics) o;
        return matchesPlayed == that.matchesPlayed &&
               matchesWon == that.matchesWon &&
               matchesLost == that.matchesLost &&
               escapes == that.escapes &&
               kills == that.kills &&
               generatorsRepaired == that.generatorsRepaired &&
               hooks == that.hooks &&
               rescues == that.rescues &&
               heals == that.heals &&
               stuns == that.stuns &&
               timePlayed == that.timePlayed &&
               bestMatchScore == that.bestMatchScore &&
               Double.compare(averageMatchScore, that.averageMatchScore) == 0;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(matchesPlayed, matchesWon, matchesLost, escapes, kills, 
                           generatorsRepaired, hooks, rescues, heals, stuns, 
                           timePlayed, bestMatchScore, averageMatchScore);
    }
}
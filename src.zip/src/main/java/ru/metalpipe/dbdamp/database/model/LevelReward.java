package ru.metalpipe.dbdamp.database.model;

import java.time.Instant;
import java.util.Objects;

/**
 * Level reward for player progression.
 */
public class LevelReward {
    
    private int level;
    private String rewardType;
    private String rewardData;
    private boolean claimed;
    private Instant claimedAt;
    
    public LevelReward() {
        this.level = 1;
        this.rewardType = "";
        this.rewardData = "";
        this.claimed = false;
        this.claimedAt = Instant.now();
    }
    
    public LevelReward(int level, String rewardType, String rewardData) {
        this();
        this.level = Math.max(1, level);
        this.rewardType = rewardType;
        this.rewardData = rewardData;
    }
    
    // Getters and setters
    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = Math.max(1, level); }
    
    public String getRewardType() { return rewardType; }
    public void setRewardType(String rewardType) { this.rewardType = rewardType; }
    
    public String getRewardData() { return rewardData; }
    public void setRewardData(String rewardData) { this.rewardData = rewardData; }
    
    public boolean isClaimed() { return claimed; }
    public void setClaimed(boolean claimed) { 
        this.claimed = claimed;
        if (claimed && claimedAt == null) {
            claimedAt = Instant.now();
        }
    }
    
    public Instant getClaimedAt() { return claimedAt; }
    public void setClaimedAt(Instant claimedAt) { this.claimedAt = claimedAt; }
    
    // Helper methods
    public void claim() {
        if (!claimed) {
            claimed = true;
            claimedAt = Instant.now();
        }
    }
    
    public boolean canClaim(int playerLevel) {
        return !claimed && playerLevel >= level;
    }
    
    public String getDisplayName() {
        switch (rewardType) {
            case "BLOODPOINTS":
                return "Bloodpoints: " + rewardData;
            case "PERK_SLOT":
                return "Perk Slot";
            case "PRESTIGE_TOKEN":
                return "Prestige Token";
            case "COSMETIC":
                return "Cosmetic: " + rewardData;
            case "EXCLUSIVE_COSMETIC":
                return "Exclusive Cosmetic: " + rewardData;
            case "PERK_UNLOCK":
                return "Perk Unlock: " + rewardData;
            case "BLOODPOINT_MULTIPLIER":
                return "Bloodpoint Multiplier: " + rewardData + "x";
            default:
                return "Unknown Reward";
        }
    }
    
    public int getBloodpointAmount() {
        if ("BLOODPOINTS".equals(rewardType)) {
            try {
                return Integer.parseInt(rewardData);
            } catch (NumberFormatException e) {
                return 0;
            }
        }
        return 0;
    }
    
    public double getMultiplierAmount() {
        if ("BLOODPOINT_MULTIPLIER".equals(rewardType)) {
            try {
                return Double.parseDouble(rewardData);
            } catch (NumberFormatException e) {
                return 1.0;
            }
        }
        return 1.0;
    }
    
    public boolean isCosmetic() {
        return "COSMETIC".equals(rewardType) || "EXCLUSIVE_COSMETIC".equals(rewardType);
    }
    
    public boolean isPerkRelated() {
        return "PERK_SLOT".equals(rewardType) || "PERK_UNLOCK".equals(rewardType);
    }
    
    public boolean isPrestigeRelated() {
        return "PRESTIGE_TOKEN".equals(rewardType);
    }
    
    public long getDaysSinceClaimed() {
        if (claimedAt == null) return 0;
        return (Instant.now().getEpochSecond() - claimedAt.getEpochSecond()) / (24 * 3600);
    }
    
    public String getStatus() {
        if (claimed) {
            return "CLAIMED (" + getDaysSinceClaimed() + " days ago)";
        } else {
            return "AVAILABLE";
        }
    }
    
    public LevelReward copy() {
        LevelReward copy = new LevelReward();
        copy.level = this.level;
        copy.rewardType = this.rewardType;
        copy.rewardData = this.rewardData;
        copy.claimed = this.claimed;
        copy.claimedAt = this.claimedAt;
        return copy;
    }
    
    @Override
    public String toString() {
        return "LevelReward{" +
               "level=" + level +
               ", rewardType='" + rewardType + '\'' +
               ", rewardData='" + rewardData + '\'' +
               ", claimed=" + claimed +
               ", status='" + getStatus() + '\'' +
               ", displayName='" + getDisplayName() + '\'' +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LevelReward that = (LevelReward) o;
        return level == that.level && 
               Objects.equals(rewardType, that.rewardType) && 
               Objects.equals(rewardData, that.rewardData);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(level, rewardType, rewardData);
    }
}
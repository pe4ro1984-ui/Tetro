package ru.metalpipe.dbdamp.database.model;

import java.util.Objects;

/**
 * Bloodpoints currency system for the DBD plugin.
 */
public class Bloodpoints {
    
    private int amount;
    private int totalEarned;
    private int totalSpent;
    
    public Bloodpoints() {
        this.amount = 0;
        this.totalEarned = 0;
        this.totalSpent = 0;
    }
    
    public Bloodpoints(int initialAmount) {
        this.amount = Math.max(0, initialAmount);
        this.totalEarned = this.amount;
        this.totalSpent = 0;
    }
    
    // Getters and setters
    public int getAmount() { return amount; }
    public void setAmount(int amount) { 
        this.amount = Math.max(0, amount);
    }
    
    public int getTotalEarned() { return totalEarned; }
    public void setTotalEarned(int totalEarned) { 
        this.totalEarned = Math.max(0, totalEarned);
    }
    
    public int getTotalSpent() { return totalSpent; }
    public void setTotalSpent(int totalSpent) { 
        this.totalSpent = Math.max(0, totalSpent);
    }
    
    // Helper methods
    public void add(int amount) {
        if (amount <= 0) return;
        
        this.amount += amount;
        this.totalEarned += amount;
    }
    
    public boolean spend(int amount) {
        if (amount <= 0) return true; // Spending 0 or negative is always successful
        
        if (this.amount >= amount) {
            this.amount -= amount;
            this.totalSpent += amount;
            return true;
        }
        return false;
    }
    
    public boolean transferTo(Bloodpoints target, int amount) {
        if (amount <= 0) return true;
        
        if (spend(amount)) {
            target.add(amount);
            return true;
        }
        return false;
    }
    
    public void reset() {
        this.amount = 0;
        // Don't reset totals - they represent lifetime statistics
    }
    
    public void setMax(int maxAmount) {
        if (this.amount > maxAmount) {
            this.amount = maxAmount;
        }
    }
    
    public boolean has(int amount) {
        return this.amount >= amount;
    }
    
    public double getSpendingPercentage() {
        if (totalEarned == 0) return 0.0;
        return (double) totalSpent / totalEarned;
    }
    
    public int getNetWorth() {
        return totalEarned - totalSpent;
    }
    
    public String getFormattedAmount() {
        return formatBloodpoints(amount);
    }
    
    public String getFormattedTotalEarned() {
        return formatBloodpoints(totalEarned);
    }
    
    public String getFormattedTotalSpent() {
        return formatBloodpoints(totalSpent);
    }
    
    // Static helper methods
    public static String formatBloodpoints(int amount) {
        if (amount >= 1_000_000) {
            return String.format("%.1fM", amount / 1_000_000.0);
        } else if (amount >= 1_000) {
            return String.format("%.1fK", amount / 1_000.0);
        } else {
            return String.valueOf(amount);
        }
    }
    
    public static int parseBloodpoints(String formatted) {
        try {
            formatted = formatted.trim().toUpperCase();
            
            if (formatted.endsWith("M")) {
                double value = Double.parseDouble(formatted.substring(0, formatted.length() - 1));
                return (int) (value * 1_000_000);
            } else if (formatted.endsWith("K")) {
                double value = Double.parseDouble(formatted.substring(0, formatted.length() - 1));
                return (int) (value * 1_000);
            } else {
                return Integer.parseInt(formatted);
            }
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    
    public static Bloodpoints fromString(String formatted) {
        return new Bloodpoints(parseBloodpoints(formatted));
    }
    
    @Override
    public String toString() {
        return "Bloodpoints{" +
               "amount=" + getFormattedAmount() +
               ", totalEarned=" + getFormattedTotalEarned() +
               ", totalSpent=" + getFormattedTotalSpent() +
               ", netWorth=" + formatBloodpoints(getNetWorth()) +
               ", spendingPercentage=" + String.format("%.1f%%", getSpendingPercentage() * 100) +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Bloodpoints that = (Bloodpoints) o;
        return amount == that.amount && totalEarned == that.totalEarned && totalSpent == that.totalSpent;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(amount, totalEarned, totalSpent);
    }
}
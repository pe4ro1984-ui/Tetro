package ru.metalpipe.dbdamp.database.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Player level and experience progression.
 */
public class PlayerLevel {
    
    private int level;
    private int experience;
    private int experienceToNext;
    private List<LevelReward> rewards;
    
    public PlayerLevel() {
        this.level = 1;
        this.experience = 0;
        this.experienceToNext = calculateExperienceToNext(level);
        this.rewards = new ArrayList<>();
    }
    
    public PlayerLevel(int level, int experience) {
        this.level = Math.max(1, level);
        this.experience = Math.max(0, experience);
        this.experienceToNext = calculateExperienceToNext(this.level);
        this.rewards = new ArrayList<>();
    }
    
    // Getters and setters
    public int getLevel() { return level; }
    public void setLevel(int level) { 
        this.level = Math.max(1, level);
        this.experienceToNext = calculateExperienceToNext(this.level);
    }
    
    public int getExperience() { return experience; }
    public void setExperience(int experience) { 
        this.experience = Math.max(0, experience);
    }
    
    public int getExperienceToNext() { return experienceToNext; }
    public void setExperienceToNext(int experienceToNext) { 
        this.experienceToNext = Math.max(1, experienceToNext);
    }
    
    public List<LevelReward> getRewards() { return rewards; }
    public void setRewards(List<LevelReward> rewards) { this.rewards = rewards; }
    
    // Helper methods
    public void addExperience(int amount) {
        if (amount <= 0) return;
        
        this.experience += amount;
        
        // Check for level up
        while (this.experience >= this.experienceToNext && this.level < getMaxLevel()) {
            levelUp();
        }
    }
    
    public void levelUp() {
        if (level >= getMaxLevel()) {
            return;
        }
        
        // Carry over excess experience
        int excess = this.experience - this.experienceToNext;
        
        this.level++;
        this.experience = excess;
        this.experienceToNext = calculateExperienceToNext(this.level);
        
        // Add level reward
        LevelReward reward = createLevelReward(this.level);
        if (reward != null) {
            rewards.add(reward);
        }
    }
    
    public int getRemainingExperience() {
        return Math.max(0, experienceToNext - experience);
    }
    
    public double getProgressPercentage() {
        if (experienceToNext == 0) return 1.0;
        return Math.min(1.0, (double) experience / experienceToNext);
    }
    
    public boolean canLevelUp() {
        return level < getMaxLevel() && experience >= experienceToNext;
    }
    
    public int getTotalExperience() {
        // Calculate total experience earned (including previous levels)
        int total = experience;
        for (int lvl = 1; lvl < level; lvl++) {
            total += calculateExperienceToNext(lvl);
        }
        return total;
    }
    
    public void reset() {
        this.level = 1;
        this.experience = 0;
        this.experienceToNext = calculateExperienceToNext(level);
        this.rewards.clear();
    }
    
    // Static helper methods
    public static int getMaxLevel() {
        return 100; // Configurable
    }
    
    public static int calculateExperienceToNext(int level) {
        // Exponential experience curve
        // Base 1000 XP for level 1, increasing by 20% per level
        return (int) (1000 * Math.pow(1.2, level - 1));
    }
    
    private LevelReward createLevelReward(int level) {
        // Create appropriate rewards based on level
        LevelReward reward = new LevelReward();
        reward.setLevel(level);
        reward.setRewardType(getRewardTypeForLevel(level));
        reward.setRewardData(getRewardDataForLevel(level));
        reward.setClaimed(false);
        return reward;
    }
    
    private String getRewardTypeForLevel(int level) {
        if (level % 10 == 0) {
            return "PRESTIGE_TOKEN";
        } else if (level % 5 == 0) {
            return "PERK_SLOT";
        } else if (level % 3 == 0) {
            return "BLOODPOINTS";
        } else {
            return "COSMETIC";
        }
    }
    
    private String getRewardDataForLevel(int level) {
        switch (getRewardTypeForLevel(level)) {
            case "BLOODPOINTS":
                return String.valueOf(level * 500);
            case "PERK_SLOT":
                return "1";
            case "PRESTIGE_TOKEN":
                return "1";
            case "COSMETIC":
                return "cosmetic_" + level;
            default:
                return "";
        }
    }
    
    @Override
    public String toString() {
        return "PlayerLevel{" +
               "level=" + level +
               ", experience=" + experience +
               ", experienceToNext=" + experienceToNext +
               ", progress=" + String.format("%.1f%%", getProgressPercentage() * 100) +
               ", rewards=" + rewards.size() +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PlayerLevel that = (PlayerLevel) o;
        return level == that.level && experience == that.experience;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(level, experience);
    }
}
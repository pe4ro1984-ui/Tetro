package ru.metalpipe.dbdamp.config;

/**
 * Configuration for individual plugin modules.
 */
public class ModuleConfig {
    
    private String moduleId;
    private String displayName;
    private boolean enabled;
    private int loadPriority;
    private String[] dependencies;
    private String configPath;
    private boolean hotReloadEnabled;
    private String version;
    
    public ModuleConfig() {
        this.moduleId = "unknown";
        this.displayName = "Unknown Module";
        this.enabled = true;
        this.loadPriority = 0;
        this.dependencies = new String[0];
        this.configPath = "";
        this.hotReloadEnabled = false;
        this.version = "1.0.0";
    }
    
    public ModuleConfig(String moduleId, String displayName, boolean enabled, int loadPriority) {
        this.moduleId = moduleId;
        this.displayName = displayName;
        this.enabled = enabled;
        this.loadPriority = loadPriority;
        this.dependencies = new String[0];
        this.configPath = "modules/" + moduleId + ".yml";
        this.hotReloadEnabled = false;
        this.version = "1.0.0";
    }
    
    // Getters and setters
    public String getModuleId() { return moduleId; }
    public void setModuleId(String moduleId) { this.moduleId = moduleId; }
    
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    
    public int getLoadPriority() { return loadPriority; }
    public void setLoadPriority(int loadPriority) { this.loadPriority = loadPriority; }
    
    public String[] getDependencies() { return dependencies; }
    public void setDependencies(String[] dependencies) { this.dependencies = dependencies; }
    
    public String getConfigPath() { return configPath; }
    public void setConfigPath(String configPath) { this.configPath = configPath; }
    
    public boolean isHotReloadEnabled() { return hotReloadEnabled; }
    public void setHotReloadEnabled(boolean hotReloadEnabled) { this.hotReloadEnabled = hotReloadEnabled; }
    
    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }
    
    @Override
    public String toString() {
        return "ModuleConfig{" +
               "moduleId='" + moduleId + '\'' +
               ", displayName='" + displayName + '\'' +
               ", enabled=" + enabled +
               ", loadPriority=" + loadPriority +
               ", dependencies=" + java.util.Arrays.toString(dependencies) +
               ", configPath='" + configPath + '\'' +
               ", hotReloadEnabled=" + hotReloadEnabled +
               ", version='" + version + '\'' +
               '}';
    }
}
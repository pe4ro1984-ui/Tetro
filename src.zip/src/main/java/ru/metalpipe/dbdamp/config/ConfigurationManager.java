package ru.metalpipe.dbdamp.config;

import java.io.File;
import java.nio.file.Path;
import java.util.function.Consumer;

/**
 * Interface for managing configuration files with support for YAML and JSON formats.
 * Provides loading, saving, validation, and hot-reload functionality.
 */
public interface ConfigurationManager {
    
    /**
     * Load a configuration file and parse it into the specified type.
     * 
     * @param <T> The type of configuration object to return
     * @param path The path to the configuration file
     * @param type The class of the configuration object
     * @return The parsed configuration object
     * @throws ConfigurationException If the configuration cannot be loaded or parsed
     */
    <T> T loadConfig(String path, Class<T> type) throws ConfigurationException;
    
    /**
     * Load a configuration file from a File object.
     * 
     * @param <T> The type of configuration object to return
     * @param file The configuration file
     * @param type The class of the configuration object
     * @return The parsed configuration object
     * @throws ConfigurationException If the configuration cannot be loaded or parsed
     */
    <T> T loadConfig(File file, Class<T> type) throws ConfigurationException;
    
    /**
     * Load a configuration file from a Path object.
     * 
     * @param <T> The type of configuration object to return
     * @param path The path to the configuration file
     * @param type The class of the configuration object
     * @return The parsed configuration object
     * @throws ConfigurationException If the configuration cannot be loaded or parsed
     */
    <T> T loadConfig(Path path, Class<T> type) throws ConfigurationException;
    
    /**
     * Save a configuration object to a file.
     * 
     * @param path The path to save the configuration to
     * @param config The configuration object to save
     * @throws ConfigurationException If the configuration cannot be saved
     */
    void saveConfig(String path, Object config) throws ConfigurationException;
    
    /**
     * Save a configuration object to a File.
     * 
     * @param file The file to save the configuration to
     * @param config The configuration object to save
     * @throws ConfigurationException If the configuration cannot be saved
     */
    void saveConfig(File file, Object config) throws ConfigurationException;
    
    /**
     * Save a configuration object to a Path.
     * 
     * @param path The path to save the configuration to
     * @param config The configuration object to save
     * @throws ConfigurationException If the configuration cannot be saved
     */
    void saveConfig(Path path, Object config) throws ConfigurationException;
    
    /**
     * Watch a configuration file for changes and reload when modified.
     * 
     * @param path The path to the configuration file to watch
     * @param listener The listener to call when the configuration changes
     * @return A watch registration that can be used to stop watching
     * @throws ConfigurationException If the file cannot be watched
     */
    WatchRegistration watchConfig(String path, ConfigChangeListener listener) throws ConfigurationException;
    
    /**
     * Validate a configuration object against its schema or constraints.
     * 
     * @param config The configuration object to validate
     * @return A validation result containing any errors or warnings
     */
    ValidationResult validateConfig(Object config);
    
    /**
     * Get the default configuration for a given type.
     * 
     * @param <T> The type of configuration object
     * @param type The class of the configuration object
     * @return A default instance of the configuration
     */
    <T> T getDefaultConfig(Class<T> type);
    
    /**
     * Check if a configuration file exists.
     * 
     * @param path The path to check
     * @return true if the configuration file exists, false otherwise
     */
    boolean configExists(String path);
    
    /**
     * Create a configuration file with default values if it doesn't exist.
     * 
     * @param <T> The type of configuration object
     * @param path The path to the configuration file
     * @param type The class of the configuration object
     * @return The loaded or created configuration
     * @throws ConfigurationException If the configuration cannot be created or loaded
     */
    <T> T loadOrCreateConfig(String path, Class<T> type) throws ConfigurationException;
    
    /**
     * Reload all watched configuration files.
     */
    void reloadAllWatchedConfigs();
    
    /**
     * Stop watching all configuration files.
     */
    void stopWatchingAll();
    
    /**
     * Interface for configuration change listeners.
     */
    @FunctionalInterface
    interface ConfigChangeListener {
        /**
         * Called when a configuration file changes.
         * 
         * @param oldConfig The old configuration (may be null)
         * @param newConfig The new configuration
         */
        void onConfigChanged(Object oldConfig, Object newConfig);
    }
    
    /**
     * Interface for watch registrations.
     */
    interface WatchRegistration {
        /**
         * Stop watching the configuration file.
         */
        void stopWatching();
        
        /**
         * Check if the watch is still active.
         * 
         * @return true if watching, false otherwise
         */
        boolean isWatching();
    }
    
    /**
     * Validation result containing errors and warnings.
     */
    class ValidationResult {
        private final boolean valid;
        private final String[] errors;
        private final String[] warnings;
        
        public ValidationResult(boolean valid, String[] errors, String[] warnings) {
            this.valid = valid;
            this.errors = errors != null ? errors : new String[0];
            this.warnings = warnings != null ? warnings : new String[0];
        }
        
        public boolean isValid() {
            return valid;
        }
        
        public String[] getErrors() {
            return errors;
        }
        
        public String[] getWarnings() {
            return warnings;
        }
        
        public boolean hasErrors() {
            return errors.length > 0;
        }
        
        public boolean hasWarnings() {
            return warnings.length > 0;
        }
        
        public static ValidationResult valid() {
            return new ValidationResult(true, null, null);
        }
        
        public static ValidationResult error(String... errors) {
            return new ValidationResult(false, errors, null);
        }
        
        public static ValidationResult warning(String... warnings) {
            return new ValidationResult(true, null, warnings);
        }
    }
    
    /**
     * Exception thrown when configuration operations fail.
     */
    class ConfigurationException extends Exception {
        public ConfigurationException(String message) {
            super(message);
        }
        
        public ConfigurationException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
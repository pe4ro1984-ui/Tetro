package ru.metalpipe.dbdamp.config;

/**
 * Economy configuration for bloodpoints, currency, and transactions.
 */
public class EconomyConfig {
    
    private String currencyName;
    private String currencySymbol;
    private boolean enableEconomy;
    private int bloodpointsPerEscape;
    private int bloodpointsPerKill;
    private int bloodpointsPerGenerator;
    private int bloodpointsPerHeal;
    private int bloodpointsPerRescue;
    private int bloodpointsPerStun;
    private int bloodpointsPerHook;
    private int bloodpointsPerSacrifice;
    private int bloodpointsPerMatchCompletion;
    private int prestigeCost;
    private int prestigeBloodpointBonus;
    private double shopTaxRate;
    private boolean enableTransactionLogging;
    private int maxBloodpoints;
    
    public EconomyConfig() {
        this.currencyName = "Bloodpoints";
        this.currencySymbol = "BP";
        this.enableEconomy = true;
        this.bloodpointsPerEscape = 5000;
        this.bloodpointsPerKill = 8000;
        this.bloodpointsPerGenerator = 1250;
        this.bloodpointsPerHeal = 1000;
        this.bloodpointsPerRescue = 1500;
        this.bloodpointsPerStun = 1000;
        this.bloodpointsPerHook = 600;
        this.bloodpointsPerSacrifice = 2000;
        this.bloodpointsPerMatchCompletion = 1000;
        this.prestigeCost = 50000;
        this.prestigeBloodpointBonus = 10000;
        this.shopTaxRate = 0.05; // 5%
        this.enableTransactionLogging = true;
        this.maxBloodpoints = 1000000;
    }
    
    // Getters and setters
    public String getCurrencyName() { return currencyName; }
    public void setCurrencyName(String currencyName) { this.currencyName = currencyName; }
    
    public String getCurrencySymbol() { return currencySymbol; }
    public void setCurrencySymbol(String currencySymbol) { this.currencySymbol = currencySymbol; }
    
    public boolean isEnableEconomy() { return enableEconomy; }
    public void setEnableEconomy(boolean enableEconomy) { this.enableEconomy = enableEconomy; }
    
    public int getBloodpointsPerEscape() { return bloodpointsPerEscape; }
    public void setBloodpointsPerEscape(int bloodpointsPerEscape) { this.bloodpointsPerEscape = bloodpointsPerEscape; }
    
    public int getBloodpointsPerKill() { return bloodpointsPerKill; }
    public void setBloodpointsPerKill(int bloodpointsPerKill) { this.bloodpointsPerKill = bloodpointsPerKill; }
    
    public int getBloodpointsPerGenerator() { return bloodpointsPerGenerator; }
    public void setBloodpointsPerGenerator(int bloodpointsPerGenerator) { this.bloodpointsPerGenerator = bloodpointsPerGenerator; }
    
    public int getBloodpointsPerHeal() { return bloodpointsPerHeal; }
    public void setBloodpointsPerHeal(int bloodpointsPerHeal) { this.bloodpointsPerHeal = bloodpointsPerHeal; }
    
    public int getBloodpointsPerRescue() { return bloodpointsPerRescue; }
    public void setBloodpointsPerRescue(int bloodpointsPerRescue) { this.bloodpointsPerRescue = bloodpointsPerRescue; }
    
    public int getBloodpointsPerStun() { return bloodpointsPerStun; }
    public void setBloodpointsPerStun(int bloodpointsPerStun) { this.bloodpointsPerStun = bloodpointsPerStun; }
    
    public int getBloodpointsPerHook() { return bloodpointsPerHook; }
    public void setBloodpointsPerHook(int bloodpointsPerHook) { this.bloodpointsPerHook = bloodpointsPerHook; }
    
    public int getBloodpointsPerSacrifice() { return bloodpointsPerSacrifice; }
    public void setBloodpointsPerSacrifice(int bloodpointsPerSacrifice) { this.bloodpointsPerSacrifice = bloodpointsPerSacrifice; }
    
    public int getBloodpointsPerMatchCompletion() { return bloodpointsPerMatchCompletion; }
    public void setBloodpointsPerMatchCompletion(int bloodpointsPerMatchCompletion) { this.bloodpointsPerMatchCompletion = bloodpointsPerMatchCompletion; }
    
    public int getPrestigeCost() { return prestigeCost; }
    public void setPrestigeCost(int prestigeCost) { this.prestigeCost = prestigeCost; }
    
    public int getPrestigeBloodpointBonus() { return prestigeBloodpointBonus; }
    public void setPrestigeBloodpointBonus(int prestigeBloodpointBonus) { this.prestigeBloodpointBonus = prestigeBloodpointBonus; }
    
    public double getShopTaxRate() { return shopTaxRate; }
    public void setShopTaxRate(double shopTaxRate) { this.shopTaxRate = shopTaxRate; }
    
    public boolean isEnableTransactionLogging() { return enableTransactionLogging; }
    public void setEnableTransactionLogging(boolean enableTransactionLogging) { this.enableTransactionLogging = enableTransactionLogging; }
    
    public int getMaxBloodpoints() { return maxBloodpoints; }
    public void setMaxBloodpoints(int maxBloodpoints) { this.maxBloodpoints = maxBloodpoints; }
    
    @Override
    public String toString() {
        return "EconomyConfig{" +
               "currencyName='" + currencyName + '\'' +
               ", currencySymbol='" + currencySymbol + '\'' +
               ", enableEconomy=" + enableEconomy +
               ", bloodpointsPerEscape=" + bloodpointsPerEscape +
               ", bloodpointsPerKill=" + bloodpointsPerKill +
               ", bloodpointsPerGenerator=" + bloodpointsPerGenerator +
               ", bloodpointsPerHeal=" + bloodpointsPerHeal +
               ", bloodpointsPerRescue=" + bloodpointsPerRescue +
               ", bloodpointsPerStun=" + bloodpointsPerStun +
               ", bloodpointsPerHook=" + bloodpointsPerHook +
               ", bloodpointsPerSacrifice=" + bloodpointsPerSacrifice +
               ", bloodpointsPerMatchCompletion=" + bloodpointsPerMatchCompletion +
               ", prestigeCost=" + prestigeCost +
               ", prestigeBloodpointBonus=" + prestigeBloodpointBonus +
               ", shopTaxRate=" + shopTaxRate +
               ", enableTransactionLogging=" + enableTransactionLogging +
               ", maxBloodpoints=" + maxBloodpoints +
               '}';
    }
}
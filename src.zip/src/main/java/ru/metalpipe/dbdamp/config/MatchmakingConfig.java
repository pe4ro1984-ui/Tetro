package ru.metalpipe.dbdamp.config;

/**
 * Matchmaking configuration for lobbies, queues, and match settings.
 */
public class MatchmakingConfig {
    
    private int minPlayersPerMatch;
    private int maxPlayersPerMatch;
    private int lobbyTimeout; // in seconds
    private int readyCheckTimeout; // in seconds
    private int matchStartCountdown; // in seconds
    private boolean enablePublicMatches;
    private boolean enableRankedMatches;
    private boolean enableCustomMatches;
    private int rankedMatchmakingThreshold; // MMR difference
    private int maxQueueTime; // in seconds
    private boolean enableRolePreferences;
    private boolean enableMapVoting;
    private int mapVotingTime; // in seconds
    private int maxCustomLobbies;
    private boolean enablePasswordProtectedLobbies;
    private int maxLobbyNameLength;
    private int maxLobbyPasswordLength;
    
    public MatchmakingConfig() {
        this.minPlayersPerMatch = 5; // 1 killer + 4 survivors
        this.maxPlayersPerMatch = 5;
        this.lobbyTimeout = 300; // 5 minutes
        this.readyCheckTimeout = 30; // 30 seconds
        this.matchStartCountdown = 10; // 10 seconds
        this.enablePublicMatches = true;
        this.enableRankedMatches = true;
        this.enableCustomMatches = true;
        this.rankedMatchmakingThreshold = 500; // MMR points
        this.maxQueueTime = 300; // 5 minutes
        this.enableRolePreferences = true;
        this.enableMapVoting = true;
        this.mapVotingTime = 30; // 30 seconds
        this.maxCustomLobbies = 50;
        this.enablePasswordProtectedLobbies = true;
        this.maxLobbyNameLength = 32;
        this.maxLobbyPasswordLength = 16;
    }
    
    // Getters and setters
    public int getMinPlayersPerMatch() { return minPlayersPerMatch; }
    public void setMinPlayersPerMatch(int minPlayersPerMatch) { this.minPlayersPerMatch = minPlayersPerMatch; }
    
    public int getMaxPlayersPerMatch() { return maxPlayersPerMatch; }
    public void setMaxPlayersPerMatch(int maxPlayersPerMatch) { this.maxPlayersPerMatch = maxPlayersPerMatch; }
    
    public int getLobbyTimeout() { return lobbyTimeout; }
    public void setLobbyTimeout(int lobbyTimeout) { this.lobbyTimeout = lobbyTimeout; }
    
    public int getReadyCheckTimeout() { return readyCheckTimeout; }
    public void setReadyCheckTimeout(int readyCheckTimeout) { this.readyCheckTimeout = readyCheckTimeout; }
    
    public int getMatchStartCountdown() { return matchStartCountdown; }
    public void setMatchStartCountdown(int matchStartCountdown) { this.matchStartCountdown = matchStartCountdown; }
    
    public boolean isEnablePublicMatches() { return enablePublicMatches; }
    public void setEnablePublicMatches(boolean enablePublicMatches) { this.enablePublicMatches = enablePublicMatches; }
    
    public boolean isEnableRankedMatches() { return enableRankedMatches; }
    public void setEnableRankedMatches(boolean enableRankedMatches) { this.enableRankedMatches = enableRankedMatches; }
    
    public boolean isEnableCustomMatches() { return enableCustomMatches; }
    public void setEnableCustomMatches(boolean enableCustomMatches) { this.enableCustomMatches = enableCustomMatches; }
    
    public int getRankedMatchmakingThreshold() { return rankedMatchmakingThreshold; }
    public void setRankedMatchmakingThreshold(int rankedMatchmakingThreshold) { this.rankedMatchmakingThreshold = rankedMatchmakingThreshold; }
    
    public int getMaxQueueTime() { return maxQueueTime; }
    public void setMaxQueueTime(int maxQueueTime) { this.maxQueueTime = maxQueueTime; }
    
    public boolean isEnableRolePreferences() { return enableRolePreferences; }
    public void setEnableRolePreferences(boolean enableRolePreferences) { this.enableRolePreferences = enableRolePreferences; }
    
    public boolean isEnableMapVoting() { return enableMapVoting; }
    public void setEnableMapVoting(boolean enableMapVoting) { this.enableMapVoting = enableMapVoting; }
    
    public int getMapVotingTime() { return mapVotingTime; }
    public void setMapVotingTime(int mapVotingTime) { this.mapVotingTime = mapVotingTime; }
    
    public int getMaxCustomLobbies() { return maxCustomLobbies; }
    public void setMaxCustomLobbies(int maxCustomLobbies) { this.maxCustomLobbies = maxCustomLobbies; }
    
    public boolean isEnablePasswordProtectedLobbies() { return enablePasswordProtectedLobbies; }
    public void setEnablePasswordProtectedLobbies(boolean enablePasswordProtectedLobbies) { this.enablePasswordProtectedLobbies = enablePasswordProtectedLobbies; }
    
    public int getMaxLobbyNameLength() { return maxLobbyNameLength; }
    public void setMaxLobbyNameLength(int maxLobbyNameLength) { this.maxLobbyNameLength = maxLobbyNameLength; }
    
    public int getMaxLobbyPasswordLength() { return maxLobbyPasswordLength; }
    public void setMaxLobbyPasswordLength(int maxLobbyPasswordLength) { this.maxLobbyPasswordLength = maxLobbyPasswordLength; }
    
    @Override
    public String toString() {
        return "MatchmakingConfig{" +
               "minPlayersPerMatch=" + minPlayersPerMatch +
               ", maxPlayersPerMatch=" + maxPlayersPerMatch +
               ", lobbyTimeout=" + lobbyTimeout +
               ", readyCheckTimeout=" + readyCheckTimeout +
               ", matchStartCountdown=" + matchStartCountdown +
               ", enablePublicMatches=" + enablePublicMatches +
               ", enableRankedMatches=" + enableRankedMatches +
               ", enableCustomMatches=" + enableCustomMatches +
               ", rankedMatchmakingThreshold=" + rankedMatchmakingThreshold +
               ", maxQueueTime=" + maxQueueTime +
               ", enableRolePreferences=" + enableRolePreferences +
               ", enableMapVoting=" + enableMapVoting +
               ", mapVotingTime=" + mapVotingTime +
               ", maxCustomLobbies=" + maxCustomLobbies +
               ", enablePasswordProtectedLobbies=" + enablePasswordProtectedLobbies +
               ", maxLobbyNameLength=" + maxLobbyNameLength +
               ", maxLobbyPasswordLength=" + maxLobbyPasswordLength +
               '}';
    }
}
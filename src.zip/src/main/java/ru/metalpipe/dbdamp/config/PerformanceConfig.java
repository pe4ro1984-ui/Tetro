package ru.metalpipe.dbdamp.config;

/**
 * Performance optimization configuration.
 */
public class PerformanceConfig {
    
    private int asyncOperationThreads;
    private int maxConcurrentMatches;
    private int entityTrackingRange;
    private int eventHandlerPriority;
    private boolean enableObjectPooling;
    private int objectPoolSize;
    private int garbageCollectionThreshold; // MB
    private int tickDistributionBatchSize;
    private boolean enablePerformanceProfiling;
    private int profilingSampleRate; // in ticks
    private int maxMemoryUsage; // MB
    private boolean enableChunkBasedOptimization;
    private int chunkLoadRadius;
    private boolean enableAsyncChunkLoading;
    private int matchCleanupDelay; // in ticks
    
    public PerformanceConfig() {
        this.asyncOperationThreads = 4;
        this.maxConcurrentMatches = 10;
        this.entityTrackingRange = 64; // blocks
        this.eventHandlerPriority = 2; // NORMAL priority
        this.enableObjectPooling = true;
        this.objectPoolSize = 1000;
        this.garbageCollectionThreshold = 512; // 512 MB
        this.tickDistributionBatchSize = 10;
        this.enablePerformanceProfiling = false;
        this.profilingSampleRate = 100; // every 5 seconds
        this.maxMemoryUsage = 1024; // 1 GB
        this.enableChunkBasedOptimization = true;
        this.chunkLoadRadius = 3;
        this.enableAsyncChunkLoading = true;
        this.matchCleanupDelay = 6000; // 5 minutes in ticks
    }
    
    // Getters and setters
    public int getAsyncOperationThreads() { return asyncOperationThreads; }
    public void setAsyncOperationThreads(int asyncOperationThreads) { this.asyncOperationThreads = asyncOperationThreads; }
    
    public int getMaxConcurrentMatches() { return maxConcurrentMatches; }
    public void setMaxConcurrentMatches(int maxConcurrentMatches) { this.maxConcurrentMatches = maxConcurrentMatches; }
    
    public int getEntityTrackingRange() { return entityTrackingRange; }
    public void setEntityTrackingRange(int entityTrackingRange) { this.entityTrackingRange = entityTrackingRange; }
    
    public int getEventHandlerPriority() { return eventHandlerPriority; }
    public void setEventHandlerPriority(int eventHandlerPriority) { this.eventHandlerPriority = eventHandlerPriority; }
    
    public boolean isEnableObjectPooling() { return enableObjectPooling; }
    public void setEnableObjectPooling(boolean enableObjectPooling) { this.enableObjectPooling = enableObjectPooling; }
    
    public int getObjectPoolSize() { return objectPoolSize; }
    public void setObjectPoolSize(int objectPoolSize) { this.objectPoolSize = objectPoolSize; }
    
    public int getGarbageCollectionThreshold() { return garbageCollectionThreshold; }
    public void setGarbageCollectionThreshold(int garbageCollectionThreshold) { this.garbageCollectionThreshold = garbageCollectionThreshold; }
    
    public int getTickDistributionBatchSize() { return tickDistributionBatchSize; }
    public void setTickDistributionBatchSize(int tickDistributionBatchSize) { this.tickDistributionBatchSize = tickDistributionBatchSize; }
    
    public boolean isEnablePerformanceProfiling() { return enablePerformanceProfiling; }
    public void setEnablePerformanceProfiling(boolean enablePerformanceProfiling) { this.enablePerformanceProfiling = enablePerformanceProfiling; }
    
    public int getProfilingSampleRate() { return profilingSampleRate; }
    public void setProfilingSampleRate(int profilingSampleRate) { this.profilingSampleRate = profilingSampleRate; }
    
    public int getMaxMemoryUsage() { return maxMemoryUsage; }
    public void setMaxMemoryUsage(int maxMemoryUsage) { this.maxMemoryUsage = maxMemoryUsage; }
    
    public boolean isEnableChunkBasedOptimization() { return enableChunkBasedOptimization; }
    public void setEnableChunkBasedOptimization(boolean enableChunkBasedOptimization) { this.enableChunkBasedOptimization = enableChunkBasedOptimization; }
    
    public int getChunkLoadRadius() { return chunkLoadRadius; }
    public void setChunkLoadRadius(int chunkLoadRadius) { this.chunkLoadRadius = chunkLoadRadius; }
    
    public boolean isEnableAsyncChunkLoading() { return enableAsyncChunkLoading; }
    public void setEnableAsyncChunkLoading(boolean enableAsyncChunkLoading) { this.enableAsyncChunkLoading = enableAsyncChunkLoading; }
    
    public int getMatchCleanupDelay() { return matchCleanupDelay; }
    public void setMatchCleanupDelay(int matchCleanupDelay) { this.matchCleanupDelay = matchCleanupDelay; }
    
    @Override
    public String toString() {
        return "PerformanceConfig{" +
               "asyncOperationThreads=" + asyncOperationThreads +
               ", maxConcurrentMatches=" + maxConcurrentMatches +
               ", entityTrackingRange=" + entityTrackingRange +
               ", eventHandlerPriority=" + eventHandlerPriority +
               ", enableObjectPooling=" + enableObjectPooling +
               ", objectPoolSize=" + objectPoolSize +
               ", garbageCollectionThreshold=" + garbageCollectionThreshold +
               ", tickDistributionBatchSize=" + tickDistributionBatchSize +
               ", enablePerformanceProfiling=" + enablePerformanceProfiling +
               ", profilingSampleRate=" + profilingSampleRate +
               ", maxMemoryUsage=" + maxMemoryUsage +
               ", enableChunkBasedOptimization=" + enableChunkBasedOptimization +
               ", chunkLoadRadius=" + chunkLoadRadius +
               ", enableAsyncChunkLoading=" + enableAsyncChunkLoading +
               ", matchCleanupDelay=" + matchCleanupDelay +
               '}';
    }
}
package ru.metalpipe.dbdamp.config;

/**
 * Database configuration for MySQL and SQLite support.
 */
public class DatabaseConfig {
    
    public enum DatabaseType {
        MYSQL,
        SQLITE
    }
    
    private DatabaseType type;
    private String host;
    private int port;
    private String database;
    private String username;
    private String password;
    private boolean useSSL;
    private int connectionPoolSize;
    private int connectionTimeout;
    private int idleTimeout;
    private int maxLifetime;
    private String sqlitePath;
    
    public DatabaseConfig() {
        // Default values for SQLite
        this.type = DatabaseType.SQLITE;
        this.host = "localhost";
        this.port = 3306;
        this.database = "dbdamp";
        this.username = "root";
        this.password = "";
        this.useSSL = false;
        this.connectionPoolSize = 10;
        this.connectionTimeout = 30000; // 30 seconds
        this.idleTimeout = 600000; // 10 minutes
        this.maxLifetime = 1800000; // 30 minutes
        this.sqlitePath = "plugins/DBD-AMP/database.db";
    }
    
    public DatabaseType getType() {
        return type;
    }
    
    public void setType(DatabaseType type) {
        this.type = type;
    }
    
    public String getHost() {
        return host;
    }
    
    public void setHost(String host) {
        this.host = host;
    }
    
    public int getPort() {
        return port;
    }
    
    public void setPort(int port) {
        this.port = port;
    }
    
    public String getDatabase() {
        return database;
    }
    
    public void setDatabase(String database) {
        this.database = database;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public boolean isUseSSL() {
        return useSSL;
    }
    
    public void setUseSSL(boolean useSSL) {
        this.useSSL = useSSL;
    }
    
    public int getConnectionPoolSize() {
        return connectionPoolSize;
    }
    
    public void setConnectionPoolSize(int connectionPoolSize) {
        this.connectionPoolSize = connectionPoolSize;
    }
    
    public int getConnectionTimeout() {
        return connectionTimeout;
    }
    
    public void setConnectionTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }
    
    public int getIdleTimeout() {
        return idleTimeout;
    }
    
    public void setIdleTimeout(int idleTimeout) {
        this.idleTimeout = idleTimeout;
    }
    
    public int getMaxLifetime() {
        return maxLifetime;
    }
    
    public void setMaxLifetime(int maxLifetime) {
        this.maxLifetime = maxLifetime;
    }
    
    public String getSqlitePath() {
        return sqlitePath;
    }
    
    public void setSqlitePath(String sqlitePath) {
        this.sqlitePath = sqlitePath;
    }
    
    public String getConnectionString() {
        if (type == DatabaseType.MYSQL) {
            return String.format("jdbc:mysql://%s:%d/%s?useSSL=%b&serverTimezone=UTC",
                    host, port, database, useSSL);
        } else {
            return "jdbc:sqlite:" + sqlitePath;
        }
    }
    
    @Override
    public String toString() {
        return "DatabaseConfig{" +
               "type=" + type +
               ", host='" + host + '\'' +
               ", port=" + port +
               ", database='" + database + '\'' +
               ", username='" + username + '\'' +
               ", password='[HIDDEN]'" +
               ", useSSL=" + useSSL +
               ", connectionPoolSize=" + connectionPoolSize +
               ", connectionTimeout=" + connectionTimeout +
               ", idleTimeout=" + idleTimeout +
               ", maxLifetime=" + maxLifetime +
               ", sqlitePath='" + sqlitePath + '\'' +
               '}';
    }
}
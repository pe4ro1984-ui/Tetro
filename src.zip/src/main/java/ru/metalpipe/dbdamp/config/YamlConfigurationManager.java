package ru.metalpipe.dbdamp.config;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

/**
 * YAML-based implementation of ConfigurationManager for Bukkit/Paper plugins.
 * Supports hot-reload, validation, and automatic file creation.
 */
public class YamlConfigurationManager implements ConfigurationManager {
    
    private final JavaPlugin plugin;
    private final File configDir;
    private final Map<String, WatchRegistrationImpl> watchRegistrations;
    private final Map<Class<?>, Object> defaultConfigs;
    private final ScheduledExecutorService watchService;
    private final Map<String, Long> lastModifiedTimes;
    
    public YamlConfigurationManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.configDir = plugin.getDataFolder();
        this.watchRegistrations = new ConcurrentHashMap<>();
        this.defaultConfigs = new ConcurrentHashMap<>();
        this.watchService = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "DBD-AMP-Config-Watcher");
            t.setDaemon(true);
            return t;
        });
        this.lastModifiedTimes = new ConcurrentHashMap<>();
        
        // Start the watch service
        watchService.scheduleAtFixedRate(this::checkForChanges, 1, 1, TimeUnit.SECONDS);
    }
    
    @Override
    public <T> T loadConfig(String path, Class<T> type) throws ConfigurationException {
        File file = getConfigFile(path);
        return loadConfig(file, type);
    }
    
    @Override
    public <T> T loadConfig(File file, Class<T> type) throws ConfigurationException {
        try {
            if (!file.exists()) {
                throw new ConfigurationException("Configuration file does not exist: " + file.getPath());
            }
            
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
            return deserialize(yaml, type);
        } catch (Exception e) {
            throw new ConfigurationException("Failed to load configuration from " + file.getPath(), e);
        }
    }
    
    @Override
    public <T> T loadConfig(Path path, Class<T> type) throws ConfigurationException {
        return loadConfig(path.toFile(), type);
    }
    
    @Override
    public void saveConfig(String path, Object config) throws ConfigurationException {
        File file = getConfigFile(path);
        saveConfig(file, config);
    }
    
    @Override
    public void saveConfig(File file, Object config) throws ConfigurationException {
        try {
            // Create parent directories if they don't exist
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }
            
            YamlConfiguration yaml = serialize(config);
            yaml.save(file);
            
            // Update last modified time
            lastModifiedTimes.put(file.getAbsolutePath(), file.lastModified());
        } catch (Exception e) {
            throw new ConfigurationException("Failed to save configuration to " + file.getPath(), e);
        }
    }
    
    @Override
    public void saveConfig(Path path, Object config) throws ConfigurationException {
        saveConfig(path.toFile(), config);
    }
    
    @Override
    public WatchRegistration watchConfig(String path, ConfigChangeListener listener) throws ConfigurationException {
        File file = getConfigFile(path);
        String absolutePath = file.getAbsolutePath();
        
        WatchRegistrationImpl registration = new WatchRegistrationImpl(absolutePath, listener);
        watchRegistrations.put(absolutePath, registration);
        
        // Store initial modification time
        if (file.exists()) {
            lastModifiedTimes.put(absolutePath, file.lastModified());
        }
        
        return registration;
    }
    
    @Override
    public ValidationResult validateConfig(Object config) {
        // Basic validation: check for null fields that shouldn't be null
        List<String> errors = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        
        try {
            validateObject(config, "", errors, warnings, new HashSet<>());
        } catch (Exception e) {
            errors.add("Validation failed: " + e.getMessage());
        }
        
        return new ValidationResult(errors.isEmpty(), 
                                   errors.toArray(new String[0]), 
                                   warnings.toArray(new String[0]));
    }
    
    @Override
    public <T> T getDefaultConfig(Class<T> type) {
        return type.cast(defaultConfigs.computeIfAbsent(type, this::createDefaultConfig));
    }
    
    @Override
    public boolean configExists(String path) {
        return getConfigFile(path).exists();
    }
    
    @Override
    public <T> T loadOrCreateConfig(String path, Class<T> type) throws ConfigurationException {
        File file = getConfigFile(path);
        
        if (!file.exists()) {
            T defaultConfig = getDefaultConfig(type);
            saveConfig(file, defaultConfig);
            return defaultConfig;
        }
        
        return loadConfig(file, type);
    }
    
    @Override
    public void reloadAllWatchedConfigs() {
        for (WatchRegistrationImpl registration : watchRegistrations.values()) {
            registration.checkForChanges();
        }
    }
    
    @Override
    public void stopWatchingAll() {
        watchRegistrations.clear();
    }
    
    public void shutdown() {
        watchService.shutdown();
        try {
            if (!watchService.awaitTermination(5, TimeUnit.SECONDS)) {
                watchService.shutdownNow();
            }
        } catch (InterruptedException e) {
            watchService.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
    
    // Private helper methods
    
    private File getConfigFile(String path) {
        if (path.startsWith("/")) {
            path = path.substring(1);
        }
        return new File(configDir, path);
    }
    
    private <T> T deserialize(YamlConfiguration yaml, Class<T> type) throws Exception {
        // For simple types, use direct conversion
        if (type == String.class) {
            return type.cast(yaml.saveToString());
        }
        
        // Create instance
        T instance = type.getDeclaredConstructor().newInstance();
        
        // Get all fields
        for (Field field : getAllFields(type)) {
            if (Modifier.isStatic(field.getModifiers()) || Modifier.isTransient(field.getModifiers())) {
                continue;
            }
            
            field.setAccessible(true);
            String fieldName = field.getName();
            
            if (yaml.contains(fieldName)) {
                Object value = convertValue(yaml.get(fieldName), field.getType());
                field.set(instance, value);
            }
        }
        
        return instance;
    }
    
    private YamlConfiguration serialize(Object config) throws Exception {
        YamlConfiguration yaml = new YamlConfiguration();
        
        for (Field field : getAllFields(config.getClass())) {
            if (Modifier.isStatic(field.getModifiers()) || Modifier.isTransient(field.getModifiers())) {
                continue;
            }
            
            field.setAccessible(true);
            Object value = field.get(config);
            
            if (value != null) {
                yaml.set(field.getName(), convertForYaml(value));
            }
        }
        
        return yaml;
    }
    
    private Object convertValue(Object yamlValue, Class<?> targetType) {
        if (yamlValue == null) {
            return null;
        }
        
        // Handle common types
        if (targetType == String.class) {
            return yamlValue.toString();
        } else if (targetType == Integer.class || targetType == int.class) {
            if (yamlValue instanceof Number) {
                return ((Number) yamlValue).intValue();
            }
            return Integer.parseInt(yamlValue.toString());
        } else if (targetType == Double.class || targetType == double.class) {
            if (yamlValue instanceof Number) {
                return ((Number) yamlValue).doubleValue();
            }
            return Double.parseDouble(yamlValue.toString());
        } else if (targetType == Boolean.class || targetType == boolean.class) {
            if (yamlValue instanceof Boolean) {
                return yamlValue;
            }
            return Boolean.parseBoolean(yamlValue.toString());
        } else if (targetType == Long.class || targetType == long.class) {
            if (yamlValue instanceof Number) {
                return ((Number) yamlValue).longValue();
            }
            return Long.parseLong(yamlValue.toString());
        } else if (targetType == Float.class || targetType == float.class) {
            if (yamlValue instanceof Number) {
                return ((Number) yamlValue).floatValue();
            }
            return Float.parseFloat(yamlValue.toString());
        } else if (targetType.isEnum()) {
            return Enum.valueOf((Class<Enum>) targetType, yamlValue.toString());
        } else if (targetType == List.class) {
            // Handle lists - YAML returns List<?> for sequences
            return yamlValue;
        } else if (targetType == Map.class) {
            // Handle maps - YAML returns Map<?, ?> for mappings
            return yamlValue;
        } else if (yamlValue instanceof ConfigurationSection) {
            // Recursively deserialize nested objects
            try {
                return deserialize((ConfigurationSection) yamlValue, targetType);
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to deserialize nested object: " + e.getMessage());
                return null;
            }
        }
        
        // Default: return as-is
        return yamlValue;
    }
    
    private Object convertForYaml(Object value) {
        if (value == null) {
            return null;
        }
        
        // Handle enums
        if (value instanceof Enum) {
            return ((Enum<?>) value).name();
        }
        
        // Handle collections and maps
        if (value instanceof Collection || value instanceof Map) {
            return value;
        }
        
        // Handle custom objects
        try {
            // Check if it's a simple type
            if (value instanceof String || value instanceof Number || value instanceof Boolean) {
                return value;
            }
            
            // For custom objects, serialize recursively
            return serialize(value);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to serialize object for YAML: " + e.getMessage());
            return value.toString();
        }
    }
    
    private <T> T deserialize(ConfigurationSection section, Class<T> type) throws Exception {
        T instance = type.getDeclaredConstructor().newInstance();
        
        for (Field field : getAllFields(type)) {
            if (Modifier.isStatic(field.getModifiers()) || Modifier.isTransient(field.getModifiers())) {
                continue;
            }
            
            field.setAccessible(true);
            String fieldName = field.getName();
            
            if (section.contains(fieldName)) {
                Object value = convertValue(section.get(fieldName), field.getType());
                field.set(instance, value);
            }
        }
        
        return instance;
    }
    
    private List<Field> getAllFields(Class<?> type) {
        List<Field> fields = new ArrayList<>();
        Class<?> current = type;
        
        while (current != null && current != Object.class) {
            fields.addAll(Arrays.asList(current.getDeclaredFields()));
            current = current.getSuperclass();
        }
        
        return fields;
    }
    
    private <T> T createDefaultConfig(Class<T> type) {
        try {
            return type.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to create default config for " + type.getName() + ": " + e.getMessage());
            return null;
        }
    }
    
    private void validateObject(Object obj, String path, List<String> errors, List<String> warnings, Set<Object> visited) {
        if (obj == null || visited.contains(obj)) {
            return;
        }
        
        visited.add(obj);
        
        try {
            for (Field field : getAllFields(obj.getClass())) {
                if (Modifier.isStatic(field.getModifiers()) || Modifier.isTransient(field.getModifiers())) {
                    continue;
                }
                
                field.setAccessible(true);
                Object value = field.get(obj);
                String fieldPath = path.isEmpty() ? field.getName() : path + "." + field.getName();
                
                // Check for null if field has @NotNull annotation
                if (value == null) {
                    // Check if field is primitive (can't be null)
                    if (field.getType().isPrimitive()) {
                        errors.add(fieldPath + ": Primitive field cannot be null");
                    }
                } else {
                    // Recursively validate nested objects
                    if (!field.getType().isPrimitive() && 
                        !field.getType().getName().startsWith("java.") &&
                        !field.getType().isEnum()) {
                        validateObject(value, fieldPath, errors, warnings, visited);
                    }
                }
            }
        } catch (Exception e) {
            errors.add("Validation error at " + path + ": " + e.getMessage());
        }
    }
    
    private void checkForChanges() {
        for (WatchRegistrationImpl registration : watchRegistrations.values()) {
            registration.checkForChanges();
        }
    }
    
    // Inner class for watch registration implementation
    private class WatchRegistrationImpl implements WatchRegistration {
        private final String filePath;
        private final ConfigChangeListener listener;
        private volatile boolean watching = true;
        private Object lastConfig;
        private final Class<?> configType;
        
        public WatchRegistrationImpl(String filePath, ConfigChangeListener listener) {
            this.filePath = filePath;
            this.listener = listener;
            this.configType = Object.class; // Default type
            
            // Try to load initial config
            try {
                File file = new File(filePath);
                if (file.exists()) {
                    // We don't know the type, so we'll use YamlConfiguration directly
                    this.lastConfig = YamlConfiguration.loadConfiguration(file);
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to load initial config for watching: " + e.getMessage());
            }
        }
        
        @Override
        public void stopWatching() {
            watching = false;
            watchRegistrations.remove(filePath);
        }
        
        @Override
        public boolean isWatching() {
            return watching;
        }
        
        public void checkForChanges() {
            if (!watching) {
                return;
            }
            
            File file = new File(filePath);
            if (!file.exists()) {
                return;
            }
            
            Long lastModified = lastModifiedTimes.get(filePath);
            long currentModified = file.lastModified();
            
            if (lastModified == null || currentModified > lastModified) {
                lastModifiedTimes.put(filePath, currentModified);
                
                try {
                    Object newConfig = YamlConfiguration.loadConfiguration(file);
                    
                    // Notify listener
                    if (listener != null) {
                        listener.onConfigChanged(lastConfig, newConfig);
                    }
                    
                    lastConfig = newConfig;
                } catch (Exception e) {
                    plugin.getLogger().warning("Failed to reload watched config " + filePath + ": " + e.getMessage());
                }
            }
        }
    }
}
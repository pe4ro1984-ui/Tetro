package ru.metalpipe.dbdamp.config;

/**
 * Gameplay configuration for DBD core mechanics.
 */
public class GameplayConfig {
    
    private int matchDuration; // in seconds
    private int generatorsRequired;
    private int totalGenerators;
    private int hookSacrificeTime; // in seconds
    private int generatorRepairTime; // in seconds
    private int skillCheckFrequency; // in ticks
    private int skillCheckWindow; // in ticks
    private double survivorBaseSpeed;
    private double killerBaseSpeed;
    private double injuredSpeedPenalty;
    private double terrorRadiusBase; // in blocks
    private int healingTime; // in seconds
    private int selfHealingTime; // in seconds
    private int attackCooldown; // in ticks
    private int bloodlustMaxStacks;
    private double bloodlustSpeedPerStack;
    
    public GameplayConfig() {
        // Default DBD-like values
        this.matchDuration = 900; // 15 minutes
        this.generatorsRequired = 5;
        this.totalGenerators = 7;
        this.hookSacrificeTime = 180; // 3 minutes
        this.generatorRepairTime = 90; // 1.5 minutes
        this.skillCheckFrequency = 200; // ~10 seconds
        this.skillCheckWindow = 20; // 1 second
        this.survivorBaseSpeed = 0.3; // 4.0 m/s in Minecraft units
        this.killerBaseSpeed = 0.35; // 4.6 m/s
        this.injuredSpeedPenalty = 0.15; // 15% slower
        this.terrorRadiusBase = 32.0; // 32 blocks
        this.healingTime = 16; // 16 seconds
        this.selfHealingTime = 32; // 32 seconds
        this.attackCooldown = 40; // 2 seconds
        this.bloodlustMaxStacks = 3;
        this.bloodlustSpeedPerStack = 0.05; // 5% per stack
    }
    
    // Getters and setters
    public int getMatchDuration() { return matchDuration; }
    public void setMatchDuration(int matchDuration) { this.matchDuration = matchDuration; }
    
    public int getGeneratorsRequired() { return generatorsRequired; }
    public void setGeneratorsRequired(int generatorsRequired) { this.generatorsRequired = generatorsRequired; }
    
    public int getTotalGenerators() { return totalGenerators; }
    public void setTotalGenerators(int totalGenerators) { this.totalGenerators = totalGenerators; }
    
    public int getHookSacrificeTime() { return hookSacrificeTime; }
    public void setHookSacrificeTime(int hookSacrificeTime) { this.hookSacrificeTime = hookSacrificeTime; }
    
    public int getGeneratorRepairTime() { return generatorRepairTime; }
    public void setGeneratorRepairTime(int generatorRepairTime) { this.generatorRepairTime = generatorRepairTime; }
    
    public int getSkillCheckFrequency() { return skillCheckFrequency; }
    public void setSkillCheckFrequency(int skillCheckFrequency) { this.skillCheckFrequency = skillCheckFrequency; }
    
    public int getSkillCheckWindow() { return skillCheckWindow; }
    public void setSkillCheckWindow(int skillCheckWindow) { this.skillCheckWindow = skillCheckWindow; }
    
    public double getSurvivorBaseSpeed() { return survivorBaseSpeed; }
    public void setSurvivorBaseSpeed(double survivorBaseSpeed) { this.survivorBaseSpeed = survivorBaseSpeed; }
    
    public double getKillerBaseSpeed() { return killerBaseSpeed; }
    public void setKillerBaseSpeed(double killerBaseSpeed) { this.killerBaseSpeed = killerBaseSpeed; }
    
    public double getInjuredSpeedPenalty() { return injuredSpeedPenalty; }
    public void setInjuredSpeedPenalty(double injuredSpeedPenalty) { this.injuredSpeedPenalty = injuredSpeedPenalty; }
    
    public double getTerrorRadiusBase() { return terrorRadiusBase; }
    public void setTerrorRadiusBase(double terrorRadiusBase) { this.terrorRadiusBase = terrorRadiusBase; }
    
    public int getHealingTime() { return healingTime; }
    public void setHealingTime(int healingTime) { this.healingTime = healingTime; }
    
    public int getSelfHealingTime() { return selfHealingTime; }
    public void setSelfHealingTime(int selfHealingTime) { this.selfHealingTime = selfHealingTime; }
    
    public int getAttackCooldown() { return attackCooldown; }
    public void setAttackCooldown(int attackCooldown) { this.attackCooldown = attackCooldown; }
    
    public int getBloodlustMaxStacks() { return bloodlustMaxStacks; }
    public void setBloodlustMaxStacks(int bloodlustMaxStacks) { this.bloodlustMaxStacks = bloodlustMaxStacks; }
    
    public double getBloodlustSpeedPerStack() { return bloodlustSpeedPerStack; }
    public void setBloodlustSpeedPerStack(double bloodlustSpeedPerStack) { this.bloodlustSpeedPerStack = bloodlustSpeedPerStack; }
    
    @Override
    public String toString() {
        return "GameplayConfig{" +
               "matchDuration=" + matchDuration +
               ", generatorsRequired=" + generatorsRequired +
               ", totalGenerators=" + totalGenerators +
               ", hookSacrificeTime=" + hookSacrificeTime +
               ", generatorRepairTime=" + generatorRepairTime +
               ", skillCheckFrequency=" + skillCheckFrequency +
               ", skillCheckWindow=" + skillCheckWindow +
               ", survivorBaseSpeed=" + survivorBaseSpeed +
               ", killerBaseSpeed=" + killerBaseSpeed +
               ", injuredSpeedPenalty=" + injuredSpeedPenalty +
               ", terrorRadiusBase=" + terrorRadiusBase +
               ", healingTime=" + healingTime +
               ", selfHealingTime=" + selfHealingTime +
               ", attackCooldown=" + attackCooldown +
               ", bloodlustMaxStacks=" + bloodlustMaxStacks +
               ", bloodlustSpeedPerStack=" + bloodlustSpeedPerStack +
               '}';
    }
}
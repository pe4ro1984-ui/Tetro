package ru.metalpipe.dbdamp.config;

import java.util.List;

/**
 * Main plugin configuration class containing all module configurations.
 */
public class PluginConfig {
    
    private DatabaseConfig database;
    private GameplayConfig gameplay;
    private EconomyConfig economy;
    private MatchmakingConfig matchmaking;
    private PerformanceConfig performance;
    private List<ModuleConfig> modules;
    
    public PluginConfig() {
        // Default values
        this.database = new DatabaseConfig();
        this.gameplay = new GameplayConfig();
        this.economy = new EconomyConfig();
        this.matchmaking = new MatchmakingConfig();
        this.performance = new PerformanceConfig();
        this.modules = List.of();
    }
    
    public DatabaseConfig getDatabase() {
        return database;
    }
    
    public void setDatabase(DatabaseConfig database) {
        this.database = database;
    }
    
    public GameplayConfig getGameplay() {
        return gameplay;
    }
    
    public void setGameplay(GameplayConfig gameplay) {
        this.gameplay = gameplay;
    }
    
    public EconomyConfig getEconomy() {
        return economy;
    }
    
    public void setEconomy(EconomyConfig economy) {
        this.economy = economy;
    }
    
    public MatchmakingConfig getMatchmaking() {
        return matchmaking;
    }
    
    public void setMatchmaking(MatchmakingConfig matchmaking) {
        this.matchmaking = matchmaking;
    }
    
    public PerformanceConfig getPerformance() {
        return performance;
    }
    
    public void setPerformance(PerformanceConfig performance) {
        this.performance = performance;
    }
    
    public List<ModuleConfig> getModules() {
        return modules;
    }
    
    public void setModules(List<ModuleConfig> modules) {
        this.modules = modules;
    }
    
    @Override
    public String toString() {
        return "PluginConfig{" +
               "database=" + database +
               ", gameplay=" + gameplay +
               ", economy=" + economy +
               ", matchmaking=" + matchmaking +
               ", performance=" + performance +
               ", modules=" + modules +
               '}';
    }
}
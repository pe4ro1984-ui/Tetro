package ru.metalpipe.dbdamp.lobby;

import ru.metalpipe.dbdamp.gameplay.model.GameMode;
import ru.metalpipe.dbdamp.gameplay.model.PlayerRole;

import java.time.Instant;
import java.util.*;

/**
 * Represents a match lobby where players wait before starting a match.
 */
public class Lobby {
    
    private UUID lobbyId;
    private String lobbyName;
    private UUID hostId;
    private GameMode gameMode;
    private String password;
    private boolean isPasswordProtected;
    private boolean isPublic;
    
    // Player management
    private Map<UUID, LobbyPlayer> players;
    private int maxPlayers;
    private int minPlayers;
    
    // Role selection
    private Map<UUID, PlayerRole> rolePreferences;
    private int maxKillers;
    private int maxSurvivors;
    
    // Lobby state
    private LobbyStatus status;
    private int countdownSeconds;
    private Instant createdTime;
    private Instant countdownStartTime;
    private Map<String, Object> settings;
    
    public Lobby() {
        this.lobbyId = UUID.randomUUID();
        this.players = new LinkedHashMap<>();
        this.rolePreferences = new HashMap<>();
        this.status = LobbyStatus.WAITING;
        this.countdownSeconds = 30;
        this.createdTime = Instant.now();
        this.settings = new HashMap<>();
        this.isPublic = true;
        this.isPasswordProtected = false;
        
        // Default limits for 1v4 match
        this.maxKillers = 1;
        this.maxSurvivors = 4;
        this.maxPlayers = 5;
        this.minPlayers = 2; // Minimum to start
    }
    
    public Lobby(UUID hostId, GameMode gameMode) {
        this();
        this.hostId = hostId;
        this.gameMode = gameMode;
    }
    
    // Getters and setters
    public UUID getLobbyId() { return lobbyId; }
    public void setLobbyId(UUID lobbyId) { this.lobbyId = lobbyId; }
    
    public String getLobbyName() { return lobbyName; }
    public void setLobbyName(String lobbyName) { this.lobbyName = lobbyName; }
    
    public UUID getHostId() { return hostId; }
    public void setHostId(UUID hostId) { this.hostId = hostId; }
    
    public GameMode getGameMode() { return gameMode; }
    public void setGameMode(GameMode gameMode) { this.gameMode = gameMode; }
    
    public String getPassword() { return password; }
    public void setPassword(String password) { 
        this.password = password;
        this.isPasswordProtected = password != null && !password.isEmpty();
    }
    
    public boolean isPasswordProtected() { return isPasswordProtected; }
    
    public boolean isPublic() { return isPublic; }
    public void setPublic(boolean isPublic) { this.isPublic = isPublic; }
    
    public Map<UUID, LobbyPlayer> getPlayers() { return players; }
    public void setPlayers(Map<UUID, LobbyPlayer> players) { this.players = players; }
    
    public int getMaxPlayers() { return maxPlayers; }
    public void setMaxPlayers(int maxPlayers) { this.maxPlayers = maxPlayers; }
    
    public int getMinPlayers() { return minPlayers; }
    public void setMinPlayers(int minPlayers) { this.minPlayers = minPlayers; }
    
    public Map<UUID, PlayerRole> getRolePreferences() { return rolePreferences; }
    public void setRolePreferences(Map<UUID, PlayerRole> rolePreferences) { 
        this.rolePreferences = rolePreferences != null ? rolePreferences : new HashMap<>(); 
    }
    
    public int getMaxKillers() { return maxKillers; }
    public void setMaxKillers(int maxKillers) { this.maxKillers = maxKillers; }
    
    public int getMaxSurvivors() { return maxSurvivors; }
    public void setMaxSurvivors(int maxSurvivors) { this.maxSurvivors = maxSurvivors; }
    
    public LobbyStatus getStatus() { return status; }
    public void setStatus(LobbyStatus status) { this.status = status; }
    
    public int getCountdownSeconds() { return countdownSeconds; }
    public void setCountdownSeconds(int countdownSeconds) { this.countdownSeconds = countdownSeconds; }
    
    public Instant getCreatedTime() { return createdTime; }
    public void setCreatedTime(Instant createdTime) { this.createdTime = createdTime; }
    
    public Instant getCountdownStartTime() { return countdownStartTime; }
    public void setCountdownStartTime(Instant countdownStartTime) { this.countdownStartTime = countdownStartTime; }
    
    public Map<String, Object> getSettings() { return settings; }
    public void setSettings(Map<String, Object> settings) { this.settings = settings; }
    
    // Player management
    public boolean addPlayer(UUID playerId, String playerName) {
        if (isFull()) {
            return false;
        }
        
        LobbyPlayer player = new LobbyPlayer(playerId, playerName);
        players.put(playerId, player);
        
        // Default role preference is survivor
        rolePreferences.put(playerId, PlayerRole.SURVIVOR);
        
        return true;
    }
    
    public boolean removePlayer(UUID playerId) {
        LobbyPlayer removed = players.remove(playerId);
        if (removed != null) {
            rolePreferences.remove(playerId);
            return true;
        }
        return false;
    }
    
    public boolean hasPlayer(UUID playerId) {
        return players.containsKey(playerId);
    }
    
    public LobbyPlayer getPlayer(UUID playerId) {
        return players.get(playerId);
    }
    
    public int getPlayerCount() {
        return players.size();
    }
    
    public boolean isFull() {
        return players.size() >= maxPlayers;
    }
    
    public boolean canStart() {
        return players.size() >= minPlayers && allPlayersReady();
    }
    
    public boolean allPlayersReady() {
        for (LobbyPlayer player : players.values()) {
            if (!player.isReady() && !player.getPlayerId().equals(hostId)) {
                return false;
            }
        }
        return true;
    }
    
    // Role management
    public boolean setRolePreference(UUID playerId, PlayerRole role) {
        if (!hasPlayer(playerId)) {
            return false;
        }
        
        // Check if role is available
        int currentCount = getRoleCount(role);
        int maxCount = role == PlayerRole.KILLER ? maxKillers : maxSurvivors;
        
        // If switching roles, check if new role has space
        PlayerRole currentRole = rolePreferences.get(playerId);
        if (currentRole == role) {
            return true; // Already set to this role
        }
        
        if (currentCount >= maxCount) {
            return false; // Role is full
        }
        
        rolePreferences.put(playerId, role);
        return true;
    }
    
    public PlayerRole getRolePreference(UUID playerId) {
        return rolePreferences.get(playerId);
    }
    
    public int getRoleCount(PlayerRole role) {
        int count = 0;
        for (PlayerRole pref : rolePreferences.values()) {
            if (pref == role) {
                count++;
            }
        }
        return count;
    }
    
    public boolean hasRoleAvailable(PlayerRole role) {
        int currentCount = getRoleCount(role);
        int maxCount = role == PlayerRole.KILLER ? maxKillers : maxSurvivors;
        return currentCount < maxCount;
    }
    
    // Ready status
    public void setPlayerReady(UUID playerId, boolean ready) {
        LobbyPlayer player = players.get(playerId);
        if (player != null) {
            player.setReady(ready);
        }
    }
    
    // Countdown
    public void startCountdown() {
        this.status = LobbyStatus.COUNTDOWN;
        this.countdownStartTime = Instant.now();
    }
    
    public void cancelCountdown() {
        this.status = LobbyStatus.WAITING;
        this.countdownStartTime = null;
    }
    
    public int getRemainingCountdownSeconds() {
        if (status != LobbyStatus.COUNTDOWN || countdownStartTime == null) {
            return 0;
        }
        
        long elapsed = Instant.now().getEpochSecond() - countdownStartTime.getEpochSecond();
        int remaining = countdownSeconds - (int) elapsed;
        return Math.max(0, remaining);
    }
    
    public boolean isCountdownComplete() {
        return getRemainingCountdownSeconds() <= 0;
    }
    
    // Settings
    public Object getSetting(String key) {
        return settings.get(key);
    }
    
    public void setSetting(String key, Object value) {
        settings.put(key, value);
    }
    
    @Override
    public String toString() {
        return "Lobby{" +
               "lobbyId=" + lobbyId +
               ", gameMode=" + gameMode +
               ", players=" + getPlayerCount() + "/" + maxPlayers +
               ", status=" + status +
               '}';
    }
    
    /**
     * Represents a player in a lobby.
     */
    public static class LobbyPlayer {
        private UUID playerId;
        private String playerName;
        private boolean isReady;
        private Instant joinTime;
        private Map<String, Object> metadata;
        
        public LobbyPlayer(UUID playerId, String playerName) {
            this.playerId = playerId;
            this.playerName = playerName;
            this.isReady = false;
            this.joinTime = Instant.now();
            this.metadata = new HashMap<>();
        }
        
        public UUID getPlayerId() { return playerId; }
        public void setPlayerId(UUID playerId) { this.playerId = playerId; }
        
        public String getPlayerName() { return playerName; }
        public void setPlayerName(String playerName) { this.playerName = playerName; }
        
        public boolean isReady() { return isReady; }
        public void setReady(boolean isReady) { this.isReady = isReady; }
        
        public Instant getJoinTime() { return joinTime; }
        public void setJoinTime(Instant joinTime) { this.joinTime = joinTime; }
        
        public Map<String, Object> getMetadata() { return metadata; }
        public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }
    }
    
    /**
     * Lobby status enum.
     */
    public enum LobbyStatus {
        WAITING("Waiting for players"),
        COUNTDOWN("Match starting soon"),
        STARTING("Starting match"),
        IN_MATCH("In match"),
        CLOSED("Closed");
        
        private final String displayName;
        
        LobbyStatus(String displayName) {
            this.displayName = displayName;
        }
        
        public String getDisplayName() { return displayName; }
    }
}
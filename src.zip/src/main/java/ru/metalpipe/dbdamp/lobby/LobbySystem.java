package ru.metalpipe.dbdamp.lobby;

import ru.metalpipe.dbdamp.gameplay.model.GameMode;
import ru.metalpipe.dbdamp.gameplay.model.Match;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Interface for managing match lobbies and player matchmaking.
 */
public interface LobbySystem {
    
    /**
     * Create a new lobby.
     * 
     * @param creatorId The creator's UUID
     * @param mode The game mode
     * @param settings Additional lobby settings
     * @return The created lobby
     */
    Lobby createLobby(UUID creatorId, GameMode mode, Map<String, Object> settings);
    
    /**
     * Create a password-protected lobby.
     * 
     * @param creatorId The creator's UUID
     * @param mode The game mode
     * @param password The lobby password
     * @param settings Additional lobby settings
     * @return The created lobby
     */
    Lobby createLobby(UUID creatorId, GameMode mode, String password, Map<String, Object> settings);
    
    /**
     * Join an existing lobby.
     * 
     * @param playerId The player's UUID
     * @param lobbyId The lobby's UUID
     * @param password The password (if required)
     * @return true if joined successfully
     */
    boolean joinLobby(UUID playerId, UUID lobbyId, String password);
    
    /**
     * Leave a lobby.
     * 
     * @param playerId The player's UUID
     * @return true if left successfully
     */
    boolean leaveLobby(UUID playerId);
    
    /**
     * Get a lobby by ID.
     * 
     * @param lobbyId The lobby's UUID
     * @return The lobby, or null if not found
     */
    Lobby getLobby(UUID lobbyId);
    
    /**
     * Get the lobby a player is currently in.
     * 
     * @param playerId The player's UUID
     * @return The lobby, or null if not in a lobby
     */
    Lobby getPlayerLobby(UUID playerId);
    
    /**
     * Get all available lobbies for a game mode.
     * 
     * @param mode The game mode
     * @return List of available lobbies
     */
    List<Lobby> getAvailableLobbies(GameMode mode);
    
    /**
     * Get all active lobbies.
     * 
     * @return List of all active lobbies
     */
    List<Lobby> getAllLobbies();
    
    /**
     * Set a player as ready in a lobby.
     * 
     * @param playerId The player's UUID
     * @param ready Whether the player is ready
     * @return true if status was updated
     */
    boolean setReady(UUID playerId, boolean ready);
    
    /**
     * Check if all players in a lobby are ready.
     * 
     * @param lobbyId The lobby's UUID
     * @return true if all players are ready
     */
    boolean allPlayersReady(UUID lobbyId);
    
    /**
     * Start the match countdown.
     * 
     * @param lobbyId The lobby's UUID
     * @return true if countdown started
     */
    boolean startCountdown(UUID lobbyId);
    
    /**
     * Cancel the match countdown.
     * 
     * @param lobbyId The lobby's UUID
     * @return true if countdown was cancelled
     */
    boolean cancelCountdown(UUID lobbyId);
    
    /**
     * Start a match from a lobby.
     * 
     * @param lobbyId The lobby's UUID
     * @return The created match
     */
    Match startMatch(UUID lobbyId);
    
    /**
     * Close a lobby.
     * 
     * @param lobbyId The lobby's UUID
     * @return true if lobby was closed
     */
    boolean closeLobby(UUID lobbyId);
    
    /**
     * Set the lobby host.
     * 
     * @param lobbyId The lobby's UUID
     * @param hostId The new host's UUID
     * @return true if host was set
     */
    boolean setHost(UUID lobbyId, UUID hostId);
    
    /**
     * Kick a player from a lobby.
     * 
     * @param lobbyId The lobby's UUID
     * @param playerId The player to kick
     * @param reason The kick reason
     * @return true if player was kicked
     */
    boolean kickPlayer(UUID lobbyId, UUID playerId, String reason);
    
    /**
     * Get the number of players in a lobby.
     * 
     * @param lobbyId The lobby's UUID
     * @return Number of players
     */
    int getPlayerCount(UUID lobbyId);
    
    /**
     * Check if a lobby is full.
     * 
     * @param lobbyId The lobby's UUID
     * @return true if lobby is full
     */
    boolean isFull(UUID lobbyId);
    
    /**
     * Find a suitable lobby for matchmaking.
     * 
     * @param playerId The player's UUID
     * @param mode The preferred game mode
     * @return The best matching lobby, or null if none found
     */
    Lobby findBestLobby(UUID playerId, GameMode mode);
}
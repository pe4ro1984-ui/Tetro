package ru.metalpipe.dbdamp.lobby;

import ru.metalpipe.dbdamp.gameplay.model.GameMode;
import ru.metalpipe.dbdamp.gameplay.model.Match;
import ru.metalpipe.dbdamp.gameplay.model.PlayerRole;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * Implementation of the lobby system.
 * Manages lobby creation, player joining, matchmaking, and match starting.
 */
public class LobbySystemImpl implements LobbySystem {
    
    private final Logger logger;
    
    // Active lobbies
    private final Map<UUID, Lobby> lobbies;
    
    // Player to lobby mapping
    private final Map<UUID, UUID> playerLobbies;
    
    // Configuration
    private static final int DEFAULT_COUNTDOWN_SECONDS = 30;
    private static final int MIN_PLAYERS_PUBLIC = 2;
    private static final int MAX_PLAYERS_PUBLIC = 5;
    
    public LobbySystemImpl() {
        this.logger = Logger.getLogger(getClass().getName());
        this.lobbies = new ConcurrentHashMap<>();
        this.playerLobbies = new ConcurrentHashMap<>();
    }
    
    // Lobby creation
    @Override
    public Lobby createLobby(UUID creatorId, GameMode mode, Map<String, Object> settings) {
        return createLobby(creatorId, mode, null, settings);
    }
    
    @Override
    public Lobby createLobby(UUID creatorId, GameMode mode, String password, Map<String, Object> settings) {
        // Check if player is already in a lobby
        if (playerLobbies.containsKey(creatorId)) {
            return null;
        }
        
        Lobby lobby = new Lobby(creatorId, mode);
        
        // Set password if provided
        if (password != null && !password.isEmpty()) {
            lobby.setPassword(password);
        }
        
        // Apply settings
        if (settings != null) {
            applyLobbySettings(lobby, settings);
        }
        
        // Add creator as host
        String creatorName = getPlayerName(creatorId);
        lobby.addPlayer(creatorId, creatorName);
        lobby.setHostId(creatorId);
        
        // Register lobby
        lobbies.put(lobby.getLobbyId(), lobby);
        playerLobbies.put(creatorId, lobby.getLobbyId());
        
        logger.info("Created lobby " + lobby.getLobbyId() + " by player " + creatorId);
        return lobby;
    }
    
    // Joining and leaving
    @Override
    public boolean joinLobby(UUID playerId, UUID lobbyId, String password) {
        // Check if player is already in a lobby
        if (playerLobbies.containsKey(playerId)) {
            return false;
        }
        
        Lobby lobby = lobbies.get(lobbyId);
        if (lobby == null) {
            return false;
        }
        
        // Check if lobby is full
        if (lobby.isFull()) {
            return false;
        }
        
        // Check password
        if (lobby.isPasswordProtected()) {
            if (password == null || !password.equals(lobby.getPassword())) {
                return false;
            }
        }
        
        // Check lobby status
        if (lobby.getStatus() != Lobby.LobbyStatus.WAITING) {
            return false;
        }
        
        // Add player
        String playerName = getPlayerName(playerId);
        if (!lobby.addPlayer(playerId, playerName)) {
            return false;
        }
        
        playerLobbies.put(playerId, lobbyId);
        
        logger.info("Player " + playerId + " joined lobby " + lobbyId);
        return true;
    }
    
    @Override
    public boolean leaveLobby(UUID playerId) {
        UUID lobbyId = playerLobbies.remove(playerId);
        if (lobbyId == null) {
            return false;
        }
        
        Lobby lobby = lobbies.get(lobbyId);
        if (lobby == null) {
            return false;
        }
        
        lobby.removePlayer(playerId);
        
        // If lobby is empty, close it
        if (lobby.getPlayerCount() == 0) {
            closeLobby(lobbyId);
        }
        
        // If host left, assign new host
        if (playerId.equals(lobby.getHostId())) {
            assignNewHost(lobby);
        }
        
        logger.info("Player " + playerId + " left lobby " + lobbyId);
        return true;
    }
    
    // Lobby retrieval
    @Override
    public Lobby getLobby(UUID lobbyId) {
        return lobbies.get(lobbyId);
    }
    
    @Override
    public Lobby getPlayerLobby(UUID playerId) {
        UUID lobbyId = playerLobbies.get(playerId);
        if (lobbyId == null) {
            return null;
        }
        return lobbies.get(lobbyId);
    }
    
    @Override
    public List<Lobby> getAvailableLobbies(GameMode mode) {
        return lobbies.values().stream()
            .filter(l -> l.getGameMode() == mode)
            .filter(l -> l.getStatus() == Lobby.LobbyStatus.WAITING)
            .filter(l -> !l.isFull())
            .filter(l -> l.isPublic())
            .collect(Collectors.toList());
    }
    
    @Override
    public List<Lobby> getAllLobbies() {
        return new ArrayList<>(lobbies.values());
    }
    
    // Ready status
    @Override
    public boolean setReady(UUID playerId, boolean ready) {
        Lobby lobby = getPlayerLobby(playerId);
        if (lobby == null) {
            return false;
        }
        
        // Host doesn't need to be ready
        if (playerId.equals(lobby.getHostId())) {
            return true;
        }
        
        lobby.setPlayerReady(playerId, ready);
        
        // Auto-start countdown if all players ready
        if (ready && lobby.canStart()) {
            startCountdown(lobby.getLobbyId());
        }
        
        return true;
    }
    
    @Override
    public boolean allPlayersReady(UUID lobbyId) {
        Lobby lobby = lobbies.get(lobbyId);
        return lobby != null && lobby.allPlayersReady();
    }
    
    // Countdown
    @Override
    public boolean startCountdown(UUID lobbyId) {
        Lobby lobby = lobbies.get(lobbyId);
        if (lobby == null || lobby.getStatus() != Lobby.LobbyStatus.WAITING) {
            return false;
        }
        
        if (!lobby.canStart()) {
            return false;
        }
        
        lobby.startCountdown();
        logger.info("Started countdown for lobby " + lobbyId);
        return true;
    }
    
    @Override
    public boolean cancelCountdown(UUID lobbyId) {
        Lobby lobby = lobbies.get(lobbyId);
        if (lobby == null || lobby.getStatus() != Lobby.LobbyStatus.COUNTDOWN) {
            return false;
        }
        
        lobby.cancelCountdown();
        logger.info("Cancelled countdown for lobby " + lobbyId);
        return true;
    }
    
    // Match starting
    @Override
    public Match startMatch(UUID lobbyId) {
        Lobby lobby = lobbies.get(lobbyId);
        if (lobby == null) {
            return null;
        }
        
        if (!lobby.canStart()) {
            return null;
        }
        
        // Create match
        Match match = new Match(lobby.getGameMode(), null);
        
        // Add players with their roles
        for (Map.Entry<UUID, Lobby.LobbyPlayer> entry : lobby.getPlayers().entrySet()) {
            PlayerRole role = lobby.getRolePreference(entry.getKey());
            if (role == null) {
                role = PlayerRole.SURVIVOR;
            }
            match.addPlayer(entry.getKey(), role);
        }
        
        // Assign roles (ensure balance)
        assignRoles(match, lobby);
        
        // Close lobby
        for (UUID playerId : lobby.getPlayers().keySet()) {
            playerLobbies.remove(playerId);
        }
        lobby.setStatus(Lobby.LobbyStatus.IN_MATCH);
        
        logger.info("Started match " + match.getMatchId() + " from lobby " + lobbyId);
        return match;
    }
    
    // Lobby management
    @Override
    public boolean closeLobby(UUID lobbyId) {
        Lobby lobby = lobbies.remove(lobbyId);
        if (lobby == null) {
            return false;
        }
        
        // Remove all players from mapping
        for (UUID playerId : lobby.getPlayers().keySet()) {
            playerLobbies.remove(playerId);
        }
        
        lobby.setStatus(Lobby.LobbyStatus.CLOSED);
        logger.info("Closed lobby " + lobbyId);
        return true;
    }
    
    @Override
    public boolean setHost(UUID lobbyId, UUID hostId) {
        Lobby lobby = lobbies.get(lobbyId);
        if (lobby == null || !lobby.hasPlayer(hostId)) {
            return false;
        }
        
        lobby.setHostId(hostId);
        logger.info("Set host of lobby " + lobbyId + " to " + hostId);
        return true;
    }
    
    @Override
    public boolean kickPlayer(UUID lobbyId, UUID playerId, String reason) {
        Lobby lobby = lobbies.get(lobbyId);
        if (lobby == null) {
            return false;
        }
        
        if (!lobby.hasPlayer(playerId)) {
            return false;
        }
        
        lobby.removePlayer(playerId);
        playerLobbies.remove(playerId);
        
        logger.info("Kicked player " + playerId + " from lobby " + lobbyId + " (" + reason + ")");
        return true;
    }
    
    @Override
    public int getPlayerCount(UUID lobbyId) {
        Lobby lobby = lobbies.get(lobbyId);
        return lobby != null ? lobby.getPlayerCount() : 0;
    }
    
    @Override
    public boolean isFull(UUID lobbyId) {
        Lobby lobby = lobbies.get(lobbyId);
        return lobby != null && lobby.isFull();
    }
    
    // Matchmaking
    @Override
    public Lobby findBestLobby(UUID playerId, GameMode mode) {
        List<Lobby> availableLobbies = getAvailableLobbies(mode);
        
        if (availableLobbies.isEmpty()) {
            return null;
        }
        
        // Sort by player count (prefer fuller lobbies for faster start)
        availableLobbies.sort((a, b) -> Integer.compare(b.getPlayerCount(), a.getPlayerCount()));
        
        // Find first lobby with available roles
        for (Lobby lobby : availableLobbies) {
            // Check if at least one role is available
            if (lobby.hasRoleAvailable(PlayerRole.SURVIVOR) || lobby.hasRoleAvailable(PlayerRole.KILLER)) {
                return lobby;
            }
        }
        
        return availableLobbies.get(0);
    }
    
    // Helper methods
    private void applyLobbySettings(Lobby lobby, Map<String, Object> settings) {
        for (Map.Entry<String, Object> entry : settings.entrySet()) {
            switch (entry.getKey()) {
                case "maxPlayers":
                    if (entry.getValue() instanceof Number) {
                        lobby.setMaxPlayers(((Number) entry.getValue()).intValue());
                    }
                    break;
                case "minPlayers":
                    if (entry.getValue() instanceof Number) {
                        lobby.setMinPlayers(((Number) entry.getValue()).intValue());
                    }
                    break;
                case "countdownSeconds":
                    if (entry.getValue() instanceof Number) {
                        lobby.setCountdownSeconds(((Number) entry.getValue()).intValue());
                    }
                    break;
                case "maxKillers":
                    if (entry.getValue() instanceof Number) {
                        lobby.setMaxKillers(((Number) entry.getValue()).intValue());
                    }
                    break;
                case "maxSurvivors":
                    if (entry.getValue() instanceof Number) {
                        lobby.setMaxSurvivors(((Number) entry.getValue()).intValue());
                    }
                    break;
                case "public":
                    if (entry.getValue() instanceof Boolean) {
                        lobby.setPublic((Boolean) entry.getValue());
                    }
                    break;
                default:
                    lobby.setSetting(entry.getKey(), entry.getValue());
            }
        }
    }
    
    private void assignNewHost(Lobby lobby) {
        // Assign first non-host player as new host
        for (UUID playerId : lobby.getPlayers().keySet()) {
            if (!playerId.equals(lobby.getHostId())) {
                lobby.setHostId(playerId);
                logger.info("Assigned new host for lobby " + lobby.getLobbyId() + ": " + playerId);
                return;
            }
        }
    }
    
    private void assignRoles(Match match, Lobby lobby) {
        // Ensure exactly one killer for standard matches
        int killerCount = lobby.getRoleCount(PlayerRole.KILLER);
        
        if (killerCount == 0) {
            // Need to assign someone as killer
            // Prefer player who has been waiting longest
            UUID killerId = lobby.getPlayers().keySet().iterator().next();
            match.addPlayer(killerId, PlayerRole.KILLER);
            lobby.setRolePreference(killerId, PlayerRole.KILLER);
        } else if (killerCount > lobby.getMaxKillers()) {
            // Too many killers, assign extras as survivors
            int extra = 0;
            for (Map.Entry<UUID, PlayerRole> entry : lobby.getRolePreferences().entrySet()) {
                if (entry.getValue() == PlayerRole.KILLER) {
                    extra++;
                    if (extra > lobby.getMaxKillers()) {
                        match.addPlayer(entry.getKey(), PlayerRole.SURVIVOR);
                    }
                }
            }
        }
    }
    
    private String getPlayerName(UUID playerId) {
        // This would integrate with the player data system
        return "Player_" + playerId.toString().substring(0, 8);
    }
}
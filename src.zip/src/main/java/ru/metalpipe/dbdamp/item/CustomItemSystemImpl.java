package ru.metalpipe.dbdamp.item;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Implementation of the custom item system.
 * Manages custom items with special behaviors and properties.
 */
public class CustomItemSystemImpl implements CustomItemSystem {
    
    private final Logger logger;
    private final Map<String, CustomItem> registeredItems;
    private final Map<String, ItemBehavior> itemBehaviors;
    private final NamespacedKey itemIdKey;
    private final NamespacedKey durabilityKey;
    
    public CustomItemSystemImpl() {
        this.logger = Logger.getLogger(getClass().getName());
        this.registeredItems = new ConcurrentHashMap<>();
        this.itemBehaviors = new ConcurrentHashMap<>();
        this.itemIdKey = new NamespacedKey("dbdamp", "custom_item_id");
        this.durabilityKey = new NamespacedKey("dbdamp", "durability");
    }
    
    @Override
    public boolean registerItem(String itemId, Map<String, Object> config) {
        if (registeredItems.containsKey(itemId)) {
            logger.warning("Item " + itemId + " is already registered");
            return false;
        }
        
        try {
            CustomItem item = parseItemConfig(itemId, config);
            registeredItems.put(itemId, item);
            logger.info("Registered custom item: " + itemId);
            return true;
        } catch (Exception e) {
            logger.severe("Failed to register item " + itemId + ": " + e.getMessage());
            return false;
        }
    }
    
    private CustomItem parseItemConfig(String itemId, Map<String, Object> config) {
        String displayName = (String) config.getOrDefault("display_name", itemId);
        String category = (String) config.getOrDefault("category", "general");
        String description = (String) config.getOrDefault("description", "");
        int maxDurability = ((Number) config.getOrDefault("max_durability", 1000)).intValue();
        int rarity = ((Number) config.getOrDefault("rarity", 1)).intValue();
        String modelPath = (String) config.getOrDefault("model_path", "");
        
        // Material info
        String material = (String) config.getOrDefault("material", "DIAMOND_SWORD");
        int customModelData = ((Number) config.getOrDefault("custom_model_data", 0)).intValue();
        String texture = (String) config.getOrDefault("texture", "");
        MaterialInfo materialInfo = new MaterialInfo(material, customModelData, texture);
        
        // Lore
        @SuppressWarnings("unchecked")
        List<String> lore = (List<String>) config.getOrDefault("lore", new ArrayList<>());
        
        // Properties
        @SuppressWarnings("unchecked")
        Map<String, Object> properties = (Map<String, Object>) config.getOrDefault("properties", new HashMap<>());
        
        return new CustomItem(itemId, displayName, category, description, maxDurability, 
                             rarity, modelPath, materialInfo, lore, properties);
    }
    
    @Override
    public void unregisterItem(String itemId) {
        registeredItems.remove(itemId);
        itemBehaviors.remove(itemId);
        logger.info("Unregistered custom item: " + itemId);
    }
    
    @Override
    public Optional<CustomItem> getItem(String itemId) {
        return Optional.ofNullable(registeredItems.get(itemId));
    }
    
    @Override
    public Optional<ItemStack> createItemStack(String itemId, int amount) {
        CustomItem customItem = registeredItems.get(itemId);
        if (customItem == null) {
            return Optional.empty();
        }
        
        Material material;
        try {
            material = Material.valueOf(customItem.getMaterialInfo().getMaterial());
        } catch (IllegalArgumentException e) {
            material = Material.DIAMOND_SWORD;
        }
        
        ItemStack item = new ItemStack(material, amount);
        ItemMeta meta = item.getItemMeta();
        
        // Set display name
        meta.setDisplayName(customItem.getDisplayName());
        
        // Set lore
        List<String> lore = new ArrayList<>(customItem.getLore());
        lore.add("");
        lore.add("§7Durability: §f" + customItem.getMaxDurability() + "/" + customItem.getMaxDurability());
        meta.setLore(lore);
        
        // Set custom model data
        if (customItem.getMaterialInfo().getCustomModelData() > 0) {
            meta.setCustomModelData(customItem.getMaterialInfo().getCustomModelData());
        }
        
        // Store item ID and durability
        PersistentDataContainer container = meta.getPersistentDataContainer();
        container.set(itemIdKey, PersistentDataType.STRING, itemId);
        container.set(durabilityKey, PersistentDataType.INTEGER, customItem.getMaxDurability());
        
        item.setItemMeta(meta);
        return Optional.of(item);
    }
    
    @Override
    public boolean isCustomItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return false;
        }
        
        PersistentDataContainer container = item.getItemMeta().getPersistentDataContainer();
        return container.has(itemIdKey, PersistentDataType.STRING);
    }
    
    @Override
    public Optional<String> getItemId(ItemStack item) {
        if (!isCustomItem(item)) {
            return Optional.empty();
        }
        
        PersistentDataContainer container = item.getItemMeta().getPersistentDataContainer();
        return Optional.ofNullable(container.get(itemIdKey, PersistentDataType.STRING));
    }
    
    @Override
    public boolean giveItem(UUID playerId, String itemId, int amount) {
        Player player = Bukkit.getPlayer(playerId);
        if (player == null) {
            return false;
        }
        
        Optional<ItemStack> itemOpt = createItemStack(itemId, amount);
        if (itemOpt.isEmpty()) {
            return false;
        }
        
        player.getInventory().addItem(itemOpt.get());
        player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1.0f, 1.0f);
        return true;
    }
    
    @Override
    public boolean handleInteract(PlayerInteractEvent event, String itemId) {
        ItemBehavior behavior = itemBehaviors.get(itemId);
        if (behavior == null) {
            return false;
        }
        
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        Action action = event.getAction();
        
        if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            return behavior.onRightClick(player, item, action);
        } else if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) {
            return behavior.onLeftClick(player, item, action);
        }
        
        return false;
    }
    
    @Override
    public Map<String, CustomItem> getAllItems() {
        return new HashMap<>(registeredItems);
    }
    
    @Override
    public List<CustomItem> getItemsByCategory(String category) {
        return registeredItems.values().stream()
            .filter(item -> item.getCategory().equalsIgnoreCase(category))
            .toList();
    }
    
    @Override
    public void registerBehavior(String itemId, ItemBehavior behavior) {
        if (registeredItems.containsKey(itemId)) {
            itemBehaviors.put(itemId, behavior);
            logger.fine("Registered behavior for item: " + itemId);
        } else {
            logger.warning("Cannot register behavior for unknown item: " + itemId);
        }
    }
    
    @Override
    public boolean dropItem(Location location, String itemId, int amount) {
        Optional<ItemStack> itemOpt = createItemStack(itemId, amount);
        if (itemOpt.isEmpty()) {
            return false;
        }
        
        location.getWorld().dropItemNaturally(location, itemOpt.get());
        location.getWorld().spawnParticle(Particle.ITEM_CRACK, location, 10, 0.5, 0.5, 0.5, 0.1);
        return true;
    }
    
    @Override
    public int getDurability(ItemStack item) {
        if (!isCustomItem(item)) {
            return 0;
        }
        
        PersistentDataContainer container = item.getItemMeta().getPersistentDataContainer();
        return container.getOrDefault(durabilityKey, PersistentDataType.INTEGER, 0);
    }
    
    @Override
    public void setDurability(ItemStack item, int durability) {
        if (!isCustomItem(item)) {
            return;
        }
        
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer container = meta.getPersistentDataContainer();
        
        String itemId = container.get(itemIdKey, PersistentDataType.STRING);
        CustomItem customItem = registeredItems.get(itemId);
        if (customItem == null) return;
        
        int maxDur = customItem.getMaxDurability();
        durability = Math.max(0, Math.min(maxDur, durability));
        
        container.set(durabilityKey, PersistentDataType.INTEGER, durability);
        
        // Update lore
        List<String> lore = new ArrayList<>(customItem.getLore());
        lore.add("");
        lore.add("§7Durability: §f" + durability + "/" + maxDur);
        meta.setLore(lore);
        
        item.setItemMeta(meta);
    }
    
    @Override
    public boolean reduceDurability(ItemStack item, int amount) {
        if (!isCustomItem(item)) {
            return false;
        }
        
        int current = getDurability(item);
        int newDurability = current - amount;
        
        if (newDurability <= 0) {
            // Item broke
            return true;
        }
        
        setDurability(item, newDurability);
        return false;
    }
    
    @Override
    public void repairItem(ItemStack item, int amount) {
        if (!isCustomItem(item)) {
            return;
        }
        
        int current = getDurability(item);
        setDurability(item, current + amount);
    }
}

package ru.metalpipe.dbdamp.item;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * System for creating and managing custom items with special abilities.
 * Provides ItemsAdder-like functionality for custom 3D models and behaviors.
 */
public interface CustomItemSystem {
    
    /**
     * Register a custom item from configuration.
     * 
     * @param itemId The unique ID for this item
     * @param config The configuration map for the item
     * @return true if the item was registered successfully
     */
    boolean registerItem(String itemId, Map<String, Object> config);
    
    /**
     * Unregister a custom item.
     * 
     * @param itemId The item ID to unregister
     */
    void unregisterItem(String itemId);
    
    /**
     * Get a custom item by ID.
     * 
     * @param itemId The item ID
     * @return The custom item, or empty if not found
     */
    Optional<CustomItem> getItem(String itemId);
    
    /**
     * Create an ItemStack for a custom item.
     * 
     * @param itemId The item ID
     * @param amount The amount of items
     * @return The ItemStack, or empty if item not found
     */
    Optional<ItemStack> createItemStack(String itemId, int amount);
    
    /**
     * Check if an ItemStack is a custom item.
     * 
     * @param item The ItemStack to check
     * @return true if it's a custom item
     */
    boolean isCustomItem(ItemStack item);
    
    /**
     * Get the custom item ID from an ItemStack.
     * 
     * @param item The ItemStack to check
     * @return The item ID, or empty if not a custom item
     */
    Optional<String> getItemId(ItemStack item);
    
    /**
     * Give a custom item to a player.
     * 
     * @param playerId The player to give the item to
     * @param itemId The item ID
     * @param amount The amount
     * @return true if successful
     */
    boolean giveItem(UUID playerId, String itemId, int amount);
    
    /**
     * Handle a player interaction with a custom item.
     * 
     * @param event The interact event
     * @param itemId The custom item ID
     * @return true if the event was handled
     */
    boolean handleInteract(PlayerInteractEvent event, String itemId);
    
    /**
     * Get all registered custom items.
     * 
     * @return Map of item IDs to custom items
     */
    Map<String, CustomItem> getAllItems();
    
    /**
     * Get items by category.
     * 
     * @param category The category to filter by
     * @return List of items in the category
     */
    List<CustomItem> getItemsByCategory(String category);
    
    /**
     * Register a custom item behavior.
     * 
     * @param itemId The item ID
     * @param behavior The behavior to register
     */
    void registerBehavior(String itemId, ItemBehavior behavior);
    
    /**
     * Drop a custom item at a location.
     * 
     * @param location The location to drop at
     * @param itemId The item ID
     * @param amount The amount
     * @return true if successful
     */
    boolean dropItem(Location location, String itemId, int amount);
    
    /**
     * Get the durability of a custom item.
     * 
     * @param item The ItemStack
     * @return The current durability
     */
    int getDurability(ItemStack item);
    
    /**
     * Set the durability of a custom item.
     * 
     * @param item The ItemStack
     * @param durability The new durability
     */
    void setDurability(ItemStack item, int durability);
    
    /**
     * Reduce durability of a custom item.
     * 
     * @param item The ItemStack
     * @param amount The amount to reduce
     * @return true if the item broke
     */
    boolean reduceDurability(ItemStack item, int amount);
    
    /**
     * Repair a custom item.
     * 
     * @param item The ItemStack
     * @param amount The amount to repair
     */
    void repairItem(ItemStack item, int amount);
    
    /**
     * Represents a custom item definition.
     */
    class CustomItem {
        private final String itemId;
        private final String displayName;
        private final String category;
        private final String description;
        private final int maxDurability;
        private final int rarity;
        private final String modelPath;
        private final MaterialInfo materialInfo;
        private final List<String> lore;
        private final Map<String, Object> properties;
        
        public CustomItem(String itemId, String displayName, String category, String description,
                         int maxDurability, int rarity, String modelPath, MaterialInfo materialInfo,
                         List<String> lore, Map<String, Object> properties) {
            this.itemId = itemId;
            this.displayName = displayName;
            this.category = category;
            this.description = description;
            this.maxDurability = maxDurability;
            this.rarity = rarity;
            this.modelPath = modelPath;
            this.materialInfo = materialInfo;
            this.lore = lore;
            this.properties = properties;
        }
        
        public String getItemId() { return itemId; }
        public String getDisplayName() { return displayName; }
        public String getCategory() { return category; }
        public String getDescription() { return description; }
        public int getMaxDurability() { return maxDurability; }
        public int getRarity() { return rarity; }
        public String getModelPath() { return modelPath; }
        public MaterialInfo getMaterialInfo() { return materialInfo; }
        public List<String> getLore() { return new ArrayList<>(lore); }
        public Map<String, Object> getProperties() { return new HashMap<>(properties); }
        
        public Object getProperty(String key) {
            return properties.get(key);
        }
        
        @SuppressWarnings("unchecked")
        public <T> T getProperty(String key, T defaultValue) {
            Object value = properties.get(key);
            if (value == null) return defaultValue;
            try {
                return (T) value;
            } catch (ClassCastException e) {
                return defaultValue;
            }
        }
    }
    
    /**
     * Material information for custom item rendering.
     */
    class MaterialInfo {
        private final String material;
        private final int customModelData;
        private final String texture;
        
        public MaterialInfo(String material, int customModelData, String texture) {
            this.material = material;
            this.customModelData = customModelData;
            this.texture = texture;
        }
        
        public String getMaterial() { return material; }
        public int getCustomModelData() { return customModelData; }
        public String getTexture() { return texture; }
    }
    
    /**
     * Behavior interface for custom items.
     */
    interface ItemBehavior {
        /**
         * Called when a player right-clicks with the item.
         * 
         * @param player The player
         * @param item The ItemStack
         * @param action The click action
         * @return true if the event should be cancelled
         */
        boolean onRightClick(Player player, ItemStack item, Action action);
        
        /**
         * Called when a player left-clicks with the item.
         * 
         * @param player The player
         * @param item The ItemStack
         * @param action The click action
         * @return true if the event should be cancelled
         */
        boolean onLeftClick(Player player, ItemStack item, Action action);
        
        /**
         * Called when the item is held.
         * 
         * @param player The player
         * @param item The ItemStack
         */
        void onHold(Player player, ItemStack item);
        
        /**
         * Called when the item stops being held.
         * 
         * @param player The player
         * @param item The ItemStack
         */
        void onRelease(Player player, ItemStack item);
        
        /**
         * Called every tick while the item is held.
         * 
         * @param player The player
         * @param item The ItemStack
         */
        void onTick(Player player, ItemStack item);
    }
}

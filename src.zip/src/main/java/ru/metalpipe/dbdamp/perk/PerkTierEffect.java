package ru.metalpipe.dbdamp.perk;

import java.util.Map;
import java.util.HashMap;

/**
 * Represents the effect values for a specific perk tier.
 */
public class PerkTierEffect {
    
    private int tier;
    private Map<String, Object> parameters;
    
    public PerkTierEffect() {
        this.parameters = new HashMap<>();
    }
    
    public PerkTierEffect(int tier) {
        this();
        this.tier = tier;
    }
    
    // Getters and setters
    public int getTier() { return tier; }
    public void setTier(int tier) { this.tier = tier; }
    
    public Map<String, Object> getParameters() { return parameters; }
    public void setParameters(Map<String, Object> parameters) { 
        this.parameters = parameters != null ? parameters : new HashMap<>(); 
    }
    
    /**
     * Get a parameter value.
     */
    public Object getParameter(String key) {
        return parameters.get(key);
    }
    
    /**
     * Get a parameter value with a default.
     */
    public Object getParameter(String key, Object defaultValue) {
        return parameters.getOrDefault(key, defaultValue);
    }
    
    /**
     * Get a parameter as int.
     */
    public int getIntParameter(String key, int defaultValue) {
        Object value = parameters.get(key);
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return defaultValue;
    }
    
    /**
     * Get a parameter as double.
     */
    public double getDoubleParameter(String key, double defaultValue) {
        Object value = parameters.get(key);
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        return defaultValue;
    }
    
    /**
     * Get a parameter as boolean.
     */
    public boolean getBooleanParameter(String key, boolean defaultValue) {
        Object value = parameters.get(key);
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        return defaultValue;
    }
    
    /**
     * Get a parameter as string.
     */
    public String getStringParameter(String key, String defaultValue) {
        Object value = parameters.get(key);
        if (value instanceof String) {
            return (String) value;
        }
        return defaultValue;
    }
    
    /**
     * Set a parameter value.
     */
    public void setParameter(String key, Object value) {
        parameters.put(key, value);
    }
    
    @Override
    public String toString() {
        return "PerkTierEffect{" +
               "tier=" + tier +
               ", parameters=" + parameters +
               '}';
    }
}
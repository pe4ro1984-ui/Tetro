package ru.metalpipe.dbdamp.perk;

import org.bukkit.entity.Player;
import ru.metalpipe.dbdamp.gameplay.model.Match;
import ru.metalpipe.dbdamp.gameplay.model.PlayerRole;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Interface for managing perk unlocking, activation, and tier progression.
 * Supports both survivor and killer perks with different effects.
 */
public interface PerkSystem {
    
    /**
     * Unlock a perk for a player.
     * 
     * @param playerId The player's UUID
     * @param perkId The perk's unique identifier
     * @return true if perk was unlocked successfully
     */
    boolean unlockPerk(UUID playerId, String perkId);
    
    /**
     * Check if a player has unlocked a perk.
     * 
     * @param playerId The player's UUID
     * @param perkId The perk's unique identifier
     * @return true if player has the perk unlocked
     */
    boolean hasPerk(UUID playerId, String perkId);
    
    /**
     * Upgrade a perk to the next tier (1-3).
     * 
     * @param playerId The player's UUID
     * @param perkId The perk's unique identifier
     * @return true if perk was upgraded successfully
     */
    boolean upgradePerk(UUID playerId, String perkId);
    
    /**
     * Get the current tier of a perk for a player.
     * 
     * @param playerId The player's UUID
     * @param perkId The perk's unique identifier
     * @return Tier level (1-3), or 0 if not unlocked
     */
    int getPerkTier(UUID playerId, String perkId);
    
    /**
     * Equip a perk in a loadout slot.
     * 
     * @param playerId The player's UUID
     * @param perkId The perk's unique identifier
     * @param slot The loadout slot (0-3)
     * @return true if perk was equipped successfully
     */
    boolean equipPerk(UUID playerId, String perkId, int slot);
    
    /**
     * Unequip a perk from a loadout slot.
     * 
     * @param playerId The player's UUID
     * @param slot The loadout slot (0-3)
     * @return true if perk was unequipped successfully
     */
    boolean unequipPerk(UUID playerId, int slot);
    
    /**
     * Get equipped perks for a player.
     * 
     * @param playerId The player's UUID
     * @return List of equipped perk IDs (may contain nulls for empty slots)
     */
    List<String> getEquippedPerks(UUID playerId);
    
    /**
     * Get the number of unlocked perk slots for a player.
     * Slots unlock at specific level thresholds.
     * 
     * @param playerId The player's UUID
     * @return Number of available perk slots (1-4)
     */
    int getAvailablePerkSlots(UUID playerId);
    
    /**
     * Check if a perk activation condition is met.
     * 
     * @param playerId The player's UUID
     * @param perkId The perk's unique identifier
     * @param eventType The game event type
     * @param eventData Additional event data
     * @return true if perk should activate
     */
    boolean checkActivation(UUID playerId, String perkId, String eventType, Map<String, Object> eventData);
    
    /**
     * Apply a perk effect to a player.
     * 
     * @param playerId The player's UUID
     * @param perkId The perk's unique identifier
     * @param eventType The game event type
     * @param eventData Additional event data
     */
    void applyEffect(UUID playerId, String perkId, String eventType, Map<String, Object> eventData);
    
    /**
     * Get perk definition.
     * 
     * @param perkId The perk's unique identifier
     * @return The perk definition, or null if not found
     */
    PerkDefinition getPerkDefinition(String perkId);
    
    /**
     * Get all available perks for a role.
     * 
     * @param role The player role (SURVIVOR or KILLER)
     * @return List of perk definitions
     */
    List<PerkDefinition> getPerksForRole(PlayerRole role);
    
    /**
     * Register a new perk definition.
     * 
     * @param definition The perk definition
     * @return true if perk was registered successfully
     */
    boolean registerPerk(PerkDefinition definition);
    
    /**
     * Update active perks (called every tick).
     * 
     * @param match The current match
     */
    void update(Match match);
    
    /**
     * Reset perk cooldowns for a player.
     * 
     * @param playerId The player's UUID
     */
    void resetCooldowns(UUID playerId);
    
    /**
     * Get perk cooldown remaining.
     * 
     * @param playerId The player's UUID
     * @param perkId The perk's unique identifier
     * @return Cooldown in ticks, 0 if ready
     */
    int getCooldown(UUID playerId, String perkId);
}
package ru.metalpipe.dbdamp.perk;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ru.metalpipe.dbdamp.database.model.PlayerLevel;
import ru.metalpipe.dbdamp.database.model.PerkProgress;
import ru.metalpipe.dbdamp.gameplay.model.Match;
import ru.metalpipe.dbdamp.gameplay.model.PlayerRole;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Implementation of the perk system.
 * Manages perk unlocking, tier progression, activation, and effects.
 */
public class PerkSystemImpl implements PerkSystem {
    
    private final Logger logger;
    
    // Registered perk definitions
    private final Map<String, PerkDefinition> registeredPerks;
    
    // Player perk progress (unlocked perks and tiers)
    private final Map<UUID, Map<String, PerkProgress>> playerPerkProgress;
    
    // Equipped perks per player (slot -> perkId)
    private final Map<UUID, String[]> equippedPerks;
    
    // Active perk cooldowns
    private final Map<UUID, Map<String, Integer>> perkCooldowns;
    
    // Level thresholds for perk slots
    private static final int[] SLOT_UNLOCK_LEVELS = {1, 10, 20, 35};
    private static final int MAX_PERK_SLOTS = 4;
    
    // Event types
    public static final String EVENT_MATCH_START = "match_start";
    public static final String EVENT_MATCH_END = "match_end";
    public static final String EVENT_GENERATOR_REPAIR = "generator_repair";
    public static final String EVENT_GENERATOR_COMPLETE = "generator_complete";
    public static final String EVENT_SKILL_CHECK = "skill_check";
    public static final String EVENT_SURVIVOR_HIT = "survivor_hit";
    public static final String EVENT_SURVIVOR_DOWNED = "survivor_downed";
    public static final String EVENT_SURVIVOR_HOOKED = "survivor_hooked";
    public static final String EVENT_SURVIVOR_UNHOOKED = "survivor_unhooked";
    public static final String EVENT_SURVIVOR_ESCAPE = "survivor_escape";
    public static final String EVENT_KILLER_HIT = "killer_hit";
    public static final String EVENT_CHASE_START = "chase_start";
    public static final String EVENT_CHASE_END = "chase_end";
    public static final String EVENT_EXIT_GATE_OPENED = "exit_gate_opened";
    public static final String EVENT_EXIT_GATE_POWERED = "exit_gate_powered";
    
    public PerkSystemImpl() {
        this.logger = Logger.getLogger(getClass().getName());
        this.registeredPerks = new ConcurrentHashMap<>();
        this.playerPerkProgress = new ConcurrentHashMap<>();
        this.equippedPerks = new ConcurrentHashMap<>();
        this.perkCooldowns = new ConcurrentHashMap<>();
        
        // Register default perks
        registerDefaultPerks();
    }
    
    // Perk unlocking and progression
    @Override
    public boolean unlockPerk(UUID playerId, String perkId) {
        PerkDefinition definition = registeredPerks.get(perkId);
        if (definition == null) {
            return false;
        }
        
        Map<String, PerkProgress> progress = getOrCreateProgress(playerId);
        if (progress.containsKey(perkId)) {
            return false; // Already unlocked
        }
        
        PerkProgress perkProgress = new PerkProgress();
        perkProgress.setPerkId(perkId);
        perkProgress.setTier(1);
        perkProgress.setUnlocked(true);
        
        progress.put(perkId, perkProgress);
        
        logger.info("Player " + playerId + " unlocked perk: " + perkId);
        return true;
    }
    
    @Override
    public boolean hasPerk(UUID playerId, String perkId) {
        Map<String, PerkProgress> progress = playerPerkProgress.get(playerId);
        if (progress == null) return false;
        
        PerkProgress perkProgress = progress.get(perkId);
        return perkProgress != null && perkProgress.isUnlocked();
    }
    
    @Override
    public boolean upgradePerk(UUID playerId, String perkId) {
        Map<String, PerkProgress> progress = playerPerkProgress.get(playerId);
        if (progress == null) return false;
        
        PerkProgress perkProgress = progress.get(perkId);
        if (perkProgress == null || !perkProgress.isUnlocked()) {
            return false;
        }
        
        PerkDefinition definition = registeredPerks.get(perkId);
        if (definition == null) return false;
        
        int currentTier = perkProgress.getTier();
        if (currentTier >= definition.getMaxTier()) {
            return false; // Already at max tier
        }
        
        perkProgress.setTier(currentTier + 1);
        
        logger.info("Player " + playerId + " upgraded perk " + perkId + " to tier " + perkProgress.getTier());
        return true;
    }
    
    @Override
    public int getPerkTier(UUID playerId, String perkId) {
        Map<String, PerkProgress> progress = playerPerkProgress.get(playerId);
        if (progress == null) return 0;
        
        PerkProgress perkProgress = progress.get(perkId);
        if (perkProgress == null || !perkProgress.isUnlocked()) {
            return 0;
        }
        
        return perkProgress.getTier();
    }
    
    // Equipment
    @Override
    public boolean equipPerk(UUID playerId, String perkId, int slot) {
        if (slot < 0 || slot >= MAX_PERK_SLOTS) {
            return false;
        }
        
        if (!hasPerk(playerId, perkId)) {
            return false;
        }
        
        if (slot >= getAvailablePerkSlots(playerId)) {
            return false; // Slot not unlocked
        }
        
        String[] equipped = getOrCreateEquipped(playerId);
        
        // Remove from other slots first
        for (int i = 0; i < equipped.length; i++) {
            if (perkId.equals(equipped[i])) {
                equipped[i] = null;
            }
        }
        
        equipped[slot] = perkId;
        
        logger.fine("Player " + playerId + " equipped " + perkId + " in slot " + slot);
        return true;
    }
    
    @Override
    public boolean unequipPerk(UUID playerId, int slot) {
        if (slot < 0 || slot >= MAX_PERK_SLOTS) {
            return false;
        }
        
        String[] equipped = equippedPerks.get(playerId);
        if (equipped == null || equipped[slot] == null) {
            return false;
        }
        
        equipped[slot] = null;
        return true;
    }
    
    @Override
    public List<String> getEquippedPerks(UUID playerId) {
        String[] equipped = equippedPerks.get(playerId);
        if (equipped == null) {
            return Arrays.asList(null, null, null, null);
        }
        return Arrays.asList(equipped);
    }
    
    @Override
    public int getAvailablePerkSlots(UUID playerId) {
        // This would integrate with the progression system
        // For now, return based on simple level calculation
        int level = getPlayerLevel(playerId);
        
        int slots = 1;
        for (int threshold : SLOT_UNLOCK_LEVELS) {
            if (level >= threshold) {
                slots++;
            }
        }
        
        return Math.min(slots, MAX_PERK_SLOTS);
    }
    
    // Activation and effects
    @Override
    public boolean checkActivation(UUID playerId, String perkId, String eventType, Map<String, Object> eventData) {
        PerkDefinition definition = registeredPerks.get(perkId);
        if (definition == null) return false;
        
        // Check if perk activates on this event
        if (!definition.activatesOnEvent(eventType)) {
            return false;
        }
        
        // Check cooldown
        if (definition.hasCooldown() && getCooldown(playerId, perkId) > 0) {
            return false;
        }
        
        return true;
    }
    
    @Override
    public void applyEffect(UUID playerId, String perkId, String eventType, Map<String, Object> eventData) {
        int tier = getPerkTier(playerId, perkId);
        if (tier <= 0) return;
        
        PerkDefinition definition = registeredPerks.get(perkId);
        if (definition == null) return;
        
        PerkTierEffect effect = definition.getTierEffect(tier);
        if (effect == null) return;
        
        // Apply effect based on perk type
        applyPerkEffect(playerId, perkId, effect, eventData);
        
        // Set cooldown if applicable
        if (definition.hasCooldown()) {
            setCooldown(playerId, perkId, definition.getCooldownTicks());
        }
        
        logger.fine("Applied perk " + perkId + " tier " + tier + " to player " + playerId);
    }
    
    // Registration
    @Override
    public PerkDefinition getPerkDefinition(String perkId) {
        return registeredPerks.get(perkId);
    }
    
    @Override
    public List<PerkDefinition> getPerksForRole(PlayerRole role) {
        List<PerkDefinition> perks = new ArrayList<>();
        for (PerkDefinition def : registeredPerks.values()) {
            if (def.getRole() == role) {
                perks.add(def);
            }
        }
        return perks;
    }
    
    @Override
    public boolean registerPerk(PerkDefinition definition) {
        if (definition == null || definition.getPerkId() == null) {
            return false;
        }
        
        registeredPerks.put(definition.getPerkId(), definition);
        logger.info("Registered perk: " + definition.getPerkId());
        return true;
    }
    
    // Update and cooldowns
    @Override
    public void update(Match match) {
        // Update cooldowns
        for (UUID playerId : perkCooldowns.keySet()) {
            Map<String, Integer> cooldowns = perkCooldowns.get(playerId);
            Iterator<Map.Entry<String, Integer>> iter = cooldowns.entrySet().iterator();
            
            while (iter.hasNext()) {
                Map.Entry<String, Integer> entry = iter.next();
                int remaining = entry.getValue() - 1;
                if (remaining <= 0) {
                    iter.remove();
                } else {
                    entry.setValue(remaining);
                }
            }
        }
    }
    
    @Override
    public void resetCooldowns(UUID playerId) {
        Map<String, Integer> cooldowns = perkCooldowns.get(playerId);
        if (cooldowns != null) {
            cooldowns.clear();
        }
    }
    
    @Override
    public int getCooldown(UUID playerId, String perkId) {
        Map<String, Integer> cooldowns = perkCooldowns.get(playerId);
        if (cooldowns == null) return 0;
        return cooldowns.getOrDefault(perkId, 0);
    }
    
    // Helper methods
    private Map<String, PerkProgress> getOrCreateProgress(UUID playerId) {
        return playerPerkProgress.computeIfAbsent(playerId, id -> new ConcurrentHashMap<>());
    }
    
    private String[] getOrCreateEquipped(UUID playerId) {
        return equippedPerks.computeIfAbsent(playerId, id -> new String[MAX_PERK_SLOTS]);
    }
    
    private void setCooldown(UUID playerId, String perkId, int ticks) {
        Map<String, Integer> cooldowns = perkCooldowns.computeIfAbsent(playerId, id -> new ConcurrentHashMap<>());
        cooldowns.put(perkId, ticks);
    }
    
    private int getPlayerLevel(UUID playerId) {
        // This would integrate with the progression system
        // For now, return a placeholder
        return 1;
    }
    
    private void applyPerkEffect(UUID playerId, String perkId, PerkTierEffect effect, Map<String, Object> eventData) {
        Player player = Bukkit.getPlayer(playerId);
        if (player == null) return;
        
        // Apply effect based on perk ID
        switch (perkId) {
            case "self_care":
                // Self-healing bonus
                applySelfCareEffect(player, effect);
                break;
                
            case "sprint_burst":
                // Speed boost on sprint start
                applySprintBurstEffect(player, effect);
                break;
                
            case "decisive_strike":
                // Stun killer when picked up
                applyDecisiveStrikeEffect(player, effect, eventData);
                break;
                
            case "brutal_strength":
                // Faster pallet breaking
                applyBrutalStrengthEffect(player, effect);
                break;
                
            case "enduring":
                // Reduce stun duration
                applyEnduringEffect(player, effect);
                break;
                
            case "no_one_escapes_death":
                // Endgame speed boost
                applyNoOneEscapesDeathEffect(player, effect);
                break;
                
            default:
                // Generic effect application
                applyGenericEffect(player, effect, eventData);
        }
    }
    
    private void registerDefaultPerks() {
        // Survivor perks
        registerSelfCare();
        registerSprintBurst();
        registerDecisiveStrike();
        
        // Killer perks
        registerBrutalStrength();
        registerEnduring();
        registerNoOneEscapesDeath();
    }
    
    private void registerSelfCare() {
        PerkDefinition selfCare = new PerkDefinition(
            "self_care", "Self-Care", 
            "Unlocks the ability to heal yourself without a Med-Kit at {speed}% speed.",
            PlayerRole.SURVIVOR
        );
        selfCare.setActivationEvents(Arrays.asList(EVENT_MATCH_START));
        
        Map<Integer, PerkTierEffect> effects = new HashMap<>();
        for (int tier = 1; tier <= 3; tier++) {
            PerkTierEffect effect = new PerkTierEffect(tier);
            effect.setParameter("speed", 30 + (tier * 10));
            effects.put(tier, effect);
        }
        selfCare.setTierEffects(effects);
        
        registerPerk(selfCare);
    }
    
    private void registerSprintBurst() {
        PerkDefinition sprintBurst = new PerkDefinition(
            "sprint_burst", "Sprint Burst",
            "Sprint at {speed}% speed for {duration} seconds when starting to run.",
            PlayerRole.SURVIVOR
        );
        sprintBurst.setActivationEvents(Arrays.asList(EVENT_CHASE_START));
        
        Map<Integer, PerkTierEffect> effects = new HashMap<>();
        for (int tier = 1; tier <= 3; tier++) {
            PerkTierEffect effect = new PerkTierEffect(tier);
            effect.setParameter("speed", 130 + (tier * 5));
            effect.setParameter("duration", 3 + tier);
            effects.put(tier, effect);
        }
        sprintBurst.setTierEffects(effects);
        sprintBurst.setHasCooldown(true);
        sprintBurst.setCooldownTicks(1200); // 60 seconds
        
        registerPerk(sprintBurst);
    }
    
    private void registerDecisiveStrike() {
        PerkDefinition decisiveStrike = new PerkDefinition(
            "decisive_strike", "Decisive Strike",
            "After being unhooked, stun the killer for {duration} seconds when picked up.",
            PlayerRole.SURVIVOR
        );
        decisiveStrike.setActivationEvents(Arrays.asList(EVENT_SURVIVOR_UNHOOKED));
        
        Map<Integer, PerkTierEffect> effects = new HashMap<>();
        for (int tier = 1; tier <= 3; tier++) {
            PerkTierEffect effect = new PerkTierEffect(tier);
            effect.setParameter("duration", 3 + tier);
            effects.put(tier, effect);
        }
        decisiveStrike.setTierEffects(effects);
        
        registerPerk(decisiveStrike);
    }
    
    private void registerBrutalStrength() {
        PerkDefinition brutalStrength = new PerkDefinition(
            "brutal_strength", "Brutal Strength",
            "Break pallets {speed}% faster.",
            PlayerRole.KILLER
        );
        brutalStrength.setActivationEvents(Arrays.asList(EVENT_MATCH_START));
        
        Map<Integer, PerkTierEffect> effects = new HashMap<>();
        for (int tier = 1; tier <= 3; tier++) {
            PerkTierEffect effect = new PerkTierEffect(tier);
            effect.setParameter("speed", 20 + (tier * 10));
            effects.put(tier, effect);
        }
        brutalStrength.setTierEffects(effects);
        
        registerPerk(brutalStrength);
    }
    
    private void registerEnduring() {
        PerkDefinition enduring = new PerkDefinition(
            "enduring", "Enduring",
            "Reduces stun duration by {reduction}%.",
            PlayerRole.KILLER
        );
        enduring.setActivationEvents(Arrays.asList(EVENT_MATCH_START));
        
        Map<Integer, PerkTierEffect> effects = new HashMap<>();
        for (int tier = 1; tier <= 3; tier++) {
            PerkTierEffect effect = new PerkTierEffect(tier);
            effect.setParameter("reduction", 30 + (tier * 15));
            effects.put(tier, effect);
        }
        enduring.setTierEffects(effects);
        
        registerPerk(enduring);
    }
    
    private void registerNoOneEscapesDeath() {
        PerkDefinition noed = new PerkDefinition(
            "no_one_escapes_death", "No One Escapes Death",
            "Gain {speed}% movement speed and see survivors when all generators are complete.",
            PlayerRole.KILLER
        );
        noed.setActivationEvents(Arrays.asList(EVENT_EXIT_GATE_POWERED));
        
        Map<Integer, PerkTierEffect> effects = new HashMap<>();
        for (int tier = 1; tier <= 3; tier++) {
            PerkTierEffect effect = new PerkTierEffect(tier);
            effect.setParameter("speed", 5 + (tier * 2));
            effects.put(tier, effect);
        }
        noed.setTierEffects(effects);
        
        registerPerk(noed);
    }
    
    // Effect application helpers
    private void applySelfCareEffect(Player player, PerkTierEffect effect) {
        // Modify self-healing speed
        player.sendActionBar("§aSelf-Care active: " + effect.getIntParameter("speed", 50) + "% healing speed");
    }
    
    private void applySprintBurstEffect(Player player, PerkTierEffect effect) {
        int speed = effect.getIntParameter("speed", 150);
        int duration = effect.getIntParameter("duration", 5) * 20; // Convert to ticks
        
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, duration, 1));
        player.sendActionBar("§eSprint Burst activated!");
    }
    
    private void applyDecisiveStrikeEffect(Player player, PerkTierEffect effect, Map<String, Object> eventData) {
        int duration = effect.getIntParameter("duration", 5);
        // Stun killer logic would go here
        player.sendActionBar("§cDecisive Strike ready for " + duration + "s!");
    }
    
    private void applyBrutalStrengthEffect(Player player, PerkTierEffect effect) {
        // Faster pallet breaking
        player.sendActionBar("§cBrutal Strength: " + effect.getIntParameter("speed", 50) + "% faster pallet breaking");
    }
    
    private void applyEnduringEffect(Player player, PerkTierEffect effect) {
        // Reduced stun duration
        player.sendActionBar("§cEnduring: " + effect.getIntParameter("reduction", 50) + "% stun reduction");
    }
    
    private void applyNoOneEscapesDeathEffect(Player player, PerkTierEffect effect) {
        int speed = effect.getIntParameter("speed", 7);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0));
        player.sendActionBar("§cNo One Escapes Death activated!");
    }
    
    private void applyGenericEffect(Player player, PerkTierEffect effect, Map<String, Object> eventData) {
        // Generic effect - apply any potion effects defined in parameters
        for (Map.Entry<String, Object> entry : effect.getParameters().entrySet()) {
            String key = entry.getKey();
            if (key.startsWith("potion_")) {
                String potionType = key.substring(7).toUpperCase();
                try {
                    PotionEffectType type = PotionEffectType.getByName(potionType);
                    if (type != null && entry.getValue() instanceof Number) {
                        int amplifier = ((Number) entry.getValue()).intValue();
                        player.addPotionEffect(new PotionEffect(type, 200, amplifier));
                    }
                } catch (Exception e) {
                    logger.warning("Failed to apply potion effect: " + potionType);
                }
            }
        }
    }
}
package ru.metalpipe.dbdamp.perk;

import ru.metalpipe.dbdamp.gameplay.model.PlayerRole;

import java.util.List;
import java.util.Map;

/**
 * Definition of a perk with all its properties and effects.
 */
public class PerkDefinition {
    
    private String perkId;
    private String name;
    private String description;
    private PlayerRole role; // SURVIVOR or KILLER
    private int maxTier;
    private boolean isTeachable;
    private int teachableLevel;
    private List<String> activationEvents;
    private Map<Integer, PerkTierEffect> tierEffects;
    private int cooldownTicks;
    private boolean hasCooldown;
    
    public PerkDefinition() {
        this.maxTier = 3;
        this.isTeachable = true;
        this.teachableLevel = 30;
        this.hasCooldown = false;
        this.cooldownTicks = 0;
    }
    
    public PerkDefinition(String perkId, String name, String description, PlayerRole role) {
        this();
        this.perkId = perkId;
        this.name = name;
        this.description = description;
        this.role = role;
    }
    
    // Getters and setters
    public String getPerkId() { return perkId; }
    public void setPerkId(String perkId) { this.perkId = perkId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public PlayerRole getRole() { return role; }
    public void setRole(PlayerRole role) { this.role = role; }
    
    public int getMaxTier() { return maxTier; }
    public void setMaxTier(int maxTier) { this.maxTier = maxTier; }
    
    public boolean isTeachable() { return isTeachable; }
    public void setTeachable(boolean teachable) { this.isTeachable = teachable; }
    
    public int getTeachableLevel() { return teachableLevel; }
    public void setTeachableLevel(int teachableLevel) { this.teachableLevel = teachableLevel; }
    
    public List<String> getActivationEvents() { return activationEvents; }
    public void setActivationEvents(List<String> activationEvents) { this.activationEvents = activationEvents; }
    
    public Map<Integer, PerkTierEffect> getTierEffects() { return tierEffects; }
    public void setTierEffects(Map<Integer, PerkTierEffect> tierEffects) { this.tierEffects = tierEffects; }
    
    public int getCooldownTicks() { return cooldownTicks; }
    public void setCooldownTicks(int cooldownTicks) { this.cooldownTicks = cooldownTicks; }
    
    public boolean hasCooldown() { return hasCooldown; }
    public void setHasCooldown(boolean hasCooldown) { this.hasCooldown = hasCooldown; }
    
    /**
     * Get the effect for a specific tier.
     */
    public PerkTierEffect getTierEffect(int tier) {
        if (tierEffects == null) return null;
        return tierEffects.get(tier);
    }
    
    /**
     * Check if this perk activates on a specific event.
     */
    public boolean activatesOnEvent(String eventType) {
        return activationEvents != null && activationEvents.contains(eventType);
    }
    
    /**
     * Get description with tier-specific values.
     */
    public String getDescriptionForTier(int tier) {
        PerkTierEffect effect = getTierEffect(tier);
        if (effect == null) return description;
        
        String desc = description;
        for (Map.Entry<String, Object> entry : effect.getParameters().entrySet()) {
            desc = desc.replace("{" + entry.getKey() + "}", String.valueOf(entry.getValue()));
        }
        return desc;
    }
    
    @Override
    public String toString() {
        return "PerkDefinition{" +
               "perkId='" + perkId + '\'' +
               ", name='" + name + '\'' +
               ", role=" + role +
               ", maxTier=" + maxTier +
               '}';
    }
}
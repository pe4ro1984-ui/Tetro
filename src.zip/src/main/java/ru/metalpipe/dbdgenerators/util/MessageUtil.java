package ru.metalpipe.dbdgenerators.util;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;

/**
 * Утилита для работы с сообщениями плагина.
 *
 * Использует messages.yml как источник всех текстов.
 * Автоматически добавляет префикс к сообщениям.
 */
public final class MessageUtil {

    private static FileConfiguration messagesConfig;
    private static String prefix = "&7[&cDBD &8| &fВзаперти&7] &r";

    private MessageUtil() {}

    public static void init(FileConfiguration config) {
        messagesConfig = config;
        prefix = config.getString("prefix", "&7[&cDBD &8| &fВзаперти&7] &r");
    }

    /**
     * Получить сообщение из messages.yml с префиксом.
     *
     * @param key Путь в YAML (например "match.started").
     * @return Форматированное сообщение с цветами.
     */
    public static String msg(String key) {
        if (messagesConfig == null) return colorize(prefix + key);
        String raw = messagesConfig.getString(key, key);
        return colorize(prefix + raw);
    }

    /**
     * Получить сообщение без префикса.
     */
    public static String raw(String key) {
        if (messagesConfig == null) return colorize(key);
        return colorize(messagesConfig.getString(key, key));
    }

    /**
     * Перевести цветовые коды (&a, &c, etc.) в ChatColor.
     */
    public static String colorize(String text) {
        if (text == null) return "";
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    public static String getPrefix() {
        return colorize(prefix);
    }
}

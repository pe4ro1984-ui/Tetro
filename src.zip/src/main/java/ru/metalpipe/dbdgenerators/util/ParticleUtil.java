package ru.metalpipe.dbdgenerators.util;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import ru.metalpipe.dbdgenerators.model.PlayerRole;
import ru.metalpipe.dbdgenerators.model.PlayerState;

/**
 * Утилита для работы с частицами.
 *
 * Обеспечивает:
 *  - Частицы ремонта генератора
 *  - Частицы vision-режима (по ролям и состояниям)
 *  - Частицы «ужаса» для коллапса
 *
 * Использует API, совместимый с 1.16.5 – 1.20.1.
 */
public final class ParticleUtil {

    private ParticleUtil() {}

    /**
     * Частицы активного ремонта (искры вокруг генератора).
     */
    public static void spawnRepairParticles(Location loc) {
        if (loc.getWorld() == null) return;
        loc.getWorld().spawnParticle(
            Particle.CRIT_MAGIC,
            loc,
            5,
            0.3, 0.3, 0.3,
            0.05
        );
    }

    /**
     * Частицы сломанного/саботированного генератора (дым).
     */
    public static void spawnBrokenParticles(Location loc) {
        if (loc.getWorld() == null) return;
        loc.getWorld().spawnParticle(
            Particle.SMOKE_LARGE,
            loc,
            3,
            0.2, 0.2, 0.2,
            0.01
        );
    }

    /**
     * Частицы для vision-режима зрителей.
     * Цвет зависит от роли и состояния игрока.
     *
     * @param observer    Зритель, которому показывается частица.
     * @param targetLoc   Позиция цели (над головой).
     * @param role        Роль цели.
     * @param state       Состояние выжившего (null для охотника).
     */
    public static void spawnVisionParticle(Player observer, Location targetLoc,
                                            PlayerRole role, PlayerState state) {
        if (targetLoc.getWorld() == null) return;

        Particle.DustOptions dust;

        if (role == PlayerRole.HUNTER) {
            // Охотник — красный
            dust = new Particle.DustOptions(org.bukkit.Color.fromRGB(220, 30, 30), 1.5f);
        } else if (state == null || state == PlayerState.HEALTHY) {
            // Здоров — зелёный
            dust = new Particle.DustOptions(org.bukkit.Color.fromRGB(40, 200, 40), 1.2f);
        } else if (state == PlayerState.INJURED) {
            // Ранен — оранжевый
            dust = new Particle.DustOptions(org.bukkit.Color.fromRGB(255, 140, 0), 1.2f);
        } else if (state == PlayerState.DOWNED) {
            // Повален — тёмно-красный
            dust = new Particle.DustOptions(org.bukkit.Color.fromRGB(180, 0, 0), 1.5f);
        } else if (state == PlayerState.HOOKED) {
            // На крюке — фиолетовый
            dust = new Particle.DustOptions(org.bukkit.Color.fromRGB(140, 0, 200), 1.5f);
        } else {
            // Мёртв — серый
            dust = new Particle.DustOptions(org.bukkit.Color.fromRGB(80, 80, 80), 1.0f);
        }

        // Показываем частицу только этому наблюдателю
        observer.spawnParticle(
            Particle.REDSTONE,
            targetLoc,
            3,
            0.15, 0.15, 0.15,
            0,
            dust
        );
    }

    /**
     * Частицы эффекта коллапса вокруг игрока.
     */
    public static void spawnCollapseParticles(Location loc) {
        if (loc.getWorld() == null) return;
        loc.getWorld().spawnParticle(
            Particle.FALLING_DUST,
            loc.add(0, 1, 0),
            8,
            1.5, 1.0, 1.5,
            0.05,
            org.bukkit.Material.NETHERRACK.createBlockData()
        );
    }
}

package ru.metalpipe.dbdgenerators.visual;

import ru.metalpipe.dbdgenerators.model.Generator;

/**
 * Интерфейс визуального провайдера генераторов.
 *
 * Реализует паттерн «Стратегия» — позволяет переключать
 * визуализацию на лету без изменения логики игры.
 *
 * Реализации:
 *   - NativeBlockProvider  (ванильный блок)
 *   - NativeMobProvider    (ArmorStand + голограмма)
 *   - ModelEngineProvider  (мягкая зависимость ModelEngine)
 *   - ItemsAdderProvider   (мягкая зависимость ItemsAdder)
 *
 * Аналогично EntityRenderer в MythicMobs.
 */
public interface VisualProvider {

    /**
     * @return Уникальный идентификатор провайдера (например "NATIVE_MOB").
     */
    String getId();

    /**
     * Проверяет доступность провайдера.
     * Для soft-зависимостей — проверяет наличие плагина.
     *
     * @return true если провайдер может быть использован.
     */
    boolean isAvailable();

    /**
     * Размещает визуальное представление генератора в мире.
     * Вызывается при старте матча или добавлении генератора.
     *
     * @param generator Генератор для визуализации.
     */
    void spawnGenerator(Generator generator);

    /**
     * Удаляет визуальное представление генератора из мира.
     * Вызывается при завершении матча или удалении генератора.
     *
     * @param generator Генератор.
     */
    void removeGenerator(Generator generator);

    /**
     * Обновляет визуал в соответствии с текущим прогрессом.
     * Например: меняет уровень заряда голограммы/BossBar.
     *
     * @param generator Генератор с актуальным прогрессом.
     */
    void updateProgress(Generator generator);

    /**
     * Обновляет визуал при изменении состояния (сломан/починен).
     *
     * @param generator Генератор.
     */
    void updateState(Generator generator);
}

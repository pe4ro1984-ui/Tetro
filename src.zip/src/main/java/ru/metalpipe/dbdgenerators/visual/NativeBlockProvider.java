package ru.metalpipe.dbdgenerators.visual;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.Generator;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Визуальный провайдер на основе ванильного блока.
 *
 * Размещает блок (по умолчанию FURNACE) в позиции генератора
 * и невидимый ArmorStand над ним для голограммы прогресса.
 * Не требует никаких зависимостей.
 */
public final class NativeBlockProvider implements VisualProvider {

    private final DBDGeneratorsPlugin plugin;

    /** Сопоставление gen_id → UUID ArmorStand-голограммы */
    private final Map<String, UUID> hologramEntities = new HashMap<>();

    public NativeBlockProvider(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "NATIVE_BLOCK";
    }

    @Override
    public boolean isAvailable() {
        return true; // всегда доступно
    }

    @Override
    public void spawnGenerator(Generator generator) {
        Location loc = generator.getLocation();
        if (loc.getWorld() == null) return;

        // Установить блок генератора
        Material mat = Material.matchMaterial(
            plugin.getConfig().getString("visual.native-block-material", "FURNACE")
        );
        if (mat == null || !mat.isBlock()) mat = Material.FURNACE;

        Block block = loc.getBlock();
        block.setType(mat, false);

        // Создать голограмму если включена
        if (plugin.getConfig().getBoolean("visual.show-hologram", true)) {
            spawnHologram(generator);
        }
    }

    @Override
    public void removeGenerator(Generator generator) {
        Location loc = generator.getLocation();
        if (loc.getWorld() != null) {
            loc.getBlock().setType(Material.AIR, false);
        }
        removeHologram(generator);
    }

    @Override
    public void updateProgress(Generator generator) {
        removeHologram(generator);
        if (plugin.getConfig().getBoolean("visual.show-hologram", true)) {
            spawnHologram(generator);
        }
    }

    @Override
    public void updateState(Generator generator) {
        Location loc = generator.getLocation();
        if (loc.getWorld() == null) return;

        if (generator.isCompleted()) {
            // Починен — заменяем блок на светящийся
            loc.getBlock().setType(Material.GLOWSTONE, false);
        } else if (generator.isSabotaged()) {
            // Сломан — заменяем на обсидиан
            loc.getBlock().setType(Material.OBSIDIAN, false);
        }
        updateProgress(generator);
    }

    // ──────────────────────────────────────────────────────────
    //  ГОЛОГРАММЫ
    // ──────────────────────────────────────────────────────────

    private void spawnHologram(Generator generator) {
        Location loc = generator.getLocation().add(0.5, 2.5, 0.5);
        if (loc.getWorld() == null) return;

        ArmorStand as = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
        as.setVisible(false);
        as.setGravity(false);
        as.setSmall(true);
        as.setMarker(true);
        as.setCustomNameVisible(true);
        as.setCustomName(buildHologramText(generator));

        hologramEntities.put(generator.getId(), as.getUniqueId());
    }

    private void removeHologram(Generator generator) {
        UUID uuid = hologramEntities.remove(generator.getId());
        if (uuid == null) return;

        Location loc = generator.getLocation();
        if (loc.getWorld() == null) return;

        loc.getWorld().getEntities().stream()
            .filter(e -> e.getUniqueId().equals(uuid))
            .findFirst()
            .ifPresent(org.bukkit.entity.Entity::remove);
    }

    private String buildHologramText(Generator generator) {
        ChatColor color;
        String status;

        if (generator.isCompleted()) {
            color = ChatColor.GREEN;
            status = "✔ ПОЧИНЕН";
        } else if (generator.isSabotaged()) {
            color = ChatColor.DARK_RED;
            status = "✘ СЛОМАН";
        } else if (!generator.getRepairingPlayers().isEmpty()) {
            color = ChatColor.YELLOW;
            status = "⚙ РЕМОНТ";
        } else {
            color = ChatColor.GRAY;
            status = "Генератор #" + generator.getId();
        }

        return color + status + ChatColor.WHITE + " " +
               ChatColor.translateAlternateColorCodes('&', generator.getProgressBar());
    }
}

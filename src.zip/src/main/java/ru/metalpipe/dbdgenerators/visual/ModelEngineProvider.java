package ru.metalpipe.dbdgenerators.visual;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.Generator;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Мягкая интеграция с ModelEngine (by Ticxo).
 *
 * Если ModelEngine не установлен — isAvailable() возвращает false,
 * и VisualProviderRegistry автоматически откатится на NATIVE_MOB.
 *
 * API ModelEngine вызывается через Reflection и прямые вызовы,
 * чтобы не требовать compile-time зависимости.
 *
 * Паттерн аналогичен MythicMobs Soft Integration.
 */
public final class ModelEngineProvider implements VisualProvider {

    private final DBDGeneratorsPlugin plugin;
    private final boolean available;

    /** gen_id → UUID сущности-носителя модели */
    private final Map<String, UUID> modelEntities = new HashMap<>();

    public ModelEngineProvider(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
        this.available = checkAvailability();
    }

    private boolean checkAvailability() {
        try {
            Class.forName("com.ticxo.modelengine.api.ModelEngineAPI");
            return Bukkit.getPluginManager().isPluginEnabled("ModelEngine");
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    @Override
    public String getId() {
        return "MODEL_ENGINE";
    }

    @Override
    public boolean isAvailable() {
        return available;
    }

    @Override
    public void spawnGenerator(Generator generator) {
        if (!available) return;
        Location loc = generator.getLocation().add(0.5, 0.0, 0.5);
        if (loc.getWorld() == null) return;

        try {
            // Создаём базовую сущность
            ArmorStand base = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
            base.setVisible(false);
            base.setGravity(false);
            base.setMarker(true);

            String modelId = plugin.getConfig().getString("visual.model-engine-model-id", "dbd_generator");

            // Вызов ModelEngine API через reflection
            Class<?> apiClass = Class.forName("com.ticxo.modelengine.api.ModelEngineAPI");
            Object api = apiClass.getMethod("getAPI").invoke(null);
            Object modelManager = api.getClass().getMethod("getModelManager").invoke(api);
            Object blueprint = modelManager.getClass()
                .getMethod("getBlueprint", String.class)
                .invoke(modelManager, modelId);

            if (blueprint == null) {
                plugin.getLogger().warning("ModelEngine: модель '" + modelId + "' не найдена!");
                base.remove();
                return;
            }

            Object modeledEntity = apiClass.getMethod("createModeledEntity", org.bukkit.entity.Entity.class)
                .invoke(null, base);
            Object activeModel = modeledEntity.getClass()
                .getMethod("addModel", blueprint.getClass(), boolean.class)
                .invoke(modeledEntity, blueprint, false);

            modelEntities.put(generator.getId(), base.getUniqueId());

        } catch (Exception ex) {
            plugin.getLogger().log(Level.WARNING, "ModelEngine ошибка при создании генератора: " + ex.getMessage());
        }
    }

    @Override
    public void removeGenerator(Generator generator) {
        UUID uuid = modelEntities.remove(generator.getId());
        if (uuid == null) return;

        Location loc = generator.getLocation();
        if (loc.getWorld() == null) return;

        loc.getWorld().getEntities().stream()
            .filter(e -> e.getUniqueId().equals(uuid))
            .findFirst()
            .ifPresent(e -> {
                try {
                    // Попытка корректно удалить через ModelEngine API
                    Class<?> apiClass = Class.forName("com.ticxo.modelengine.api.ModelEngineAPI");
                    Object modeledEntity = apiClass.getMethod("getModeledEntity",
                        org.bukkit.entity.Entity.class).invoke(null, e);
                    if (modeledEntity != null) {
                        modeledEntity.getClass().getMethod("destroy").invoke(modeledEntity);
                    }
                } catch (Exception ex) {
                    plugin.getLogger().log(Level.FINE, "ModelEngine cleanup: " + ex.getMessage());
                }
                e.remove();
            });
    }

    @Override
    public void updateProgress(Generator generator) {
        // ModelEngine анимации можно переключать через model.getAnimationHandler()
        // Для базовой реализации — ничего не делаем, анимация идёт сама
    }

    @Override
    public void updateState(Generator generator) {
        // Можно переключать animation state в зависимости от состояния генератора
        UUID uuid = modelEntities.get(generator.getId());
        if (uuid == null) return;

        String animationName = generator.isCompleted() ? "completed" :
                               generator.isSabotaged() ? "broken" : "idle";

        Location loc = generator.getLocation();
        if (loc.getWorld() == null) return;

        loc.getWorld().getEntities().stream()
            .filter(e -> e.getUniqueId().equals(uuid))
            .findFirst()
            .ifPresent(e -> {
                try {
                    Class<?> apiClass = Class.forName("com.ticxo.modelengine.api.ModelEngineAPI");
                    Object modeledEntity = apiClass.getMethod("getModeledEntity",
                        org.bukkit.entity.Entity.class).invoke(null, e);
                    if (modeledEntity != null) {
                        Object model = modeledEntity.getClass()
                            .getMethod("getModel", String.class)
                            .invoke(modeledEntity,
                                plugin.getConfig().getString("visual.model-engine-model-id", "dbd_generator")
                            );
                        if (model != null) {
                            Object animHandler = model.getClass()
                                .getMethod("getAnimationHandler").invoke(model);
                            animHandler.getClass()
                                .getMethod("playAnimation", String.class, double.class, double.class,
                                    double.class, boolean.class)
                                .invoke(animHandler, animationName, 0.0, 0.0, 0.0, true);
                        }
                    }
                } catch (Exception ex) {
                    plugin.getLogger().log(Level.FINE, "ModelEngine state update: " + ex.getMessage());
                }
            });
    }
}

package ru.metalpipe.dbdgenerators.visual;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.Generator;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

/**
 * Мягкая интеграция с ItemsAdder (by LoneDev).
 *
 * Использует ItemsAdder CustomBlock API для размещения
 * кастомного блока генератора в мире.
 *
 * Если ItemsAdder не установлен — isAvailable() = false,
 * система откатывается на NATIVE_MOB.
 */
public final class ItemsAdderProvider implements VisualProvider {

    private final DBDGeneratorsPlugin plugin;
    private final boolean available;

    /** gen_id → сериализованная локация для последующего удаления */
    private final Map<String, Location> placedLocations = new HashMap<>();

    public ItemsAdderProvider(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
        this.available = checkAvailability();
    }

    private boolean checkAvailability() {
        try {
            Class.forName("dev.lone.itemsadder.api.CustomBlock");
            return Bukkit.getPluginManager().isPluginEnabled("ItemsAdder");
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    @Override
    public String getId() {
        return "ITEMS_ADDER";
    }

    @Override
    public boolean isAvailable() {
        return available;
    }

    @Override
    public void spawnGenerator(Generator generator) {
        if (!available) return;
        Location loc = generator.getLocation();
        if (loc.getWorld() == null) return;

        String modelId = plugin.getConfig().getString("visual.items-adder-model-id", "dbdgenerators:generator");

        try {
            Class<?> customBlockClass = Class.forName("dev.lone.itemsadder.api.CustomBlock");
            Object customBlock = customBlockClass.getMethod("getInstance", String.class)
                .invoke(null, modelId);

            if (customBlock == null) {
                plugin.getLogger().warning("ItemsAdder: блок '" + modelId + "' не найден!");
                return;
            }

            customBlockClass.getMethod("place", Location.class).invoke(customBlock, loc);
            placedLocations.put(generator.getId(), loc.clone());

        } catch (Exception ex) {
            plugin.getLogger().log(Level.WARNING, "ItemsAdder spawn error: " + ex.getMessage());
        }
    }

    @Override
    public void removeGenerator(Generator generator) {
        Location loc = placedLocations.remove(generator.getId());
        if (loc == null || !available) return;

        try {
            Class<?> customBlockClass = Class.forName("dev.lone.itemsadder.api.CustomBlock");
            Object customBlock = customBlockClass.getMethod("byAlreadyPlacedBlock", Location.class)
                .invoke(null, loc);
            if (customBlock != null) {
                customBlockClass.getMethod("remove").invoke(customBlock);
            }
        } catch (Exception ex) {
            plugin.getLogger().log(Level.WARNING, "ItemsAdder remove error: " + ex.getMessage());
            // Fallback: просто ставим воздух
            if (loc.getWorld() != null) {
                loc.getBlock().setType(org.bukkit.Material.AIR, false);
            }
        }
    }

    @Override
    public void updateProgress(Generator generator) {
        // ItemsAdder кастомные блоки не имеют динамического состояния.
        // Прогресс показывается через отдельную голограмму (опционально).
    }

    @Override
    public void updateState(Generator generator) {
        // Можно заменить на другую текстуру в зависимости от состояния
        removeGenerator(generator);
        spawnGenerator(generator);
    }
}

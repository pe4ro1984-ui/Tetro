package ru.metalpipe.dbdgenerators.visual;

import org.bukkit.*;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.Generator;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Визуальный провайдер на основе ArmorStand.
 *
 * Создаёт крупный ArmorStand с головой (имитация генератора)
 * и отдельный ArmorStand-голограмму над ним.
 * Не требует никаких зависимостей — только ванильный Bukkit API.
 *
 * Это провайдер по умолчанию — хорошо выглядит без плагинов.
 */
public final class NativeMobProvider implements VisualProvider {

    private final DBDGeneratorsPlugin plugin;

    /** gen_id → UUID основного ArmorStand (тело генератора) */
    private final Map<String, UUID> bodyEntities = new HashMap<>();

    /** gen_id → UUID ArmorStand-голограммы */
    private final Map<String, UUID> hologramEntities = new HashMap<>();

    public NativeMobProvider(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "NATIVE_MOB";
    }

    @Override
    public boolean isAvailable() {
        return true;
    }

    @Override
    public void spawnGenerator(Generator generator) {
        Location loc = generator.getLocation().add(0.5, 0.0, 0.5);
        if (loc.getWorld() == null) return;

        // ── Основной ArmorStand (тело генератора) ──
        ArmorStand body = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
        body.setVisible(false);
        body.setGravity(false);
        body.setSmall(false);
        body.setArms(false);
        body.setBasePlate(false);
        body.setCustomNameVisible(false);

        // Голова — железный блок (имитация детали генератора)
        ItemStack head = new ItemStack(Material.IRON_BLOCK);
        body.setHelmet(head);

        bodyEntities.put(generator.getId(), body.getUniqueId());

        // ── Голограмма прогресса ──
        if (plugin.getConfig().getBoolean("visual.show-hologram", true)) {
            spawnHologram(generator, loc.add(0, 2.2, 0));
        }
    }

    @Override
    public void removeGenerator(Generator generator) {
        removeEntityByUUID(generator.getLocation(), bodyEntities.remove(generator.getId()));
        removeEntityByUUID(generator.getLocation(), hologramEntities.remove(generator.getId()));
    }

    @Override
    public void updateProgress(Generator generator) {
        UUID holoId = hologramEntities.get(generator.getId());
        if (holoId == null) return;

        findArmorStand(generator.getLocation(), holoId).ifPresent(as ->
            as.setCustomName(buildHologramText(generator))
        );
    }

    @Override
    public void updateState(Generator generator) {
        UUID bodyId = bodyEntities.get(generator.getId());
        if (bodyId == null) return;

        findArmorStand(generator.getLocation(), bodyId).ifPresent(as -> {
            // Меняем «голову» в зависимости от состояния
            Material headMat;
            if (generator.isCompleted()) {
                headMat = Material.GOLD_BLOCK;
            } else if (generator.isSabotaged()) {
                headMat = Material.COAL_BLOCK;
            } else {
                headMat = Material.IRON_BLOCK;
            }
            as.setHelmet(new ItemStack(headMat));
        });

        updateProgress(generator);
    }

    // ──────────────────────────────────────────────────────────
    //  ПРИВАТНЫЕ ХЕЛПЕРЫ
    // ──────────────────────────────────────────────────────────

    private void spawnHologram(Generator generator, Location loc) {
        ArmorStand holo = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
        holo.setVisible(false);
        holo.setGravity(false);
        holo.setSmall(true);
        holo.setMarker(true);
        holo.setCustomNameVisible(true);
        holo.setCustomName(buildHologramText(generator));

        hologramEntities.put(generator.getId(), holo.getUniqueId());
    }

    private java.util.Optional<ArmorStand> findArmorStand(Location loc, UUID uuid) {
        if (uuid == null || loc.getWorld() == null) return java.util.Optional.empty();
        return loc.getWorld().getEntities().stream()
            .filter(e -> e.getUniqueId().equals(uuid) && e instanceof ArmorStand)
            .map(e -> (ArmorStand) e)
            .findFirst();
    }

    private void removeEntityByUUID(Location loc, UUID uuid) {
        if (uuid == null || loc.getWorld() == null) return;
        loc.getWorld().getEntities().stream()
            .filter(e -> e.getUniqueId().equals(uuid))
            .findFirst()
            .ifPresent(org.bukkit.entity.Entity::remove);
    }

    private String buildHologramText(Generator generator) {
        String tag;
        if (generator.isCompleted()) {
            tag = ChatColor.GREEN + "⚡ ПОЧИНЕН";
        } else if (generator.isSabotaged()) {
            tag = ChatColor.DARK_RED + "✘ СЛОМАН";
        } else if (!generator.getRepairingPlayers().isEmpty()) {
            tag = ChatColor.YELLOW + "⚙ " + String.format("%.0f%%", generator.getProgress());
        } else {
            tag = ChatColor.GRAY + "GEN #" + generator.getId();
        }
        return tag;
    }
}

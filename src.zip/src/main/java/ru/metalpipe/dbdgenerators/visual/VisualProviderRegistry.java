package ru.metalpipe.dbdgenerators.visual;

import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Реестр всех визуальных провайдеров.
 *
 * Хранит все зарегистрированные провайдеры и управляет
 * текущим активным провайдером.
 *
 * Позволяет переключить провайдер «на лету» командой /dbd provider <name>.
 */
public final class VisualProviderRegistry {

    private final DBDGeneratorsPlugin plugin;

    /** Все зарегистрированные провайдеры (id → провайдер) */
    private final Map<String, VisualProvider> providers = new LinkedHashMap<>();

    /** Текущий активный провайдер */
    private VisualProvider activeProvider;

    public VisualProviderRegistry(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Регистрирует все встроенные провайдеры.
     * Вызывается один раз при старте плагина.
     */
    public void registerAll() {
        register(new NativeBlockProvider(plugin));
        register(new NativeMobProvider(plugin));
        register(new ModelEngineProvider(plugin));
        register(new ItemsAdderProvider(plugin));
    }

    /**
     * Регистрирует провайдер.
     */
    public void register(VisualProvider provider) {
        providers.put(provider.getId().toUpperCase(), provider);
        plugin.getLogger().fine("Зарегистрирован провайдер: " + provider.getId() +
            " (доступен: " + provider.isAvailable() + ")");
    }

    /**
     * Устанавливает активный провайдер по имени.
     *
     * @param id Идентификатор провайдера (NATIVE_BLOCK, NATIVE_MOB, MODEL_ENGINE, ITEMS_ADDER).
     * @return true если успешно установлен и провайдер доступен.
     */
    public boolean setActiveProvider(String id) {
        VisualProvider provider = providers.get(id.toUpperCase());
        if (provider == null) return false;
        if (!provider.isAvailable()) return false;

        this.activeProvider = provider;
        return true;
    }

    public VisualProvider getActiveProvider() {
        return activeProvider;
    }

    public VisualProvider getProvider(String id) {
        return providers.get(id.toUpperCase());
    }

    public Map<String, VisualProvider> getAllProviders() {
        return providers;
    }
}

package ru.metalpipe.dbdgenerators.commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.gui.LootEditorGUI;
import ru.metalpipe.dbdgenerators.model.Generator;
import ru.metalpipe.dbdgenerators.model.Match;
import ru.metalpipe.dbdgenerators.util.MessageUtil;
import ru.metalpipe.dbdgenerators.visual.VisualProvider;

import java.util.*;

/**
 * Главная команда плагина: /dbd (алиасы: /generator, /gens, /dbdg)
 *
 * Подкоманды:
 *  start, stop, reload, status, debug, selfcheck
 *  gen add|remove <id>|list
 *  loot create <name>|delete <name>|list|edit <name>|additem <name>
 *  vision on|off
 *  provider <name>
 *  help
 */
public final class DBDCommand implements CommandExecutor, TabCompleter {

    private final DBDGeneratorsPlugin plugin;

    public DBDCommand(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "help":
                sendHelp(sender);
                break;

            case "start":
                if (!sender.hasPermission("dbdgenerators.start")) {
                    sender.sendMessage(MessageUtil.msg("general.no-permission")); return true;
                }
                if (!(sender instanceof Player)) {
                    plugin.getMatchManager().startMatch(null);
                } else {
                    plugin.getMatchManager().startMatch((Player) sender);
                }
                break;

            case "stop":
                if (!sender.hasPermission("dbdgenerators.stop")) {
                    sender.sendMessage(MessageUtil.msg("general.no-permission")); return true;
                }
                plugin.getMatchManager().stopMatch(
                    sender instanceof Player ? (Player) sender : null,
                    "Admin stop"
                );
                break;

            case "reload":
                if (!sender.hasPermission("dbdgenerators.reload")) {
                    sender.sendMessage(MessageUtil.msg("general.no-permission")); return true;
                }
                try {
                    plugin.getConfigManager().reloadAll();
                    MessageUtil.init(plugin.getConfigManager().getMessagesConfig());
                    plugin.getGeneratorManager().loadGenerators();
                    plugin.getLootManager().loadLootTables();
                    sender.sendMessage(MessageUtil.msg("general.reload-success"));
                } catch (Exception ex) {
                    sender.sendMessage(MessageUtil.msg("general.reload-fail"));
                    plugin.getLogger().severe("Reload error: " + ex.getMessage());
                }
                break;

            case "status":
                if (!sender.hasPermission("dbdgenerators.status")) {
                    sender.sendMessage(MessageUtil.msg("general.no-permission")); return true;
                }
                sendStatus(sender);
                break;

            case "debug":
                if (!sender.hasPermission("dbdgenerators.debug")) {
                    sender.sendMessage(MessageUtil.msg("general.no-permission")); return true;
                }
                sendDebug(sender);
                break;

            case "selfcheck":
                if (!sender.hasPermission("dbdgenerators.selfcheck")) {
                    sender.sendMessage(MessageUtil.msg("general.no-permission")); return true;
                }
                runSelfCheck(sender);
                break;

            case "gen":
                if (!sender.hasPermission("dbdgenerators.setup")) {
                    sender.sendMessage(MessageUtil.msg("general.no-permission")); return true;
                }
                handleGenCommand(sender, args);
                break;

            case "loot":
                if (!sender.hasPermission("dbdgenerators.loot.create")) {
                    sender.sendMessage(MessageUtil.msg("general.no-permission")); return true;
                }
                handleLootCommand(sender, args);
                break;

            case "vision":
                if (!sender.hasPermission("dbdgenerators.vision")) {
                    sender.sendMessage(MessageUtil.msg("general.no-permission")); return true;
                }
                if (!(sender instanceof Player)) {
                    sender.sendMessage(MessageUtil.msg("general.player-only")); return true;
                }
                plugin.getMatchManager().toggleVision((Player) sender);
                break;

            case "provider":
                if (!sender.hasPermission("dbdgenerators.provider")) {
                    sender.sendMessage(MessageUtil.msg("general.no-permission")); return true;
                }
                handleProviderCommand(sender, args);
                break;

            case "stats":
                handleStatsCommand(sender, args);
                break;

            default:
                sender.sendMessage(MessageUtil.msg("general.unknown-command"));
        }

        return true;
    }

    // ──────────────────────────────────────────────────────────
    //  ПОДКОМАНДЫ
    // ──────────────────────────────────────────────────────────

    private void handleGenCommand(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§eИспользование: /dbd gen <add|remove <id>|list>");
            return;
        }

        switch (args[1].toLowerCase()) {
            case "add":
                if (!(sender instanceof Player)) {
                    sender.sendMessage(MessageUtil.msg("general.player-only")); return;
                }
                Player p = (Player) sender;
                Generator added = plugin.getGeneratorManager().addGenerator(p.getLocation());
                sender.sendMessage(MessageUtil.msg("generators.gen-added")
                    .replace("{gen_id}", added.getId()));
                break;

            case "remove":
                if (args.length < 3) {
                    sender.sendMessage("§eИспользование: /dbd gen remove <id>"); return;
                }
                boolean removed = plugin.getGeneratorManager().removeGenerator(args[2]);
                if (removed) {
                    sender.sendMessage(MessageUtil.msg("generators.gen-removed")
                        .replace("{gen_id}", args[2]));
                } else {
                    sender.sendMessage(MessageUtil.msg("generators.gen-not-found")
                        .replace("{gen_id}", args[2]));
                }
                break;

            case "list":
                Collection<Generator> gens = plugin.getGeneratorManager().getAllGenerators();
                sender.sendMessage(MessageUtil.msg("generators.gen-list-header")
                    .replace("{count}", String.valueOf(gens.size())));
                for (Generator gen : gens) {
                    org.bukkit.Location loc = gen.getLocation();
                    String status = gen.isCompleted() ? "§aПОЧИНЕН" :
                                    gen.isSabotaged() ? "§cСЛОМАН"  : "§7Ожидает";
                    sender.sendMessage(MessageUtil.msg("generators.gen-list-entry")
                        .replace("{gen_id}", gen.getId())
                        .replace("{progress}", String.format("%.0f", gen.getProgress()))
                        .replace("{status}", status)
                        .replace("{world}", loc.getWorld() != null ? loc.getWorld().getName() : "?")
                        .replace("{x}", String.valueOf(loc.getBlockX()))
                        .replace("{y}", String.valueOf(loc.getBlockY()))
                        .replace("{z}", String.valueOf(loc.getBlockZ())));
                }
                break;

            default:
                sender.sendMessage("§eИспользование: /dbd gen <add|remove <id>|list>");
        }
    }

    private void handleLootCommand(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§eИспользование: /dbd loot <create|delete|list|edit|additem> [name]");
            return;
        }

        switch (args[1].toLowerCase()) {
            case "create":
                if (args.length < 3) { sender.sendMessage("§eУкажите имя таблицы."); return; }
                plugin.getLootManager().createLootTable(args[2]);
                sender.sendMessage(MessageUtil.msg("loot.loot-created")
                    .replace("{name}", args[2]));
                break;

            case "delete":
                if (!sender.hasPermission("dbdgenerators.loot.delete")) {
                    sender.sendMessage(MessageUtil.msg("general.no-permission")); return;
                }
                if (args.length < 3) { sender.sendMessage("§eУкажите имя таблицы."); return; }
                if (plugin.getLootManager().deleteLootTable(args[2])) {
                    sender.sendMessage(MessageUtil.msg("loot.loot-deleted").replace("{name}", args[2]));
                } else {
                    sender.sendMessage(MessageUtil.msg("loot.loot-not-found").replace("{name}", args[2]));
                }
                break;

            case "list":
                if (!sender.hasPermission("dbdgenerators.loot.list")) {
                    sender.sendMessage(MessageUtil.msg("general.no-permission")); return;
                }
                Collection<ru.metalpipe.dbdgenerators.model.LootChest> tables =
                    plugin.getLootManager().getAllLootTables();
                sender.sendMessage(MessageUtil.msg("loot.loot-list-header")
                    .replace("{count}", String.valueOf(tables.size())));
                tables.forEach(t -> sender.sendMessage(
                    MessageUtil.msg("loot.loot-list-entry")
                        .replace("{name}", t.getName())
                        .replace("{count}", String.valueOf(t.getEntries().size()))
                ));
                break;

            case "edit":
                if (!(sender instanceof Player)) {
                    sender.sendMessage(MessageUtil.msg("general.player-only")); return;
                }
                if (args.length < 3) { sender.sendMessage("§eУкажите имя таблицы."); return; }
                LootEditorGUI.open(plugin, (Player) sender, args[2]);
                break;

            case "additem":
                if (!(sender instanceof Player)) {
                    sender.sendMessage(MessageUtil.msg("general.player-only")); return;
                }
                if (args.length < 3) { sender.sendMessage("§eУкажите имя таблицы."); return; }
                boolean added = plugin.getLootManager().addItemFromHand((Player) sender, args[2]);
                if (added) {
                    sender.sendMessage(MessageUtil.msg("loot.loot-item-added").replace("{name}", args[2]));
                } else {
                    sender.sendMessage("§cНет предмета в руке или таблица не найдена.");
                }
                break;

            default:
                sender.sendMessage("§eИспользование: /dbd loot <create|delete|list|edit|additem> [name]");
        }
    }

    private void handleStatsCommand(CommandSender sender, String[] args) {
        java.util.UUID targetUuid;
        String targetName;

        if (args.length >= 2 && sender.hasPermission("dbdgenerators.status")) {
            // /dbd stats <игрок>
            org.bukkit.OfflinePlayer target = org.bukkit.Bukkit.getOfflinePlayer(args[1]);
            targetUuid = target.getUniqueId();
            targetName = target.getName() != null ? target.getName() : args[1];
        } else if (sender instanceof Player) {
            targetUuid = ((Player) sender).getUniqueId();
            targetName = sender.getName();
        } else {
            sender.sendMessage(MessageUtil.msg("general.player-only"));
            return;
        }

        sender.sendMessage("§8§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        sender.sendMessage("  §c§lDBDGenerators §8| §7Статистика: §e" + targetName);
        sender.sendMessage("§8§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        plugin.getStatisticsManager().formatStats(targetUuid).forEach(sender::sendMessage);
    }

    private void handleProviderCommand(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(MessageUtil.msg("provider.unknown").replace("{provider}", ""));
            return;
        }
        String provName = args[1].toUpperCase();
        VisualProvider prov = plugin.getVisualProviderRegistry().getProvider(provName);
        if (prov == null) {
            sender.sendMessage(MessageUtil.msg("provider.unknown").replace("{provider}", provName));
            return;
        }
        if (!prov.isAvailable()) {
            sender.sendMessage(MessageUtil.msg("provider.not-available").replace("{provider}", provName));
            return;
        }
        plugin.getVisualProviderRegistry().setActiveProvider(provName);
        sender.sendMessage(MessageUtil.msg("provider.changed").replace("{provider}", provName));
    }

    // ──────────────────────────────────────────────────────────
    //  STATUS / DEBUG / SELFCHECK
    // ──────────────────────────────────────────────────────────

    private void sendStatus(CommandSender sender) {
        sender.sendMessage(MessageUtil.msg("status.header"));
        sender.sendMessage(MessageUtil.msg("status.title"));
        sender.sendMessage(MessageUtil.msg("status.header"));

        Match match = plugin.getMatchManager().getCurrentMatch();
        if (match == null) {
            sender.sendMessage(MessageUtil.msg("status.no-match"));
        } else {
            sender.sendMessage(MessageUtil.msg("status.phase")
                .replace("{phase}", match.getPhase().getDisplayName()));
            sender.sendMessage(MessageUtil.msg("status.players")
                .replace("{count}", String.valueOf(match.getParticipants().size()))
                .replace("{max}", String.valueOf(plugin.getConfig().getInt("match.max-players", 5))));
            sender.sendMessage(MessageUtil.msg("status.generators")
                .replace("{done}", String.valueOf(match.getCompletedGenerators()))
                .replace("{total}", String.valueOf(match.getRequiredGenerators())));
            sender.sendMessage(MessageUtil.msg("status.provider")
                .replace("{provider}", plugin.getVisualProviderRegistry().getActiveProvider().getId()));
            sender.sendMessage(MessageUtil.msg("status.time-left")
                .replace("{time}", String.valueOf(
                    plugin.getConfig().getInt("match.match-duration", 600) -
                    match.getPhaseElapsedSeconds()
                )));
        }
        sender.sendMessage(MessageUtil.msg("status.footer"));
    }

    private void sendDebug(CommandSender sender) {
        sender.sendMessage("§8§m═══════════════════════════════════");
        sender.sendMessage("  §c§lDBDGenerators §8| §7Debug Info");
        sender.sendMessage("§8§m═══════════════════════════════════");
        sender.sendMessage("§7Plugin version: §e" + plugin.getDescription().getVersion());
        sender.sendMessage("§7Server: §e" + Bukkit.getVersion());
        sender.sendMessage("§7Active provider: §e" +
            plugin.getVisualProviderRegistry().getActiveProvider().getId());
        sender.sendMessage("§7Generators: §e" +
            plugin.getGeneratorManager().getRegisteredGeneratorsCount());
        sender.sendMessage("§7Loot tables: §e" +
            plugin.getLootManager().getAllLootTables().size());
        sender.sendMessage("§7Match running: §e" +
            plugin.getMatchManager().isMatchRunning());

        // Провайдеры
        sender.sendMessage("§7Providers:");
        plugin.getVisualProviderRegistry().getAllProviders().forEach((id, prov) ->
            sender.sendMessage("  §7- §e" + id + " §8→ " + (prov.isAvailable() ? "§aДоступен" : "§cНедоступен"))
        );
        sender.sendMessage("§8§m═══════════════════════════════════");
    }

    private void runSelfCheck(CommandSender sender) {
        sender.sendMessage(MessageUtil.msg("selfcheck.header"));
        sender.sendMessage(MessageUtil.msg("selfcheck.title"));
        sender.sendMessage(MessageUtil.msg("selfcheck.header"));

        // 1. Генераторы
        int genCount = plugin.getGeneratorManager().getRegisteredGeneratorsCount();
        int required = plugin.getConfig().getInt("match.generators-required", 5);
        if (genCount < required) {
            sender.sendMessage(MessageUtil.msg("selfcheck.warn")
                .replace("{check}", "Генераторов: " + genCount + " (требуется " + required + ")"));
        } else {
            sender.sendMessage(MessageUtil.msg("selfcheck.ok")
                .replace("{check}", "Генераторы: " + genCount + " шт."));
        }

        // 2. Провайдер
        VisualProvider prov = plugin.getVisualProviderRegistry().getActiveProvider();
        if (prov != null && prov.isAvailable()) {
            sender.sendMessage(MessageUtil.msg("selfcheck.ok")
                .replace("{check}", "Провайдер: " + prov.getId() + " доступен"));
        } else {
            sender.sendMessage(MessageUtil.msg("selfcheck.error")
                .replace("{check}", "Провайдер недоступен!"));
        }

        // 3. Конфиг
        int minPlayers = plugin.getConfig().getInt("match.min-players", 2);
        int maxPlayers = plugin.getConfig().getInt("match.max-players", 5);
        if (minPlayers > maxPlayers) {
            sender.sendMessage(MessageUtil.msg("selfcheck.error")
                .replace("{check}", "min-players > max-players в config.yml!"));
        } else {
            sender.sendMessage(MessageUtil.msg("selfcheck.ok")
                .replace("{check}", "Лимиты игроков: " + minPlayers + "-" + maxPlayers));
        }

        // 4. Лут-таблицы
        int lootCount = plugin.getLootManager().getAllLootTables().size();
        if (lootCount == 0) {
            sender.sendMessage(MessageUtil.msg("selfcheck.warn")
                .replace("{check}", "Лут-таблиц не найдено. Создайте: /dbd loot create <name>"));
        } else {
            sender.sendMessage(MessageUtil.msg("selfcheck.ok")
                .replace("{check}", "Лут-таблиц: " + lootCount));
        }

        // 5. Soft-зависимости
        boolean meAvail = plugin.getVisualProviderRegistry()
            .getProvider("MODEL_ENGINE").isAvailable();
        boolean iaAvail = plugin.getVisualProviderRegistry()
            .getProvider("ITEMS_ADDER").isAvailable();

        sender.sendMessage(MessageUtil.msg(meAvail ? "selfcheck.ok" : "selfcheck.warn")
            .replace("{check}", "ModelEngine: " + (meAvail ? "установлен" : "не установлен (ок)")));
        sender.sendMessage(MessageUtil.msg(iaAvail ? "selfcheck.ok" : "selfcheck.warn")
            .replace("{check}", "ItemsAdder: " + (iaAvail ? "установлен" : "не установлен (ок)")));

        sender.sendMessage(MessageUtil.msg("selfcheck.footer"));
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(MessageUtil.msg("help.header"));
        sender.sendMessage(MessageUtil.msg("help.title"));
        for (String entry : plugin.getConfigManager().getMessagesConfig()
                .getStringList("help.entries")) {
            sender.sendMessage(MessageUtil.colorize(entry));
        }
        sender.sendMessage(MessageUtil.msg("help.footer"));
    }

    // ──────────────────────────────────────────────────────────
    //  TAB COMPLETION
    // ──────────────────────────────────────────────────────────

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();

        if (args.length == 1) {
            List<String> subs = Arrays.asList("help", "start", "stop", "reload",
                "status", "debug", "selfcheck", "stats", "gen", "loot", "vision", "provider");
            filterStartsWith(result, subs, args[0]);
        } else if (args.length == 2) {
            switch (args[0].toLowerCase()) {
                case "gen":
                    filterStartsWith(result, Arrays.asList("add", "remove", "list"), args[1]);
                    break;
                case "loot":
                    filterStartsWith(result, Arrays.asList("create", "delete", "list", "edit", "additem"), args[1]);
                    break;
                case "vision":
                    filterStartsWith(result, Arrays.asList("on", "off"), args[1]);
                    break;
                case "provider":
                    filterStartsWith(result,
                        Arrays.asList("NATIVE_BLOCK", "NATIVE_MOB", "MODEL_ENGINE", "ITEMS_ADDER"),
                        args[1]);
                    break;
            }
        } else if (args.length == 3) {
            if (args[0].equalsIgnoreCase("gen") && args[1].equalsIgnoreCase("remove")) {
                plugin.getGeneratorManager().getAllGenerators()
                    .forEach(g -> result.add(g.getId()));
            } else if (args[0].equalsIgnoreCase("loot") &&
                       (args[1].equalsIgnoreCase("delete") ||
                        args[1].equalsIgnoreCase("edit") ||
                        args[1].equalsIgnoreCase("additem"))) {
                plugin.getLootManager().getAllLootTables()
                    .forEach(t -> result.add(t.getName()));
            }
        }

        return result;
    }

    private void filterStartsWith(List<String> result, List<String> options, String prefix) {
        options.stream()
            .filter(o -> o.toLowerCase().startsWith(prefix.toLowerCase()))
            .forEach(result::add);
    }
}

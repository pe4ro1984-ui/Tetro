package ru.metalpipe.dbdgenerators.model;

import org.bukkit.entity.Player;

import java.util.*;

/**
 * Модель активного матча.
 *
 * Хранит фазу, роли игроков, счёт починенных генераторов,
 * временны́е метки фаз.
 *
 * Паттерн: аналогично Match в Marcely's BedWars — один объект
 * на активную игровую сессию.
 */
public final class Match {

    /** Уникальный ID матча (UUID для логирования) */
    private final UUID matchId;

    /** Текущая фаза матча */
    private MatchPhase phase;

    /** Роли игроков: UUID → PlayerRole */
    private final Map<UUID, PlayerRole> playerRoles;

    /** Список UUID всех участников матча */
    private final Set<UUID> participants;

    /** Количество починенных генераторов */
    private int completedGenerators;

    /** Требуемое количество для победы */
    private final int requiredGenerators;

    /** Время начала текущей фазы (System.currentTimeMillis) */
    private long phaseStartTime;

    /** Открыты ли ворота эвакуации */
    private boolean gatesOpen;

    /** Победитель: true = выжившие, false = охотник, null = ничья/таймаут */
    private Boolean survivorsWon;

    /** Количество живых выживших (HEALTHY / INJURED / DOWNED / HOOKED) */
    private int aliveSurvivors;

    public Match(int requiredGenerators) {
        this.matchId = UUID.randomUUID();
        this.phase = MatchPhase.LOBBY;
        this.playerRoles = new LinkedHashMap<>();
        this.participants = new LinkedHashSet<>();
        this.completedGenerators = 0;
        this.requiredGenerators = requiredGenerators;
        this.phaseStartTime = System.currentTimeMillis();
        this.gatesOpen = false;
        this.survivorsWon = null;
        this.aliveSurvivors = 0;
    }

    // ──────────────────────────────────────────────────────────
    //  УПРАВЛЕНИЕ ИГРОКАМИ
    // ──────────────────────────────────────────────────────────

    public void addPlayer(Player player, PlayerRole role) {
        participants.add(player.getUniqueId());
        playerRoles.put(player.getUniqueId(), role);
        if (role == PlayerRole.SURVIVOR) aliveSurvivors++;
    }

    public void removePlayer(UUID uuid) {
        PlayerRole role = playerRoles.remove(uuid);
        participants.remove(uuid);
        if (role == PlayerRole.SURVIVOR) {
            aliveSurvivors = Math.max(0, aliveSurvivors - 1);
        }
    }

    public PlayerRole getRoleOf(UUID uuid) {
        return playerRoles.getOrDefault(uuid, null);
    }

    public boolean isParticipant(UUID uuid) {
        return participants.contains(uuid);
    }

    /** Получить UUID охотника (или null) */
    public UUID getHunterUUID() {
        return playerRoles.entrySet().stream()
            .filter(e -> e.getValue() == PlayerRole.HUNTER)
            .map(Map.Entry::getKey)
            .findFirst()
            .orElse(null);
    }

    /** Получить UUID всех выживших */
    public List<UUID> getSurvivorUUIDs() {
        List<UUID> result = new ArrayList<>();
        playerRoles.forEach((uuid, role) -> {
            if (role == PlayerRole.SURVIVOR) result.add(uuid);
        });
        return result;
    }

    // ──────────────────────────────────────────────────────────
    //  ФАЗЫ
    // ──────────────────────────────────────────────────────────

    public void setPhase(MatchPhase phase) {
        this.phase = phase;
        this.phaseStartTime = System.currentTimeMillis();
    }

    public long getPhaseElapsedSeconds() {
        return (System.currentTimeMillis() - phaseStartTime) / 1000L;
    }

    // ──────────────────────────────────────────────────────────
    //  ГЕНЕРАТОРЫ
    // ──────────────────────────────────────────────────────────

    public void incrementCompletedGenerators() {
        completedGenerators++;
    }

    public boolean isGeneratorGoalReached() {
        return completedGenerators >= requiredGenerators;
    }

    // ──────────────────────────────────────────────────────────
    //  ГЕТТЕРЫ / СЕТТЕРЫ
    // ──────────────────────────────────────────────────────────

    public UUID getMatchId() { return matchId; }

    public MatchPhase getPhase() { return phase; }

    public Map<UUID, PlayerRole> getPlayerRoles() { return Collections.unmodifiableMap(playerRoles); }

    public Set<UUID> getParticipants() { return Collections.unmodifiableSet(participants); }

    public int getCompletedGenerators() { return completedGenerators; }

    public int getRequiredGenerators() { return requiredGenerators; }

    public boolean isGatesOpen() { return gatesOpen; }

    public void setGatesOpen(boolean gatesOpen) { this.gatesOpen = gatesOpen; }

    public Boolean getSurvivorsWon() { return survivorsWon; }

    public void setSurvivorsWon(Boolean survivorsWon) { this.survivorsWon = survivorsWon; }

    public int getAliveSurvivors() { return aliveSurvivors; }

    public void setAliveSurvivors(int count) { this.aliveSurvivors = count; }

    public void decrementAliveSurvivors() {
        aliveSurvivors = Math.max(0, aliveSurvivors - 1);
    }
}

package ru.metalpipe.dbdgenerators.model;

/**
 * Фазы матча DBDGenerators.
 * Аналогичны фазам в Marcely's BedWars:
 *   LOBBY → IN_GAME → ENDGAME_COLLAPSE → FINISHED
 */
public enum MatchPhase {

    /** Лобби — ожидание игроков, обратный отсчёт. */
    LOBBY("Лобби"),

    /** Активная игра — генераторы, охота, ремонт. */
    IN_GAME("В игре"),

    /**
     * Коллапс — финальная фаза после истечения времени
     * или выполнения условий победы.
     * Усиленные эффекты, финальный таймер эвакуации.
     */
    ENDGAME_COLLAPSE("Коллапс"),

    /** Матч завершён — показ результатов, подготовка к перезапуску. */
    FINISHED("Завершён");

    private final String displayName;

    MatchPhase(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}

package ru.metalpipe.dbdgenerators.model;

import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Модель лут-таблицы для ящиков снаряжения.
 * Хранит список возможных предметов с весами.
 */
public final class LootChest {

    /** Уникальное имя таблицы */
    private final String name;

    /** Список возможных предметов */
    private final List<LootEntry> entries;

    public LootChest(String name) {
        this.name = name;
        this.entries = new ArrayList<>();
    }

    public void addEntry(LootEntry entry) {
        entries.add(entry);
    }

    public void removeEntry(int index) {
        if (index >= 0 && index < entries.size()) {
            entries.remove(index);
        }
    }

    public List<LootEntry> getEntries() {
        return entries;
    }

    public String getName() {
        return name;
    }

    /**
     * Вложенный класс — один предмет лут-таблицы с весом.
     */
    public static final class LootEntry {

        private ItemStack item;
        private int weight;
        private int slot; // 0-26 для GUI-слота или -1 = любой

        public LootEntry(ItemStack item, int weight, int slot) {
            this.item = item;
            this.weight = weight;
            this.slot = slot;
        }

        public ItemStack getItem() { return item; }
        public void setItem(ItemStack item) { this.item = item; }
        public int getWeight() { return weight; }
        public void setWeight(int weight) { this.weight = weight; }
        public int getSlot() { return slot; }
        public void setSlot(int slot) { this.slot = slot; }
    }
}

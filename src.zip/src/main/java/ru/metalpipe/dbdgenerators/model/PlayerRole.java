package ru.metalpipe.dbdgenerators.model;

import org.bukkit.ChatColor;

/**
 * Роли игроков в матче DBDGenerators.
 */
public enum PlayerRole {

    /** Выживший — чинит генераторы, эвакуируется. */
    SURVIVOR("&2Выживший", ChatColor.GREEN),

    /** Охотник — преследует, ловит, саботирует генераторы. */
    HUNTER("&4Охотник", ChatColor.RED),

    /** Зритель — наблюдает, видит партиклы всех игроков. */
    SPECTATOR("&8Зритель", ChatColor.GRAY);

    private final String displayName;
    private final ChatColor color;

    PlayerRole(String displayName, ChatColor color) {
        this.displayName = displayName;
        this.color = color;
    }

    public String getDisplayName() {
        return ChatColor.translateAlternateColorCodes('&', displayName);
    }

    public ChatColor getColor() {
        return color;
    }
}

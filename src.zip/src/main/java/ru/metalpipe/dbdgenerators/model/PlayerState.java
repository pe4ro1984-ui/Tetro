package ru.metalpipe.dbdgenerators.model;

import org.bukkit.ChatColor;

/**
 * Состояния выживших в матче.
 * Реализует механику из Dead by Daylight:
 *   HEALTHY → INJURED → DOWNED → HOOKED → (DEAD)
 */
public enum PlayerState {

    /** Здоров — полное здоровье, нормальное передвижение. */
    HEALTHY("Здоров", ChatColor.GREEN),

    /**
     * Ранен — замедленное движение, издаёт звуки стонов,
     * следующий удар = DOWNED.
     */
    INJURED("Ранен", ChatColor.YELLOW),

    /**
     * Повален — ползёт по земле, не может использовать предметы,
     * ждёт помощи союзников.
     */
    DOWNED("Повален", ChatColor.RED),

    /**
     * На крюке — подвешен охотником,
     * союзники могут снять за ограниченное время.
     */
    HOOKED("На крюке", ChatColor.DARK_RED),

    /**
     * Мёртв — вышел из матча (все хуки исчерпаны).
     * Переходит в SPECTATOR.
     */
    DEAD("Мёртв", ChatColor.DARK_GRAY);

    private final String displayName;
    private final ChatColor color;

    PlayerState(String displayName, ChatColor color) {
        this.displayName = displayName;
        this.color = color;
    }

    public String getDisplayName() {
        return displayName;
    }

    public ChatColor getColor() {
        return color;
    }
}

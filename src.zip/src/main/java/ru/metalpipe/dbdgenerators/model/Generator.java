package ru.metalpipe.dbdgenerators.model;

import org.bukkit.Location;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Модель генератора.
 *
 * Хранит:
 *  - ID и позицию в мире
 *  - Прогресс ремонта (0.0 - 100.0)
 *  - Список чинящих игроков
 *  - Статус (сломан / починен / саботирован)
 *  - Ссылку на визуальную сущность (UUID ArmorStand или entityId)
 */
public final class Generator {

    /** Уникальный строковый ID, например "gen_1" */
    private final String id;

    /** Местоположение в мире */
    private final Location location;

    /** Прогресс ремонта от 0.0 до 100.0 */
    private double progress;

    /** Полностью починен? */
    private boolean completed;

    /** Саботирован охотником (прогресс обнуляется, временно не чинится)? */
    private boolean sabotaged;

    /** UUID игроков, которые сейчас чинят этот генератор */
    private final Set<UUID> repairingPlayers;

    /** UUID ArmorStand или иной визуальной сущности (может быть null) */
    private UUID visualEntityId;

    /** Тик последнего ремонта — для расчёта regression delay */
    private long lastRepairTick;

    public Generator(String id, Location location) {
        this.id = id;
        this.location = location.clone();
        this.progress = 0.0;
        this.completed = false;
        this.sabotaged = false;
        this.repairingPlayers = new HashSet<>();
        this.lastRepairTick = 0L;
    }

    // ──────────────────────────────────────────────────────────
    //  РЕМОНТ
    // ──────────────────────────────────────────────────────────

    /**
     * Добавить игрока к ремонту.
     * @return true, если игрок только что начал чинить.
     */
    public boolean addRepairingPlayer(UUID playerUuid) {
        return repairingPlayers.add(playerUuid);
    }

    /**
     * Убрать игрока из ремонта.
     */
    public void removeRepairingPlayer(UUID playerUuid) {
        repairingPlayers.remove(playerUuid);
    }

    /**
     * Проверить, чинит ли указанный игрок этот генератор.
     */
    public boolean isRepairedBy(UUID playerUuid) {
        return repairingPlayers.contains(playerUuid);
    }

    /**
     * Добавить прогресс с ограничением в 100.0.
     * @return true, если генератор только что починился (перешёл 100).
     */
    public boolean addProgress(double amount) {
        if (completed || sabotaged) return false;
        progress = Math.min(100.0, progress + amount);
        if (progress >= 100.0) {
            progress = 100.0;
            completed = true;
            repairingPlayers.clear();
            return true;
        }
        return false;
    }

    /**
     * Уменьшить прогресс (регрессия или саботаж).
     */
    public void subtractProgress(double amount) {
        progress = Math.max(0.0, progress - amount);
    }

    /**
     * Сбросить состояние генератора для нового матча.
     */
    public void reset() {
        progress = 0.0;
        completed = false;
        sabotaged = false;
        repairingPlayers.clear();
        lastRepairTick = 0L;
    }

    // ──────────────────────────────────────────────────────────
    //  ГЕТТЕРЫ / СЕТТЕРЫ
    // ──────────────────────────────────────────────────────────

    public String getId() { return id; }

    public Location getLocation() { return location.clone(); }

    public double getProgress() { return progress; }

    public void setProgress(double progress) {
        this.progress = Math.max(0.0, Math.min(100.0, progress));
    }

    public boolean isCompleted() { return completed; }

    public void setCompleted(boolean completed) { this.completed = completed; }

    public boolean isSabotaged() { return sabotaged; }

    public void setSabotaged(boolean sabotaged) {
        this.sabotaged = sabotaged;
        if (sabotaged) {
            repairingPlayers.clear();
        }
    }

    public Set<UUID> getRepairingPlayers() {
        return Collections.unmodifiableSet(repairingPlayers);
    }

    public UUID getVisualEntityId() { return visualEntityId; }

    public void setVisualEntityId(UUID id) { this.visualEntityId = id; }

    public long getLastRepairTick() { return lastRepairTick; }

    public void setLastRepairTick(long tick) { this.lastRepairTick = tick; }

    /**
     * Красивое отображение прогресса в виде прогресс-бара.
     * Пример: [████████░░] 80%
     */
    public String getProgressBar() {
        int filled = (int) (progress / 10.0);
        StringBuilder sb = new StringBuilder("&7[");
        for (int i = 0; i < 10; i++) {
            if (i < filled) sb.append("&a█");
            else sb.append("&8░");
        }
        sb.append("&7] &f").append(String.format("%.0f", progress)).append("%");
        return sb.toString();
    }

    @Override
    public String toString() {
        return "Generator{id='" + id + "', progress=" + progress + "%, completed=" + completed + "}";
    }
}

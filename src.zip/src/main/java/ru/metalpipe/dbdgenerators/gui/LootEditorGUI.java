package ru.metalpipe.dbdgenerators.gui;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.LootChest;
import ru.metalpipe.dbdgenerators.util.MessageUtil;

import java.util.Arrays;
import java.util.Collections;

/**
 * GUI-редактор лут-таблиц.
 *
 * Открывается командой /dbd loot edit <name>.
 * Позволяет:
 *  - Просматривать предметы таблицы
 *  - Добавлять предметы (кликом в пустой слот)
 *  - Убирать предметы (кликом Shift+ЛКМ)
 *  - Заполнители — стеклянные панели
 *
 * Паттерн вдохновлён EliteMobs GUI-редактором.
 */
public final class LootEditorGUI {

    private static final int GUI_SIZE = 54;
    private static final int CONTENT_SLOTS = 27; // 0-26

    private LootEditorGUI() {}

    /**
     * Открыть GUI-редактор лут-таблицы для игрока.
     */
    public static void open(DBDGeneratorsPlugin plugin, Player player, String tableName) {
        LootChest chest = plugin.getLootManager().getLootTable(tableName);
        if (chest == null) {
            player.sendMessage(MessageUtil.msg("loot.loot-not-found")
                .replace("{name}", tableName));
            return;
        }

        String title = MessageUtil.colorize(
            plugin.getConfigManager().getMessagesConfig()
                .getString("loot.loot-gui-title", "&8Редактор лута: &e{name}")
                .replace("{name}", tableName)
        );

        Inventory inv = Bukkit.createInventory(null, GUI_SIZE, title);

        // Заполняем содержимое
        for (int i = 0; i < CONTENT_SLOTS && i < chest.getEntries().size(); i++) {
            inv.setItem(i, chest.getEntries().get(i).getItem().clone());
        }

        // Разделитель — стеклянные панели (строка 4)
        ItemStack pane = createGlassPane(ChatColor.DARK_GRAY + "§m─────────────────────");
        for (int i = 27; i < 36; i++) {
            inv.setItem(i, pane);
        }

        // Информационные панели внизу
        inv.setItem(36, createInfoItem(Material.PAPER,
            ChatColor.YELLOW + "Добавить предмет",
            Collections.singletonList(ChatColor.GRAY + "Переместите предмет в слоты 0-26")));

        inv.setItem(40, createInfoItem(Material.BARRIER,
            ChatColor.RED + "Убрать предмет",
            Collections.singletonList(ChatColor.GRAY + "Возьмите предмет из слота 0-26")));

        inv.setItem(44, createInfoItem(Material.EMERALD,
            ChatColor.GREEN + "Сохранено автоматически",
            Collections.singletonList(ChatColor.GRAY + "Закройте GUI для сохранения")));

        plugin.getLootManager().startEditSession(player.getUniqueId(), tableName);
        player.openInventory(inv);
    }

    /**
     * Сохранить изменения из инвентаря GUI в лут-таблицу.
     * Вызывается при закрытии GUI (InventoryCloseEvent).
     */
    public static void saveFromInventory(DBDGeneratorsPlugin plugin, Player player,
                                          String tableName, Inventory inv) {
        LootChest chest = plugin.getLootManager().getLootTable(tableName);
        if (chest == null) return;

        // Очищаем и пересобираем таблицу
        chest.getEntries().clear();

        for (int i = 0; i < CONTENT_SLOTS; i++) {
            ItemStack item = inv.getItem(i);
            if (item == null || item.getType() == Material.AIR) continue;
            if (isGuiItem(item)) continue;

            chest.addEntry(new LootChest.LootEntry(item.clone(), 50, i));
        }

        plugin.getLootManager().saveLootTables();
        player.sendMessage(MessageUtil.msg("loot.loot-item-added")
            .replace("{name}", tableName));
    }

    // ──────────────────────────────────────────────────────────
    //  УТИЛИТЫ
    // ──────────────────────────────────────────────────────────

    private static ItemStack createGlassPane(String name) {
        ItemStack item = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            item.setItemMeta(meta);
        }
        return item;
    }

    private static ItemStack createInfoItem(Material mat, String name, java.util.List<String> lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    private static boolean isGuiItem(ItemStack item) {
        if (item == null) return false;
        return item.getType() == Material.GRAY_STAINED_GLASS_PANE ||
               item.getType() == Material.PAPER ||
               item.getType() == Material.BARRIER ||
               item.getType() == Material.EMERALD;
    }
}

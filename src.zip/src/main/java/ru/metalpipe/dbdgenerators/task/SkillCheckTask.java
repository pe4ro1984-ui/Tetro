package ru.metalpipe.dbdgenerators.task;

import org.bukkit.Sound;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.Generator;
import ru.metalpipe.dbdgenerators.util.MessageUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Задача skill-check.
 *
 * Механика:
 *  1. Показывает BossBar игроку с движущимся «индикатором».
 *  2. В случайном месте находится «зона успеха» (жёлтый сегмент) и «great-зона» (зелёный).
 *  3. Игрок должен нажать SNEAK когда BossBar заполнен до нужного значения.
 *  4. Результат: GREAT / SUCCESS / FAIL / TIMEOUT
 *
 * BossBar progress [0.0 ... 1.0] = позиция индикатора.
 * Зона успеха: [successStart ... successEnd]
 * Зона great: [greatStart ... greatEnd] (подмножество успешной зоны)
 */
public final class SkillCheckTask extends BukkitRunnable {

    /** Активные skill-check задачи: playerUUID → задача */
    private static final Map<UUID, SkillCheckTask> ACTIVE_CHECKS = new HashMap<>();

    private final DBDGeneratorsPlugin plugin;
    private final Player player;
    private final Generator generator;
    private final BossBar bossBar;

    /** Текущая позиция индикатора (0.0 - 1.0) */
    private double indicatorProgress = 0.0;

    /** Начало/конец зоны успеха */
    private final double successStart;
    private final double successEnd;

    /** Начало/конец great-зоны */
    private final double greatStart;
    private final double greatEnd;

    /** Скорость движения индикатора */
    private final double speed;

    /** Время истечения (тики) */
    private final int timeoutTicks;
    private int elapsed = 0;

    /** Состояние */
    private boolean resolved = false;

    public SkillCheckTask(DBDGeneratorsPlugin plugin, Player player, Generator generator) {
        this.plugin = plugin;
        this.player = player;
        this.generator = generator;

        double successSize = plugin.getConfig().getDouble(
            "generators.skill-check.success-zone-size", 0.15
        );
        double greatFraction = plugin.getConfig().getDouble(
            "generators.skill-check.great-zone-size", 0.3
        );
        this.speed = plugin.getConfig().getDouble(
            "generators.skill-check.indicator-speed", 0.4
        ) / 20.0 * 2; // /20 = сек, *2 = 2-тик интервал

        int timeoutSec = plugin.getConfig().getInt("generators.skill-check.timeout", 4);
        this.timeoutTicks = timeoutSec * 20 / 2; // /2 = 2-тик интервал

        // Случайное расположение зоны успеха
        double maxStart = 1.0 - successSize;
        this.successStart = Math.random() * maxStart;
        this.successEnd = successStart + successSize;

        double greatSize = successSize * greatFraction;
        double greatOffset = Math.random() * (successSize - greatSize);
        this.greatStart = successStart + greatOffset;
        this.greatEnd = greatStart + greatSize;

        // BossBar
        this.bossBar = plugin.getServer().createBossBar(
            buildTitle(), BarColor.YELLOW, BarStyle.SOLID
        );
        bossBar.addPlayer(player);
        bossBar.setProgress(0.0);

        ACTIVE_CHECKS.put(player.getUniqueId(), this);
    }

    @Override
    public void run() {
        if (resolved || !player.isOnline()) {
            finish();
            return;
        }

        elapsed++;
        if (elapsed >= timeoutTicks) {
            onTimeout();
            return;
        }

        // Двигаем индикатор
        indicatorProgress = Math.min(1.0, indicatorProgress + speed);

        // Обновляем BossBar
        bossBar.setProgress(indicatorProgress);
        bossBar.setTitle(buildTitle());

        // Ставим цвет в зависимости от позиции
        if (indicatorProgress >= greatStart && indicatorProgress <= greatEnd) {
            bossBar.setColor(BarColor.GREEN);
        } else if (indicatorProgress >= successStart && indicatorProgress <= successEnd) {
            bossBar.setColor(BarColor.YELLOW);
        } else {
            bossBar.setColor(BarColor.RED);
        }

        if (indicatorProgress >= 1.0) {
            onTimeout();
        }
    }

    /**
     * Вызывается когда игрок нажал SHIFT (из PlayerListener).
     */
    public void onPlayerAttempt() {
        if (resolved) return;
        resolved = true;

        if (indicatorProgress >= greatStart && indicatorProgress <= greatEnd) {
            // GREAT
            int bonus = plugin.getConfig().getInt("generators.skill-check.great-bonus", 3);
            generator.addProgress(bonus);
            plugin.getGeneratorManager().applyRepairProgress(generator, 0);

            player.sendMessage(MessageUtil.msg("skill-check.great")
                .replace("{bonus}", String.valueOf(bonus)));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);

        } else if (indicatorProgress >= successStart && indicatorProgress <= successEnd) {
            // SUCCESS
            player.sendMessage(MessageUtil.msg("skill-check.success"));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);

        } else {
            // FAIL
            onFail();
            return;
        }

        finish();
    }

    private void onFail() {
        if (resolved) return;
        resolved = true;

        int penalty = plugin.getConfig().getInt("generators.skill-check.fail-penalty", 15);
        generator.subtractProgress(penalty);
        plugin.getGeneratorManager().applyRepairProgress(generator, 0); // обновить визуал

        player.sendMessage(MessageUtil.msg("skill-check.fail")
            .replace("{penalty}", String.valueOf(penalty)));

        // Взрыв-эффект
        double soundRadius = plugin.getConfig().getDouble("generators.skillcheck-sound-radius", 32.0);
        generator.getLocation().getWorld().getNearbyEntities(
            generator.getLocation(), soundRadius, soundRadius, soundRadius
        ).stream()
            .filter(e -> e instanceof Player)
            .map(e -> (Player) e)
            .forEach(p -> p.playSound(generator.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.2f));

        finish();
    }

    private void onTimeout() {
        if (!resolved) {
            player.sendMessage(MessageUtil.msg("skill-check.timeout"));
            onFail();
        }
        finish();
    }

    private void finish() {
        cancel();
        bossBar.removeAll();
        ACTIVE_CHECKS.remove(player.getUniqueId());
    }

    private String buildTitle() {
        // Строим визуальный индикатор текстом
        int barWidth = 20;
        int indicatorPos = (int) (indicatorProgress * barWidth);
        int successStartPos = (int) (successStart * barWidth);
        int successEndPos = (int) (successEnd * barWidth);
        int greatStartPos = (int) (greatStart * barWidth);
        int greatEndPos = (int) (greatEnd * barWidth);

        StringBuilder sb = new StringBuilder("§f[");
        for (int i = 0; i < barWidth; i++) {
            if (i == indicatorPos) {
                sb.append("§c◆");
            } else if (i >= greatStartPos && i <= greatEndPos) {
                sb.append("§a█");
            } else if (i >= successStartPos && i <= successEndPos) {
                sb.append("§e█");
            } else {
                sb.append("§8░");
            }
        }
        sb.append("§f]");
        return sb.toString();
    }

    // ──────────────────────────────────────────────────────────
    //  СТАТИЧЕСКИЕ МЕТОДЫ
    // ──────────────────────────────────────────────────────────

    public static boolean hasActiveSkillCheck(UUID uuid) {
        return ACTIVE_CHECKS.containsKey(uuid);
    }

    public static SkillCheckTask getActiveSkillCheck(UUID uuid) {
        return ACTIVE_CHECKS.get(uuid);
    }

    public static void cancelAll() {
        new HashMap<>(ACTIVE_CHECKS).forEach((uuid, task) -> {
            task.resolved = true;
            task.finish();
        });
        ACTIVE_CHECKS.clear();
    }
}

package ru.metalpipe.dbdgenerators.task;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.Generator;
import ru.metalpipe.dbdgenerators.model.Match;
import ru.metalpipe.dbdgenerators.model.MatchPhase;
import ru.metalpipe.dbdgenerators.model.PlayerRole;
import ru.metalpipe.dbdgenerators.model.PlayerState;
import ru.metalpipe.dbdgenerators.util.ParticleUtil;

import java.util.UUID;

/**
 * Основная задача матча — тикается каждые generator-tick-interval тиков.
 *
 * Обрабатывает:
 *  - Прогресс ремонта генераторов
 *  - Регрессию генераторов
 *  - Случайные skill-check события
 *  - Прогресс поднятия (revive)
 *  - Таймер матча
 *  - Частицы vision-режима
 */
public final class MatchTask extends BukkitRunnable {

    private final DBDGeneratorsPlugin plugin;

    /** Количество тиков с начала матча */
    private long tickCount = 0;

    /** Интервал тика в тиках сервера */
    private final int tickInterval;

    public MatchTask(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
        this.tickInterval = plugin.getConfig().getInt("performance.generator-tick-interval", 4);
    }

    @Override
    public void run() {
        Match match = plugin.getMatchManager().getCurrentMatch();
        if (match == null || match.getPhase() != MatchPhase.IN_GAME) {
            return;
        }

        tickCount++;
        double deltaSeconds = tickInterval / 20.0;

        // ── 1. Тик генераторов ──
        tickGenerators(match, deltaSeconds);

        // ── 2. Тик поднятий ──
        tickRevives(match, deltaSeconds);

        // ── 3. Таймер матча ──
        tickMatchTimer(match);

        // ── 4. Vision частицы ──
        if (tickCount % (plugin.getConfig().getInt("performance.particle-update-interval", 10) / tickInterval + 1) == 0) {
            tickVisionParticles(match);
        }

        // ── 5. Scoreboard (раз в секунду) ──
        if (tickCount % (20 / tickInterval + 1) == 0) {
            plugin.getScoreboardManager().updateAll(match);
        }
    }

    // ──────────────────────────────────────────────────────────
    //  ГЕНЕРАТОРЫ
    // ──────────────────────────────────────────────────────────

    private void tickGenerators(Match match, double deltaSeconds) {
        double regressionSpeed = plugin.getConfig().getDouble("generators.regression-speed", 0.5);
        double regressionDelaySec = plugin.getConfig().getDouble("generators.regression-delay", 3.0);
        long currentTick = Bukkit.getCurrentTick();

        for (Generator gen : plugin.getGeneratorManager().getAllGenerators()) {
            if (gen.isCompleted() || gen.isSabotaged()) continue;

            int repairingCount = gen.getRepairingPlayers().size();

            if (repairingCount > 0) {
                // Ремонт
                double speed = plugin.getGeneratorManager().getEffectiveRepairSpeed(repairingCount);
                double progressDelta = speed * deltaSeconds;

                // Skill-check проверка
                boolean skillCheckActive = isSkillCheckActiveForAny(gen);
                if (!skillCheckActive) {
                    boolean completed = plugin.getGeneratorManager().applyRepairProgress(gen, progressDelta);
                    gen.setLastRepairTick(currentTick);

                    if (completed) {
                        plugin.getMatchManager().onGeneratorCompleted(gen.getId());
                        // Сигилы + статистика ремонтёрам
                        int sigils = plugin.getConfig().getInt("loot.sigil-reward-repair", 25);
                        for (UUID uuid : gen.getRepairingPlayers()) {
                            Player p = Bukkit.getPlayer(uuid);
                            if (p != null) {
                                plugin.getLootManager().giveSigils(p, sigils, "ремонт");
                                plugin.getStatisticsManager().incrementGeneratorsFixed(uuid);
                            }
                        }
                    }
                }

                // Случайный skill-check
                if (plugin.getConfig().getBoolean("generators.skill-check.enabled", true)) {
                    tryTriggerSkillCheck(gen);
                }

            } else {
                // Регрессия (никто не чинит)
                long ticksSinceRepair = currentTick - gen.getLastRepairTick();
                double secSinceRepair = ticksSinceRepair / 20.0;

                if (gen.getProgress() > 0 && secSinceRepair > regressionDelaySec) {
                    plugin.getGeneratorManager().applySabotage(gen, regressionSpeed * deltaSeconds);
                }
            }

            // Частицы ремонта
            if (repairingCount > 0 && plugin.getConfig().getBoolean("visual.show-repair-particles", true)) {
                ParticleUtil.spawnRepairParticles(gen.getLocation().add(0.5, 1.0, 0.5));
            }
        }
    }

    private boolean isSkillCheckActiveForAny(Generator gen) {
        for (UUID uuid : gen.getRepairingPlayers()) {
            if (plugin.getMatchManager().getCurrentMatch() != null) {
                // Проверяем активные skill-check задачи
                // (SkillCheckTask сам управляет паузой ремонта)
                return SkillCheckTask.hasActiveSkillCheck(uuid);
            }
        }
        return false;
    }

    private void tryTriggerSkillCheck(Generator gen) {
        double chancePerTick = plugin.getConfig().getDouble(
            "generators.skill-check.chance-per-tick", 0.02
        );

        if (Math.random() >= chancePerTick) return;

        for (UUID uuid : gen.getRepairingPlayers()) {
            if (SkillCheckTask.hasActiveSkillCheck(uuid)) continue;

            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;

            SkillCheckTask skillCheck = new SkillCheckTask(plugin, p, gen);
            skillCheck.runTaskTimer(plugin, 0L, 2L);
            break; // один skill-check за раз
        }
    }

    // ──────────────────────────────────────────────────────────
    //  ПОДНЯТИЕ (REVIVE)
    // ──────────────────────────────────────────────────────────

    private void tickRevives(Match match, double deltaSeconds) {
        int reviveTimeSec = plugin.getConfig().getInt("survivor-states.revive-time", 12);
        double deltaProgress = deltaSeconds / reviveTimeSec;

        for (UUID uuid : match.getParticipants()) {
            if (!plugin.getPlayerStateManager().isReviving(uuid)) continue;

            Player p = Bukkit.getPlayer(uuid);
            if (p == null) {
                plugin.getPlayerStateManager().cancelRevive(uuid);
                continue;
            }

            UUID target = plugin.getPlayerStateManager().getReviveTarget(uuid);
            Player targetPlayer = Bukkit.getPlayer(target);

            // Проверяем близость
            if (targetPlayer == null ||
                p.getLocation().distanceSquared(targetPlayer.getLocation()) > 9.0) {
                plugin.getPlayerStateManager().cancelRevive(uuid);
                p.sendMessage("§cВы отошли слишком далеко! Поднятие прервано.");
                continue;
            }

            boolean done = plugin.getPlayerStateManager().tickRevive(uuid, deltaProgress);
            if (done) {
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.5f);
            }
        }
    }

    // ──────────────────────────────────────────────────────────
    //  ТАЙМЕР МАТЧА
    // ──────────────────────────────────────────────────────────

    private void tickMatchTimer(Match match) {
        long matchDuration = plugin.getConfig().getLong("match.match-duration", 600);
        long elapsed = match.getPhaseElapsedSeconds();

        if (elapsed >= matchDuration) {
            plugin.getMatchManager().startCollapse();
        }

        // Предупреждения о времени
        long remaining = matchDuration - elapsed;
        if (remaining == 300 || remaining == 120 || remaining == 60 || remaining == 30) {
            String timeMsg = "§e⏰ До конца матча: §c" + remaining + " §eсек.";
            plugin.getMatchManager().broadcastToMatch("", msg -> timeMsg);
        }
    }

    // ──────────────────────────────────────────────────────────
    //  VISION ЧАСТИЦЫ
    // ──────────────────────────────────────────────────────────

    private void tickVisionParticles(Match match) {
        for (UUID visionUuid : match.getParticipants()) {
            if (!plugin.getMatchManager().hasVision(visionUuid)) continue;

            Player observer = Bukkit.getPlayer(visionUuid);
            if (observer == null) continue;

            // Для каждого участника показываем частицу их состояния
            for (UUID targetUuid : match.getParticipants()) {
                if (targetUuid.equals(visionUuid)) continue;

                Player target = Bukkit.getPlayer(targetUuid);
                if (target == null) continue;

                PlayerState state;
                PlayerRole role = match.getRoleOf(targetUuid);
                if (role == PlayerRole.HUNTER) {
                    state = null; // Охотник — красные частицы
                } else {
                    state = plugin.getPlayerStateManager().getState(targetUuid);
                }

                ParticleUtil.spawnVisionParticle(observer, target.getLocation().add(0, 2, 0), role, state);
            }
        }
    }
}

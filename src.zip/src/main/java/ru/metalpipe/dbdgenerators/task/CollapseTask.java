package ru.metalpipe.dbdgenerators.task;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.Match;
import ru.metalpipe.dbdgenerators.model.MatchPhase;

import java.util.UUID;

/**
 * Задача фазы «Коллапс» (ENDGAME_COLLAPSE).
 *
 * Нагнетает атмосферу ужаса:
 *  - Тикает таймер обратного отсчёта.
 *  - Добавляет звуки и вибрации.
 *  - По истечении → FINISHED (таймаут).
 */
public final class CollapseTask extends BukkitRunnable {

    private final DBDGeneratorsPlugin plugin;
    private int remainingSeconds;

    public CollapseTask(DBDGeneratorsPlugin plugin, int durationSeconds) {
        this.plugin = plugin;
        this.remainingSeconds = durationSeconds;
    }

    @Override
    public void run() {
        Match match = plugin.getMatchManager().getCurrentMatch();
        if (match == null || match.getPhase() != MatchPhase.ENDGAME_COLLAPSE) {
            cancel();
            return;
        }

        if (remainingSeconds <= 0) {
            // Таймаут — ничья / победа охотника
            plugin.getMatchManager().onHunterWin();
            cancel();
            return;
        }

        // Обратный отсчёт
        if (remainingSeconds % 30 == 0 || remainingSeconds <= 10) {
            for (UUID uuid : match.getParticipants()) {
                Player p = Bukkit.getPlayer(uuid);
                if (p == null) continue;

                p.sendMessage("§4§l☠ КОЛЛАПС: §c" + remainingSeconds + " §4секунд до конца!");
                p.sendTitle("§4⚠", "§cВремя выходит!", 0, 25, 5);
            }
        }

        // Звук нарастающего ужаса
        for (UUID uuid : match.getParticipants()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;

            if (remainingSeconds > 30) {
                // Далёкие тревожные звуки
                if (remainingSeconds % 10 == 0) {
                    p.playSound(p.getLocation(), Sound.AMBIENT_CAVE, 0.3f, 0.5f);
                }
            } else if (remainingSeconds > 10) {
                // Частые тревожные звуки
                if (remainingSeconds % 5 == 0) {
                    p.playSound(p.getLocation(), Sound.BLOCK_PORTAL_AMBIENT, 0.5f, 0.8f);
                }
            } else {
                // Критический момент — каждую секунду
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.5f);

                // Молния-эффект в случайном месте
                if (remainingSeconds % 3 == 0) {
                    p.getWorld().strikeLightningEffect(
                        p.getLocation().add(
                            (Math.random() - 0.5) * 20,
                            0,
                            (Math.random() - 0.5) * 20
                        )
                    );
                }
            }
        }

        remainingSeconds--;
    }
}

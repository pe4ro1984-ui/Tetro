package ru.metalpipe.dbdgenerators.config;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

/**
 * Менеджер конфигурационных файлов.
 * Управляет: config.yml, messages.yml, generators.yml, lootchests.yml
 *
 * Паттерн аналогичен MythicMobs ConfigManager —
 * каждый файл имеет свой FileConfiguration + методы reload/save.
 */
public final class ConfigManager {

    private final DBDGeneratorsPlugin plugin;

    // ── Файлы конфигурации ──
    private FileConfiguration messagesConfig;
    private FileConfiguration generatorsConfig;
    private FileConfiguration lootChestsConfig;

    private File messagesFile;
    private File generatorsFile;
    private File lootChestsFile;

    public ConfigManager(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Загружает все конфигурационные файлы.
     * При отсутствии — создаёт из ресурсов плагина.
     */
    public void loadAll() {
        // config.yml (встроенный в JavaPlugin)
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        validateMainConfig();

        // messages.yml
        messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        messagesConfig = YamlConfiguration.loadConfiguration(messagesFile);
        mergeDefaults(messagesFile, "messages.yml", messagesConfig);

        // generators.yml
        generatorsFile = new File(plugin.getDataFolder(), "generators.yml");
        if (!generatorsFile.exists()) {
            plugin.saveResource("generators.yml", false);
        }
        generatorsConfig = YamlConfiguration.loadConfiguration(generatorsFile);

        // lootchests.yml
        lootChestsFile = new File(plugin.getDataFolder(), "lootchests.yml");
        if (!lootChestsFile.exists()) {
            plugin.saveResource("lootchests.yml", false);
        }
        lootChestsConfig = YamlConfiguration.loadConfiguration(lootChestsFile);

        plugin.getLogger().info("Все конфигурационные файлы загружены.");
    }

    /**
     * Перезагрузка всех конфигов (команда /dbd reload).
     */
    public void reloadAll() {
        plugin.reloadConfig();
        messagesConfig = YamlConfiguration.loadConfiguration(messagesFile);
        generatorsConfig = YamlConfiguration.loadConfiguration(generatorsFile);
        lootChestsConfig = YamlConfiguration.loadConfiguration(lootChestsFile);
    }

    /**
     * Сохранение generators.yml.
     */
    public void saveGeneratorsConfig() {
        try {
            generatorsConfig.save(generatorsFile);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Ошибка сохранения generators.yml", ex);
        }
    }

    /**
     * Сохранение lootchests.yml.
     */
    public void saveLootChestsConfig() {
        try {
            lootChestsConfig.save(lootChestsFile);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Ошибка сохранения lootchests.yml", ex);
        }
    }

    /**
     * Merges keys from the resource default into existing file
     * (добавляет новые ключи без удаления существующих).
     */
    private void mergeDefaults(File file, String resource, FileConfiguration config) {
        YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
            new java.io.InputStreamReader(
                plugin.getResource(resource),
                java.nio.charset.StandardCharsets.UTF_8
            )
        );
        config.setDefaults(defaults);
        config.options().copyDefaults(true);
        try {
            config.save(file);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.WARNING, "Не удалось обновить " + resource, ex);
        }
    }

    /**
     * Проверяет основные параметры config.yml при старте.
     * Выводит предупреждения при некорректных значениях.
     */
    private void validateMainConfig() {
        FileConfiguration cfg = plugin.getConfig();

        validateRange(cfg, "match.min-players", 2, 16, 2);
        validateRange(cfg, "match.max-players", 2, 16, 5);
        validateRange(cfg, "match.lobby-countdown", 10, 120, 30);
        validateRange(cfg, "match.match-duration", 120, 1800, 600);
        validateRange(cfg, "match.generators-required", 1, 10, 5);
        validateRange(cfg, "generators.repair-speed", 0.1, 10.0, 1.0);
        validateRange(cfg, "generators.sabotage-speed", 0.5, 20.0, 5.0);
        validateRange(cfg, "generators.skill-check.success-zone-size", 0.05, 0.4, 0.15);
        validateRange(cfg, "performance.generator-tick-interval", 2, 40, 4);
    }

    private void validateRange(FileConfiguration cfg, String path, double min, double max, double def) {
        double val = cfg.getDouble(path, def);
        if (val < min || val > max) {
            plugin.getLogger().warning(
                "Конфиг: " + path + " = " + val + " вне диапазона [" + min + ", " + max +
                "]. Используется: " + def
            );
            cfg.set(path, def);
        }
    }

    // ──────────────────────────────────────────────────────────
    //  ГЕТТЕРЫ
    // ──────────────────────────────────────────────────────────

    public FileConfiguration getMessagesConfig() {
        return messagesConfig;
    }

    public FileConfiguration getGeneratorsConfig() {
        return generatorsConfig;
    }

    public FileConfiguration getLootChestsConfig() {
        return lootChestsConfig;
    }
}

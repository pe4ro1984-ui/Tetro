package ru.metalpipe.dbdgenerators;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import ru.metalpipe.dbdgenerators.commands.DBDCommand;
import ru.metalpipe.dbdgenerators.config.ConfigManager;
import ru.metalpipe.dbdgenerators.listeners.GeneratorListener;
import ru.metalpipe.dbdgenerators.listeners.LootChestListener;
import ru.metalpipe.dbdgenerators.listeners.PlayerListener;
import ru.metalpipe.dbdgenerators.managers.GeneratorManager;
import ru.metalpipe.dbdgenerators.managers.ItemManager;
import ru.metalpipe.dbdgenerators.managers.LootManager;
import ru.metalpipe.dbdgenerators.managers.MatchManager;
import ru.metalpipe.dbdgenerators.managers.PlayerStateManager;
import ru.metalpipe.dbdgenerators.managers.ScoreboardManager;
import ru.metalpipe.dbdgenerators.managers.StatisticsManager;
import ru.metalpipe.dbdgenerators.util.MessageUtil;
import ru.metalpipe.dbdgenerators.visual.VisualProviderRegistry;

import java.util.logging.Level;

/**
 * Главный класс плагина DBDGenerators.
 * Инициализирует все менеджеры, регистрирует команды и слушатели.
 *
 * Архитектура вдохновлена Marcely's BedWars и MythicMobs.
 */
public final class DBDGeneratorsPlugin extends JavaPlugin {

    /** Singleton-инстанс плагина */
    private static DBDGeneratorsPlugin instance;

    // ──── Менеджеры ────
    private ConfigManager configManager;
    private VisualProviderRegistry visualProviderRegistry;
    private GeneratorManager generatorManager;
    private PlayerStateManager playerStateManager;
    private LootManager lootManager;
    private MatchManager matchManager;
    private ScoreboardManager scoreboardManager;
    private StatisticsManager statisticsManager;
    private ItemManager itemManager;

    @Override
    public void onEnable() {
        instance = this;

        // ── 1. ASCII-баннер ──
        printBanner();

        // ── 2. Конфигурация ──
        try {
            configManager = new ConfigManager(this);
            configManager.loadAll();
        } catch (Exception ex) {
            getLogger().log(Level.SEVERE, "Ошибка загрузки конфигурации! Плагин отключается.", ex);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // ── 3. MessageUtil ──
        MessageUtil.init(configManager.getMessagesConfig());

        // ── 4. Визуальные провайдеры ──
        visualProviderRegistry = new VisualProviderRegistry(this);
        visualProviderRegistry.registerAll();

        String providerName = getConfig().getString("visual.provider", "NATIVE_MOB");
        boolean providerSet = visualProviderRegistry.setActiveProvider(providerName);
        if (!providerSet) {
            getLogger().warning("Провайдер '" + providerName + "' недоступен, используется NATIVE_MOB.");
            visualProviderRegistry.setActiveProvider("NATIVE_MOB");
        }

        // ── 5. Менеджеры ──
        generatorManager = new GeneratorManager(this);
        generatorManager.loadGenerators();

        playerStateManager = new PlayerStateManager(this);

        lootManager = new LootManager(this);
        lootManager.loadLootTables();

        matchManager = new MatchManager(this);

        // ── Бонус-менеджеры ──
        scoreboardManager = new ScoreboardManager(this);

        statisticsManager = new StatisticsManager(this);
        statisticsManager.load();

        itemManager = new ItemManager(this);

        // ── 6. Команды ──
        DBDCommand dbdCommand = new DBDCommand(this);
        getCommand("dbd").setExecutor(dbdCommand);
        getCommand("dbd").setTabCompleter(dbdCommand);

        // ── 7. Слушатели событий ──
        registerListeners();

        // ── 8. Успешный старт ──
        getLogger().info("DBDGenerators v" + getDescription().getVersion() + " успешно запущен!");
        getLogger().info("Провайдер: " + visualProviderRegistry.getActiveProvider().getId());
        getLogger().info("Генераторов загружено: " + generatorManager.getRegisteredGeneratorsCount());
    }

    @Override
    public void onDisable() {
        // Остановить активный матч
        if (matchManager != null && matchManager.isMatchRunning()) {
            matchManager.stopMatch(null, "Сервер отключается");
        }

        // Сохранить все данные
        if (generatorManager != null) {
            generatorManager.saveGenerators();
        }
        if (lootManager != null) {
            lootManager.saveLootTables();
        }

        if (statisticsManager != null) {
            statisticsManager.save();
        }

        // Удалить визуальные объекты
        if (visualProviderRegistry != null && visualProviderRegistry.getActiveProvider() != null) {
            if (generatorManager != null) {
                generatorManager.getAllGenerators().forEach(gen ->
                    visualProviderRegistry.getActiveProvider().removeGenerator(gen)
                );
            }
        }

        getLogger().info("DBDGenerators отключён. До свидания.");
        instance = null;
    }

    // ──────────────────────────────────────────────────────────
    //  ПРИВАТНЫЕ МЕТОДЫ
    // ──────────────────────────────────────────────────────────

    private void registerListeners() {
        Bukkit.getPluginManager().registerEvents(
            new GeneratorListener(this), this
        );
        Bukkit.getPluginManager().registerEvents(
            new PlayerListener(this), this
        );
        Bukkit.getPluginManager().registerEvents(
            new LootChestListener(this), this
        );
    }

    private void printBanner() {
        String[] banner = {
            "",
            "  &4╔══════════════════════════════════════╗",
            "  &4║  &c&lDBDGenerators &4| &fВзаперти &4║",
            "  &4║  &7Dead by Daylight Mini-Game          &4║",
            "  &4║  &8v" + getDescription().getVersion() + " &8| Spigot 1.16-1.20      &4║",
            "  &4╚══════════════════════════════════════╝",
            ""
        };
        for (String line : banner) {
            Bukkit.getConsoleSender().sendMessage(
                org.bukkit.ChatColor.translateAlternateColorCodes('&', line)
            );
        }
    }

    // ──────────────────────────────────────────────────────────
    //  ГЕТТЕРЫ
    // ──────────────────────────────────────────────────────────

    public static DBDGeneratorsPlugin getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public VisualProviderRegistry getVisualProviderRegistry() {
        return visualProviderRegistry;
    }

    public GeneratorManager getGeneratorManager() {
        return generatorManager;
    }

    public PlayerStateManager getPlayerStateManager() {
        return playerStateManager;
    }

    public LootManager getLootManager() {
        return lootManager;
    }

    public MatchManager getMatchManager() {
        return matchManager;
    }

    public ScoreboardManager getScoreboardManager() {
        return scoreboardManager;
    }

    public StatisticsManager getStatisticsManager() {
        return statisticsManager;
    }

    public ItemManager getItemManager() {
        return itemManager;
    }
}

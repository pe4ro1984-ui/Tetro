package ru.metalpipe.dbdgenerators.listeners;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.gui.LootEditorGUI;
import ru.metalpipe.dbdgenerators.model.Match;
import ru.metalpipe.dbdgenerators.model.MatchPhase;
import ru.metalpipe.dbdgenerators.util.MessageUtil;

import java.util.List;

/**
 * Слушатель лут-ящиков.
 *
 * Обрабатывает:
 *  - ПКМ по сундуку в активном матче → выдать лут
 *  - Закрытие GUI редактора
 */
public final class LootChestListener implements Listener {

    private final DBDGeneratorsPlugin plugin;

    public LootChestListener(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;

        Player player = event.getPlayer();
        Block block = event.getClickedBlock();

        // Проверяем тип блока
        Material chestMat = Material.matchMaterial(
            plugin.getConfig().getString("loot.chest-material", "CHEST")
        );
        if (chestMat == null || block.getType() != chestMat) return;

        // Только во время матча
        Match match = plugin.getMatchManager().getCurrentMatch();
        if (match == null || match.getPhase() != MatchPhase.IN_GAME) return;
        if (!match.isParticipant(player.getUniqueId())) return;

        if (!plugin.getConfig().getBoolean("loot.enabled", true)) return;

        // Проверяем кулдаун
        if (plugin.getLootManager().isChestOnCooldown(block.getLocation())) {
            long remaining = plugin.getLootManager().getRemainingCooldown(block.getLocation());
            player.sendMessage(MessageUtil.msg("loot.chest-cooldown")
                .replace("{time}", String.valueOf(remaining)));
            event.setCancelled(true);
            return;
        }

        // Берём лут из первой доступной таблицы (или можно хранить в PersistentDataContainer)
        String tableName = getTableForChest(block);
        if (tableName == null) {
            player.sendMessage(MessageUtil.msg("loot.chest-empty"));
            event.setCancelled(true);
            return;
        }

        List<ItemStack> loot = plugin.getLootManager().generateLoot(tableName);
        if (loot.isEmpty()) {
            player.sendMessage(MessageUtil.msg("loot.chest-empty"));
        } else {
            player.sendMessage(MessageUtil.msg("loot.chest-opened"));
            loot.forEach(item -> {
                java.util.HashMap<Integer, ItemStack> leftover = player.getInventory().addItem(item);
                leftover.values().forEach(leftItem ->
                    player.getWorld().dropItemNaturally(player.getLocation(), leftItem)
                );
            });
        }

        plugin.getLootManager().setChestCooldown(block.getLocation());
        event.setCancelled(true);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player)) return;
        Player player = (Player) event.getPlayer();

        String editingTable = plugin.getLootManager().getEditingTable(player.getUniqueId());
        if (editingTable == null) return;

        // Сохранить изменения из GUI
        LootEditorGUI.saveFromInventory(plugin, player, editingTable, event.getInventory());
        plugin.getLootManager().endEditSession(player.getUniqueId());
    }

    private String getTableForChest(Block block) {
        // Простая логика: берём первую доступную таблицу
        // В продакшен-версии здесь должен быть PersistentDataContainer
        // для хранения имени таблицы в блоке
        if (plugin.getLootManager().getAllLootTables().isEmpty()) return null;
        return plugin.getLootManager().getAllLootTables().iterator().next().getName();
    }
}

package ru.metalpipe.dbdgenerators.listeners;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.Generator;
import ru.metalpipe.dbdgenerators.model.Match;
import ru.metalpipe.dbdgenerators.model.MatchPhase;
import ru.metalpipe.dbdgenerators.model.PlayerRole;
import ru.metalpipe.dbdgenerators.model.PlayerState;
import ru.metalpipe.dbdgenerators.task.SkillCheckTask;
import ru.metalpipe.dbdgenerators.util.MessageUtil;

/**
 * Слушатель событий взаимодействия с генераторами.
 *
 * Обрабатывает:
 *  - ПКМ по блоку/сущности вблизи генератора → начать ремонт
 *  - SHIFT → попытка skill-check
 *  - Прекращение ремонта при отходе
 */
public final class GeneratorListener implements Listener {

    private final DBDGeneratorsPlugin plugin;

    public GeneratorListener(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Игрок правым кликом — начать/прекратить ремонт генератора.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK &&
            event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_AIR) {
            return;
        }

        Player player = event.getPlayer();
        Match match = plugin.getMatchManager().getCurrentMatch();

        if (match == null || match.getPhase() != MatchPhase.IN_GAME) return;
        if (!match.isParticipant(player.getUniqueId())) return;

        PlayerRole role = match.getRoleOf(player.getUniqueId());
        if (role == null || role == PlayerRole.SPECTATOR) return;

        Generator gen = plugin.getGeneratorManager().getNearestInteractable(player.getLocation());
        if (gen == null) return;

        PlayerState state = plugin.getPlayerStateManager().getState(player.getUniqueId());
        if (state == PlayerState.DOWNED || state == PlayerState.HOOKED || state == PlayerState.DEAD) {
            return;
        }

        if (role == PlayerRole.SURVIVOR) {
            handleSurvivorInteract(player, gen);
        } else if (role == PlayerRole.HUNTER) {
            handleHunterInteract(player, gen);
        }

        event.setCancelled(true);
    }

    /**
     * Нажатие SHIFT → попытка skill-check.
     */
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onPlayerSneak(PlayerToggleSneakEvent event) {
        if (!event.isSneaking()) return; // только нажатие вниз

        Player player = event.getPlayer();
        SkillCheckTask skillCheck = SkillCheckTask.getActiveSkillCheck(player.getUniqueId());
        if (skillCheck != null) {
            skillCheck.onPlayerAttempt();
        }
    }

    // ──────────────────────────────────────────────────────────
    //  ПРИВАТНЫЕ МЕТОДЫ
    // ──────────────────────────────────────────────────────────

    private void handleSurvivorInteract(Player player, Generator gen) {
        if (gen.isRepairedBy(player.getUniqueId())) {
            // Уже чинит — прекратить
            gen.removeRepairingPlayer(player.getUniqueId());
            player.sendMessage(MessageUtil.msg("generators.repair-interrupted"));
            return;
        }

        if (!player.hasPermission("dbdgenerators.repair")) {
            player.sendMessage(MessageUtil.msg("general.no-permission"));
            return;
        }

        gen.addRepairingPlayer(player.getUniqueId());
        player.sendMessage(MessageUtil.msg("generators.repair-start")
            .replace("{gen_id}", gen.getId()));
        player.sendMessage(gen.getProgressBar());
    }

    private void handleHunterInteract(Player player, Generator gen) {
        if (gen.isCompleted()) {
            player.sendMessage(MessageUtil.msg("generators.already-completed"));
            return;
        }

        // Мгновенный саботаж одним кликом (охотник)
        double sabotageSpeed = plugin.getConfig().getDouble("generators.sabotage-speed", 5.0);

        // Прервать всех ремонтников
        for (java.util.UUID uuid : gen.getRepairingPlayers()) {
            Player repairer = plugin.getServer().getPlayer(uuid);
            if (repairer != null) {
                repairer.sendMessage(MessageUtil.msg("generators.repair-interrupted"));
                repairer.sendMessage("§c" + player.getName() + " §4вмешался в ремонт!");
            }
        }

        boolean sabotaged = plugin.getGeneratorManager().applySabotage(gen, sabotageSpeed * 5);

        if (sabotaged) {
            // Уведомление всем
            plugin.getMatchManager().broadcastToMatch("generators.sabotage-complete-global", m -> m);

            // Сигилы охотнику + статистика
            int sigils = plugin.getConfig().getInt("loot.sigil-reward-sabotage", 30);
            plugin.getLootManager().giveSigils(player, sigils, "саботаж");
            plugin.getStatisticsManager().incrementGeneratorsSabotaged(player.getUniqueId());
        } else {
            player.sendMessage(MessageUtil.msg("generators.sabotage-start")
                .replace("{gen_id}", gen.getId()));
        }
    }
}

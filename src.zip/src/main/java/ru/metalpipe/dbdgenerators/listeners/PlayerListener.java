package ru.metalpipe.dbdgenerators.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.Generator;
import ru.metalpipe.dbdgenerators.model.Match;
import ru.metalpipe.dbdgenerators.model.MatchPhase;
import ru.metalpipe.dbdgenerators.model.PlayerRole;
import ru.metalpipe.dbdgenerators.model.PlayerState;
import ru.metalpipe.dbdgenerators.task.SkillCheckTask;

/**
 * Слушатель событий игроков.
 *
 * Обрабатывает:
 *  - Нанесение урона (охотник бьёт выжившего)
 *  - Смерть игрока
 *  - Движение (прекращение ремонта при отходе)
 *  - Выход из игры
 */
public final class PlayerListener implements Listener {

    private final DBDGeneratorsPlugin plugin;

    public PlayerListener(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Охотник атакует выжившего — меняем состояние.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;

        Player attacker = (Player) event.getDamager();
        Player victim = (Player) event.getEntity();

        Match match = plugin.getMatchManager().getCurrentMatch();
        if (match == null || match.getPhase() != MatchPhase.IN_GAME) return;
        if (!match.isParticipant(attacker.getUniqueId())) return;
        if (!match.isParticipant(victim.getUniqueId())) return;

        PlayerRole attackerRole = match.getRoleOf(attacker.getUniqueId());
        PlayerRole victimRole = match.getRoleOf(victim.getUniqueId());

        if (attackerRole != PlayerRole.HUNTER || victimRole != PlayerRole.SURVIVOR) {
            event.setCancelled(true);
            return;
        }

        // Отменяем ванильный урон, используем нашу систему
        event.setCancelled(true);

        PlayerState victimState = plugin.getPlayerStateManager().getState(victim.getUniqueId());
        if (victimState == PlayerState.DOWNED || victimState == PlayerState.HOOKED ||
            victimState == PlayerState.DEAD) {
            return;
        }

        // Прервать ремонт жертвы
        stopRepairingForPlayer(victim);

        plugin.getPlayerStateManager().hitSurvivor(victim.getUniqueId());

        // Сигилы охотнику за хук
        PlayerState newState = plugin.getPlayerStateManager().getState(victim.getUniqueId());
        if (newState == PlayerState.DOWNED) {
            // Предложить охотнику повесить
            attacker.sendMessage("§cВыживший повален! ПКМ по нему, чтобы повесить на крюк.");
        }
    }

    /**
     * Смерть игрока (ванильная) — отменяем, обрабатываем своей системой.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Match match = plugin.getMatchManager().getCurrentMatch();
        if (match == null) return;
        if (!match.isParticipant(event.getEntity().getUniqueId())) return;

        event.setDeathMessage(null);
        event.getDrops().clear();
        event.setDroppedExp(0);
        // Respawn is handled by the game naturally after death event
    }

    /**
     * Выход из игры — убрать из матча.
     */
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();

        // Прервать skill-check
        SkillCheckTask skillCheck = SkillCheckTask.getActiveSkillCheck(player.getUniqueId());
        if (skillCheck != null) {
            skillCheck.onPlayerAttempt(); // провал
        }

        // Убрать из ремонта
        stopRepairingForPlayer(player);

        // Убрать из матча
        Match match = plugin.getMatchManager().getCurrentMatch();
        if (match != null && match.isParticipant(player.getUniqueId())) {
            plugin.getPlayerStateManager().clearPlayer(player.getUniqueId());

            // Если охотник ушёл — победа выживших
            if (match.getRoleOf(player.getUniqueId()) == PlayerRole.HUNTER) {
                plugin.getMatchManager().onSurvivorsEscape();
            } else {
                plugin.getMatchManager().onSurvivorDied(player.getUniqueId());
            }
        }
    }

    /**
     * Движение — проверяем удалённость от генератора при ремонте.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        // Оптимизация: проверяем только если изменился блок
        if (event.getFrom().getBlockX() == event.getTo().getBlockX() &&
            event.getFrom().getBlockY() == event.getTo().getBlockY() &&
            event.getFrom().getBlockZ() == event.getTo().getBlockZ()) {
            return;
        }

        Player player = event.getPlayer();
        Match match = plugin.getMatchManager().getCurrentMatch();
        if (match == null || !match.isParticipant(player.getUniqueId())) return;

        double radius = plugin.getConfig().getDouble("generators.interaction-radius", 2.5);
        double radiusSq = (radius + 0.5) * (radius + 0.5);

        // Проверить все генераторы, где игрок ремонтирует
        for (Generator gen : plugin.getGeneratorManager().getAllGenerators()) {
            if (!gen.isRepairedBy(player.getUniqueId())) continue;
            if (gen.getLocation().distanceSquared(player.getLocation()) > radiusSq) {
                gen.removeRepairingPlayer(player.getUniqueId());
                player.sendMessage("§7Вы отошли от генератора. Ремонт прерван.");
            }
        }
    }

    // ──────────────────────────────────────────────────────────

    private void stopRepairingForPlayer(Player player) {
        for (Generator gen : plugin.getGeneratorManager().getAllGenerators()) {
            gen.removeRepairingPlayer(player.getUniqueId());
        }
    }
}

package ru.metalpipe.dbdgenerators.managers;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.Generator;
import ru.metalpipe.dbdgenerators.visual.VisualProvider;

import java.util.*;

/**
 * Менеджер генераторов.
 *
 * Управляет:
 *  - Хранением и загрузкой генераторов из generators.yml
 *  - Логикой ремонта, регрессии и саботажа
 *  - Триггером skill-check
 *  - Обновлением визуала
 */
public final class GeneratorManager {

    private final DBDGeneratorsPlugin plugin;

    /** Все зарегистрированные генераторы (id → Generator) */
    private final Map<String, Generator> generators = new LinkedHashMap<>();

    /** Счётчик ID для автогенерации */
    private int idCounter = 1;

    public GeneratorManager(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    // ──────────────────────────────────────────────────────────
    //  ЗАГРУЗКА / СОХРАНЕНИЕ
    // ──────────────────────────────────────────────────────────

    /**
     * Загружает генераторы из generators.yml.
     */
    public void loadGenerators() {
        generators.clear();
        FileConfiguration cfg = plugin.getConfigManager().getGeneratorsConfig();
        ConfigurationSection section = cfg.getConfigurationSection("generators");

        if (section == null) {
            plugin.getLogger().info("generators.yml: генераторов не найдено.");
            return;
        }

        for (String key : section.getKeys(false)) {
            String worldName = section.getString(key + ".world");
            double x = section.getDouble(key + ".x");
            double y = section.getDouble(key + ".y");
            double z = section.getDouble(key + ".z");

            World world = plugin.getServer().getWorld(worldName);
            if (world == null) {
                plugin.getLogger().warning("Генератор " + key + ": мир '" + worldName + "' не найден, пропускаю.");
                continue;
            }

            Generator gen = new Generator(key, new Location(world, x, y, z));
            generators.put(key, gen);

            // Извлечь номер из ID для счётчика
            try {
                int num = Integer.parseInt(key.replace("gen_", ""));
                if (num >= idCounter) idCounter = num + 1;
            } catch (NumberFormatException ignored) {}
        }

        plugin.getLogger().info("Генераторов загружено: " + generators.size());
    }

    /**
     * Сохраняет генераторы в generators.yml.
     */
    public void saveGenerators() {
        FileConfiguration cfg = plugin.getConfigManager().getGeneratorsConfig();

        // Очищаем старую секцию
        cfg.set("generators", null);

        for (Generator gen : generators.values()) {
            String path = "generators." + gen.getId();
            cfg.set(path + ".world", gen.getLocation().getWorld().getName());
            cfg.set(path + ".x", gen.getLocation().getX());
            cfg.set(path + ".y", gen.getLocation().getY());
            cfg.set(path + ".z", gen.getLocation().getZ());
            cfg.set(path + ".id", gen.getId());
        }

        plugin.getConfigManager().saveGeneratorsConfig();
    }

    // ──────────────────────────────────────────────────────────
    //  CRUD ГЕНЕРАТОРОВ
    // ──────────────────────────────────────────────────────────

    /**
     * Добавить новый генератор в указанной позиции.
     *
     * @param location Местоположение генератора.
     * @return Созданный генератор.
     */
    public Generator addGenerator(Location location) {
        String id = "gen_" + idCounter++;
        Generator gen = new Generator(id, location);
        generators.put(id, gen);

        // Спавнить визуал если матч активен
        VisualProvider provider = plugin.getVisualProviderRegistry().getActiveProvider();
        if (provider != null) {
            provider.spawnGenerator(gen);
        }

        saveGenerators();
        return gen;
    }

    /**
     * Удалить генератор по ID.
     *
     * @param id ID генератора.
     * @return true если успешно удалён.
     */
    public boolean removeGenerator(String id) {
        Generator gen = generators.remove(id);
        if (gen == null) return false;

        VisualProvider provider = plugin.getVisualProviderRegistry().getActiveProvider();
        if (provider != null) {
            provider.removeGenerator(gen);
        }

        saveGenerators();
        return true;
    }

    /**
     * Получить генератор по ID.
     */
    public Generator getGenerator(String id) {
        return generators.get(id);
    }

    /**
     * Получить все зарегистрированные генераторы.
     */
    public Collection<Generator> getAllGenerators() {
        return generators.values();
    }

    public int getRegisteredGeneratorsCount() {
        return generators.size();
    }

    // ──────────────────────────────────────────────────────────
    //  ПОИСК БЛИЖАЙШЕГО ГЕНЕРАТОРА
    // ──────────────────────────────────────────────────────────

    /**
     * Найти ближайший некомплектный генератор в радиусе interaction-radius.
     *
     * @param location Позиция игрока.
     * @return Generator или null.
     */
    public Generator getNearestInteractable(Location location) {
        double radius = plugin.getConfig().getDouble("generators.interaction-radius", 2.5);
        double radiusSq = radius * radius;

        Generator nearest = null;
        double nearestDist = Double.MAX_VALUE;

        for (Generator gen : generators.values()) {
            if (gen.getLocation().getWorld() == null) continue;
            if (!gen.getLocation().getWorld().equals(location.getWorld())) continue;
            if (gen.isCompleted()) continue;

            double dist = gen.getLocation().add(0.5, 0, 0.5).distanceSquared(location);
            if (dist <= radiusSq && dist < nearestDist) {
                nearestDist = dist;
                nearest = gen;
            }
        }
        return nearest;
    }

    // ──────────────────────────────────────────────────────────
    //  ИГРОВАЯ ЛОГИКА ГЕНЕРАТОРОВ
    // ──────────────────────────────────────────────────────────

    /**
     * Добавить прогресс к генератору.
     * Обновляет визуал и проверяет завершение.
     *
     * @param gen    Генератор.
     * @param amount Прогресс (%).
     * @return true если генератор только что починен.
     */
    public boolean applyRepairProgress(Generator gen, double amount) {
        boolean completed = gen.addProgress(amount);
        updateVisual(gen);
        return completed;
    }

    /**
     * Применить саботаж к генератору.
     *
     * @param gen    Генератор.
     * @param amount Урон по прогрессу (%).
     * @return true если генератор полностью саботирован (progress → 0).
     */
    public boolean applySabotage(Generator gen, double amount) {
        if (gen.isCompleted()) return false;
        gen.subtractProgress(amount);
        if (gen.getProgress() <= 0) {
            gen.setSabotaged(true);
            updateVisual(gen);
            return true;
        }
        updateVisual(gen);
        return false;
    }

    /**
     * Сбросить все генераторы для нового матча.
     * Спавнит визуал.
     */
    public void resetForMatch() {
        VisualProvider provider = plugin.getVisualProviderRegistry().getActiveProvider();
        for (Generator gen : generators.values()) {
            // Удалить старый визуал
            if (provider != null) provider.removeGenerator(gen);
            // Сбросить состояние
            gen.reset();
            // Создать новый визуал
            if (provider != null) provider.spawnGenerator(gen);
        }
    }

    /**
     * Убрать весь визуал после матча.
     */
    public void clearVisualsAfterMatch() {
        VisualProvider provider = plugin.getVisualProviderRegistry().getActiveProvider();
        if (provider == null) return;
        for (Generator gen : generators.values()) {
            provider.removeGenerator(gen);
        }
    }

    /**
     * Рассчитать скорость ремонта с учётом множителей.
     */
    public double getEffectiveRepairSpeed(int playerCount) {
        double baseSpeed = plugin.getConfig().getDouble("generators.repair-speed", 1.0);
        if (playerCount <= 1) return baseSpeed;

        String key = "generators.multi-repair-multipliers." + playerCount;
        double multiplier = plugin.getConfig().getDouble(key, 1.0 + (playerCount - 1) * 0.2);
        return baseSpeed * multiplier;
    }

    // ──────────────────────────────────────────────────────────
    //  ПРИВАТНЫЕ МЕТОДЫ
    // ──────────────────────────────────────────────────────────

    private void updateVisual(Generator gen) {
        VisualProvider provider = plugin.getVisualProviderRegistry().getActiveProvider();
        if (provider != null) {
            provider.updateProgress(gen);
            provider.updateState(gen);
        }
    }
}

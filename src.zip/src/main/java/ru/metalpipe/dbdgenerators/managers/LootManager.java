package ru.metalpipe.dbdgenerators.managers;

import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.LootChest;
import ru.metalpipe.dbdgenerators.util.MessageUtil;

import java.util.*;
import java.util.logging.Level;
import java.util.stream.Collectors;

/**
 * Менеджер лут-системы.
 *
 * Управляет:
 *  - Лут-таблицами (загрузка, сохранение, редактирование)
 *  - Выдачей случайного лута
 *  - Наградами «Мрачный Сигил»
 *  - Временем перезарядки ящиков
 *
 * Паттерн вдохновлён EliteMobs и продвинутыми chest-плагинами.
 */
public final class LootManager {

    private final DBDGeneratorsPlugin plugin;

    /** Имя таблицы → объект LootChest */
    private final Map<String, LootChest> lootTables = new LinkedHashMap<>();

    /** Сериализованная локация ящика → время следующего respawn */
    private final Map<String, Long> chestCooldowns = new HashMap<>();

    /** UUID игроков, открывающих лут-GUI прямо сейчас (имя таблицы) */
    private final Map<UUID, String> editingSessions = new HashMap<>();

    public LootManager(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    // ──────────────────────────────────────────────────────────
    //  ЗАГРУЗКА / СОХРАНЕНИЕ
    // ──────────────────────────────────────────────────────────

    public void loadLootTables() {
        lootTables.clear();
        FileConfiguration cfg = plugin.getConfigManager().getLootChestsConfig();
        ConfigurationSection tablesSection = cfg.getConfigurationSection("loot-tables");

        if (tablesSection == null) {
            plugin.getLogger().info("lootchests.yml: лут-таблиц не найдено.");
            return;
        }

        for (String tableName : tablesSection.getKeys(false)) {
            LootChest chest = new LootChest(tableName);
            ConfigurationSection items = tablesSection.getConfigurationSection(tableName + ".items");

            if (items != null) {
                for (String key : items.getKeys(false)) {
                    String matName = items.getString(key + ".material", "STONE");
                    Material mat = Material.matchMaterial(matName);
                    if (mat == null) {
                        plugin.getLogger().warning("Лут: неизвестный материал '" + matName + "' в " + tableName);
                        continue;
                    }

                    int amount = items.getInt(key + ".amount", 1);
                    int weight = items.getInt(key + ".weight", 50);
                    int slot = items.getInt(key + ".slot", -1);
                    String displayName = items.getString(key + ".name");
                    List<String> lore = items.getStringList(key + ".lore");

                    ItemStack item = new ItemStack(mat, amount);
                    ItemMeta meta = item.getItemMeta();
                    if (meta != null) {
                        if (displayName != null && !displayName.equals("null")) {
                            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', displayName));
                        }
                        if (!lore.isEmpty()) {
                            meta.setLore(lore.stream()
                                .map(l -> ChatColor.translateAlternateColorCodes('&', l))
                                .collect(Collectors.toList()));
                        }
                        item.setItemMeta(meta);
                    }

                    chest.addEntry(new LootChest.LootEntry(item, weight, slot));
                }
            }
            lootTables.put(tableName, chest);
        }
        plugin.getLogger().info("Лут-таблиц загружено: " + lootTables.size());
    }

    public void saveLootTables() {
        FileConfiguration cfg = plugin.getConfigManager().getLootChestsConfig();
        cfg.set("loot-tables", null);

        for (Map.Entry<String, LootChest> entry : lootTables.entrySet()) {
            String tablePath = "loot-tables." + entry.getKey();
            List<LootChest.LootEntry> entries = entry.getValue().getEntries();

            for (int i = 0; i < entries.size(); i++) {
                LootChest.LootEntry lootEntry = entries.get(i);
                String itemPath = tablePath + ".items." + i;

                cfg.set(itemPath + ".material", lootEntry.getItem().getType().name());
                cfg.set(itemPath + ".amount", lootEntry.getItem().getAmount());
                cfg.set(itemPath + ".weight", lootEntry.getWeight());
                cfg.set(itemPath + ".slot", lootEntry.getSlot());

                ItemMeta meta = lootEntry.getItem().getItemMeta();
                if (meta != null) {
                    cfg.set(itemPath + ".name",
                        meta.hasDisplayName() ? meta.getDisplayName() : null);
                    cfg.set(itemPath + ".lore",
                        meta.hasLore() ? meta.getLore() : Collections.emptyList());
                }
            }
        }
        plugin.getConfigManager().saveLootChestsConfig();
    }

    // ──────────────────────────────────────────────────────────
    //  CRUD ЛУТ-ТАБЛИЦ
    // ──────────────────────────────────────────────────────────

    public LootChest createLootTable(String name) {
        LootChest chest = new LootChest(name);
        lootTables.put(name, chest);
        saveLootTables();
        return chest;
    }

    public boolean deleteLootTable(String name) {
        if (!lootTables.containsKey(name)) return false;
        lootTables.remove(name);
        saveLootTables();
        return true;
    }

    public LootChest getLootTable(String name) {
        return lootTables.get(name);
    }

    public Collection<LootChest> getAllLootTables() {
        return lootTables.values();
    }

    /**
     * Добавить предмет из руки игрока в лут-таблицу.
     */
    public boolean addItemFromHand(Player player, String tableName) {
        LootChest chest = lootTables.get(tableName);
        if (chest == null) return false;

        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || item.getType() == Material.AIR) return false;

        chest.addEntry(new LootChest.LootEntry(item.clone(), 50, -1));
        saveLootTables();
        return true;
    }

    // ──────────────────────────────────────────────────────────
    //  ГЕНЕРАЦИЯ ЛУТА
    // ──────────────────────────────────────────────────────────

    /**
     * Получить случайный набор предметов из таблицы.
     *
     * @param tableName Имя лут-таблицы.
     * @return Список ItemStack (не более max-items).
     */
    public List<ItemStack> generateLoot(String tableName) {
        LootChest chest = lootTables.get(tableName);
        if (chest == null || chest.getEntries().isEmpty()) return Collections.emptyList();

        int maxItems = plugin.getConfig().getInt("loot.max-items", 3);
        int minItems = plugin.getConfig().getInt("loot.min-items", 1);
        int count = minItems + new Random().nextInt(Math.max(1, maxItems - minItems + 1));

        // Взвешенная случайная выборка
        List<LootChest.LootEntry> entries = chest.getEntries();
        int totalWeight = entries.stream().mapToInt(LootChest.LootEntry::getWeight).sum();

        List<ItemStack> result = new ArrayList<>();
        Set<Integer> usedIndices = new HashSet<>();

        for (int i = 0; i < count && i < entries.size(); i++) {
            int roll = new Random().nextInt(totalWeight);
            int cumulative = 0;

            for (int j = 0; j < entries.size(); j++) {
                if (usedIndices.contains(j)) continue;
                cumulative += entries.get(j).getWeight();
                if (roll < cumulative) {
                    result.add(entries.get(j).getItem().clone());
                    usedIndices.add(j);
                    break;
                }
            }
        }
        return result;
    }

    // ──────────────────────────────────────────────────────────
    //  ПЕРЕЗАРЯДКА ЯЩИКОВ
    // ──────────────────────────────────────────────────────────

    public boolean isChestOnCooldown(Location loc) {
        String key = serializeLocation(loc);
        Long cooldownTime = chestCooldowns.get(key);
        return cooldownTime != null && System.currentTimeMillis() < cooldownTime;
    }

    public long getRemainingCooldown(Location loc) {
        String key = serializeLocation(loc);
        Long cooldownTime = chestCooldowns.get(key);
        if (cooldownTime == null) return 0;
        return Math.max(0, (cooldownTime - System.currentTimeMillis()) / 1000);
    }

    public void setChestCooldown(Location loc) {
        int respawnTime = plugin.getConfig().getInt("loot.respawn-time", 60);
        if (respawnTime <= 0) return;
        chestCooldowns.put(serializeLocation(loc),
            System.currentTimeMillis() + respawnTime * 1000L);
    }

    private String serializeLocation(Location loc) {
        return loc.getWorld().getName() + "," + loc.getBlockX() + "," +
               loc.getBlockY() + "," + loc.getBlockZ();
    }

    // ──────────────────────────────────────────────────────────
    //  МРАЧНЫЙ СИГИЛ
    // ──────────────────────────────────────────────────────────

    /**
     * Выдать игроку Мрачные Сигилы.
     *
     * @param player Игрок.
     * @param amount Количество.
     * @param reason Причина (для сообщения).
     */
    public void giveSigils(Player player, int amount, String reason) {
        if (amount <= 0) return;

        ItemStack sigil = createSigilItem(amount);

        // Добавить в инвентарь или бросить на пол
        HashMap<Integer, ItemStack> leftover = player.getInventory().addItem(sigil);
        if (!leftover.isEmpty()) {
            leftover.values().forEach(item ->
                player.getWorld().dropItemNaturally(player.getLocation(), item)
            );
        }

        // Счётчик для скоборда + глобальная статистика
        plugin.getScoreboardManager().addSessionSigils(player.getUniqueId(), amount);
        plugin.getStatisticsManager().addSigils(player.getUniqueId(), amount);

        player.sendMessage(MessageUtil.msg("loot.sigils-earned")
            .replace("{sigils}", String.valueOf(amount)));

        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.2f);
    }

    private ItemStack createSigilItem(int amount) {
        Material mat = Material.NETHER_STAR;
        ItemStack item = new ItemStack(mat, amount);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            String name = plugin.getConfig().getString("loot.sigil-item-name",
                "&5✦ &dМрачный Сигил &5✦");
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));

            List<String> loreConfig = plugin.getConfig().getStringList("loot.sigil-item-lore");
            List<String> lore = loreConfig.stream()
                .map(l -> ChatColor.translateAlternateColorCodes('&', l))
                .collect(Collectors.toList());
            meta.setLore(lore);

            // Enchantment glow
            meta.addEnchant(org.bukkit.enchantments.Enchantment.LUCK, 1, true);
            meta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);

            item.setItemMeta(meta);
        }
        return item;
    }

    // ──────────────────────────────────────────────────────────
    //  РЕДАКТИРОВАНИЕ (GUI СЕССИИ)
    // ──────────────────────────────────────────────────────────

    public void startEditSession(UUID uuid, String tableName) {
        editingSessions.put(uuid, tableName);
    }

    public void endEditSession(UUID uuid) {
        editingSessions.remove(uuid);
    }

    public String getEditingTable(UUID uuid) {
        return editingSessions.get(uuid);
    }
}

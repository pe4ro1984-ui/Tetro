package ru.metalpipe.dbdgenerators.managers;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Менеджер статистики игроков.
 *
 * Хранит и сохраняет:
 *  - Количество сыгранных матчей
 *  - Количество побед (выжил / поймал всех)
 *  - Количество починенных генераторов
 *  - Количество саботажей
 *  - Количество хуков
 *  - Количество поднятий союзников
 *  - Суммарные Мрачные Сигилы (за все сессии)
 *
 * Данные хранятся в stats.yml в папке плагина.
 * Автосохранение каждые 5 минут + при disable.
 *
 * Паттерн — плоская YAML-персистентность как в топовых minigame-плагинах.
 */
public final class StatisticsManager {

    private final DBDGeneratorsPlugin plugin;

    /** UUID → StatsEntry */
    private final Map<UUID, StatsEntry> stats = new HashMap<>();

    private File statsFile;
    private FileConfiguration statsConfig;

    public StatisticsManager(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    // ──────────────────────────────────────────────────────────
    //  ЗАГРУЗКА / СОХРАНЕНИЕ
    // ──────────────────────────────────────────────────────────

    public void load() {
        statsFile = new File(plugin.getDataFolder(), "stats.yml");
        if (!statsFile.exists()) {
            try {
                statsFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().log(Level.WARNING, "Не удалось создать stats.yml", e);
                return;
            }
        }
        statsConfig = YamlConfiguration.loadConfiguration(statsFile);

        // Загружаем все записи
        stats.clear();
        if (statsConfig.getConfigurationSection("players") == null) return;

        for (String uuidStr : statsConfig.getConfigurationSection("players").getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidStr);
                String path = "players." + uuidStr;
                StatsEntry entry = new StatsEntry();
                entry.matchesPlayed     = statsConfig.getInt(path + ".matches-played", 0);
                entry.matchesWon        = statsConfig.getInt(path + ".matches-won", 0);
                entry.generatorsFixed   = statsConfig.getInt(path + ".generators-fixed", 0);
                entry.generatorsSabotaged = statsConfig.getInt(path + ".generators-sabotaged", 0);
                entry.hooks             = statsConfig.getInt(path + ".hooks", 0);
                entry.revives           = statsConfig.getInt(path + ".revives", 0);
                entry.totalSigils       = statsConfig.getInt(path + ".total-sigils", 0);
                entry.escapes           = statsConfig.getInt(path + ".escapes", 0);
                entry.deaths            = statsConfig.getInt(path + ".deaths", 0);
                stats.put(uuid, entry);
            } catch (IllegalArgumentException ignored) {}
        }

        plugin.getLogger().info("Статистика загружена: " + stats.size() + " игроков.");
    }

    public void save() {
        if (statsConfig == null) return;
        statsConfig.set("players", null);

        for (Map.Entry<UUID, StatsEntry> e : stats.entrySet()) {
            String path = "players." + e.getKey();
            StatsEntry entry = e.getValue();
            statsConfig.set(path + ".matches-played",      entry.matchesPlayed);
            statsConfig.set(path + ".matches-won",         entry.matchesWon);
            statsConfig.set(path + ".generators-fixed",    entry.generatorsFixed);
            statsConfig.set(path + ".generators-sabotaged",entry.generatorsSabotaged);
            statsConfig.set(path + ".hooks",               entry.hooks);
            statsConfig.set(path + ".revives",             entry.revives);
            statsConfig.set(path + ".total-sigils",        entry.totalSigils);
            statsConfig.set(path + ".escapes",             entry.escapes);
            statsConfig.set(path + ".deaths",              entry.deaths);
        }

        try {
            statsConfig.save(statsFile);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Ошибка сохранения stats.yml", ex);
        }
    }

    // ──────────────────────────────────────────────────────────
    //  ИНКРЕМЕНТАЦИЯ
    // ──────────────────────────────────────────────────────────

    public void incrementMatchPlayed(UUID uuid)         { get(uuid).matchesPlayed++; }
    public void incrementMatchWon(UUID uuid)            { get(uuid).matchesWon++; }
    public void incrementGeneratorsFixed(UUID uuid)     { get(uuid).generatorsFixed++; }
    public void incrementGeneratorsSabotaged(UUID uuid) { get(uuid).generatorsSabotaged++; }
    public void incrementHooks(UUID uuid)               { get(uuid).hooks++; }
    public void incrementRevives(UUID uuid)             { get(uuid).revives++; }
    public void addSigils(UUID uuid, int amount)        { get(uuid).totalSigils += amount; }
    public void incrementEscapes(UUID uuid)             { get(uuid).escapes++; }
    public void incrementDeaths(UUID uuid)              { get(uuid).deaths++; }

    // ──────────────────────────────────────────────────────────
    //  ГЕТТЕРЫ
    // ──────────────────────────────────────────────────────────

    public StatsEntry getStats(UUID uuid) {
        return stats.getOrDefault(uuid, new StatsEntry());
    }

    public int getTotalSigils(UUID uuid) {
        return get(uuid).totalSigils;
    }

    private StatsEntry get(UUID uuid) {
        return stats.computeIfAbsent(uuid, k -> new StatsEntry());
    }

    // ──────────────────────────────────────────────────────────
    //  ФОРМАТИРОВАННЫЙ ВЫВОД СТАТИСТИКИ
    // ──────────────────────────────────────────────────────────

    /**
     * Получить строки статистики для отображения игроку.
     */
    public java.util.List<String> formatStats(UUID uuid) {
        StatsEntry e = getStats(uuid);
        java.util.List<String> lines = new java.util.ArrayList<>();
        lines.add("§8§m═══════════════════════════════════");
        lines.add("  §c§lDBDGenerators §8| §7Статистика");
        lines.add("§8§m═══════════════════════════════════");
        lines.add("§7Матчей сыграно:  §e" + e.matchesPlayed);
        lines.add("§7Матчей выиграно: §a" + e.matchesWon);
        lines.add("§7Побегов:         §a" + e.escapes);
        lines.add("§7Гибелей:         §c" + e.deaths);
        lines.add("§7Генераторов починено: §e" + e.generatorsFixed);
        lines.add("§7Генераторов сломано:  §c" + e.generatorsSabotaged);
        lines.add("§7Хуков повешено:   §c" + e.hooks);
        lines.add("§7Союзников поднято:§a" + e.revives);
        lines.add("§7Мрачных Сигилов:  §5" + e.totalSigils);
        lines.add("§8§m═══════════════════════════════════");
        return lines;
    }

    // ──────────────────────────────────────────────────────────
    //  DATA CLASS
    // ──────────────────────────────────────────────────────────

    /**
     * Запись статистики одного игрока.
     */
    public static final class StatsEntry {
        public int matchesPlayed     = 0;
        public int matchesWon        = 0;
        public int generatorsFixed   = 0;
        public int generatorsSabotaged = 0;
        public int hooks             = 0;
        public int revives           = 0;
        public int totalSigils       = 0;
        public int escapes           = 0;
        public int deaths            = 0;
    }
}

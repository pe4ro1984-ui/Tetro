package ru.metalpipe.dbdgenerators.managers;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.Match;
import ru.metalpipe.dbdgenerators.model.MatchPhase;
import ru.metalpipe.dbdgenerators.model.PlayerRole;
import ru.metalpipe.dbdgenerators.model.PlayerState;
import ru.metalpipe.dbdgenerators.task.CollapseTask;
import ru.metalpipe.dbdgenerators.task.MatchTask;
import ru.metalpipe.dbdgenerators.util.MessageUtil;

import java.util.*;
import java.util.logging.Level;

/**
 * Главный менеджер матча.
 *
 * Управляет жизненным циклом матча:
 *   LOBBY → IN_GAME → ENDGAME_COLLAPSE → FINISHED
 *
 * Аналогичен MatchManager в Marcely's BedWars —
 * единая точка входа для всех матч-событий.
 */
public final class MatchManager {

    private final DBDGeneratorsPlugin plugin;

    /** Текущий активный матч (null = матч не запущен) */
    private Match currentMatch;

    /** ID задачи лобби-обратного отсчёта */
    private int lobbyTaskId = -1;

    /** Основная задача матча */
    private MatchTask matchTask;

    /** Задача коллапса */
    private CollapseTask collapseTask;

    /** Список игроков в очереди (лобби) */
    private final List<UUID> lobbyQueue = new ArrayList<>();

    /** Игроки с включённым vision-режимом */
    private final Set<UUID> visionPlayers = new HashSet<>();

    public MatchManager(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    // ──────────────────────────────────────────────────────────
    //  УПРАВЛЕНИЕ МАТЧЕМ
    // ──────────────────────────────────────────────────────────

    /**
     * Запуск матча вручную или автоматически.
     *
     * @param initiator Игрок, запустивший матч (или null для автозапуска).
     */
    public void startMatch(Player initiator) {
        if (currentMatch != null && currentMatch.getPhase() != MatchPhase.FINISHED) {
            if (initiator != null) {
                initiator.sendMessage(MessageUtil.msg("match.already-running"));
            }
            return;
        }

        // Сбор игроков (из очереди или все онлайн)
        List<Player> players = getPlayersForMatch();
        int minPlayers = plugin.getConfig().getInt("match.min-players", 2);

        if (players.size() < minPlayers) {
            if (initiator != null) {
                initiator.sendMessage(MessageUtil.msg("match.not-enough-players")
                    .replace("{count}", String.valueOf(minPlayers)));
            }
            return;
        }

        // Создать матч
        int requiredGens = plugin.getConfig().getInt("match.generators-required", 5);
        currentMatch = new Match(requiredGens);

        // Назначить роли
        assignRoles(players);

        // Сбросить генераторы
        plugin.getGeneratorManager().resetForMatch();

        // Инициализировать состояния игроков
        for (Player p : players) {
            if (currentMatch.getRoleOf(p.getUniqueId()) == PlayerRole.SURVIVOR) {
                plugin.getPlayerStateManager().initPlayer(p.getUniqueId());
                p.setGameMode(GameMode.ADVENTURE);
                plugin.getItemManager().giveSurvivorKit(p);
            } else if (currentMatch.getRoleOf(p.getUniqueId()) == PlayerRole.HUNTER) {
                p.setGameMode(GameMode.ADVENTURE);
                plugin.getItemManager().giveHunterKit(p);
            }
            plugin.getScoreboardManager().createScoreboard(p);
            plugin.getStatisticsManager().incrementMatchPlayed(p.getUniqueId());
        }

        // Переход в фазу IN_GAME
        transitionToPhase(MatchPhase.IN_GAME);

        // Уведомления
        broadcastToMatch("match.started", msg -> msg.replace("{player}",
            initiator != null ? initiator.getName() : "Авто"));

        // Сообщить роли каждому
        for (UUID uuid : currentMatch.getParticipants()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;
            PlayerRole role = currentMatch.getRoleOf(uuid);
            String roleMsg = role == PlayerRole.SURVIVOR ? "roles.assigned-survivor" :
                             role == PlayerRole.HUNTER   ? "roles.assigned-hunter" :
                                                           "roles.assigned-spectator";
            p.sendMessage(MessageUtil.msg(roleMsg));
        }

        // Запустить основную задачу матча
        matchTask = new MatchTask(plugin);
        matchTask.runTaskTimer(plugin, 20L,
            plugin.getConfig().getLong("performance.generator-tick-interval", 4L));

        plugin.getLogger().info("Матч начался! Игроков: " + players.size());
    }

    /**
     * Остановить матч вручную.
     *
     * @param stopper    Кто остановил (или null).
     * @param reason     Причина.
     */
    public void stopMatch(Player stopper, String reason) {
        if (currentMatch == null) return;

        // Отменить задачи
        cancelTasks();

        // Вернуть всех игроков в нормальный режим
        for (UUID uuid : currentMatch.getParticipants()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) {
                p.setGameMode(GameMode.SURVIVAL);
                p.removePotionEffect(org.bukkit.potion.PotionEffectType.SLOW);
                plugin.getPlayerStateManager().clearPlayer(uuid);
            }
        }

        plugin.getGeneratorManager().clearVisualsAfterMatch();

        broadcastToAll(MessageUtil.msg("match.stopped"));

        transitionToPhase(MatchPhase.FINISHED);
        currentMatch = null;
        lobbyQueue.clear();
    }

    /**
     * Выжившие победили — запустить финальную последовательность.
     */
    public void onSurvivorsEscape() {
        if (currentMatch == null) return;

        currentMatch.setSurvivorsWon(true);
        endMatch();
    }

    /**
     * Охотник победил (все выжившие мертвы).
     */
    public void onHunterWin() {
        if (currentMatch == null) return;

        currentMatch.setSurvivorsWon(false);
        endMatch();
    }

    /**
     * Выживший умер — проверить условие победы охотника.
     */
    public void onSurvivorDied(UUID uuid) {
        if (currentMatch == null) return;

        currentMatch.decrementAliveSurvivors();
        plugin.getLogger().fine("Выживший умер. Живых: " + currentMatch.getAliveSurvivors());

        if (currentMatch.getAliveSurvivors() <= 0) {
            onHunterWin();
        }
    }

    /**
     * Генератор починен — проверить условие открытия ворот.
     */
    public void onGeneratorCompleted(String genId) {
        if (currentMatch == null) return;

        currentMatch.incrementCompletedGenerators();
        int done = currentMatch.getCompletedGenerators();
        int max = currentMatch.getRequiredGenerators();

        broadcastToMatch("generators.repair-complete-global", msg ->
            msg.replace("{count}", String.valueOf(done))
               .replace("{max}", String.valueOf(max))
        );

        if (currentMatch.isGeneratorGoalReached()) {
            openEscapeGates();
        }

        // Очки Мрачного Сигила
        // (игрок-репайрер получает сигилы в GeneratorListener)
    }

    // ──────────────────────────────────────────────────────────
    //  ФАЗЫ МАТЧА
    // ──────────────────────────────────────────────────────────

    /**
     * Переход в фазу ENDGAME_COLLAPSE.
     */
    public void startCollapse() {
        if (currentMatch == null) return;
        transitionToPhase(MatchPhase.ENDGAME_COLLAPSE);

        int collapseDuration = plugin.getConfig().getInt("match.collapse-duration", 60);

        // Рассылка
        for (UUID uuid : currentMatch.getParticipants()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;
            for (String line : plugin.getConfigManager().getMessagesConfig()
                    .getStringList("match.phase-collapse")) {
                p.sendMessage(MessageUtil.colorize(line
                    .replace("{time}", String.valueOf(collapseDuration))));
            }
        }

        collapseTask = new CollapseTask(plugin, collapseDuration);
        collapseTask.runTaskTimer(plugin, 0L, 20L);
    }

    private void openEscapeGates() {
        if (currentMatch == null) return;
        currentMatch.setGatesOpen(true);

        broadcastToMatch("generators.gates-opening", msg -> msg);
        broadcastToMatch("generators.gates-open", msg -> msg);

        // Звук открытия ворот
        for (UUID uuid : currentMatch.getParticipants()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) {
                p.playSound(p.getLocation(), Sound.BLOCK_IRON_DOOR_OPEN, 1.0f, 0.6f);
            }
        }

        // Начать коллапс
        startCollapse();
    }

    private void endMatch() {
        if (currentMatch == null) return;
        cancelTasks();

        transitionToPhase(MatchPhase.FINISHED);

        // Показать результаты
        Boolean survivorsWon = currentMatch.getSurvivorsWon();
        List<String> resultLines = survivorsWon == null ?
            plugin.getConfigManager().getMessagesConfig().getStringList("match.result-time-out") :
            survivorsWon ?
            plugin.getConfigManager().getMessagesConfig().getStringList("match.result-survivors-win") :
            plugin.getConfigManager().getMessagesConfig().getStringList("match.result-hunter-win");

        for (UUID uuid : currentMatch.getParticipants()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;
            for (String line : resultLines) {
                p.sendMessage(MessageUtil.colorize(line));
            }
            // Сигилы за побег
            if (survivorsWon != null && survivorsWon &&
                currentMatch.getRoleOf(uuid) == PlayerRole.SURVIVOR) {
                int sigils = plugin.getConfig().getInt("loot.sigil-reward-escape", 100);
                plugin.getLootManager().giveSigils(p, sigils, "эвакуацию");
            }
        }

        plugin.getGeneratorManager().clearVisualsAfterMatch();

        // Вернуть игроков в нормальный режим
        for (UUID uuid : currentMatch.getParticipants()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) {
                // Статистика победы
                if (survivorsWon != null) {
                    PlayerRole role = currentMatch.getRoleOf(uuid);
                    boolean won = (survivorsWon && role == PlayerRole.SURVIVOR) ||
                                  (!survivorsWon && role == PlayerRole.HUNTER);
                    if (won) plugin.getStatisticsManager().incrementMatchWon(uuid);
                    if (survivorsWon && role == PlayerRole.SURVIVOR) {
                        plugin.getStatisticsManager().incrementEscapes(uuid);
                    }
                }
                // Убрать скоборд, очистить предметы, вернуть режим
                plugin.getScoreboardManager().removeScoreboard(p);
                plugin.getItemManager().clearPlayerKit(p);
                p.setGameMode(GameMode.SURVIVAL);
                p.removePotionEffect(org.bukkit.potion.PotionEffectType.SLOW);
                plugin.getPlayerStateManager().clearPlayer(uuid);
            }
        }
        // Автосохранение статистики
        plugin.getStatisticsManager().save();

        // Автоперезапуск
        int restartDelay = plugin.getConfig().getInt("match.restart-delay", 10);
        Match finishedMatch = currentMatch;
        currentMatch = null;
        lobbyQueue.clear();

        new BukkitRunnable() {
            @Override
            public void run() {
                plugin.getLogger().info("Матч завершён. ID: " + finishedMatch.getMatchId());
            }
        }.runTaskLater(plugin, restartDelay * 20L);
    }

    private void transitionToPhase(MatchPhase phase) {
        if (currentMatch != null) {
            currentMatch.setPhase(phase);
        }
        plugin.getLogger().info("Матч → фаза: " + phase.getDisplayName());
    }

    // ──────────────────────────────────────────────────────────
    //  ЛОББИ / ОЧЕРЕДЬ
    // ──────────────────────────────────────────────────────────

    /**
     * Добавить игрока в лобби-очередь.
     */
    public void addToLobby(Player player) {
        if (lobbyQueue.contains(player.getUniqueId())) return;
        lobbyQueue.add(player.getUniqueId());

        int minPlayers = plugin.getConfig().getInt("match.min-players", 2);
        if (lobbyQueue.size() >= minPlayers && lobbyTaskId == -1) {
            startLobbyCountdown();
        }
    }

    private void startLobbyCountdown() {
        int countdown = plugin.getConfig().getInt("match.lobby-countdown", 30);
        final int[] timer = {countdown};
        int maxPlayers = plugin.getConfig().getInt("match.max-players", 5);

        lobbyTaskId = new BukkitRunnable() {
            @Override
            public void run() {
                if (timer[0] <= 0) {
                    cancel();
                    lobbyTaskId = -1;
                    startMatch(null);
                    return;
                }

                if (timer[0] % 10 == 0 || timer[0] <= 5) {
                    String msg = MessageUtil.msg("match.lobby-countdown")
                        .replace("{time}", String.valueOf(timer[0]))
                        .replace("{count}", String.valueOf(lobbyQueue.size()))
                        .replace("{max}", String.valueOf(maxPlayers));
                    broadcastToQueue(msg);
                }
                timer[0]--;
            }
        }.runTaskTimer(plugin, 20L, 20L).getTaskId();
    }

    // ──────────────────────────────────────────────────────────
    //  УТИЛИТЫ
    // ──────────────────────────────────────────────────────────

    private void assignRoles(List<Player> players) {
        boolean autoAssign = plugin.getConfig().getBoolean("match.auto-assign-hunter", true);

        Player hunter;
        if (autoAssign) {
            hunter = players.get(new Random().nextInt(players.size()));
        } else {
            hunter = players.get(0);
        }

        for (Player p : players) {
            PlayerRole role = p.equals(hunter) ? PlayerRole.HUNTER : PlayerRole.SURVIVOR;
            currentMatch.addPlayer(p, role);
        }
    }

    private List<Player> getPlayersForMatch() {
        List<Player> result = new ArrayList<>();
        int maxPlayers = plugin.getConfig().getInt("match.max-players", 5);

        for (UUID uuid : lobbyQueue) {
            if (result.size() >= maxPlayers) break;
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) result.add(p);
        }

        // Если очередь пустая — взять всех онлайн-игроков
        if (result.isEmpty()) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (result.size() >= maxPlayers) break;
                result.add(p);
            }
        }
        return result;
    }

    private void cancelTasks() {
        if (matchTask != null) {
            matchTask.cancel();
            matchTask = null;
        }
        if (collapseTask != null) {
            collapseTask.cancel();
            collapseTask = null;
        }
        if (lobbyTaskId != -1) {
            Bukkit.getScheduler().cancelTask(lobbyTaskId);
            lobbyTaskId = -1;
        }
    }

    public void broadcastToMatch(String msgKey, java.util.function.Function<String, String> replacer) {
        if (currentMatch == null) return;
        String msg = MessageUtil.msg(msgKey);
        msg = replacer.apply(msg);
        for (UUID uuid : currentMatch.getParticipants()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) p.sendMessage(msg);
        }
    }

    private void broadcastToAll(String msg) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(msg);
        }
    }

    private void broadcastToQueue(String msg) {
        for (UUID uuid : lobbyQueue) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) p.sendMessage(msg);
        }
    }

    // ──────────────────────────────────────────────────────────
    //  VISION (РЕЖИМ НАБЛЮДАТЕЛЯ)
    // ──────────────────────────────────────────────────────────

    public void toggleVision(Player player) {
        if (visionPlayers.contains(player.getUniqueId())) {
            visionPlayers.remove(player.getUniqueId());
            player.sendMessage(MessageUtil.msg("vision.disabled"));
        } else {
            visionPlayers.add(player.getUniqueId());
            player.sendMessage(MessageUtil.msg("vision.enabled"));
        }
    }

    public boolean hasVision(UUID uuid) {
        return visionPlayers.contains(uuid);
    }

    // ──────────────────────────────────────────────────────────
    //  ГЕТТЕРЫ
    // ──────────────────────────────────────────────────────────

    public Match getCurrentMatch() { return currentMatch; }

    public boolean isMatchRunning() {
        return currentMatch != null &&
               currentMatch.getPhase() != MatchPhase.FINISHED &&
               currentMatch.getPhase() != MatchPhase.LOBBY;
    }

    public List<UUID> getLobbyQueue() { return lobbyQueue; }
}

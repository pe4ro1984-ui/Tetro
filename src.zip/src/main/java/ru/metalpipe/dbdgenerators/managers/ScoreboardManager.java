package ru.metalpipe.dbdgenerators.managers;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.Match;
import ru.metalpipe.dbdgenerators.model.MatchPhase;
import ru.metalpipe.dbdgenerators.model.PlayerRole;
import ru.metalpipe.dbdgenerators.model.PlayerState;

import java.util.*;

/**
 * Менеджер сайдбар-скоробордов.
 *
 * Показывает каждому участнику матча персонализированный скоборд:
 *  - Роль игрока (Выживший / Охотник)
 *  - Количество починенных генераторов
 *  - Оставшееся время матча
 *  - Состояние игрока (здоров / ранен / повален)
 *  - Количество Мрачных Сигилов (если хранятся в сессии)
 *
 * Обновляется каждые 20 тиков (1 сек) через MatchTask.
 *
 * Паттерн аналогичен скоробордам в Marcely's BedWars.
 */
public final class ScoreboardManager {

    private final DBDGeneratorsPlugin plugin;

    /** UUID → объект Scoreboard игрока */
    private final Map<UUID, Scoreboard> playerScoreboards = new HashMap<>();

    /** UUID → Objective скоборда */
    private final Map<UUID, Objective> playerObjectives = new HashMap<>();

    /** Счётчик Сигилов в текущей сессии: UUID → количество */
    private final Map<UUID, Integer> sessionSigils = new HashMap<>();

    private static final String OBJECTIVE_NAME = "dbd_sidebar";

    // Уникальные ChatColor-«ключи» для строк скоборда (Bukkit требует уникальные имена)
    private static final String[] LINE_KEYS = {
        ChatColor.BLACK + "" + ChatColor.BLACK,
        ChatColor.BLACK + "" + ChatColor.DARK_BLUE,
        ChatColor.BLACK + "" + ChatColor.DARK_GREEN,
        ChatColor.BLACK + "" + ChatColor.DARK_AQUA,
        ChatColor.BLACK + "" + ChatColor.DARK_RED,
        ChatColor.BLACK + "" + ChatColor.DARK_PURPLE,
        ChatColor.BLACK + "" + ChatColor.GOLD,
        ChatColor.BLACK + "" + ChatColor.GRAY,
        ChatColor.BLACK + "" + ChatColor.DARK_GRAY,
        ChatColor.BLACK + "" + ChatColor.BLUE,
        ChatColor.BLACK + "" + ChatColor.GREEN,
        ChatColor.BLACK + "" + ChatColor.AQUA,
        ChatColor.BLACK + "" + ChatColor.RED,
    };

    public ScoreboardManager(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    // ──────────────────────────────────────────────────────────
    //  СОЗДАНИЕ / УДАЛЕНИЕ СКОБОРДА
    // ──────────────────────────────────────────────────────────

    /**
     * Создать и показать скоборд игроку.
     * Вызывается при входе в матч.
     */
    public void createScoreboard(Player player) {
        org.bukkit.scoreboard.ScoreboardManager sm = Bukkit.getScoreboardManager();
        if (sm == null) return;

        Scoreboard board = sm.getNewScoreboard();
        Objective obj = board.registerNewObjective(OBJECTIVE_NAME, "dummy",
            ChatColor.DARK_RED + "" + ChatColor.BOLD + "✖ ВЗАПЕРТИ ✖");
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        playerScoreboards.put(player.getUniqueId(), board);
        playerObjectives.put(player.getUniqueId(), obj);
        sessionSigils.put(player.getUniqueId(), 0);

        player.setScoreboard(board);
    }

    /**
     * Убрать скоборд у игрока и восстановить дефолтный.
     * Вызывается при выходе из матча.
     */
    public void removeScoreboard(Player player) {
        playerScoreboards.remove(player.getUniqueId());
        playerObjectives.remove(player.getUniqueId());
        sessionSigils.remove(player.getUniqueId());

        org.bukkit.scoreboard.ScoreboardManager sm = Bukkit.getScoreboardManager();
        if (sm != null) {
            player.setScoreboard(sm.getMainScoreboard());
        }
    }

    // ──────────────────────────────────────────────────────────
    //  ОБНОВЛЕНИЕ СКОБОРДА
    // ──────────────────────────────────────────────────────────

    /**
     * Обновить скоборд всех участников матча.
     * Вызывается из MatchTask каждую секунду.
     */
    public void updateAll(Match match) {
        if (match == null || match.getPhase() == MatchPhase.FINISHED) return;

        long matchDuration = plugin.getConfig().getLong("match.match-duration", 600);
        long timeLeft = Math.max(0, matchDuration - match.getPhaseElapsedSeconds());

        for (UUID uuid : match.getParticipants()) {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null) continue;

            Objective obj = playerObjectives.get(uuid);
            Scoreboard board = playerScoreboards.get(uuid);
            if (obj == null || board == null) continue;

            // Очищаем все старые строки
            clearLines(board);

            PlayerRole role = match.getRoleOf(uuid);
            PlayerState state = plugin.getPlayerStateManager().getState(uuid);
            int doneGens = match.getCompletedGenerators();
            int totalGens = match.getRequiredGenerators();
            int sigils = sessionSigils.getOrDefault(uuid, 0);

            // Строим скоборд (строки добавляются снизу вверх по score)
            int line = 12;

            setLine(board, obj, line--, LINE_KEYS[0]); // пустая строка

            // Время
            setLine(board, obj, line--, ChatColor.GRAY + "⏰ Время: " + formatTime(timeLeft));

            setLine(board, obj, line--, LINE_KEYS[1]); // разделитель

            // Генераторы
            setLine(board, obj, line--, ChatColor.YELLOW + "⚡ Генераторы:");
            setLine(board, obj, line--, " " + buildGenBar(doneGens, totalGens));

            setLine(board, obj, line--, LINE_KEYS[2]);

            // Роль
            String roleStr = role == PlayerRole.HUNTER
                ? ChatColor.RED + "🔪 Охотник"
                : ChatColor.GREEN + "🔧 Выживший";
            setLine(board, obj, line--, ChatColor.GRAY + "Роль: " + roleStr);

            // Состояние (только для выживших)
            if (role == PlayerRole.SURVIVOR) {
                String stateStr;
                switch (state) {
                    case HEALTHY:  stateStr = ChatColor.GREEN  + "❤ Здоров";   break;
                    case INJURED:  stateStr = ChatColor.YELLOW + "💛 Ранен";    break;
                    case DOWNED:   stateStr = ChatColor.RED    + "💔 Повален";  break;
                    case HOOKED:   stateStr = ChatColor.DARK_RED + "⛓ На крюке"; break;
                    default:       stateStr = ChatColor.DARK_GRAY + "☠ Мёртв";  break;
                }
                setLine(board, obj, line--, ChatColor.GRAY + "Состояние: " + stateStr);
            }

            setLine(board, obj, line--, LINE_KEYS[3]);

            // Сигилы
            setLine(board, obj, line--, ChatColor.LIGHT_PURPLE + "✦ Сигилы: " + ChatColor.WHITE + sigils);

            setLine(board, obj, line--, LINE_KEYS[4]); // разделитель

            // Фаза
            String phaseStr;
            if (match.getPhase() == MatchPhase.ENDGAME_COLLAPSE) {
                phaseStr = ChatColor.DARK_RED + "" + ChatColor.BOLD + "КОЛЛАПС!";
            } else {
                phaseStr = ChatColor.GRAY + "В игре";
            }
            setLine(board, obj, line--, ChatColor.GRAY + "Фаза: " + phaseStr);
        }
    }

    // ──────────────────────────────────────────────────────────
    //  СИГИЛЫ В СЕССИИ
    // ──────────────────────────────────────────────────────────

    /**
     * Добавить сигилы в счётчик текущей сессии.
     * Отображается на скоборде.
     */
    public void addSessionSigils(UUID uuid, int amount) {
        int current = sessionSigils.getOrDefault(uuid, 0);
        sessionSigils.put(uuid, current + amount);
    }

    public int getSessionSigils(UUID uuid) {
        return sessionSigils.getOrDefault(uuid, 0);
    }

    public void resetSessionSigils(UUID uuid) {
        sessionSigils.put(uuid, 0);
    }

    // ──────────────────────────────────────────────────────────
    //  ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    // ──────────────────────────────────────────────────────────

    private void clearLines(Scoreboard board) {
        for (String key : LINE_KEYS) {
            Objective objective = board.getObjective(DisplaySlot.SIDEBAR);
            if (objective != null) {
                Score s = objective.getScore(key);
                if (s.isScoreSet()) {
                    board.resetScores(key);
                }
            }
        }
    }

    private void setLine(Scoreboard board, Objective obj, int score, String text) {
        // Bukkit требует уникальные строки. Если текст уже существует, добавляем пустой суффикс.
        String finalText = text.length() > 40 ? text.substring(0, 40) : text;
        Score s = obj.getScore(finalText);
        s.setScore(score);
    }

    /**
     * Форматировать секунды в MM:SS.
     */
    private String formatTime(long seconds) {
        long m = seconds / 60;
        long s = seconds % 60;
        if (seconds <= 30) {
            return ChatColor.RED + "" + m + ":" + String.format("%02d", s);
        } else if (seconds <= 120) {
            return ChatColor.YELLOW + "" + m + ":" + String.format("%02d", s);
        }
        return ChatColor.GREEN + "" + m + ":" + String.format("%02d", s);
    }

    /**
     * Построить прогресс-бар генераторов.
     * Пример: §a■■■§8□□ (3/5)
     */
    private String buildGenBar(int done, int total) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < total; i++) {
            if (i < done) sb.append(ChatColor.GREEN).append("■");
            else          sb.append(ChatColor.DARK_GRAY).append("□");
        }
        sb.append(ChatColor.GRAY).append(" (").append(done).append("/").append(total).append(")");
        return sb.toString();
    }
}

package ru.metalpipe.dbdgenerators.managers;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;

import java.util.Arrays;
import java.util.List;

/**
 * Менеджер кастомных предметов для ролей.
 *
 * Создаёт и выдаёт:
 *  - Инструментарий Выжившего (ключ, аптечка, фонарь)
 *  - Оружие Охотника (нож, силки, молоток)
 *
 * Предметы помечаются через PersistentDataContainer (NBT-совместимо),
 * чтобы избежать конфликтов с ванильными предметами.
 *
 * Паттерн — как в MythicMobs ItemManager (кастомные предметы с метаданными).
 */
public final class ItemManager {

    private final DBDGeneratorsPlugin plugin;

    // Ключи PersistentData для идентификации предметов
    private final NamespacedKey KEY_ITEM_TYPE;
    private final NamespacedKey KEY_ITEM_USES;

    // Значения типов предметов
    public static final String TYPE_TOOLKIT    = "survivor_toolkit";
    public static final String TYPE_MEDKIT     = "survivor_medkit";
    public static final String TYPE_FLASHLIGHT = "survivor_flashlight";
    public static final String TYPE_KNIFE      = "hunter_knife";
    public static final String TYPE_TRAP       = "hunter_trap";
    public static final String TYPE_HAMMER     = "hunter_hammer";

    public ItemManager(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
        KEY_ITEM_TYPE = new NamespacedKey(plugin, "dbd_item_type");
        KEY_ITEM_USES = new NamespacedKey(plugin, "dbd_item_uses");
    }

    // ──────────────────────────────────────────────────────────
    //  ВЫДАЧА ПРЕДМЕТОВ РОЛЯМ
    // ──────────────────────────────────────────────────────────

    /**
     * Выдать набор Выжившего.
     * Слот 0: Инструментарий, Слот 1: Аптечка, Слот 8: Фонарик.
     */
    public void giveSurvivorKit(Player player) {
        player.getInventory().clear();
        player.getInventory().setItem(0, createToolkit());
        player.getInventory().setItem(1, createMedkit());
        player.getInventory().setItem(8, createFlashlight());
    }

    /**
     * Выдать набор Охотника.
     * Слот 0: Нож, Слот 1: Силки, Слот 2: Молот.
     */
    public void giveHunterKit(Player player) {
        player.getInventory().clear();
        player.getInventory().setItem(0, createKnife());
        player.getInventory().setItem(1, createTrap());
        player.getInventory().setItem(2, createHammer());
    }

    /**
     * Очистить инвентарь после матча.
     */
    public void clearPlayerKit(Player player) {
        // Убрать только наши кастомные предметы
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (contents[i] != null && isDBDItem(contents[i])) {
                contents[i] = null;
            }
        }
        player.getInventory().setContents(contents);
    }

    // ──────────────────────────────────────────────────────────
    //  ФАБРИКА ПРЕДМЕТОВ — ВЫЖИВШИЕ
    // ──────────────────────────────────────────────────────────

    /**
     * Инструментарий Выжившего.
     * Используется для ремонта генераторов (декоративный — ПКМ запускает логику GeneratorListener).
     */
    public ItemStack createToolkit() {
        ItemStack item = new ItemStack(Material.IRON_HOE);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.setDisplayName(ChatColor.AQUA + "🔧 Инструментарий");
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Комплект для ремонта оборудования.",
            ChatColor.GRAY + "Подойдите к генератору и нажмите ПКМ,",
            ChatColor.GRAY + "чтобы начать ремонт.",
            "",
            ChatColor.YELLOW + "▶ ПКМ по генератору — ремонт",
            ChatColor.RED    + "▶ Shift — skill-check"
        ));
        meta.addEnchant(Enchantment.LUCK, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES,
                          ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        // Тег типа
        PersistentDataContainer data = meta.getPersistentDataContainer();
        data.set(KEY_ITEM_TYPE, PersistentDataType.STRING, TYPE_TOOLKIT);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Аптечка Выжившего.
     * Используется для исцеления союзников (INJURED → HEALTHY).
     * ПКМ по раненому союзнику — запускает анимацию лечения.
     */
    public ItemStack createMedkit() {
        ItemStack item = new ItemStack(Material.RED_DYE);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.setDisplayName(ChatColor.RED + "❤ Аптечка");
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Базовый медицинский комплект.",
            ChatColor.GRAY + "Позволяет перевязать рану союзника.",
            "",
            ChatColor.YELLOW + "▶ ПКМ по раненому союзнику — лечение",
            ChatColor.GRAY   + "Использований: " + ChatColor.WHITE + "1"
        ));
        meta.addEnchant(Enchantment.LUCK, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES,
                          ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        PersistentDataContainer data = meta.getPersistentDataContainer();
        data.set(KEY_ITEM_TYPE, PersistentDataType.STRING, TYPE_MEDKIT);
        data.set(KEY_ITEM_USES, PersistentDataType.INTEGER, 1);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Фонарик Выжившего.
     * Ослепляет охотника на короткое время (эффект Blindness).
     */
    public ItemStack createFlashlight() {
        ItemStack item = new ItemStack(Material.BLAZE_ROD);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.setDisplayName(ChatColor.YELLOW + "🔦 Фонарик");
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Мощный тактический фонарь.",
            ChatColor.GRAY + "Направьте на охотника и используйте,",
            ChatColor.GRAY + "чтобы ослепить его на 3 секунды.",
            "",
            ChatColor.YELLOW + "▶ ПКМ — ослепить охотника (дальность 8 блоков)",
            ChatColor.GRAY   + "Перезарядка: " + ChatColor.WHITE + "15 сек"
        ));
        meta.addEnchant(Enchantment.LUCK, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES,
                          ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        PersistentDataContainer data = meta.getPersistentDataContainer();
        data.set(KEY_ITEM_TYPE, PersistentDataType.STRING, TYPE_FLASHLIGHT);

        item.setItemMeta(meta);
        return item;
    }

    // ──────────────────────────────────────────────────────────
    //  ФАБРИКА ПРЕДМЕТОВ — ОХОТНИК
    // ──────────────────────────────────────────────────────────

    /**
     * Нож Охотника.
     * Основное оружие. При попадании: HEALTHY → INJURED → DOWNED.
     * Урон ванильный заменяется нашей системой (PlayerListener).
     */
    public ItemStack createKnife() {
        ItemStack item = new ItemStack(Material.IRON_SWORD);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.setDisplayName(ChatColor.RED + "🔪 Охотничий нож");
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Орудие мести и страха.",
            ChatColor.GRAY + "Каждый удар ослабляет жертву.",
            "",
            ChatColor.RED    + "HEALTHY  → INJURED (1 удар)",
            ChatColor.RED    + "INJURED  → DOWNED  (1 удар)",
            "",
            ChatColor.YELLOW + "▶ ЛКМ — удар"
        ));
        meta.addEnchant(Enchantment.DAMAGE_ALL, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES,
                          ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        PersistentDataContainer data = meta.getPersistentDataContainer();
        data.set(KEY_ITEM_TYPE, PersistentDataType.STRING, TYPE_KNIFE);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Силки Охотника.
     * ПКМ — установить силки на землю. Выживший, наступивший на силки,
     * замедляется и испускает частицы. Один раз.
     */
    public ItemStack createTrap() {
        ItemStack item = new ItemStack(Material.TRIPWIRE_HOOK);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.setDisplayName(ChatColor.GOLD + "⚙ Силки");
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Хитроумный капкан.",
            ChatColor.GRAY + "Установите рядом с генератором,",
            ChatColor.GRAY + "чтобы поймать выжившего.",
            "",
            ChatColor.YELLOW + "▶ ПКМ по блоку — установить силки",
            ChatColor.GRAY   + "Запас: " + ChatColor.WHITE + "2 шт."
        ));
        meta.addEnchant(Enchantment.LUCK, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES,
                          ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        PersistentDataContainer data = meta.getPersistentDataContainer();
        data.set(KEY_ITEM_TYPE, PersistentDataType.STRING, TYPE_TRAP);
        data.set(KEY_ITEM_USES, PersistentDataType.INTEGER, 2);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Молот Охотника.
     * Саботаж генераторов — ПКМ по генератору выводит его из строя.
     */
    public ItemStack createHammer() {
        ItemStack item = new ItemStack(Material.GOLDEN_AXE);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.setDisplayName(ChatColor.DARK_RED + "🔨 Молот Разрушителя");
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Тяжёлый молот для разрушения техники.",
            ChatColor.GRAY + "Используйте на генераторе,",
            ChatColor.GRAY + "чтобы вывести его из строя мгновенно.",
            "",
            ChatColor.YELLOW + "▶ ПКМ по генератору — саботаж",
            ChatColor.RED    + "Зона слышимости: 32 блока"
        ));
        meta.addEnchant(Enchantment.LUCK, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES,
                          ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        PersistentDataContainer data = meta.getPersistentDataContainer();
        data.set(KEY_ITEM_TYPE, PersistentDataType.STRING, TYPE_HAMMER);

        item.setItemMeta(meta);
        return item;
    }

    // ──────────────────────────────────────────────────────────
    //  ИДЕНТИФИКАЦИЯ
    // ──────────────────────────────────────────────────────────

    /**
     * Проверить, является ли предмет кастомным предметом DBD.
     */
    public boolean isDBDItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer().has(KEY_ITEM_TYPE, PersistentDataType.STRING);
    }

    /**
     * Получить тип кастомного предмета DBD.
     * @return Строка типа (TYPE_TOOLKIT и т.д.) или null.
     */
    public String getItemType(ItemStack item) {
        if (!isDBDItem(item)) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        return meta.getPersistentDataContainer().get(KEY_ITEM_TYPE, PersistentDataType.STRING);
    }

    /**
     * Получить количество оставшихся использований предмета.
     * @return -1 если предмет не имеет счётчика использований.
     */
    public int getRemainingUses(ItemStack item) {
        if (!isDBDItem(item)) return -1;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return -1;
        Integer uses = meta.getPersistentDataContainer().get(KEY_ITEM_USES, PersistentDataType.INTEGER);
        return uses != null ? uses : -1;
    }

    /**
     * Уменьшить счётчик использований предмета на 1.
     * Если достигает 0 — удалить из инвентаря.
     *
     * @param player Игрок.
     * @param slot   Слот инвентаря.
     * @return true если предмет израсходован.
     */
    public boolean consumeUse(Player player, int slot) {
        ItemStack item = player.getInventory().getItem(slot);
        if (item == null) return false;

        int uses = getRemainingUses(item);
        if (uses <= 0) return false;

        if (uses == 1) {
            player.getInventory().setItem(slot, null);
            return true;
        }

        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;

        meta.getPersistentDataContainer().set(KEY_ITEM_USES, PersistentDataType.INTEGER, uses - 1);

        // Обновляем лор
        List<String> lore = meta.getLore();
        if (lore != null) {
            for (int i = 0; i < lore.size(); i++) {
                if (lore.get(i).contains("Использований:") || lore.get(i).contains("Запас:")) {
                    lore.set(i, ChatColor.GRAY + "Запас: " + ChatColor.WHITE + (uses - 1) + " шт.");
                    break;
                }
            }
            meta.setLore(lore);
        }
        item.setItemMeta(meta);
        return false;
    }
}

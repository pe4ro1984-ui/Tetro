package ru.metalpipe.dbdgenerators.managers;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import ru.metalpipe.dbdgenerators.DBDGeneratorsPlugin;
import ru.metalpipe.dbdgenerators.model.PlayerState;
import ru.metalpipe.dbdgenerators.util.MessageUtil;
import ru.metalpipe.dbdgenerators.util.ParticleUtil;

import java.util.*;

/**
 * Менеджер состояний выживших.
 *
 * Управляет:
 *  - Состояниями HEALTHY/INJURED/DOWNED/HOOKED/DEAD
 *  - Хуками (счётчик + стадии)
 *  - Механикой поднятия (revive)
 *  - Кровотечением (bleed-out timer)
 *  - Таймерами на крюке
 */
public final class PlayerStateManager {

    private final DBDGeneratorsPlugin plugin;

    /** UUID → текущее состояние */
    private final Map<UUID, PlayerState> states = new HashMap<>();

    /** UUID → количество раз на крюке */
    private final Map<UUID, Integer> hookCounts = new HashMap<>();

    /** UUID → UUID игрока, который поднимает (revive) */
    private final Map<UUID, UUID> reviveTargets = new HashMap<>();

    /** UUID → прогресс поднятия (0.0 - 1.0) */
    private final Map<UUID, Double> reviveProgress = new HashMap<>();

    /** UUID → TaskID таймера на крюке */
    private final Map<UUID, Integer> hookTimers = new HashMap<>();

    /** UUID → TaskID таймера кровотечения */
    private final Map<UUID, Integer> bleedTimers = new HashMap<>();

    public PlayerStateManager(DBDGeneratorsPlugin plugin) {
        this.plugin = plugin;
    }

    // ──────────────────────────────────────────────────────────
    //  ИНИЦИАЛИЗАЦИЯ
    // ──────────────────────────────────────────────────────────

    /**
     * Инициализировать состояние игрока для матча.
     */
    public void initPlayer(UUID uuid) {
        states.put(uuid, PlayerState.HEALTHY);
        hookCounts.put(uuid, 0);
    }

    /**
     * Сбросить состояние игрока после матча.
     */
    public void clearPlayer(UUID uuid) {
        states.remove(uuid);
        hookCounts.remove(uuid);
        cancelHookTimer(uuid);
        cancelBleedTimer(uuid);
        reviveTargets.values().remove(uuid);
        reviveProgress.remove(uuid);
    }

    // ──────────────────────────────────────────────────────────
    //  ПЕРЕХОДЫ СОСТОЯНИЙ
    // ──────────────────────────────────────────────────────────

    /**
     * Нанести урон выжившему (HEALTHY→INJURED или INJURED→DOWNED).
     *
     * @param uuid UUID выжившего.
     */
    public void hitSurvivor(UUID uuid) {
        PlayerState current = getState(uuid);
        if (current == PlayerState.HEALTHY) {
            setState(uuid, PlayerState.INJURED);
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) {
                p.sendMessage(MessageUtil.msg("survivor-states.injured"));
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_HURT, 1.0f, 0.8f);
                startBleedTimer(uuid, p);
            }
        } else if (current == PlayerState.INJURED) {
            downSurvivor(uuid);
        }
    }

    /**
     * Повалить выжившего (→ DOWNED).
     */
    public void downSurvivor(UUID uuid) {
        setState(uuid, PlayerState.DOWNED);
        cancelBleedTimer(uuid);
        Player p = Bukkit.getPlayer(uuid);
        if (p != null) {
            p.sendMessage(MessageUtil.msg("survivor-states.downed"));
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_DEATH, 0.8f, 0.9f);
            p.addPotionEffect(new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.SLOW, Integer.MAX_VALUE, 3, false, false
            ));
        }
    }

    /**
     * Повесить выжившего на крюк (→ HOOKED).
     */
    public void hookSurvivor(UUID uuid) {
        cancelBleedTimer(uuid);
        setState(uuid, PlayerState.HOOKED);
        int hooks = hookCounts.getOrDefault(uuid, 0) + 1;
        hookCounts.put(uuid, hooks);

        int maxHooks = plugin.getConfig().getInt("survivor-states.hooks-to-death", 2);

        Player p = Bukkit.getPlayer(uuid);
        if (p != null) {
            p.sendMessage(MessageUtil.msg("survivor-states.hooked")
                .replace("{hooks}", String.valueOf(hooks))
                .replace("{max_hooks}", String.valueOf(maxHooks)));
            p.playSound(p.getLocation(), Sound.BLOCK_CHAIN_PLACE, 1.0f, 0.8f);
            p.addPotionEffect(new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.SLOW, Integer.MAX_VALUE, 10, false, false
            ));
        }

        if (hooks >= maxHooks) {
            // Следующий хук — смерть, запускаем финальный таймер
            startFinalHookTimer(uuid);
        } else {
            startHookTimer(uuid);
        }
    }

    /**
     * Снять выжившего с крюка (исцеление → INJURED).
     */
    public void unhookSurvivor(UUID uuid, UUID rescuerUuid) {
        cancelHookTimer(uuid);
        setState(uuid, PlayerState.INJURED);

        Player p = Bukkit.getPlayer(uuid);
        Player rescuer = Bukkit.getPlayer(rescuerUuid);

        if (p != null) {
            p.removePotionEffect(org.bukkit.potion.PotionEffectType.SLOW);
            if (rescuer != null) {
                p.sendMessage(MessageUtil.msg("survivor-states.revived-by")
                    .replace("{player}", rescuer.getName()));
            }
        }
        if (rescuer != null) {
            rescuer.sendMessage(MessageUtil.msg("survivor-states.revived")
                .replace("{player}", p != null ? p.getName() : "?"));
        }
    }

    /**
     * Убить выжившего (→ DEAD, переводим в зрителя).
     */
    public void killSurvivor(UUID uuid) {
        cancelHookTimer(uuid);
        cancelBleedTimer(uuid);
        setState(uuid, PlayerState.DEAD);

        Player p = Bukkit.getPlayer(uuid);
        if (p != null) {
            p.sendMessage(MessageUtil.msg("survivor-states.executed"));
            p.setGameMode(GameMode.SPECTATOR);
            p.playSound(p.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.5f, 1.2f);
        }

        // Учёт статистики
        plugin.getStatisticsManager().incrementDeaths(uuid);

        // Уведомить матч-менеджер о гибели
        plugin.getMatchManager().onSurvivorDied(uuid);
    }

    // ──────────────────────────────────────────────────────────
    //  МЕХАНИКА ПОДНЯТИЯ (REVIVE)
    // ──────────────────────────────────────────────────────────

    /**
     * Начать поднятие поваленного выжившего.
     *
     * @param reviver UUID поднимающего.
     * @param target  UUID поваленного.
     */
    public void startRevive(UUID reviver, UUID target) {
        if (getState(target) != PlayerState.DOWNED) return;
        reviveTargets.put(reviver, target);
        reviveProgress.put(reviver, 0.0);

        Player reviverPlayer = Bukkit.getPlayer(reviver);
        if (reviverPlayer != null) {
            reviverPlayer.sendMessage(MessageUtil.msg("survivor-states.reviving")
                .replace("{player}", Bukkit.getOfflinePlayer(target).getName()));
        }
    }

    /**
     * Тикать прогресс поднятия (вызывается из MatchTask).
     *
     * @param reviver UUID поднимающего.
     * @param delta   Прогресс за тик (0.0 - 1.0).
     * @return true если поднятие завершено.
     */
    public boolean tickRevive(UUID reviver, double delta) {
        UUID target = reviveTargets.get(reviver);
        if (target == null) return false;

        double progress = reviveProgress.getOrDefault(reviver, 0.0) + delta;
        reviveProgress.put(reviver, progress);

        if (progress >= 1.0) {
            reviveTargets.remove(reviver);
            reviveProgress.remove(reviver);

            // Поднять и восстановить INJURED состояние
            Player p = Bukkit.getPlayer(target);
            if (p != null) p.removePotionEffect(org.bukkit.potion.PotionEffectType.SLOW);
            unhookSurvivor(target, reviver);
            setState(target, PlayerState.INJURED);
            return true;
        }
        return false;
    }

    /**
     * Прервать поднятие (игрок отошёл).
     */
    public void cancelRevive(UUID reviver) {
        reviveTargets.remove(reviver);
        reviveProgress.remove(reviver);
    }

    // ──────────────────────────────────────────────────────────
    //  ТАЙМЕРЫ
    // ──────────────────────────────────────────────────────────

    private void startHookTimer(UUID uuid) {
        int duration = plugin.getConfig().getInt("survivor-states.hook-stage-duration", 60);
        int taskId = new BukkitRunnable() {
            @Override
            public void run() {
                if (getState(uuid) == PlayerState.HOOKED) {
                    // После времени на крюке — смерть
                    killSurvivor(uuid);
                }
            }
        }.runTaskLater(plugin, duration * 20L).getTaskId();
        hookTimers.put(uuid, taskId);
    }

    private void startFinalHookTimer(UUID uuid) {
        int taskId = new BukkitRunnable() {
            @Override
            public void run() {
                if (getState(uuid) == PlayerState.HOOKED) {
                    killSurvivor(uuid);
                }
            }
        }.runTaskLater(plugin, 30 * 20L).getTaskId(); // 30 сек на финальном крюке
        hookTimers.put(uuid, taskId);
    }

    private void startBleedTimer(UUID uuid, Player player) {
        int bleedTime = plugin.getConfig().getInt("survivor-states.bleed-out-time", 120);
        if (bleedTime <= 0) return;

        int taskId = new BukkitRunnable() {
            @Override
            public void run() {
                if (getState(uuid) == PlayerState.INJURED) {
                    downSurvivor(uuid);
                }
            }
        }.runTaskLater(plugin, bleedTime * 20L).getTaskId();
        bleedTimers.put(uuid, taskId);
    }

    private void cancelHookTimer(UUID uuid) {
        Integer taskId = hookTimers.remove(uuid);
        if (taskId != null) Bukkit.getScheduler().cancelTask(taskId);
    }

    private void cancelBleedTimer(UUID uuid) {
        Integer taskId = bleedTimers.remove(uuid);
        if (taskId != null) Bukkit.getScheduler().cancelTask(taskId);
    }

    // ──────────────────────────────────────────────────────────
    //  ГЕТТЕРЫ / СЕТТЕРЫ
    // ──────────────────────────────────────────────────────────

    public PlayerState getState(UUID uuid) {
        return states.getOrDefault(uuid, PlayerState.HEALTHY);
    }

    public void setState(UUID uuid, PlayerState state) {
        states.put(uuid, state);
    }

    public boolean isReviving(UUID uuid) {
        return reviveTargets.containsKey(uuid);
    }

    public UUID getReviveTarget(UUID uuid) {
        return reviveTargets.get(uuid);
    }

    public double getReviveProgress(UUID uuid) {
        return reviveProgress.getOrDefault(uuid, 0.0);
    }

    public int getHookCount(UUID uuid) {
        return hookCounts.getOrDefault(uuid, 0);
    }
}

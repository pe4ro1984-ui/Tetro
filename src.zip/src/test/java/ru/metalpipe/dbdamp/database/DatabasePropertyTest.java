package ru.metalpipe.dbdamp.database;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Property test for database operation consistency.
 * Validates Property 4: Database Operation Consistency
 * Validates: Requirements 15.5
 */
public class DatabasePropertyTest {
    
    private Path tempDir;
    private TestDatabaseManager dbManager;
    private Logger logger;
    
    @BeforeEach
    public void setUp() throws Exception {
        // Create temporary directory for test database
        tempDir = Files.createTempDirectory("dbdamp-db-test");
        
        // Create test logger
        logger = Logger.getLogger("TestLogger");
        
        // Create test database configuration
        ru.metalpipe.dbdamp.config.DatabaseConfig dbConfig = new ru.metalpipe.dbdamp.config.DatabaseConfig();
        dbConfig.setType(ru.metalpipe.dbdamp.config.DatabaseConfig.DatabaseType.SQLITE);
        dbConfig.setSqlitePath(tempDir.resolve("test.db").toString());
        
        // Create database manager
        dbManager = new TestDatabaseManager(logger, dbConfig);
        dbManager.initialize();
        
        // Create test table
        createTestTable();
    }
    
    @AfterEach
    public void tearDown() throws Exception {
        if (dbManager != null) {
            dbManager.shutdown();
        }
        
        // Clean up temporary directory
        deleteDirectory(tempDir.toFile());
    }
    
    @Test
    public void testReadWriteConsistency() throws Exception {
        // Test Property 4: Database Operation Consistency
        // For any database operation sequence, reading data, writing modified data, 
        // then reading again SHALL return the written data (read-your-writes consistency).
        
        System.out.println("Testing read-write consistency property...");
        
        // Test 1: Simple insert and read
        String testId = UUID.randomUUID().toString();
        String testName = "Test Player";
        int testLevel = 42;
        
        // Write data
        String insertSql = "INSERT INTO test_players (id, name, level) VALUES (?, ?, ?)";
        dbManager.update(insertSql, testId, testName, testLevel);
        
        // Read data immediately
        String selectSql = "SELECT name, level FROM test_players WHERE id = ?";
        PlayerData readData = dbManager.query(selectSql, this::mapPlayerData, testId);
        
        assertNotNull(readData, "Read data should not be null");
        assertEquals(testName, readData.name, "Name should match");
        assertEquals(testLevel, readData.level, "Level should match");
        
        System.out.println("Test 1 passed: Simple insert and read consistency");
        
        // Test 2: Update and read
        String updatedName = "Updated Player";
        int updatedLevel = 99;
        
        // Update data
        String updateSql = "UPDATE test_players SET name = ?, level = ? WHERE id = ?";
        dbManager.update(updateSql, updatedName, updatedLevel, testId);
        
        // Read updated data
        PlayerData updatedData = dbManager.query(selectSql, this::mapPlayerData, testId);
        
        assertNotNull(updatedData, "Updated data should not be null");
        assertEquals(updatedName, updatedData.name, "Updated name should match");
        assertEquals(updatedLevel, updatedData.level, "Updated level should match");
        
        System.out.println("Test 2 passed: Update and read consistency");
        
        // Test 3: Transaction consistency
        String transactionId = UUID.randomUUID().toString();
        
        dbManager.executeTransaction(conn -> {
            try (var stmt = conn.prepareStatement("INSERT INTO test_players (id, name, level) VALUES (?, ?, ?)")) {
                stmt.setString(1, transactionId);
                stmt.setString(2, "Transaction Test");
                stmt.setInt(3, 100);
                stmt.executeUpdate();
            }
        });
        
        // Read after transaction commit
        PlayerData transactionData = dbManager.query(selectSql, this::mapPlayerData, transactionId);
        
        assertNotNull(transactionData, "Transaction data should not be null");
        assertEquals("Transaction Test", transactionData.name, "Transaction name should match");
        assertEquals(100, transactionData.level, "Transaction level should match");
        
        System.out.println("Test 3 passed: Transaction consistency");
        
        // Test 4: Batch operation consistency
        List<String> batchIds = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            batchIds.add(UUID.randomUUID().toString());
        }
        
        Object[][] batchParams = new Object[batchIds.size()][3];
        for (int i = 0; i < batchIds.size(); i++) {
            batchParams[i] = new Object[]{batchIds.get(i), "Batch Player " + i, i * 10};
        }
        
        String batchSql = "INSERT INTO test_players (id, name, level) VALUES (?, ?, ?)";
        int[] batchResults = dbManager.batchUpdate(batchSql, batchParams);
        
        assertEquals(batchIds.size(), batchResults.length, "Batch results length should match");
        for (int result : batchResults) {
            assertEquals(1, result, "Each batch insert should affect 1 row");
        }
        
        // Verify all batch inserts
        for (int i = 0; i < batchIds.size(); i++) {
            PlayerData batchData = dbManager.query(selectSql, this::mapPlayerData, batchIds.get(i));
            assertNotNull(batchData, "Batch data " + i + " should not be null");
            assertEquals("Batch Player " + i, batchData.name, "Batch name " + i + " should match");
            assertEquals(i * 10, batchData.level, "Batch level " + i + " should match");
        }
        
        System.out.println("Test 4 passed: Batch operation consistency");
        
        // Test 5: Concurrent operations (simulated)
        String concurrentId = UUID.randomUUID().toString();
        
        // Write in one "session"
        dbManager.update(insertSql, concurrentId, "Concurrent Test", 50);
        
        // Simulate concurrent read in another "session" (same connection pool)
        PlayerData concurrentData = dbManager.query(selectSql, this::mapPlayerData, concurrentId);
        
        assertNotNull(concurrentData, "Concurrent data should not be null");
        assertEquals("Concurrent Test", concurrentData.name, "Concurrent name should match");
        assertEquals(50, concurrentData.level, "Concurrent level should match");
        
        System.out.println("Test 5 passed: Concurrent operation consistency");
        
        System.out.println("All read-write consistency tests passed!");
    }
    
    @Test
    public void testTransactionRollback() throws Exception {
        // Test that failed transactions don't persist data
        System.out.println("Testing transaction rollback...");
        
        String rollbackId = UUID.randomUUID().toString();
        
        try {
            dbManager.executeTransaction(conn -> {
                // Insert data
                try (var stmt = conn.prepareStatement("INSERT INTO test_players (id, name, level) VALUES (?, ?, ?)")) {
                    stmt.setString(1, rollbackId);
                    stmt.setString(2, "Should Rollback");
                    stmt.setInt(3, 999);
                    stmt.executeUpdate();
                }
                
                // Simulate an error to trigger rollback
                throw new SQLException("Simulated transaction failure");
            });
            
            fail("Transaction should have thrown an exception");
            
        } catch (DatabaseManager.DatabaseException e) {
            // Expected - transaction should roll back
        }
        
        // Verify data was not persisted
        String selectSql = "SELECT COUNT(*) as count FROM test_players WHERE id = ?";
        Integer count = dbManager.query(selectSql, rs -> {
            if (rs.next()) {
                return rs.getInt("count");
            }
            return 0;
        }, rollbackId);
        
        assertEquals(0, count, "Data should not exist after transaction rollback");
        
        System.out.println("Transaction rollback test passed!");
    }
    
    @Test
    public void testSchemaVersionPersistence() throws Exception {
        // Test that schema version is properly tracked
        System.out.println("Testing schema version persistence...");
        
        DatabaseManager.SchemaVersion initialVersion = dbManager.getCurrentVersion();
        assertNotNull(initialVersion, "Initial version should not be null");
        
        // Register a test migration
        DatabaseManager.SchemaVersion newVersion = new DatabaseManager.SchemaVersion(1, 0, 0);
        HikariDatabaseManager.Migration migration = HikariDatabaseManager.Migration.builder(newVersion, "Test Migration")
            .addSql("CREATE TABLE IF NOT EXISTS test_migration (id TEXT PRIMARY KEY, data TEXT)")
            .build();
        
        dbManager.registerMigration(migration);
        
        // Apply migration
        dbManager.migrate(initialVersion, newVersion);
        
        // Verify new version is recorded
        DatabaseManager.SchemaVersion currentVersion = dbManager.getCurrentVersion();
        assertEquals(newVersion, currentVersion, "Current version should be updated");
        
        // Verify migration table was created
        String checkTableSql = "SELECT name FROM sqlite_master WHERE type='table' AND name='test_migration'";
        String tableName = dbManager.query(checkTableSql, rs -> {
            if (rs.next()) {
                return rs.getString("name");
            }
            return null;
        });
        
        assertEquals("test_migration", tableName, "Migration table should exist");
        
        System.out.println("Schema version persistence test passed!");
    }
    
    @Test
    public void testConnectionPooling() throws Exception {
        // Test that connection pooling works correctly
        System.out.println("Testing connection pooling...");
        
        DatabaseManager.DatabaseStats initialStats = dbManager.getStats();
        assertNotNull(initialStats, "Initial stats should not be null");
        
        // Perform multiple operations to exercise connection pool
        List<Thread> threads = new ArrayList<>();
        int threadCount = 10;
        int operationsPerThread = 5;
        
        for (int i = 0; i < threadCount; i++) {
            final int threadId = i;
            Thread thread = new Thread(() -> {
                try {
                    for (int j = 0; j < operationsPerThread; j++) {
                        String testId = UUID.randomUUID().toString();
                        dbManager.update(
                            "INSERT INTO test_players (id, name, level) VALUES (?, ?, ?)",
                            testId, "Thread " + threadId + " Op " + j, threadId * 100 + j
                        );
                        
                        // Small delay to simulate real workload
                        Thread.sleep(10);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            threads.add(thread);
            thread.start();
        }
        
        // Wait for all threads to complete
        for (Thread thread : threads) {
            thread.join();
        }
        
        // Verify all operations succeeded
        String countSql = "SELECT COUNT(*) as count FROM test_players WHERE name LIKE 'Thread %'";
        Integer totalCount = dbManager.query(countSql, rs -> {
            if (rs.next()) {
                return rs.getInt("count");
            }
            return 0;
        });
        
        int expectedCount = threadCount * operationsPerThread;
        assertEquals(expectedCount, totalCount, "All thread operations should be persisted");
        
        // Check connection pool stats
        DatabaseManager.DatabaseStats finalStats = dbManager.getStats();
        assertTrue(finalStats.getQueryCount() > initialStats.getQueryCount(), "Query count should increase");
        assertTrue(finalStats.getUpdateCount() > initialStats.getUpdateCount(), "Update count should increase");
        
        System.out.println("Connection pooling test passed! Total operations: " + totalCount);
    }
    
    @Test
    public void testErrorHandlingAndRetry() throws Exception {
        // Test error handling and retry logic
        System.out.println("Testing error handling and retry...");
        
        // Test 1: Invalid SQL should throw exception
        try {
            dbManager.update("INVALID SQL STATEMENT");
            fail("Invalid SQL should throw exception");
        } catch (DatabaseManager.DatabaseException e) {
            // Expected
            assertTrue(e.getMessage().contains("Invalid SQL"), "Error message should indicate invalid SQL");
        }
        
        // Test 2: Invalid parameters should throw exception
        try {
            dbManager.update("INSERT INTO test_players (id, name, level) VALUES (?, ?, ?)", 
                           "test-id", "test-name" /* missing level parameter */);
            fail("Missing parameters should throw exception");
        } catch (DatabaseManager.DatabaseException e) {
            // Expected
            assertTrue(e.getMessage().contains("failed"), "Error message should indicate failure");
        }
        
        // Test 3: Query with no results should return null/default
        String nonExistentId = UUID.randomUUID().toString();
        PlayerData nonExistentData = dbManager.query(
            "SELECT name, level FROM test_players WHERE id = ?",
            this::mapPlayerData,
            nonExistentId
        );
        
        assertNull(nonExistentData, "Query for non-existent data should return null");
        
        System.out.println("Error handling and retry tests passed!");
    }
    
    // Helper methods
    
    private void createTestTable() throws DatabaseManager.DatabaseException {
        String createTableSql = """
            CREATE TABLE IF NOT EXISTS test_players (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                level INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """;
        
        dbManager.update(createTableSql);
    }
    
    private PlayerData mapPlayerData(ResultSet rs) throws SQLException {
        if (rs.next()) {
            return new PlayerData(
                rs.getString("name"),
                rs.getInt("level")
            );
        }
        return null;
    }
    
    private void deleteDirectory(File dir) {
        if (dir.exists()) {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        deleteDirectory(file);
                    } else {
                        file.delete();
                    }
                }
            }
            dir.delete();
        }
    }
    
    // Test data class
    private static class PlayerData {
        final String name;
        final int level;
        
        PlayerData(String name, int level) {
            this.name = name;
            this.level = level;
        }
    }
    
    // Test implementation that extends HikariDatabaseManager for testing
    private static class TestDatabaseManager extends HikariDatabaseManager {
        public TestDatabaseManager(Logger logger, ru.metalpipe.dbdamp.config.DatabaseConfig dbConfig) {
            super(logger, dbConfig);
        }
        
        // Expose protected methods for testing
        public void registerMigration(Migration migration) {
            super.registerMigration(migration);
        }
    }
}
package ru.metalpipe.dbdamp.gameplay.model;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Property test for role assignment balance (Task 5.4).
 * Validates: Requirements 1.1, 5.4
 */
public class RoleAssignmentPropertyTest {
    
    /**
     * Property 1: Role assignment is balanced.
     * In any match, there should be exactly 1 killer and 1-4 survivors.
     */
    @Test
    void property1_roleBalance() {
        // Test with different player counts
        for (int totalPlayers = 2; totalPlayers <= 8; totalPlayers++) {
            Match match = createTestMatch();
            
            // Add players
            for (int i = 0; i < totalPlayers; i++) {
                UUID playerId = UUID.randomUUID();
                match.addPlayer(playerId, "Player" + i);
            }
            
            // Assign roles
            match.assignRoles();
            
            // Verify exactly 1 killer
            int killerCount = 0;
            int survivorCount = 0;
            
            for (Map.Entry<UUID, PlayerRole> entry : match.getPlayerRoles().entrySet()) {
                if (entry.getValue() == PlayerRole.KILLER) {
                    killerCount++;
                } else if (entry.getValue() == PlayerRole.SURVIVOR) {
                    survivorCount++;
                }
            }
            
            assertEquals(1, killerCount, 
                "Should have exactly 1 killer for " + totalPlayers + " players");
            assertEquals(totalPlayers - 1, survivorCount,
                "Should have " + (totalPlayers - 1) + " survivors for " + totalPlayers + " players");
            
            // Verify all players have roles
            assertEquals(totalPlayers, match.getPlayerRoles().size(),
                "All players should have assigned roles");
        }
    }
    
    /**
     * Property 2: Role assignment is deterministic for same input.
     * Given the same players and random seed, role assignment should be the same.
     */
    @Test
    void property2_deterministicRoleAssignment() {
        // Create list of player IDs
        List<UUID> playerIds = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            playerIds.add(UUID.randomUUID());
        }
        
        // Create two matches with same players
        Match match1 = createTestMatch();
        Match match2 = createTestMatch();
        
        for (UUID playerId : playerIds) {
            match1.addPlayer(playerId, "Player");
            match2.addPlayer(playerId, "Player");
        }
        
        // Set same random seed for both matches
        long seed = System.currentTimeMillis();
        match1.setRandomSeed(seed);
        match2.setRandomSeed(seed);
        
        // Assign roles
        match1.assignRoles();
        match2.assignRoles();
        
        // Verify same role assignment
        for (UUID playerId : playerIds) {
            PlayerRole role1 = match1.getPlayerRole(playerId);
            PlayerRole role2 = match2.getPlayerRole(playerId);
            
            assertEquals(role1, role2, 
                "Player " + playerId + " should have same role in both matches");
        }
        
        // Verify same killer assignment
        UUID killer1 = match1.getKillerId();
        UUID killer2 = match2.getKillerId();
        
        assertEquals(killer1, killer2, "Same player should be killer in both matches");
    }
    
    /**
     * Property 3: Killer assignment is fair over multiple matches.
     * Over many matches, each player should have similar chance to be killer.
     */
    @ParameterizedTest
    @ValueSource(ints = {10, 20, 50})
    void property3_fairKillerAssignment(int matchCount) {
        // Create 4 players
        List<UUID> playerIds = Arrays.asList(
            UUID.randomUUID(),
            UUID.randomUUID(),
            UUID.randomUUID(),
            UUID.randomUUID()
        );
        
        Map<UUID, Integer> killerCounts = new HashMap<>();
        for (UUID playerId : playerIds) {
            killerCounts.put(playerId, 0);
        }
        
        // Run multiple matches
        for (int i = 0; i < matchCount; i++) {
            Match match = createTestMatch();
            
            for (UUID playerId : playerIds) {
                match.addPlayer(playerId, "Player");
            }
            
            // Use different seed for each match
            match.setRandomSeed(System.nanoTime() + i);
            match.assignRoles();
            
            UUID killerId = match.getKillerId();
            killerCounts.put(killerId, killerCounts.get(killerId) + 1);
        }
        
        // Calculate expected and actual distribution
        double expectedPercentage = 1.0 / playerIds.size(); // 25% for 4 players
        double tolerance = 0.15; // 15% tolerance
        
        for (UUID playerId : playerIds) {
            double actualPercentage = (double) killerCounts.get(playerId) / matchCount;
            double difference = Math.abs(actualPercentage - expectedPercentage);
            
            assertTrue(difference <= tolerance,
                String.format("Player %s killer percentage %.2f should be close to expected %.2f (diff: %.2f)",
                    playerId.toString().substring(0, 8),
                    actualPercentage,
                    expectedPercentage,
                    difference));
        }
        
        // Verify total killer assignments equals match count
        int totalKillerAssignments = killerCounts.values().stream().mapToInt(Integer::intValue).sum();
        assertEquals(matchCount, totalKillerAssignments,
            "Total killer assignments should equal match count");
    }
    
    /**
     * Property 4: Role assignment respects player preferences when possible.
     * Players with role preferences should have higher chance to get preferred role.
     */
    @Test
    void property4_rolePreferences() {
        // Create players with preferences
        Map<UUID, PlayerRole> preferences = new HashMap<>();
        List<UUID> playerIds = new ArrayList<>();
        
        for (int i = 0; i < 4; i++) {
            UUID playerId = UUID.randomUUID();
            playerIds.add(playerId);
            
            // First player prefers killer, others prefer survivor
            if (i == 0) {
                preferences.put(playerId, PlayerRole.KILLER);
            } else {
                preferences.put(playerId, PlayerRole.SURVIVOR);
            }
        }
        
        int matchesWithPreferredRole = 0;
        int totalMatches = 100;
        
        for (int i = 0; i < totalMatches; i++) {
            Match match = createTestMatch();
            
            for (UUID playerId : playerIds) {
                match.addPlayer(playerId, "Player");
                if (preferences.containsKey(playerId)) {
                    match.setPlayerPreference(playerId, preferences.get(playerId));
                }
            }
            
            match.setRandomSeed(System.nanoTime() + i);
            match.assignRoles();
            
            // Check if players got their preferred roles
            boolean allPreferencesMet = true;
            for (UUID playerId : playerIds) {
                PlayerRole preferred = preferences.get(playerId);
                PlayerRole assigned = match.getPlayerRole(playerId);
                
                if (preferred != null && preferred != assigned) {
                    allPreferencesMet = false;
                    break;
                }
            }
            
            if (allPreferencesMet) {
                matchesWithPreferredRole++;
            }
        }
        
        // With preferences, should have higher chance of getting preferred roles
        double preferredMatchRate = (double) matchesWithPreferredRole / totalMatches;
        assertTrue(preferredMatchRate > 0.5,
            String.format("With role preferences, should have >50%% matches with preferred roles (actual: %.1f%%)",
                preferredMatchRate * 100));
    }
    
    /**
     * Property 5: Role assignment works with minimum and maximum player counts.
     */
    @ParameterizedTest
    @ValueSource(ints = {2, 3, 4, 5})
    void property5_variousPlayerCounts(int playerCount) {
        Match match = createTestMatch();
        
        // Add players
        for (int i = 0; i < playerCount; i++) {
            match.addPlayer(UUID.randomUUID(), "Player" + i);
        }
        
        // Assign roles
        match.assignRoles();
        
        // Verify roles
        int killerCount = 0;
        int survivorCount = 0;
        
        for (PlayerRole role : match.getPlayerRoles().values()) {
            if (role == PlayerRole.KILLER) {
                killerCount++;
            } else if (role == PlayerRole.SURVIVOR) {
                survivorCount++;
            }
        }
        
        assertEquals(1, killerCount, "Should have exactly 1 killer");
        assertEquals(playerCount - 1, survivorCount, "Should have " + (playerCount - 1) + " survivors");
        
        // Verify match can start with this configuration
        assertTrue(match.canStart(), "Match should be able to start with " + playerCount + " players");
    }
    
    /**
     * Property 6: Role reassignment maintains balance.
     * When roles are reassigned, balance should be maintained.
     */
    @Test
    void property6_roleReassignment() {
        Match match = createTestMatch();
        
        // Add 5 players
        List<UUID> playerIds = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            UUID playerId = UUID.randomUUID();
            playerIds.add(playerId);
            match.addPlayer(playerId, "Player" + i);
        }
        
        // Initial role assignment
        match.assignRoles();
        UUID initialKiller = match.getKillerId();
        
        // Reassign roles
        match.reassignRoles();
        UUID newKiller = match.getKillerId();
        
        // Verify still exactly 1 killer
        int killerCount = 0;
        for (PlayerRole role : match.getPlayerRoles().values()) {
            if (role == PlayerRole.KILLER) {
                killerCount++;
            }
        }
        
        assertEquals(1, killerCount, "Should still have exactly 1 killer after reassignment");
        
        // Killer should usually change (but could randomly be same)
        // Just verify the new killer is a valid player
        assertTrue(playerIds.contains(newKiller), "New killer should be one of the players");
        
        // Verify all players still have roles
        assertEquals(5, match.getPlayerRoles().size(), "All players should still have roles");
    }
    
    /**
     * Property 7: Player joining/leaving maintains role balance.
     * When players join or leave, roles should be rebalanced if needed.
     */
    @Test
    void property7_dynamicPlayerChanges() {
        Match match = createTestMatch();
        
        // Start with 3 players
        UUID player1 = UUID.randomUUID();
        UUID player2 = UUID.randomUUID();
        UUID player3 = UUID.randomUUID();
        
        match.addPlayer(player1, "Player1");
        match.addPlayer(player2, "Player2");
        match.addPlayer(player3, "Player3");
        
        match.assignRoles();
        UUID initialKiller = match.getKillerId();
        
        // Add 2 more players
        UUID player4 = UUID.randomUUID();
        UUID player5 = UUID.randomUUID();
        
        match.addPlayer(player4, "Player4");
        match.addPlayer(player5, "Player5");
        
        // Rebalance roles
        match.rebalanceRoles();
        
        // Verify still exactly 1 killer
        int killerCount = 0;
        int survivorCount = 0;
        
        for (PlayerRole role : match.getPlayerRoles().values()) {
            if (role == PlayerRole.KILLER) {
                killerCount++;
            } else if (role == PlayerRole.SURVIVOR) {
                survivorCount++;
            }
        }
        
        assertEquals(1, killerCount, "Should have exactly 1 killer after adding players");
        assertEquals(4, survivorCount, "Should have 4 survivors after adding players");
        
        // Remove a player (could be killer or survivor)
        match.removePlayer(player3);
        
        // Rebalance again
        match.rebalanceRoles();
        
        // Verify still exactly 1 killer
        killerCount = 0;
        survivorCount = 0;
        
        for (PlayerRole role : match.getPlayerRoles().values()) {
            if (role == PlayerRole.KILLER) {
                killerCount++;
            } else if (role == PlayerRole.SURVIVOR) {
                survivorCount++;
            }
        }
        
        assertEquals(1, killerCount, "Should have exactly 1 killer after removing player");
        assertEquals(3, survivorCount, "Should have 3 survivors after removing player");
    }
    
    /**
     * Property 8: Role assignment with custom game modes.
     * Different game modes may have different role requirements.
     */
    @Test
    void property8_gameModeVariations() {
        // Test PUBLIC mode (default: 1 killer, 1-4 survivors)
        Match publicMatch = createTestMatch();
        publicMatch.setGameMode(GameMode.PUBLIC);
        
        for (int i = 0; i < 5; i++) {
            publicMatch.addPlayer(UUID.randomUUID(), "Player");
        }
        
        publicMatch.assignRoles();
        assertEquals(1, countRoles(publicMatch, PlayerRole.KILLER),
            "PUBLIC mode should have 1 killer");
        
        // Test RANKED mode (same as public)
        Match rankedMatch = createTestMatch();
        rankedMatch.setGameMode(GameMode.RANKED);
        
        for (int i = 0; i = 4; i++) {
            rankedMatch.addPlayer(UUID.randomUUID(), "Player");
        }
        
        rankedMatch.assignRoles();
        assertEquals(1, countRoles(rankedMatch, PlayerRole.KILLER),
            "RANKED mode should have 1 killer");
        
        // Test CUSTOM mode (could have custom rules)
        Match customMatch = createTestMatch();
        customMatch.setGameMode(GameMode.CUSTOM);
        
        // Custom mode with 2 killers (if supported)
        // Note: This would require custom match settings
        for (int i = 0; i < 6; i++) {
            customMatch.addPlayer(UUID.randomUUID(), "Player");
        }
        
        customMatch.assignRoles();
        // Custom mode should still have at least 1 killer
        assertTrue(countRoles(customMatch, PlayerRole.KILLER) >= 1,
            "CUSTOM mode should have at least 1 killer");
    }
    
    /**
     * Property 9: Role assignment consistency across match restarts.
     * If match is restarted, role assignment should be consistent or re-randomized based on settings.
     */
    @Test
    void property9_matchRestartConsistency() {
        List<UUID> playerIds = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            playerIds.add(UUID.randomUUID());
        }
        
        // First match
        Match match1 = createTestMatch();
        for (UUID playerId : playerIds) {
            match1.addPlayer(playerId, "Player");
        }
        
        long seed = 123456789L;
        match1.setRandomSeed(seed);
        match1.assignRoles();
        
        Map<UUID, PlayerRole> roles1 = new HashMap<>(match1.getPlayerRoles());
        
        // Simulate match end and restart
        match1.reset();
        
        // Second match with same players and seed
        Match match2 = createTestMatch();
        for (UUID playerId : playerIds) {
            match2.addPlayer(playerId, "Player");
        }
        
        match2.setRandomSeed(seed);
        match2.assignRoles();
        
        Map<UUID, PlayerRole> roles2 = new HashMap<>(match2.getPlayerRoles());
        
        // With same seed, roles should be the same
        for (UUID playerId : playerIds) {
            assertEquals(roles1.get(playerId), roles2.get(playerId),
                "Player " + playerId + " should have same role with same seed");
        }
        
        // Third match with different seed
        Match match3 = createTestMatch();
        for (UUID playerId : playerIds) {
            match3.addPlayer(playerId, "Player");
        }
        
        match3.setRandomSeed(987654321L);
        match3.assignRoles();
        
        // With different seed, roles may be different
        // Just verify balance is maintained
        assertEquals(1, countRoles(match3, PlayerRole.KILLER),
            "Should still have exactly 1 killer with different seed");
    }
    
    /**
     * Property 10: Role assignment with player skill levels.
     * When skill-based matchmaking is enabled, roles may be assigned based on skill.
     */
    @Test
    void property10_skillBasedAssignment() {
        // Create players with different skill levels
        Map<UUID, Integer> playerSkills = new HashMap<>();
        List<UUID> playerIds = new ArrayList<>();
        
        for (int i = 0; i < 5; i++) {
            UUID playerId = UUID.randomUUID();
            playerIds.add(playerId);
            playerSkills.put(playerId, i * 100); // Skill from 0 to 400
        }
        
        // Track killer assignments by skill
        Map<Integer, Integer> skillKillerCounts = new HashMap<>();
        for (int skill : playerSkills.values()) {
            skillKillerCounts.put(skill, 0);
        }
        
        int totalMatches = 100;
        
        for (int matchNum = 0; matchNum < totalMatches; matchNum++) {
            Match match = createTestMatch();
            
            for (UUID playerId : playerIds) {
                match.addPlayer(playerId, "Player");
                // In real implementation, would set player skill
            }
            
            // Enable skill-based assignment (if supported)
            // match.setSkillBasedAssignment(true);
            
            match.setRandomSeed(System.nanoTime() + matchNum);
            match.assignRoles();
            
            UUID killerId = match.getKillerId();
            int killerSkill = playerSkills.get(killerId);
            skillKillerCounts.put(killerSkill, skillKillerCounts.get(killerSkill) + 1);
        }
        
        // With skill-based assignment, higher skill players might get killer more often
        // For now, just verify all skill levels got killer at least sometimes
        for (int skill : playerSkills.values()) {
            int count = skillKillerCounts.get(skill);
            assertTrue(count > 0,
                String.format("Skill level %d should get killer role at least once (got %d times)",
                    skill, count));
        }
    }
    
    // Helper method to count roles
    private int countRoles(Match match, PlayerRole role) {
        int count = 0;
        for (PlayerRole playerRole : match.getPlayerRoles().values()) {
            if (playerRole == role) {
                count++;
            }
        }
        return count;
    }
    
    // Helper method to create a test match
    private Match createTestMatch() {
        Match match = new Match();
        match.setMatchId(UUID.randomUUID());
        match.setMatchName("Test Match");
        match.setGameMode(GameMode.PUBLIC);
        
        MatchSettings settings = new MatchSettings();
        settings.setMinPlayers(2);
        settings.setMaxPlayers(5);
        settings.setMatchDuration(900);
        match.setSettings(settings);
        
        return match;
    }
}
package ru.metalpipe.dbdamp.gameplay.model;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.time.Instant;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Property test for match state transitions (Task 5.3).
 * Validates: Requirements 1.2, 1.3, 1.4, 1.5, 1.6
 */
public class MatchStateTransitionPropertyTest {
    
    /**
     * Property 1: Match state transitions follow a deterministic finite state machine.
     * For any given current state and transition type, the next state is always the same.
     */
    @Test
    void property1_deterministicStateTransitions() {
        // Create multiple matches with same initial state
        List<Match> matches = new ArrayList<>();
        List<MatchStateTransition> transitions = new ArrayList<>();
        
        for (int i = 0; i < 10; i++) {
            Match match = createTestMatch();
            match.setStatus(MatchStatus.LOBBY);
            MatchStateTransition transition = new MatchStateTransition(match);
            matches.add(match);
            transitions.add(transition);
        }
        
        // Apply same transition to all matches
        for (MatchStateTransition transition : transitions) {
            boolean result = transition.processTransition(
                MatchStateTransition.TransitionType.MATCH_START,
                UUID.randomUUID(),
                null
            );
            assertTrue(result, "Transition should succeed from LOBBY to STARTING");
        }
        
        // All matches should be in the same state
        MatchStatus expectedStatus = matches.get(0).getStatus();
        for (Match match : matches) {
            assertEquals(expectedStatus, match.getStatus(), 
                "All matches should be in the same state after same transition");
        }
    }
    
    /**
     * Property 2: Match cannot transition from completed or cancelled states.
     * Once a match is completed or cancelled, no further transitions are allowed.
     */
    @ParameterizedTest
    @EnumSource(value = MatchStateTransition.TransitionType.class, 
                names = {"MATCH_START", "MATCH_READY", "ALL_SURVIVORS_ESCAPED", 
                        "ALL_SURVIVORS_DEAD", "TIME_EXPIRED", "MATCH_COMPLETE"})
    void property2_noTransitionsFromTerminalStates(MatchStateTransition.TransitionType transitionType) {
        // Test from COMPLETED state
        Match match1 = createTestMatch();
        match1.setStatus(MatchStatus.COMPLETED);
        MatchStateTransition transition1 = new MatchStateTransition(match1);
        
        boolean result1 = transition1.processTransition(transitionType, UUID.randomUUID(), null);
        assertFalse(result1, "Should not allow transition from COMPLETED state with type: " + transitionType);
        assertEquals(MatchStatus.COMPLETED, match1.getStatus(), 
            "Status should remain COMPLETED after failed transition");
        
        // Test from CANCELLED state
        Match match2 = createTestMatch();
        match2.setStatus(MatchStatus.CANCELLED);
        MatchStateTransition transition2 = new MatchStateTransition(match2);
        
        boolean result2 = transition2.processTransition(transitionType, UUID.randomUUID(), null);
        assertFalse(result2, "Should not allow transition from CANCELLED state with type: " + transitionType);
        assertEquals(MatchStatus.CANCELLED, match2.getStatus(), 
            "Status should remain CANCELLED after failed transition");
    }
    
    /**
     * Property 3: Match can only end when specific conditions are met.
     * Match can only transition to ending states when all survivors escaped, all dead, or time expired.
     */
    @Test
    void property3_matchEndConditions() {
        // Test 1: Cannot end match from LOBBY
        Match match1 = createTestMatch();
        match1.setStatus(MatchStatus.LOBBY);
        MatchStateTransition transition1 = new MatchStateTransition(match1);
        
        boolean result1 = transition1.processTransition(
            MatchStateTransition.TransitionType.ALL_SURVIVORS_ESCAPED,
            null,
            null
        );
        assertFalse(result1, "Should not allow match end from LOBBY state");
        assertEquals(MatchStatus.LOBBY, match1.getStatus(), "Status should remain LOBBY");
        
        // Test 2: Cannot end match from STARTING
        Match match2 = createTestMatch();
        match2.setStatus(MatchStatus.STARTING);
        MatchStateTransition transition2 = new MatchStateTransition(match2);
        
        boolean result2 = transition2.processTransition(
            MatchStateTransition.TransitionType.ALL_SURVIVORS_DEAD,
            null,
            null
        );
        assertFalse(result2, "Should not allow match end from STARTING state");
        assertEquals(MatchStatus.STARTING, match2.getStatus(), "Status should remain STARTING");
        
        // Test 3: Can end match from IN_PROGRESS with valid conditions
        // (This would require setting up match statistics to meet conditions)
        Match match3 = createTestMatch();
        match3.setStatus(MatchStatus.IN_PROGRESS);
        MatchStateTransition transition3 = new MatchStateTransition(match3);
        
        // Setup statistics to show all survivors escaped
        MatchStatistics stats = transition3.getStatistics();
        stats.setSurvivorsEscaped(4);
        stats.setSurvivorsSacrificed(0);
        stats.setSurvivorsKilled(0);
        stats.setSurvivorsDisconnected(0);
        
        boolean result3 = transition3.processTransition(
            MatchStateTransition.TransitionType.ALL_SURVIVORS_ESCAPED,
            null,
            null
        );
        assertTrue(result3, "Should allow match end when all survivors escaped");
        assertEquals(MatchStatus.ENDING_SURVIVOR_VICTORY, match3.getStatus(), 
            "Status should transition to ENDING_SURVIVOR_VICTORY");
    }
    
    /**
     * Property 4: Match timing is consistent.
     * Match duration calculation should be consistent regardless of when transitions occur.
     */
    @Test
    void property4_consistentMatchTiming() {
        Match match = createTestMatch();
        match.setStatus(MatchStatus.LOBBY);
        MatchStateTransition transition = new MatchStateTransition(match);
        
        // Record start time
        Instant startTime = Instant.now();
        
        // Start match
        boolean startResult = transition.processTransition(
            MatchStateTransition.TransitionType.MATCH_START,
            UUID.randomUUID(),
            null
        );
        assertTrue(startResult, "Should allow match start");
        
        // Small delay
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            // Ignore
        }
        
        // Ready match
        boolean readyResult = transition.processTransition(
            MatchStateTransition.TransitionType.MATCH_READY,
            UUID.randomUUID(),
            null
        );
        assertTrue(readyResult, "Should allow match ready");
        
        // Check that match start time was set
        assertNotNull(match.getStartTime(), "Match start time should be set");
        assertTrue(match.getStartTime().isAfter(startTime) || match.getStartTime().equals(startTime),
            "Match start time should be after or equal to recorded start time");
        
        // Check duration calculation
        long duration = transition.getMatchDuration();
        assertTrue(duration >= 0, "Match duration should be non-negative");
        
        // End match (simulate all survivors escaped)
        MatchStatistics stats = transition.getStatistics();
        stats.setSurvivorsEscaped(4);
        stats.setSurvivorsSacrificed(0);
        stats.setSurvivorsKilled(0);
        stats.setSurvivorsDisconnected(0);
        
        boolean endResult = transition.processTransition(
            MatchStateTransition.TransitionType.ALL_SURVIVORS_ESCAPED,
            null,
            null
        );
        assertTrue(endResult, "Should allow match end");
        
        // Complete match
        boolean completeResult = transition.processTransition(
            MatchStateTransition.TransitionType.MATCH_COMPLETE,
            null,
            null
        );
        assertTrue(completeResult, "Should allow match completion");
        
        // Check final duration
        long finalDuration = transition.getMatchDuration();
        assertTrue(finalDuration > 0, "Final match duration should be positive");
        assertTrue(finalDuration >= duration, "Final duration should be greater than or equal to intermediate duration");
    }
    
    /**
     * Property 5: Statistics are updated correctly for each transition.
     * Each valid transition should update match statistics appropriately.
     */
    @Test
    void property5_statisticsUpdateConsistency() {
        Match match = createTestMatch();
        match.setStatus(MatchStatus.IN_PROGRESS);
        MatchStateTransition transition = new MatchStateTransition(match);
        
        UUID testPlayerId = UUID.randomUUID();
        
        // Test generator completion
        int initialGenerators = transition.getStatistics().getGeneratorsCompleted();
        boolean genResult = transition.processGameEvent(
            MatchStateTransition.TransitionType.GENERATOR_COMPLETED,
            testPlayerId
        );
        assertTrue(genResult, "Should process generator completion");
        assertEquals(initialGenerators + 1, transition.getStatistics().getGeneratorsCompleted(),
            "Generator count should increment by 1");
        
        // Test hook usage
        int initialHooks = transition.getStatistics().getHooksUsed();
        boolean hookResult = transition.processGameEvent(
            MatchStateTransition.TransitionType.HOOK_USED,
            testPlayerId
        );
        assertTrue(hookResult, "Should process hook usage");
        assertEquals(initialHooks + 1, transition.getStatistics().getHooksUsed(),
            "Hook count should increment by 1");
        assertEquals(1, transition.getStatistics().getKillerHooks(),
            "Killer hook count should be 1");
        
        // Test survivor hit
        int initialHits = transition.getStatistics().getKillerHits();
        boolean hitResult = transition.processGameEvent(
            MatchStateTransition.TransitionType.SURVIVOR_HIT,
            testPlayerId
        );
        assertTrue(hitResult, "Should process survivor hit");
        assertEquals(initialHits + 1, transition.getStatistics().getKillerHits(),
            "Killer hit count should increment by 1");
        
        // Test survivor escape
        int initialEscapes = transition.getStatistics().getSurvivorsEscaped();
        boolean escapeResult = transition.processGameEvent(
            MatchStateTransition.TransitionType.SURVIVOR_ESCAPED,
            testPlayerId
        );
        assertTrue(escapeResult, "Should process survivor escape");
        assertEquals(initialEscapes + 1, transition.getStatistics().getSurvivorsEscaped(),
            "Survivor escape count should increment by 1");
        
        // Check that match events were recorded
        assertFalse(transition.getStatistics().getMatchEvents().isEmpty(),
            "Match events should not be empty");
        assertEquals(4, transition.getStatistics().getMatchEvents().size(),
            "Should have 4 match events recorded");
    }
    
    /**
     * Property 6: Emergency exit conditions are validated correctly.
     * Emergency exit can only open when exactly one survivor remains alive.
     */
    @Test
    void property6_emergencyExitConditions() {
        // Test 1: Emergency exit cannot open with multiple survivors alive
        Match match1 = createTestMatch();
        match1.setStatus(MatchStatus.IN_PROGRESS);
        MatchStateTransition transition1 = new MatchStateTransition(match1);
        
        MatchStatistics stats1 = transition1.getStatistics();
        stats1.setSurvivorsEscaped(0);
        stats1.setSurvivorsSacrificed(1);
        stats1.setSurvivorsKilled(1);
        stats1.setSurvivorsDisconnected(0);
        // 2 survivors still alive (out of 4)
        
        Map<String, Object> data1 = new HashMap<>();
        data1.put("emergencyExit", true);
        
        boolean result1 = transition1.processTransition(
            MatchStateTransition.TransitionType.EMERGENCY_EXIT_OPENED,
            null,
            data1
        );
        assertFalse(result1, "Should not allow emergency exit with 2 survivors alive");
        assertEquals(MatchStatus.IN_PROGRESS, match1.getStatus(),
            "Status should remain IN_PROGRESS");
        
        // Test 2: Emergency exit can open with exactly one survivor alive
        Match match2 = createTestMatch();
        match2.setStatus(MatchStatus.IN_PROGRESS);
        MatchStateTransition transition2 = new MatchStateTransition(match2);
        
        MatchStatistics stats2 = transition2.getStatistics();
        stats2.setSurvivorsEscaped(0);
        stats2.setSurvivorsSacrificed(2);
        stats2.setSurvivorsKilled(1);
        stats2.setSurvivorsDisconnected(0);
        // 1 survivor still alive (out of 4)
        
        Map<String, Object> data2 = new HashMap<>();
        data2.put("emergencyExit", true);
        
        boolean result2 = transition2.processTransition(
            MatchStateTransition.TransitionType.EMERGENCY_EXIT_OPENED,
            null,
            data2
        );
        assertTrue(result2, "Should allow emergency exit with 1 survivor alive");
        assertEquals(MatchStatus.ENDING_SURVIVOR_VICTORY, match2.getStatus(),
            "Status should transition to ENDING_SURVIVOR_VICTORY");
    }
    
    /**
     * Property 7: Transition history is complete and accurate.
     * All successful transitions should be recorded in history.
     */
    @Test
    void property7_completeTransitionHistory() {
        Match match = createTestMatch();
        match.setStatus(MatchStatus.LOBBY);
        MatchStateTransition transition = new MatchStateTransition(match);
        
        List<MatchStateTransition.StateTransition> history = transition.getTransitionHistory();
        assertTrue(history.isEmpty(), "History should be empty initially");
        
        // Execute series of transitions
        UUID playerId = UUID.randomUUID();
        
        // 1. Start match
        boolean result1 = transition.processTransition(
            MatchStateTransition.TransitionType.MATCH_START,
            playerId,
            null
        );
        assertTrue(result1, "Should allow match start");
        assertEquals(1, history.size(), "History should have 1 entry");
        assertEquals(MatchStatus.LOBBY, history.get(0).getFromStatus());
        assertEquals(MatchStatus.STARTING, history.get(0).getToStatus());
        
        // 2. Ready match
        boolean result2 = transition.processTransition(
            MatchStateTransition.TransitionType.MATCH_READY,
            playerId,
            null
        );
        assertTrue(result2, "Should allow match ready");
        assertEquals(2, history.size(), "History should have 2 entries");
        assertEquals(MatchStatus.STARTING, history.get(1).getFromStatus());
        assertEquals(MatchStatus.IN_PROGRESS, history.get(1).getToStatus());
        
        // 3. Game event
        boolean result3 = transition.processGameEvent(
            MatchStateTransition.TransitionType.GENERATOR_COMPLETED,
            playerId
        );
        assertTrue(result3, "Should process game event");
        assertEquals(3, history.size(), "History should have 3 entries");
        
        // 4. Failed transition (should not be recorded)
        boolean result4 = transition.processTransition(
            MatchStateTransition.TransitionType.ALL_SURVIVORS_ESCAPED,
            null,
            null
        );
        assertFalse(result4, "Should not allow premature match end");
        assertEquals(3, history.size(), "History should still have 3 entries (failed transition not recorded)");
        
        // Verify history order and consistency
        for (int i = 1; i < history.size(); i++) {
            assertTrue(history.get(i).getTimestamp().isAfter(history.get(i-1).getTimestamp()) ||
                      history.get(i).getTimestamp().equals(history.get(i-1).getTimestamp()),
                    "History entries should be in chronological order");
        }
    }
    
    /**
     * Property 8: Match state cannot skip required intermediate states.
     * Match must go through all required states in order.
     */
    @Test
    void property8_noStateSkipping() {
        // Test: Cannot go directly from LOBBY to IN_PROGRESS
        Match match = createTestMatch();
        match.setStatus(MatchStatus.LOBBY);
        MatchStateTransition transition = new MatchStateTransition(match);
        
        // Try to skip STARTING state
        boolean result = transition.processTransition(
            MatchStateTransition.TransitionType.MATCH_READY,
            UUID.randomUUID(),
            null
        );
        assertFalse(result, "Should not allow skipping STARTING state");
        assertEquals(MatchStatus.LOBBY, match.getStatus(), "Status should remain LOBBY");
        
        // Proper sequence: LOBBY -> STARTING -> IN_PROGRESS
        boolean result1 = transition.processTransition(
            MatchStateTransition.TransitionType.MATCH_START,
            UUID.randomUUID(),
            null
        );
        assertTrue(result1, "Should allow transition to STARTING");
        assertEquals(MatchStatus.STARTING, match.getStatus(), "Status should be STARTING");
        
        boolean result2 = transition.processTransition(
            MatchStateTransition.TransitionType.MATCH_READY,
            UUID.randomUUID(),
            null
        );
        assertTrue(result2, "Should allow transition to IN_PROGRESS");
        assertEquals(MatchStatus.IN_PROGRESS, match.getStatus(), "Status should be IN_PROGRESS");
    }
    
    /**
     * Property 9: Performance scores are calculated correctly.
     * Performance scores should be in range [0, 1] and reflect match outcomes.
     */
    @Test
    void property9_performanceScoreCalculation() {
        Match match = createTestMatch();
        match.setStatus(MatchStatus.IN_PROGRESS);
        MatchStateTransition transition = new MatchStateTransition(match);
        MatchStatistics stats = transition.getStatistics();
        
        // Setup a killer victory scenario
        stats.setSurvivorsEscaped(0);
        stats.setSurvivorsSacrificed(3);
        stats.setSurvivorsKilled(1);
        stats.setSurvivorsDisconnected(0);
        stats.setKillerHits(15);
        stats.setKillerHooks(8);
        stats.setKillerGeneratorsDamaged(5);
        
        // End match
        boolean result = transition.processTransition(
            MatchStateTransition.TransitionType.ALL_SURVIVORS_DEAD,
            null,
            null
        );
        assertTrue(result, "Should allow match end");
        
        // Complete match
        transition.processTransition(
            MatchStateTransition.TransitionType.MATCH_COMPLETE,
            null,
            null
        );
        
        // Calculate scores
        stats.calculatePerformanceScores();
        
        // Check score ranges
        assertTrue(stats.getKillerPerformanceScore() >= 0.0 && stats.getKillerPerformanceScore() <= 1.0,
            "Killer performance score should be in range [0, 1]");
        assertTrue(stats.getSurvivorPerformanceScore() >= 0.0 && stats.getSurvivorPerformanceScore() <= 1.0,
            "Survivor performance score should be in range [0, 1]");
        assertTrue(stats.getMatchBalanceScore() >= 0.0 && stats.getMatchBalanceScore() <= 1.0,
            "Match balance score should be in range [0, 1]");
        
        // In killer victory, killer score should be higher than survivor score
        assertTrue(stats.getKillerPerformanceScore() > stats.getSurvivorPerformanceScore(),
            "Killer score should be higher than survivor score in killer victory");
        
        // Match should be marked as stomp (unbalanced)
        assertTrue(stats.wasStompMatch(), "Match should be marked as stomp");
        assertFalse(stats.wasCloseMatch(), "Match should not be marked as close");
    }
    
    /**
     * Property 10: Match cleanup occurs after completion.
     * Match resources should be cleaned up after match completes.
     */
    @Test
    void property10_matchCleanupAfterCompletion() {
        Match match = createTestMatch();
        match.setStatus(MatchStatus.IN_PROGRESS);
        MatchStateTransition transition = new MatchStateTransition(match);
        
        // Setup match end conditions
        MatchStatistics stats = transition.getStatistics();
        stats.setSurvivorsEscaped(4);
        stats.setSurvivorsSacrificed(0);
        stats.setSurvivorsKilled(0);
        stats.setSurvivorsDisconnected(0);
        
        // End and complete match
        boolean endResult = transition.processTransition(
            MatchStateTransition.TransitionType.ALL_SURVIVORS_ESCAPED,
            null,
            null
        );
        assertTrue(endResult, "Should allow match end");
        
        boolean completeResult = transition.processTransition(
            MatchStateTransition.TransitionType.MATCH_COMPLETE,
            null,
            null
        );
        assertTrue(completeResult, "Should allow match completion");
        
        // Verify match is completed
        assertTrue(transition.isMatchCompleted(), "Match should be completed");
        assertEquals(MatchStatus.COMPLETED, match.getStatus(), "Status should be COMPLETED");
        
        // Verify statistics are finalized
        assertNotNull(stats.getMatchEndTime(), "Match end time should be set");
        assertTrue(stats.getMatchDuration() > 0, "Match duration should be positive");
        
        // Verify cleanup occurred (in real implementation, would check resource release)
        // For now, just verify match is in terminal state
        assertFalse(transition.isMatchInProgress(), "Match should not be in progress");
    }
    
    // Helper method to create a test match
    private Match createTestMatch() {
        Match match = new Match();
        match.setMatchId(UUID.randomUUID());
        match.setMatchName("Test Match");
        match.setGameMode(GameMode.PUBLIC);
        
        MatchSettings settings = new MatchSettings();
        settings.setMinPlayers(2);
        settings.setMaxPlayers(5);
        settings.setMatchDuration(900); // 15 minutes
        match.setSettings(settings);
        
        MapState mapState = new MapState();
        mapState.setMapName("Test Map");
        match.setMapState(mapState);
        
        return match;
    }
}